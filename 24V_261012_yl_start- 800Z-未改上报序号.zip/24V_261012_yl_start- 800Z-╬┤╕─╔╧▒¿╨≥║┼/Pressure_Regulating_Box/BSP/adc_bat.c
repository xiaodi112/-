#include "adc_bat.h"
#include "adc.h"

/* ADC 12位分辨率 */
#define ADC_RESOLUTION     4095.0f

/* VREFINT典型值 */
#define ADC_VREFINT        1.20f

/* 分压比 (新板 24V 母线检测, 见 adc_bat.h 电路图):
 *   V24a -- R63(1.5M,1%) --+-- R60(1K) -- AD_BAT(PC2)
 *                          |
 *                       R64(100K,1%) -- GND
 *   分压比 = (R63 + R60 + R64) / R64 = (1.5M + 1K + 100K) / 100K = 16.01
 * 注: 下臂直接到 GND (无分压开关脚), 分压常通, 静态电流 ≈ V24a/1.601MΩ ≈ 15µA。 */
#define DIVIDER_RATIO      16.01f

/* PC2: AD_BAT = ADC_CHANNEL_12 */
#define ADC_BAT_PORT       GPIOC
#define ADC_BAT_PIN        GPIO_PIN_2


void adc_bat_init(void)
{
    /* 使能时钟 */
    rcu_periph_clock_enable(RCU_GPIOC);

    /* PC2配置为模拟输入 */
    gpio_mode_set(ADC_BAT_PORT,
                  GPIO_MODE_ANALOG,
                  GPIO_PUPD_NONE,
                  ADC_BAT_PIN);

    /* ADC初始化/校准 */
    adc_svc_init();
}


float adc_bat_read_voltage(void)
{
    uint16_t adc_bat;
    uint16_t adc_vrefint;
    float v_bat;

    /* 读取 AD_BAT (PC2) */
    adc_bat = adc_svc_read_raw(ADC_CHANNEL_12);

    if(adc_bat == ADC_SVC_RAW_INVALID)
        return -1.0f;

    /* 读取内部VREFINT (按实际 VDDA 归一, 消除参考误差) */
    adc_vrefint = adc_svc_read_vrefint();

    if(adc_vrefint == ADC_SVC_RAW_INVALID ||
       adc_vrefint == 0)
        return -1.0f;

    /*
     * V24a =
     * ADC_BAT / ADC_VREFINT × VREFINT × 分压比
     */
    v_bat = ((float)adc_bat / (float)adc_vrefint)
            * ADC_VREFINT
            * DIVIDER_RATIO;

    return v_bat;
}
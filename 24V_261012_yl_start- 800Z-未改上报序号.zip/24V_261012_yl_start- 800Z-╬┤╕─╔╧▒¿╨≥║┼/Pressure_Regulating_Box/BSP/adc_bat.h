#ifndef ADC_BAT_H
#define ADC_BAT_H

#include "gd32l23x.h"

/* 电压采集: AD_BAT = PC2 (ADC_CHANNEL_12), 检测对象为 24V 母线 V24a
 * 电路 (新板): V24a -- R63(1.5M,1%) --+-- R60(1K) -- AD_BAT(PC2)
 *                                     |
 *                                  R64(100K,1%)
 *                                     |
 *                                    GND                     (C62 0.1uF 滤波)
 * 分压比 = (R63 + R60 + R64) / R64 = (1.5M + 1K + 100K) / 100K = 16.01
 *   → 满量程 ≈ 3.0V × 16.01 ≈ 48V; 分压常通, 静态电流 ≈ 24V/1.601MΩ ≈ 15µA
 * 换算按 VREFINT 归一 (见 adc_bat.c), 不依赖固定 VDDA。 */
void adc_bat_init(void);

/* 读取母线电压 (单位: V); 失败返回 -1.0f */
float adc_bat_read_voltage(void);

#endif /* ADC_BAT_H */

#ifndef __MOTOR_H
#define __MOTOR_H

#include "gd32l23x.h"
#include "app_config.h"
#include "adc.h"        /* ADC_SVC_VREF_MV (仅电流采样换算宏使用) */

/* ==================== 板级配置 (电机: BTN8982 双半桥) ====================
 *   PA6(M_IN1) → DM1 IN  ┐ 方向 = 一侧给 PWM + 另一侧低电平
 *   PA7(M_IN2) → DM2 IN  ┘ (TIMER2 CH0/CH1, 与旧板驱动方式一致)
 *   PB1(M_INH)  : 驱动使能 (高=使能) —— 操作电机前必须先使能
 *   PA8(V24_EN) : 电机 24V 电源门控 (引脚/接口在 BSP/power.h) —— 与 M_INH 配合
 *   PB12(K1-S)  : 开到位输入 (低电平有效, 板上 20K 上拉)
 *   PB14(K2-S)  : 关到位输入 (低电平有效)
 *   M_IS(电流)  : 采样网络与新板不同, 当前未实施 (见 MOTOR_CS_ENABLED) */
#define MOTOR_INH_PORT             GPIOB      /* M_INH 驱动使能 (高=使能) */
#define MOTOR_INH_PIN              GPIO_PIN_1
/* 驱动方式: 0=GPIO电平驱动(PA6/PA7); 1=PWM驱动(TIMER2 CH0/CH1, 160kHz) */
#define MOTOR_DRV_MODE             1
/* 驱动占空比 (仅 MOTOR_DRV_MODE=1 有效, 两个方向共用): 0.0~1.0。
 * BTN8982 的 IN 为 PWM 输入 → 占空比直接决定电机平均电压 (24V × 占空比):
 *   0.9 ≈ 满速; 调低 = 降速/降力矩 (启动带载能力同步下降, 一般不低于 0.5)。 */
#define MOTOR_DRIVE_DUTY           0.95f  
/* V24_EN 使能后到驱动可用的稳定时间(ms): motor 驱动前等待 */
#define MOTOR_V24_SETTLE_MS        20u

/* ==================== 阀门"到位"检测方式 (板级编译开关) ====================
 * VALVE_POS_SENSE_LIMIT = 0: 双限位开关 (新板: PB12=开到位 / PB14=关到位, 低电平有效)
 * VALVE_POS_SENSE_STALL = 1: 堵转电流   (依赖电流采样, 须 MOTOR_CS_ENABLED=1)
 * 两种方式互斥; valve.c / led.c 各有一段对应实现。 */
#define VALVE_POS_SENSE_LIMIT      0
#define VALVE_POS_SENSE_STALL      1
#define VALVE_POS_SENSE            VALVE_POS_SENSE_LIMIT

/* ---------- 限位开关引脚 (VALVE_POS_SENSE_LIMIT) ---------- */
#define MOTOR_LIMIT1_PORT          GPIOB      /* K1-S: 开阀到位 (低电平=到位) */
#define MOTOR_LIMIT1_PIN           GPIO_PIN_12
#define MOTOR_LIMIT2_PORT          GPIOB      /* K2-S: 关阀到位 (低电平=到位) */
#define MOTOR_LIMIT2_PIN           GPIO_PIN_14

/* ==================== 电机电流采样 (板级选配: 当前未实施) ====================
 * 0 = 不编译电流采样(函数与调试命令都不存在); 下面的换算宏仅为兼容既有引用保留。
 * 启用前必须:
 *   ① 确认 M_IS 采样脚 (旧板为 PB0/ADC_IN8) 与 BTN8982 kILIS;
 *   ② 按新板 IS 网络 (kILIS 比例电流 + Rnc 1K / Rn5-7 510Ω) 重算 MOTOR_CS_* 与出厂阈值;
 *   ③ 用调试命令 motor_cs_th:/motor_cs_ma: 现场标定后写入 EEPROM。 */
#define MOTOR_CS_ENABLED           0

#if (VALVE_POS_SENSE == VALVE_POS_SENSE_STALL) && !MOTOR_CS_ENABLED
#error "阀门到位用堵转电流(VALVE_POS_SENSE_STALL)必须开启电流采样: 请置 MOTOR_CS_ENABLED=1 并重算换算宏"
#endif

/* ---------- 堵转电流采样 (VALVE_POS_SENSE_STALL 使用; 换算按旧板 1Ω 分流, 待重算) ---------- */
#define MOTOR_CS_PORT              GPIOB
#define MOTOR_CS_PIN               GPIO_PIN_0
#define MOTOR_CS_ADC_CH            ADC_CHANNEL_8   /* PB0 = ADC_IN8 */
#define MOTOR_CS_R_SHUNT           1.0f            /* 采样电阻(Ω): 1Ω → 1V/A (须与下面 mΩ 宏一致) */
#define MOTOR_CS_R_MILLIOHM        1000u           /* 采样电阻(毫欧): 1000 = 1.0Ω */

/* 电流(mA) <-> ADC 原始值 换算 (12 位 ADC, 参考 ADC_SVC_VREF_MV) */
#define MOTOR_CS_MA_TO_RAW(ma)     ((uint16_t)(((uint32_t)(ma) * 4095u * MOTOR_CS_R_MILLIOHM) /      \
                                               ((uint32_t)ADC_SVC_VREF_MV * 1000u)))
#define MOTOR_CS_RAW_TO_MA(raw)    ((uint32_t)(((uint32_t)(raw) * (uint32_t)ADC_SVC_VREF_MV * 1000u) / \
                                               (4095u * MOTOR_CS_R_MILLIOHM)))

/* ---------- 堵转阈值 (编译期出厂默认 + EEPROM 运行时可覆盖) ----------
 * MOTOR_CS_TH_MA_DEFAULT: 出厂默认阈值(mA)。EEPROM 该字段从未写过(0xFFFF)时生效;
 *                         一旦用 motor_cs_th:<raw> 写过, 以 EEPROM 为准(写 0 = 关闭判定)。
 * 换算参考: 1Ω + 3.0V 基准 → raw ≈ mA × 1.365, 即 50mA ≈ raw 68。 */
#define MOTOR_CS_TH_MA_DEFAULT     50u
#define MOTOR_CS_TH_DEFAULT        MOTOR_CS_MA_TO_RAW(MOTOR_CS_TH_MA_DEFAULT)

/* 堵转判定时间参数 (阈值由 EEPROM 配置, 现场标定后生效) */
#define MOTOR_CS_BLANK_MS          300u    /* 启动屏蔽期: 避开启动浪涌误判 */
#define MOTOR_CS_SAMPLE_MS         10u     /* 电流采样周期 */
#define MOTOR_CS_CONFIRM_N         5u      /* 连续超阈次数确认到位(抗 PWM 纹波) */
#define MOTOR_CS_CAL_MAX_MS        4000u   /* 标定驱动的最长持续时间 */
/* 阈值未标定时的驱动时限: 避免无判据时电机长时间堵转发热 */
#define MOTOR_CS_UNCAL_MAX_MS      5000u

#if MOTOR_ENABLED
/* 到位检测硬件初始化 (按 VALVE_POS_SENSE 分派; 深休眠后引脚为 Analog, 动作/读取前必须调用) */
void motor_pos_init(void);

#if VALVE_POS_SENSE == VALVE_POS_SENSE_LIMIT
void motor_limit_init(void);          /* PB12/PB14: 输入+上拉 (低电平=到位) */
uint8_t motor_limit1_reached(void);   /* 开阀到位 PB12 (K1-S) */
uint8_t motor_limit2_reached(void);   /* 关阀到位 PB14 (K2-S) */
#endif

#if MOTOR_CS_ENABLED
void     motor_current_init(void);    /* PB0 配置为模拟输入 */
uint16_t motor_current_raw(void);     /* ADC 原始值; ADC_SVC_RAW_INVALID(0xFFFF)=读失败 */
uint32_t motor_current_ma(void);      /* 换算电流(mA); 0xFFFFFFFF=读失败 */
#endif

/* ==================== 电机初始化 / 驱动 ==================== */
/* enabled: 1=产品带电机, 初始化到位检测+驱动输出; 0=无电机, 跳过硬件配置 */
void motor_init(uint8_t enabled);

/* 方向驱动: V24_EN 上电 → 稳定延时 → M_INH 使能 → 对应方向 PWM */
void motor_drive_open(void);
void motor_drive_close(void);
/* 停止: PWM 归零 → M_INH 禁用 → V24_EN 断电 (阀门动作收尾/休眠前调用) */
void motor_stop(void);
#else
/* 无电机硬件: 提供空实现, 调用点无需 #if 保护 */
static inline void motor_pos_init(void)             { }
static inline void motor_init(uint8_t enabled)      { (void)enabled; }
static inline void motor_drive_open(void)           { }
static inline void motor_drive_close(void)          { }
static inline void motor_stop(void)                 { }
#if VALVE_POS_SENSE == VALVE_POS_SENSE_LIMIT
static inline void motor_limit_init(void)           { }
static inline uint8_t motor_limit1_reached(void)    { return 0; }
static inline uint8_t motor_limit2_reached(void)    { return 0; }
#endif
#if MOTOR_CS_ENABLED
static inline void motor_current_init(void)         { }
static inline uint16_t motor_current_raw(void)      { return 0xFFFFu; }
static inline uint32_t motor_current_ma(void)       { return 0xFFFFFFFFu; }
#endif
#endif /* MOTOR_ENABLED */

#endif

#include "mygpio.h"
#include "power.h"
#include "output.h"
#include "motor.h"
#include "app_config.h"   /* BLE_ENABLED: PC12 的角色(SW_BT / I2C0_SDA)由产品配置决定 */



void gpio_init(void)
{
    rcu_periph_clock_enable(RCU_GPIOA);
    rcu_periph_clock_enable(RCU_GPIOB);
    rcu_periph_clock_enable(RCU_GPIOC);
    rcu_periph_clock_enable(RCU_GPIOD);
    rcu_periph_clock_enable(RCU_GPIOF);

    /* 电源引脚 (V4G_EN/PWRKEY/BLE_EN/CH4/DTR): BSP/power.c 统一管理 */
    power_gpio_init();
    /* 蜂鸣器/LED 输出引脚: BSP/output.c 统一管理 */
    output_gpio_init();

#if MOTOR_ENABLED
    /* 到位检测引脚: 按板级方式分派 (双限位 PB12/PB14 或 堵转电流 PB0) */
    motor_pos_init();
    /* 注: 驱动使能 M_INH(PB1) 与 24V 门控 V24_EN(PA8) 的安全初态
     *     分别由 motor_init() / power_gpio_init() 建立 (均默认禁用/断电) */
#endif

    /* PA15: 保持低电平输出 (运行态/深睡态一致) */
    gpio_mode_set(GPIOA, GPIO_MODE_OUTPUT, GPIO_PUPD_NONE, GPIO_PIN_15);
    gpio_output_options_set(GPIOA, GPIO_OTYPE_PP, GPIO_OSPEED_2MHZ, GPIO_PIN_15);
    gpio_bit_reset(GPIOA, GPIO_PIN_15);
}

// ===================== PB11(Btn1) 按键唤醒 =====================
volatile uint8_t button_wakeup_flag = 0;

// 深休眠前调用: PB11输入(外部上拉, 不加内部上拉) → EXTI11下降沿 → NVIC使能
void button_exti_init(void)
{
#if BUTTON_ENABLED
    rcu_periph_clock_enable(RCU_GPIOB);
    rcu_periph_clock_enable(RCU_SYSCFG);

    // PB11(Btn1): 输入, 无内部上下拉 (空闲HIGH由板上外部上拉决定, 按下LOW)
    gpio_mode_set(BUTTON_PORT, GPIO_MODE_INPUT, GPIO_PUPD_NONE, BUTTON_PIN);

    // EXTI11 → PB11(Btn1), 下降沿触发唤醒
    syscfg_exti_line_config(BUTTON_EXTI_SOURCE, BUTTON_EXTI_SOURCE_PIN);
    exti_init(BUTTON_EXTI_LINE, EXTI_INTERRUPT, EXTI_TRIG_FALLING);
    exti_flag_clear(BUTTON_EXTI_LINE);

    // NVIC使能 EXTI10_15 中断 (GD32L23x 线10~15共用该向量)
    nvic_irq_enable(BUTTON_EXTI_IRQn, 2);

    button_wakeup_flag = 0;
#endif
}

// 唤醒后调用: 禁用EXTI11 + 清标志, 防止抖动重复触发
void button_exti_disable(void)
{
#if BUTTON_ENABLED
    exti_interrupt_disable(BUTTON_EXTI_LINE);
    exti_flag_clear(BUTTON_EXTI_LINE);
    nvic_irq_disable(BUTTON_EXTI_IRQn);
#endif
}

// 读取PB11(Btn1)电平: 1=按下(LOW), 0=松开(HIGH)
uint8_t button_is_pressed(void)
{
#if BUTTON_ENABLED
    return (gpio_input_bit_get(BUTTON_PORT, BUTTON_PIN) == RESET) ? 1 : 0;
#else
    return 0;
#endif
}

// ===================== 极低功耗休眠配置 =====================
// 将休眠期间不需要的GPIO配置为 Analog Input (不带上下拉)，彻底杜绝引脚倒灌和悬空漏电
void gpio_enter_low_power(uint8_t lpuart_enabled, uint8_t lcd_active, uint8_t bt_on)
{
    /* 1. 确保所有GPIO时钟开启以允许配置其寄存器 */
    rcu_periph_clock_enable(RCU_GPIOA);
    rcu_periph_clock_enable(RCU_GPIOB);
    rcu_periph_clock_enable(RCU_GPIOC);
    rcu_periph_clock_enable(RCU_GPIOD);
    rcu_periph_clock_enable(RCU_GPIOF);

    (void)lcd_active;   /* 本板无 LCD (LCD_ENABLED=0), 参数保留以兼容 PmSleepCfg_t */

    /* 2. GPIOA 配置
     *    保持: PA0(4G DTR, 输出电平保持) / PA1(4G RI, EXTI)
     *          PA8(V24_EN 电机24V门控, 输出低=断电)
     *          PA15(输出低, 见下)
     *    Analog: PA2/PA3(CH4 未启用) / PA4(空闲, 原 Btn1) / PA5(空闲) / PA6/PA7(电机 PWM)
     *            PA9/PA10/PA11/PA12(空闲; 本板无 3 路 LED)
     */
    uint32_t gpioa_analog_pins = GPIO_PIN_2 | GPIO_PIN_3 | GPIO_PIN_4 | GPIO_PIN_5 |
                                 GPIO_PIN_6 | GPIO_PIN_7 |
                                 GPIO_PIN_9 | GPIO_PIN_10 | GPIO_PIN_11 |
                                 GPIO_PIN_12;
    if(!lpuart_enabled)
        gpioa_analog_pins |= (GPIO_PIN_0 | GPIO_PIN_1);  /* 4G 未保持在线(模块已软关机): DTR/RI 转Analog */
    gpio_mode_set(GPIOA, GPIO_MODE_ANALOG, GPIO_PUPD_NONE, gpioa_analog_pins);

#if MOTOR_ENABLED
    /* PA8 (V24_EN): 电机 24V 断电 (输出低) */
    power_v24_set(0);
#endif

    /* PA15: 保持低电平输出 (推挽) */
    gpio_mode_set(GPIOA, GPIO_MODE_OUTPUT, GPIO_PUPD_NONE, GPIO_PIN_15);
    gpio_output_options_set(GPIOA, GPIO_OTYPE_PP, GPIO_OSPEED_2MHZ, GPIO_PIN_15);
    gpio_bit_reset(GPIOA, GPIO_PIN_15);

    /* 3. GPIOB 配置
     *    Analog: PB0(电流采样输入, 未实施) / PB2(空闲)
     *            PB6/PB7(I2C1 低压总线, 采集后已释放)
     *            PB8(I2C2 压变预留 SCL, 未使能; 蜂鸣器已挪到 PD4) / PB9(I2C2 预留 SDA)
     *            PB10/PB13/PB15(空闲)
     *    保持:   PB1(M_INH 驱动使能, 输出低=禁用)
     *            PB5(指示灯 LED1: 推挽输出高=灭; VCC->LED->2.2K->PB5, 高电平零电流)
     *            PB11(Btn1 按键唤醒: 输入, 外部上拉, 低电平=按下)
     *            PB12/PB14(限位开关 K1-S/K2-S: 输入, 外部 20K 上拉, 低电平=到位)
     */
    uint32_t gpiob_analog_pins = GPIO_PIN_0 | GPIO_PIN_2 |
                                 GPIO_PIN_6 | GPIO_PIN_7 | GPIO_PIN_8 |
                                 GPIO_PIN_9 | GPIO_PIN_10 |
                                 GPIO_PIN_13 | GPIO_PIN_15;
    if(!bt_on)
        gpiob_analog_pins |= (GPIO_PIN_3 | GPIO_PIN_4);  /* 蓝牙关闭时PB3/PB4转Analog */
#if !BUTTON_ENABLED
    gpiob_analog_pins |= BUTTON_PIN;                     /* 无按键: PB11 转Analog */
#endif
    gpio_mode_set(GPIOB, GPIO_MODE_ANALOG, GPIO_PUPD_NONE, gpiob_analog_pins);

    /* PB5 (LED1): 保持推挽输出高 = 灭 (深睡期间零电流, 睡醒后可直接点亮) */
    output_led_init();

#if MOTOR_ENABLED
    /* PB1 (M_INH): 驱动禁用 (输出低), 防止休眠期间驱动器误动作 */
    gpio_mode_set(MOTOR_INH_PORT, GPIO_MODE_OUTPUT, GPIO_PUPD_NONE, MOTOR_INH_PIN);
    gpio_output_options_set(MOTOR_INH_PORT, GPIO_OTYPE_PP, GPIO_OSPEED_2MHZ, MOTOR_INH_PIN);
    gpio_bit_reset(MOTOR_INH_PORT, MOTOR_INH_PIN);
#endif

#if VALVE_POS_SENSE == VALVE_POS_SENSE_LIMIT
    /* PB12/PB14 (限位): 保持输入, 不带内部上拉 (电平由板上 20K 上拉决定),
     * 位置随时可读 (低电平=到位) */
    gpio_mode_set(MOTOR_LIMIT1_PORT, GPIO_MODE_INPUT, GPIO_PUPD_NONE, MOTOR_LIMIT1_PIN);
    gpio_mode_set(MOTOR_LIMIT2_PORT, GPIO_MODE_INPUT, GPIO_PUPD_NONE, MOTOR_LIMIT2_PIN);
#endif

#if BUTTON_ENABLED
    /* PB11 按键唤醒: 保持输入, 不加内部上拉 (空闲HIGH由板上外部上拉决定, 按下=LOW) */
    gpio_mode_set(BUTTON_PORT, GPIO_MODE_INPUT, GPIO_PUPD_NONE, BUTTON_PIN);
#endif

    /* 4G 软开关机控制脚在 PF1 (见 GPIOF 配置); PB13(旧板 V4G_EN)已在上方 Analog 列表中释放 */

    /* 4. GPIOC 配置
     *    Analog: PC0/PC1(I2C3 压变预留, 未使能) / PC2(AD_BAT) / PC3(原传感器电源, 新板空置)
     *            PC4/PC5(调试串口) / PC6-PC9(空闲, 原 SLCD SEG) / PC11(I2C0 中压 SCL, 采集后已释放)
     *            PC13(未使用, 原 CH4 电源脚)
     *    保持:   PC10(传感器电源域, 输出低)
     *    无蓝牙: PC12 转 Analog (新板 PC12 = I2C0 中压 SDA; 仅带蓝牙产品才是 SW_BT 输出)
     *    绝不动: PC14/PC15 (LXTAL, RTC 时钟)
     */
    uint32_t gpioc_analog_pins = GPIO_PIN_0 | GPIO_PIN_1 | GPIO_PIN_2 |
                                 GPIO_PIN_3 | GPIO_PIN_4 | GPIO_PIN_5 |
                                 GPIO_PIN_6 | GPIO_PIN_7 | GPIO_PIN_8 |
                                 GPIO_PIN_9 | GPIO_PIN_11 | GPIO_PIN_13;   /* PC13: 未使用 (原 CH4 电源脚) */
#if !BLE_ENABLED
    gpioc_analog_pins |= GPIO_PIN_12;   /* 无蓝牙: PC12(I2C0 中压 SDA) 释放为 Analog */
#endif
    gpio_mode_set(GPIOC, GPIO_MODE_ANALOG, GPIO_PUPD_NONE, gpioc_analog_pins);

    power_sensor_set(0);    /* PC10: 传感器电源域断电 (I2C0~I2C3 四条总线共用) */

#if BLE_ENABLED
    /* PC12 SW_BT: 保持推挽输出(电平不变: 蓝牙开HIGH / 关LOW) */
    gpio_mode_set(PWR_BLE_PORT, GPIO_MODE_OUTPUT, GPIO_PUPD_NONE, PWR_BLE_PIN);
    gpio_output_options_set(PWR_BLE_PORT, GPIO_OTYPE_PP, GPIO_OSPEED_2MHZ, PWR_BLE_PIN);
#endif

    /* 5. GPIOD 配置
     *    PD0/PD1(I2CM EEPROM 总线, 长供电; 深睡释放为 Analog) / PD3/PD6/PD7/PD10-PD15 空闲
     *    PD5 = CH4 电源脚: 无 CH4 硬件时转 Analog, 带 CH4 时保持输出低 (见下)
     *    保持: PD4(蜂鸣器, 输出低=停响)
     *    PD8/PD9(LPUART0): LPUART启用时保留 AF
     *    PD2(BLE 连接检测): 蓝牙开启时保持 INPUT
     */
    uint32_t gpiod_analog_pins = GPIO_PIN_0 | GPIO_PIN_1 | GPIO_PIN_3 |
                                 GPIO_PIN_6 | GPIO_PIN_7 |
                                 GPIO_PIN_10 | GPIO_PIN_11 | GPIO_PIN_12 | GPIO_PIN_13 |
                                 GPIO_PIN_14 | GPIO_PIN_15;
#if !LASER_CH4_ENABLED
    gpiod_analog_pins |= GPIO_PIN_5;   /* 本板无 CH4 硬件: PD5(CH4 电源脚) 未使用 */
#endif
    if(!bt_on)
        gpiod_analog_pins |= GPIO_PIN_2;  /* BLE关闭时PD2转Analog, BLE开启时保持INPUT */
    if (!lpuart_enabled)
    {
        gpiod_analog_pins |= (GPIO_PIN_8 | GPIO_PIN_9);  /* PD8=LPUART_TX, PD9=LPUART_RX */
    }
    gpio_mode_set(GPIOD, GPIO_MODE_ANALOG, GPIO_PUPD_NONE, gpiod_analog_pins);

    /* PD4 蜂鸣器: 保持推挽输出低 (停响; 与运行期驱动方式一致) */
    gpio_mode_set(OUT_BUZZER_PORT, GPIO_MODE_OUTPUT, GPIO_PUPD_NONE, OUT_BUZZER_PIN);
    gpio_output_options_set(OUT_BUZZER_PORT, GPIO_OTYPE_PP, GPIO_OSPEED_2MHZ, OUT_BUZZER_PIN);
    gpio_bit_reset(OUT_BUZZER_PORT, OUT_BUZZER_PIN);

#if LASER_CH4_ENABLED
    /* PD5 CH4 电源: 保持输出低 (CH4 断电; 仅带 CH4 硬件的产品) */
    gpio_mode_set(PWR_CH4_PORT, GPIO_MODE_OUTPUT, GPIO_PUPD_NONE, PWR_CH4_PIN);
    gpio_output_options_set(PWR_CH4_PORT, GPIO_OTYPE_PP, GPIO_OSPEED_2MHZ, PWR_CH4_PIN);
    gpio_bit_reset(PWR_CH4_PORT, PWR_CH4_PIN);
#endif

    /* 6. GPIOF 配置
     *    PF0: 未使用 → 模拟
     *    PF1: 4G 软开关机控制 (V4G_EN → NPN → 模块 PWRKEY), 保持"释放"电平:
     *         推挽输出低 —— 不能转模拟(避免悬空被干扰), 板上 Rg2 47K 基极下拉兜底 */
    gpio_mode_set(GPIOF, GPIO_MODE_ANALOG, GPIO_PUPD_NONE, GPIO_PIN_0);
    gpio_mode_set(PWR_4G_KEY_PORT, GPIO_MODE_OUTPUT, GPIO_PUPD_NONE, PWR_4G_KEY_PIN);
    gpio_output_options_set(PWR_4G_KEY_PORT, GPIO_OTYPE_PP, GPIO_OSPEED_2MHZ, PWR_4G_KEY_PIN);
    gpio_bit_reset(PWR_4G_KEY_PORT, PWR_4G_KEY_PIN);
}

// ===================== PD2 蓝牙连接状态引脚 =====================
// BLE模块(VG6328A-MS)连接成功后输出LOW, 未连接时HIGH
void ble_link_gpio_init(void)
{
    rcu_periph_clock_enable(RCU_GPIOD);
    gpio_mode_set(GPIOD, GPIO_MODE_INPUT, GPIO_PUPD_PULLUP, GPIO_PIN_2);
}

uint8_t ble_link_is_connected(void)
{
    return (gpio_input_bit_get(GPIOD, GPIO_PIN_2) == RESET) ? 1 : 0;
}

// ===================== PD2 蓝牙连接 EXTI 唤醒 =====================
volatile uint8_t ble_connect_wakeup_flag = 0;

// BLE开启时深休眠前调用: PD2 EXTI2 下降沿唤醒
void ble_exti_init(void)
{
    rcu_periph_clock_enable(RCU_GPIOD);
    rcu_periph_clock_enable(RCU_SYSCFG);

    // PD2: 输入, 内部上拉 (空闲HIGH, 连接LOW)
    gpio_mode_set(GPIOD, GPIO_MODE_INPUT, GPIO_PUPD_PULLUP, GPIO_PIN_2);

    // EXTI2 → PD2, 下降沿触发
    syscfg_exti_line_config(EXTI_SOURCE_GPIOD, EXTI_SOURCE_PIN2);
    exti_init(EXTI_2, EXTI_INTERRUPT, EXTI_TRIG_FALLING);
    exti_flag_clear(EXTI_2);

    // GD32L23x: EXTI2独立中断
    nvic_irq_enable(EXTI2_IRQn, 2);

    ble_connect_wakeup_flag = 0;
}

void ble_exti_disable(void)
{
    exti_interrupt_disable(EXTI_2);
    exti_flag_clear(EXTI_2);
    nvic_irq_disable(EXTI2_IRQn);
}

// ===================== PA1 4G RI引脚 EXTI 唤醒 =====================
// EC800E 收到服务器下行数据时 RI 脚产生低电平脉冲(~120ms)
// PA1 下降沿中断唤醒 MCU, 与 LPUART 起始位唤醒互为冗余
volatile uint8_t ri_wakeup_flag = 0;

void ri_exti_init(void)
{
    rcu_periph_clock_enable(RCU_GPIOA);
    rcu_periph_clock_enable(RCU_SYSCFG);

    // PA1: 输入, 内部上拉 (RI空闲HIGH, 有数据时LOW)
    gpio_mode_set(GPIOA, GPIO_MODE_INPUT, GPIO_PUPD_PULLUP, GPIO_PIN_1);

    // EXTI1 → PA1, 下降沿触发
    syscfg_exti_line_config(EXTI_SOURCE_GPIOA, EXTI_SOURCE_PIN1);
    exti_init(EXTI_1, EXTI_INTERRUPT, EXTI_TRIG_FALLING);
    exti_flag_clear(EXTI_1);

    nvic_irq_enable(EXTI1_IRQn, 1);

    ri_wakeup_flag = 0;
}

void ri_exti_disable(void)
{
    exti_interrupt_disable(EXTI_1);
    exti_flag_clear(EXTI_1);
    nvic_irq_disable(EXTI1_IRQn);
}

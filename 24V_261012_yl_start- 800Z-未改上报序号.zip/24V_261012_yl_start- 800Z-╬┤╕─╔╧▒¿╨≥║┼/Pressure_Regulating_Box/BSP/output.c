#include "output.h"
#include "delay.h"      /* trea_delay_ms / swdt_feed */

/* 板级输出: 蜂鸣器 (PD4, HIGH=响) + 指示灯 LED1 (PB5, LOW=亮, 灌电流) */

void output_gpio_init(void)
{
    output_buzzer_init();
    output_led_init();
}

void output_buzzer_init(void)
{
    rcu_periph_clock_enable(RCU_GPIOD);
    gpio_mode_set(OUT_BUZZER_PORT, GPIO_MODE_OUTPUT, GPIO_PUPD_NONE, OUT_BUZZER_PIN);
    gpio_output_options_set(OUT_BUZZER_PORT, GPIO_OTYPE_PP, GPIO_OSPEED_2MHZ, OUT_BUZZER_PIN);
    gpio_bit_reset(OUT_BUZZER_PORT, OUT_BUZZER_PIN);   /* 默认关闭 */
}

void output_buzzer_set(uint8_t on)
{
    if(on) gpio_bit_set(OUT_BUZZER_PORT, OUT_BUZZER_PIN);
    else   gpio_bit_reset(OUT_BUZZER_PORT, OUT_BUZZER_PIN);
}

/* LED 初始化: 先写 ODR(灭) 再切推挽输出, 避免切换瞬间闪一下。
 * 深睡会把其它脚转 Analog, 本脚保持"输出高=灭"(VCC->LED->2.2K->PB5, 零电流)。 */
void output_led_init(void)
{
    rcu_periph_clock_enable(RCU_GPIOB);
#if OUT_LED_ACTIVE_LOW
    gpio_bit_set(OUT_LED_PORT, OUT_LED_PIN);       /* 高=灭 (先定电平) */
#else
    gpio_bit_reset(OUT_LED_PORT, OUT_LED_PIN);
#endif
    gpio_mode_set(OUT_LED_PORT, GPIO_MODE_OUTPUT, GPIO_PUPD_NONE, OUT_LED_PIN);
    gpio_output_options_set(OUT_LED_PORT, GPIO_OTYPE_PP, GPIO_OSPEED_2MHZ, OUT_LED_PIN);
}

void output_led_set(uint8_t on)
{
#if OUT_LED_ACTIVE_LOW
    if(on) gpio_bit_reset(OUT_LED_PORT, OUT_LED_PIN);   /* 低=亮 */
    else   gpio_bit_set(OUT_LED_PORT, OUT_LED_PIN);     /* 高=灭 */
#else
    if(on) gpio_bit_set(OUT_LED_PORT, OUT_LED_PIN);
    else   gpio_bit_reset(OUT_LED_PORT, OUT_LED_PIN);
#endif
}

/* 闪一次 (上电/联网提示用): 亮 ms 后灭; 期间喂狗, 供 swdt 已使能的场景使用 */
void output_led_blink(uint16_t ms)
{
    uint32_t t0 = trea_millis();

    output_led_set(1);
    while((uint32_t)(trea_millis() - t0) < (uint32_t)ms)
        swdt_feed();
    output_led_set(0);
}

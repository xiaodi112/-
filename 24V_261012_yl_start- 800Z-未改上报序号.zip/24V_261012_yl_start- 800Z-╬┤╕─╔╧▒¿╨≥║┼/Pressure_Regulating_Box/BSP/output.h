#ifndef OUTPUT_H
#define OUTPUT_H

#include "gd32l23x.h"

/* ==================== 板级输出引脚映射 ==================== */
#define OUT_BUZZER_PORT   GPIOD      /* BUZZER: HIGH=响, LOW=停 (驱动方式与旧板一致, 仅换脚) */
#define OUT_BUZZER_PIN    GPIO_PIN_4

/* 指示灯 LED1 (PB5): VCC_3V3 -> D30(LED) -> Rs3 2.2K -> PB5
 * 灌电流接法: PB5 拉低=亮(约 0.6mA), 拉高=灭; 高阻(模拟/浮空)同样为灭。
 * 注意: 不可配内部下拉 —— VCC->LED->2.2K->下拉 会形成约 30uA 通路, LED 微亮。 */
#define OUT_LED_PORT      GPIOB
#define OUT_LED_PIN       GPIO_PIN_5
#define OUT_LED_ACTIVE_LOW 1

/* 初始化输出引脚(默认关闭): 蜂鸣器 LOW / LED 灭 */
void output_gpio_init(void);
void output_buzzer_init(void);
void output_led_init(void);

/* 蜂鸣器: 1=响, 0=停 */
void output_buzzer_set(uint8_t on);

/* 指示灯: 1=亮, 0=灭 (内部按 OUT_LED_ACTIVE_LOW 转换电平) */
void output_led_set(uint8_t on);

/* 指示灯闪烁一次: 亮 ms → 灭 (阻塞, 内部喂狗) */
void output_led_blink(uint16_t ms);

#endif /* OUTPUT_H */

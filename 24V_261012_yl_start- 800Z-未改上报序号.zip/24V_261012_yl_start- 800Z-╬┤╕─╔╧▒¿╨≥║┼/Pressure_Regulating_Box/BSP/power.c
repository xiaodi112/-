#include "power.h"
#include "app_config.h"   /* BLE_ENABLED: 决定 PC12 是 SW_BT 还是 I2C0_SDA */

/* 蓝牙电源状态: 与引脚电平同步的模块内状态 (定义从 App/lcd_ui.c 迁移到此,
 * 使无 LCD 产品仍保有 BLE 电源状态) */
uint8_t g_bt_on = 0;

void power_gpio_init(void)
{
    rcu_periph_clock_enable(RCU_GPIOA);
    rcu_periph_clock_enable(RCU_GPIOB);
    rcu_periph_clock_enable(RCU_GPIOC);
    rcu_periph_clock_enable(RCU_GPIOF);

    /* PA0 (4G_DTR): 默认 HIGH (允许模块进入轻休眠) */
    gpio_mode_set(PWR_4G_DTR_PORT, GPIO_MODE_OUTPUT, GPIO_PUPD_NONE, PWR_4G_DTR_PIN);
    gpio_output_options_set(PWR_4G_DTR_PORT, GPIO_OTYPE_PP, GPIO_OSPEED_2MHZ, PWR_4G_DTR_PIN);
    gpio_bit_set(PWR_4G_DTR_PORT, PWR_4G_DTR_PIN);

    /* PF1 (V4G_EN → NPN → 模块 PWRKEY): 释放态 = 推挽输出低 (NPN 截止)。
     * 模块供电常供, 开关机由 ec800e.c 用 PWRKEY 脉冲控制 (开机 ≥500ms / 关机 ≥650ms),
     * 本处只保证复位后处于"不按下"状态, 避免模块被误开机/误关机。 */
    gpio_mode_set(PWR_4G_KEY_PORT, GPIO_MODE_OUTPUT, GPIO_PUPD_NONE, PWR_4G_KEY_PIN);
    gpio_output_options_set(PWR_4G_KEY_PORT, GPIO_OTYPE_PP, GPIO_OSPEED_2MHZ, PWR_4G_KEY_PIN);
    gpio_bit_reset(PWR_4G_KEY_PORT, PWR_4G_KEY_PIN);

#if BLE_ENABLED
    /* PC12 (SW_BT): 只配置为输出, 不改变电平 (重入 sys_init 时保持蓝牙现有供电状态)
     * 无蓝牙构建下 PC12 已让给 I2C0_SDA(中压), 绝不能在此被配成推挽输出 */
    gpio_mode_set(PWR_BLE_PORT, GPIO_MODE_OUTPUT, GPIO_PUPD_NONE, PWR_BLE_PIN);
    gpio_output_options_set(PWR_BLE_PORT, GPIO_OTYPE_PP, GPIO_OSPEED_2MHZ, PWR_BLE_PIN);
#endif

#if LASER_CH4_ENABLED
    /* PD5 (CH4 电源): 只配置为输出 (仅带 CH4 硬件的产品; 本板无 CH4, 不配置) */
    rcu_periph_clock_enable(RCU_GPIOD);
    gpio_mode_set(PWR_CH4_PORT, GPIO_MODE_OUTPUT, GPIO_PUPD_NONE, PWR_CH4_PIN);
    gpio_output_options_set(PWR_CH4_PORT, GPIO_OTYPE_PP, GPIO_OSPEED_2MHZ, PWR_CH4_PIN);
#endif

    /* PC10 (SW_IIC/传感器电源域): 默认 LOW (断电). 采集前由 PT304D 驱动上电, 四条传感器总线共用 */
    gpio_mode_set(PWR_SENSOR_PORT, GPIO_MODE_OUTPUT, GPIO_PUPD_NONE, PWR_SENSOR_PIN);
    gpio_output_options_set(PWR_SENSOR_PORT, GPIO_OTYPE_PP, GPIO_OSPEED_2MHZ, PWR_SENSOR_PIN);
    gpio_bit_reset(PWR_SENSOR_PORT, PWR_SENSOR_PIN);

    /* PA8 (V24_EN 电机24V电源): 默认 LOW (断电). 操作阀门时由 motor 驱动使能, 停止/休眠断电 */
    gpio_mode_set(PWR_V24_PORT, GPIO_MODE_OUTPUT, GPIO_PUPD_NONE, PWR_V24_PIN);
    gpio_output_options_set(PWR_V24_PORT, GPIO_OTYPE_PP, GPIO_OSPEED_2MHZ, PWR_V24_PIN);
    gpio_bit_reset(PWR_V24_PORT, PWR_V24_PIN);
}

/* 注: 4G 电源轨开关 (原 PB13 V4G_EN + power_4g_set/is_on/apply_state) 已随硬件取消 ——
 *     新板模块常供电, 开关机改为 PWRKEY 软控制, 时序与状态探测见 Drivers/ec800e.c。 */

void power_ble_set(uint8_t on)
{
    g_bt_on = on ? 1u : 0u;
#if BLE_ENABLED
    if(on) gpio_bit_set(PWR_BLE_PORT, PWR_BLE_PIN);
    else   gpio_bit_reset(PWR_BLE_PORT, PWR_BLE_PIN);
#endif
}

uint8_t power_ble_is_on(void)
{
    return g_bt_on;
}

void power_4g_dtr_set(uint8_t level)
{
    /* 深睡会把该脚转 Analog: 每次调用先恢复推挽输出, 保证探测/唤醒路径无需再单独 gpio_init */
    gpio_mode_set(PWR_4G_DTR_PORT, GPIO_MODE_OUTPUT, GPIO_PUPD_NONE, PWR_4G_DTR_PIN);
    gpio_output_options_set(PWR_4G_DTR_PORT, GPIO_OTYPE_PP, GPIO_OSPEED_2MHZ, PWR_4G_DTR_PIN);
    if(level) gpio_bit_set(PWR_4G_DTR_PORT, PWR_4G_DTR_PIN);
    else      gpio_bit_reset(PWR_4G_DTR_PORT, PWR_4G_DTR_PIN);
}

void power_ch4_set(uint8_t on)
{
#if LASER_CH4_ENABLED
    /* 深睡会把该脚转 Analog: 每次调用先恢复输出模式 (与 power_sensor_set 同规则) */
    rcu_periph_clock_enable(RCU_GPIOD);
    gpio_mode_set(PWR_CH4_PORT, GPIO_MODE_OUTPUT, GPIO_PUPD_NONE, PWR_CH4_PIN);
    gpio_output_options_set(PWR_CH4_PORT, GPIO_OTYPE_PP, GPIO_OSPEED_2MHZ, PWR_CH4_PIN);
    if(on) gpio_bit_set(PWR_CH4_PORT, PWR_CH4_PIN);
    else  gpio_bit_reset(PWR_CH4_PORT, PWR_CH4_PIN);
#else
    (void)on;   /* 本板无 CH4 硬件 (PD5 未使用) */
#endif
}

uint8_t power_ch4_is_on(void)
{
#if LASER_CH4_ENABLED
    return (gpio_input_bit_get(PWR_CH4_PORT, PWR_CH4_PIN) == SET) ? 1 : 0;
#else
    return 0;
#endif
}

void power_sensor_set(uint8_t on)
{
    /* 唤醒后首次使用需先恢复输出模式 (深睡期间本脚由 gpio_enter_low_power 保持输出低) */
    gpio_mode_set(PWR_SENSOR_PORT, GPIO_MODE_OUTPUT, GPIO_PUPD_NONE, PWR_SENSOR_PIN);
    gpio_output_options_set(PWR_SENSOR_PORT, GPIO_OTYPE_PP, GPIO_OSPEED_2MHZ, PWR_SENSOR_PIN);
    if(on) gpio_bit_set(PWR_SENSOR_PORT, PWR_SENSOR_PIN);
    else   gpio_bit_reset(PWR_SENSOR_PORT, PWR_SENSOR_PIN);
}

uint8_t power_sensor_is_on(void)
{
    return (gpio_input_bit_get(PWR_SENSOR_PORT, PWR_SENSOR_PIN) == SET) ? 1 : 0;
}

/* 电机 24V 电源 (PA8 V24_EN, 正逻辑): 深睡会把该脚转 Analog, 每次调用先恢复输出模式 */
void power_v24_set(uint8_t on)
{
    gpio_mode_set(PWR_V24_PORT, GPIO_MODE_OUTPUT, GPIO_PUPD_NONE, PWR_V24_PIN);
    gpio_output_options_set(PWR_V24_PORT, GPIO_OTYPE_PP, GPIO_OSPEED_2MHZ, PWR_V24_PIN);
    if(on) gpio_bit_set(PWR_V24_PORT, PWR_V24_PIN);
    else   gpio_bit_reset(PWR_V24_PORT, PWR_V24_PIN);
}

uint8_t power_v24_is_on(void)
{
    return (gpio_input_bit_get(PWR_V24_PORT, PWR_V24_PIN) == SET) ? 1 : 0;
}

#ifndef POWER_H
#define POWER_H

#include "gd32l23x.h"

/* ==================== 板级电源引脚映射 ====================
 * 换板只改本表: 引脚全部收口在 BSP/power.c 与本头文件, 驱动/应用层不含裸引脚
 */
#include <stdint.h>

/* V4G_EN(网名): 4G 模块"软开关机"控制 —— 经 NPN(Q21) 拉低模块 PWRKEY。
 *   高电平 = 拉低 PWRKEY(按下), 低电平 = 释放(断开)。
 *   模块供电常供, 不再由 MCU 通断; 开关机时序(开机 >500ms / 关机 >=650ms)与状态探测
 *   (DTR+AT 握手) 在 Drivers/ec800e.c 内实现: EC801E_PowerOn / EC801E_PowerOff / EC801E_IsAlive。
 *   深睡期间保持"释放"电平即可 (板上 Rg2 47K 基极下拉, 高阻也不会误动)。 */
#define PWR_4G_KEY_PORT   GPIOF
#define PWR_4G_KEY_PIN    GPIO_PIN_1
#define PWR_BLE_PORT      GPIOC      /* SW_BT: 蓝牙模块电源 (HIGH=供电)
                                      * 注: 新板 PC12 已改作 I2C0_SDA(中压); 本产品 BLE_ENABLED=0,
                                      *     power.c / mygpio.c 在无蓝牙构建下不再配置与驱动该脚 */
#define PWR_BLE_PIN       GPIO_PIN_12
#define PWR_CH4_PORT      GPIOD      /* CH4 (HIGH=ON): 仅带 CH4 硬件的产品使用;
                                      * 本板(24V)无 CH4 → PD5 未使用, 不再配置该脚 */
#define PWR_CH4_PIN       GPIO_PIN_5
#define PWR_SENSOR_PORT   GPIOC      /* 传感器 I2C 电源域 (HIGH=供电, 正逻辑):
                                      * I2C0~I2C3 四条传感器总线共用同一门控, 采集前上电/采集后断电 */
#define PWR_SENSOR_PIN    GPIO_PIN_10
#define PWR_V24_PORT      GPIOA      /* V24_EN: 电机 24V 电源门控 (正逻辑: HIGH=24V 通)
                                      * 与 M_INH(驱动使能) 配合: 两者都使能才能操作阀门 */
#define PWR_V24_PIN       GPIO_PIN_8
#define PWR_4G_DTR_PORT   GPIOA      /* 4G_DTR: 模块休眠控制 (HIGH=允许休眠) */
#define PWR_4G_DTR_PIN    GPIO_PIN_0

/* 注意: 电压采集为 AD_BAT=PC2 (BSP/adc_bat.c); 旧板的分压使能脚 PB11 新板已不用 */

/* 初始化全部电源控制引脚: 4G PWRKEY 释放态(输出低)/蓝牙/CH4 默认断电(LOW), DTR 默认 HIGH */
void power_gpio_init(void);

/* 蓝牙模块电源: 1=供电, 0=断电 */
void power_ble_set(uint8_t on);
uint8_t power_ble_is_on(void);

/* 蓝牙模块电源状态 (0=断电, 1=供电): 与 power_ble_set() 双向同步, 供状态机/日志读取 */
extern uint8_t g_bt_on;

/* 4G DTR: 1=HIGH(允许模块休眠), 0=LOW(强制唤醒)
 * 注: 深睡会把该脚转 Analog, 本函数每次调用都会重新配置为推挽输出再置电平 */
void power_4g_dtr_set(uint8_t level);

/* CH4 电源: 1=ON, 0=OFF (仅 LASER_CH4_ENABLED=1 的构建有效; 本板无 CH4 → 空操作) */
void power_ch4_set(uint8_t on);
uint8_t power_ch4_is_on(void);

/* 传感器 I2C 电源域 (PC10, 四条传感器总线共用): 1=供电, 0=断电 */
void power_sensor_set(uint8_t on);
uint8_t power_sensor_is_on(void);

/* 电机 24V 电源 (PA8 V24_EN, 正逻辑): 1=24V 通, 0=断
 * 注: 操作阀门时必须与 M_INH 一起使能; 停止/休眠时断电 (省电) */
void power_v24_set(uint8_t on);
uint8_t power_v24_is_on(void);

#endif /* POWER_H */

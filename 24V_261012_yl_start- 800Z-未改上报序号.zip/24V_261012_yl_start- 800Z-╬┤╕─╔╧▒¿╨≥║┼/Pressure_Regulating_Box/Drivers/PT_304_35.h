#ifndef PT_304_35__H
#define PT_304_35__H

#include "gd32l23x.h"
#include "app_config.h"
#include "soft_i2c.h"
#include "delay.h"
#include "stddef.h"

/*****************************************************************************
 * Driver protocol selection (compile-time switch):
 * - Enable one: both sensors use the same protocol
 * - Enable both 4BYTE+7BYTE: each sensor selects via PT304D_S1_DRIVER / S2_DRIVER
 * - PT304D_DRV_SENSOR: new register-based calibrated sensor (addr 0x76/0x77)
 *****************************************************************************/
//#define PT304D_DRV_7BYTE         // 7-byte protocol: send 0xAA cmd + read 7 bytes
#define PT304D_DRV_4BYTE         // 4-byte protocol: direct read 4 bytes (addr=0x28)
//#define PT304D_DRV_SENSOR          // New sensor: register map + calib coefficients (0x76/0x77)

/*****************************************************************************
 * 大气基准(零点)适用性 —— 由上面的协议选择自动推导, 不手工设置
 *   仅寄存器式传感器(PT304D_DRV_SENSOR)是绝压式: 测量值 = 读数 - 大气基准 (表压语义);
 *   4字节/7字节协议输出已是目标口径, 不使用大气基准。
 *   驱动(压力换算)与中间层(zero_cal 标定 / calib_mode)统一按本宏匹配,
 *   各处不再各自去判断协议宏。
 *****************************************************************************/
#if defined(PT304D_DRV_SENSOR)
#define PT304D_USES_ZERO_BASELINE      1
#else
#define PT304D_USES_ZERO_BASELINE      0
#endif

/*****************************************************************************
 * Per-sensor driver binding (effective only when both 4BYTE and 7BYTE are enabled)
 * value: 7 = 7-byte protocol, 4 = 4-byte protocol
 *****************************************************************************/
#define PT304D_S1_DRIVER   4
#define PT304D_S2_DRIVER   4

/*****************************************************************************
 * 通道数 (压变扩展):
 *   2 = 当前产品: CH1 低压(I2C1) + CH2 中压(I2C0)
 *   4 = 后期 4 路压变: 增加 CH3(I2C2)/CH4(I2C3), 需要:
 *       1) app_config.h 打开 IIC_RSV0_ENABLED / IIC_RSV1_ENABLED
 *       2) 在 PT_304_35.c 的 s_pt304d_ch[] 表里确认地址/量程
 * 通道号→总线/地址/量程 的差异全部收在该表, 驱动其它代码与通道数无关。
 *****************************************************************************/
#ifndef PT304D_CHANNEL_COUNT
#define PT304D_CHANNEL_COUNT   2
#endif
#if (PT304D_CHANNEL_COUNT < 2)
#error "PT304D: 通道数至少为 2 (CH1 低压 + CH2 中压), 本驱动与双通道兼容接口依赖此前提"
#endif
/* 应用层路数不能超过驱动通道数: 否则第 3/4 路的采集掩码会被驱动静默丢弃
 * (pt304d_read_channels 只遍历 < PT304D_CHANNEL_COUNT 的通道), 属"配了但没生效"的隐性故障。 */
#if (APP_DEFAULT_SENSOR_COUNT > PT304D_CHANNEL_COUNT)
#error "APP_DEFAULT_SENSOR_COUNT 大于 PT304D_CHANNEL_COUNT: 请同步提高驱动通道数并补齐通道表 s_pt304d_ch[] (PT_304_35.c)"
#endif

/*****************************************************************************
 * Per-sensor full scale (unit: Pa)  —— only used by 4BYTE/7BYTE
 *****************************************************************************/
#define PT304D_S1_FS       600000.0f    // S1 full scale (Pa): 40kPa
#define PT304D_S2_FS       600000.0f   // S2 full scale (Pa): 600kPa
#define PT304D_S3_FS       600000.0f   // S3 full scale (Pa): 压变3 上板后按实际量程修改
#define PT304D_S4_FS       600000.0f   // S4 full scale (Pa): 压变4 上板后按实际量程修改

/************************** 传感器通道索引 **************************/
#define PT304D_SENSOR_1    0   // 阀后/出气/低压 (I2C1: PB6/PB7)   → addr 0x77
#define PT304D_SENSOR_2    1   // 阀前/进气/中压 (I2C0: PC11/PC12) → addr 0x77 (与S1同址, 靠独立总线区分)
#if PT304D_CHANNEL_COUNT >= 3
#define PT304D_SENSOR_3    2   // 压变3 (I2C2: PB8/PB9, 上板后确认地址)
#endif
#if PT304D_CHANNEL_COUNT >= 4
#define PT304D_SENSOR_4    3   // 压变4 (I2C3: PC0/PC1, 上板后确认地址)
#endif

/************************** New sensor addresses **************************
 * 通道→从机地址: 与所选协议无关, 统一给出 (4BYTE/7BYTE 协议用各自的固定地址
 * PT304D_4B_ADDR / PT304D_7B_ADDR, 只有 PT304D_DRV_SENSOR 走本表地址)。 */
#define PT304D_S1_I2C_ADDR     0x77    // 阀后出气端 (CH1)
//#define PT304D_S2_I2C_ADDR     0x76    // 阀前进气端
#define PT304D_S2_I2C_ADDR     0x77    // 阀前进气端 (CH2, 与CH1同址, 靠独立总线区分)
#define PT304D_S3_I2C_ADDR     0x77    // 压变3 (预留, CH3, 上板后确认)
#define PT304D_S4_I2C_ADDR     0x77    // 压变4 (预留, CH4, 上板后确认)

/************************** 7-byte protocol **************************/
#ifdef PT304D_DRV_7BYTE
#define PT304D_7B_ADDR         0x00
#define PT304D_7B_MEAS_CMD     0xAA
#define PT304D_7B_READ_BYTES   7
#define PT304D_7B_MEAS_DELAY   15
#define PT304D_7B_ADDR_REG     0x02
#define PT304D_7B_24BIT_MAX    0xFFFFFF
#define PT304D_7B_TEMP_MIN     -40.0f
#define PT304D_7B_TEMP_MAX     125.0f
#endif

/************************** 4-byte protocol **************************/
#ifdef PT304D_DRV_4BYTE
#define PT304D_4B_ADDR         0x28
#define PT304D_4B_READ_BYTES   4
#define PT304D_4B_ZERO_ADC     1638
#define PT304D_4B_SPAN_ADC     13110
#define PT304D_4B_TEMP_SCALE   2047
#endif

/************************** Legacy aliases **************************/
#define PT304D_I2C_ADDR_7BIT   0x00
#define PT304D_MEAS_CMD        0xAA
#define PT304D_READ_BYTES      7
#define PT304D_MEAS_DELAY_MS   15
#define PT304D_ADDR_REG        0x02
#define PT304D_PRESS_FS_35     600000.0f
#define PT304D_PRESS_FS_600    600000.0f
#define PT304D_24BIT_MAX       0xFFFFFF
#define PT304D_TEMP_MIN        -40.0f
#define PT304D_TEMP_MAX        125.0f

/************************** Legacy protocol selector **************************/
#if defined(PT304D_DRV_7BYTE) && defined(PT304D_DRV_4BYTE)
  #define PT304D_IS_4BYTE(idx) \
      (((idx) == PT304D_SENSOR_1) ? (PT304D_S1_DRIVER == 4) : (PT304D_S2_DRIVER == 4))
#elif defined(PT304D_DRV_4BYTE)
  #define PT304D_IS_4BYTE(idx)  1
#else
  #define PT304D_IS_4BYTE(idx)  0
#endif

/************************** Status bit definitions (7-byte) **************************/
#define PT304D_STAT_BIT7       (1 << 7)
#define PT304D_STAT_POWERED    (1 << 6)
#define PT304D_STAT_BUSY       (1 << 5)
#define PT304D_STAT_MODE_BIT4  (1 << 4)
#define PT304D_STAT_MODE_BIT3  (1 << 3)
#define PT304D_STAT_MEM_ERR    (1 << 2)
#define PT304D_STAT_CONN_ERR   (1 << 1)
#define PT304D_STAT_MATH_SAT   (1 << 0)
#define PT304D_STAT_MODE_MASK  (PT304D_STAT_MODE_BIT4 | PT304D_STAT_MODE_BIT3)
#define PT304D_MODE_LOW_POWER  0b10

/************************** Sensor status codes **************************/
typedef enum {
    PT304D_OK          = 0,
    PT304D_ERR_I2C     = 1,
    PT304D_ERR_BUSY    = 2,
    PT304D_ERR_MODE    = 3,
    PT304D_ERR_POWER   = 4,
    PT304D_ERR_NULLPTR = 5,
    PT304D_ERR_DATA    = 6
} PT304D_Status;

/************************** Sensor data struct **************************/
typedef struct {
    uint8_t  stat_raw;
    uint32_t press_raw;
    uint32_t temp_raw;
    float    pressure;      // Pa
    float    temperature;   // °C
    PT304D_Status err;
} PT304D_Data;

/* ==================== 无效读数哨兵 ====================
 * 传感器离线/读取失败时, 驱动把 pressure/temperature 写成这两个值 (不再保留上次旧值)。
 * 用途: 存历史与上报时可辨识"该路无数据"(0 Pa / 0℃ 是合法读数, 无法区分)。
 * 约束: 设备侧对 err != PT304D_OK 的通道一律不参与阈值/报警/关阀/突变判定,
 *       哨兵值只用于存储与上报, 绝不可送入 threshold_* 函数。
 * 注: 4 字节协议的原始温度 0 也对应 -50℃ (量程下限), 靠 err 字段区分。 */
#define PT304D_INVALID_PRESSURE_PA   (-1000.0f)
#define PT304D_INVALID_TEMP_C        (-50.0f)

/************************** Public interfaces **************************/
PT304D_Status PT304D_Init(uint8_t sensor_idx);
PT304D_Status PT304D_SendMeasCmd(uint8_t sensor_idx);
PT304D_Status PT304D_ReadMeasData(uint8_t sensor_idx, PT304D_Data *p_data);
PT304D_Status PT304D_Collect(uint8_t sensor_idx, PT304D_Data *p_data);
PT304D_Status PT304D_SetI2CAddr(uint8_t sensor_idx, uint8_t new_7bit_addr);

void  PT304D_SetZeroOffset(uint8_t sensor_idx, float offset_pa);
float PT304D_GetZeroOffset(uint8_t sensor_idx);

void PT304D_CollectAll(PT304D_Data *p_s1, PT304D_Data *p_s2);

/* ==================== 多通道采集 (后期 4 路压变用) ====================
 * mask bit i=1: 采集通道 i; p_out[i] 为对应结果缓冲(NULL 跳过该路)。
 * 通道间共用一次上电/断电; 单路读取可直接用 PT304D_Collect(idx, data)。
 * 例(4 路): PT304D_Data d[4]; PT304D_Data *o[4]={&d[0],&d[1],&d[2],&d[3]};
 *           PT304D_CollectMask(0x0F, o); */
void PT304D_CollectMask(uint32_t ch_mask, PT304D_Data *p_out[]);

/* ==================== 静态测漏: 保持供电采集 ====================
 * 常规采集每次上/断电; 静态测漏任务期间要求传感器不断电(读数稳定/避免50ms上电等待),
 * 用法: 任务开始 PT304D_PowerHold(1) → 循环 PT304D_CollectAllHeld() → 任务结束 PT304D_PowerHold(0)
 * PT304D_PowerHold(1) 幂等: 供电已被其它路径断开时会重新上电并等待稳定。 */
void PT304D_PowerHold(uint8_t on);
void PT304D_CollectAllHeld(PT304D_Data *p_s1, PT304D_Data *p_s2);
void PT304D_CollectMaskHeld(uint32_t ch_mask, PT304D_Data *p_out[]);

#endif

#include "soft_i2c.h"
#include "power.h"
#include "delay.h"

/* ==================== 五组总线实例 ====================
 * half_period 统一取 SOFT_I2C_HALF_PERIOD (app_config.h), 默认 150 与原驱动一致;
 * 需要提速时改小该宏即可, 不必动驱动代码。
 * 未使能的总线(IICx_ENABLED=0)同样有描述符, 但不会被初始化, 引脚不受影响。 */
const SoftI2C_t g_iic_mid    = { RCU_GPIOC, IIC_MID_SCL_PORT,    IIC_MID_SCL_PIN,    IIC_MID_SDA_PORT,    IIC_MID_SDA_PIN,    SOFT_I2C_HALF_PERIOD };
const SoftI2C_t g_iic_low    = { RCU_GPIOB, IIC_LOW_SCL_PORT,    IIC_LOW_SCL_PIN,    IIC_LOW_SDA_PORT,    IIC_LOW_SDA_PIN,    SOFT_I2C_HALF_PERIOD };
const SoftI2C_t g_iic_rsv0   = { RCU_GPIOB, IIC_RSV0_SCL_PORT,   IIC_RSV0_SCL_PIN,   IIC_RSV0_SDA_PORT,   IIC_RSV0_SDA_PIN,   SOFT_I2C_HALF_PERIOD };
const SoftI2C_t g_iic_rsv1   = { RCU_GPIOC, IIC_RSV1_SCL_PORT,   IIC_RSV1_SCL_PIN,   IIC_RSV1_SDA_PORT,   IIC_RSV1_SDA_PIN,   SOFT_I2C_HALF_PERIOD };
const SoftI2C_t g_iic_eeprom = { RCU_GPIOD, IIC_EEPROM_SCL_PORT, IIC_EEPROM_SCL_PIN, IIC_EEPROM_SDA_PORT, IIC_EEPROM_SDA_PIN, SOFT_I2C_HALF_PERIOD };

/* 总线表: ID → 描述符 / 是否使能 (IICx_ENABLED 来自 app_config.h) */
static const SoftI2C_t *const s_iic_buses[IIC_BUS_COUNT] = {
    &g_iic_mid, &g_iic_low, &g_iic_rsv0, &g_iic_rsv1, &g_iic_eeprom
};
static const uint8_t s_iic_bus_enabled[IIC_BUS_COUNT] = {
    IIC_MID_ENABLED, IIC_LOW_ENABLED, IIC_RSV0_ENABLED, IIC_RSV1_ENABLED, IIC_EEPROM_ENABLED
};

/* 按 ID 取总线; 未使能返回 NULL */
const SoftI2C_t *iic_bus(IicBusId_t id)
{
    if((uint8_t)id >= (uint8_t)IIC_BUS_COUNT) return NULL;
    return s_iic_bus_enabled[id] ? s_iic_buses[id] : NULL;
}

/* 半周期延时: 空循环, 编译后每条约1~2周期 */
static void i2c_delay(uint16_t n)
{
    volatile uint16_t i;
    for(i = 0; i < n; i++);
}

/* 开漏输出 + 内部上拉, 总线死锁恢复(9个SCL脉冲), 结束时释放总线 */
void soft_i2c_init(const SoftI2C_t *bus)
{
    uint8_t i;

    rcu_periph_clock_enable(bus->rcu);

    gpio_mode_set(bus->scl_port, GPIO_MODE_OUTPUT, GPIO_PUPD_PULLUP, bus->scl_pin);
    gpio_mode_set(bus->sda_port, GPIO_MODE_OUTPUT, GPIO_PUPD_PULLUP, bus->sda_pin);
    gpio_output_options_set(bus->scl_port, GPIO_OTYPE_OD, GPIO_OSPEED_50MHZ, bus->scl_pin);
    gpio_output_options_set(bus->sda_port, GPIO_OTYPE_OD, GPIO_OSPEED_50MHZ, bus->sda_pin);

    I2C_SCL_H(bus);
    I2C_SDA_H(bus);
    i2c_delay(bus->half_period);

    /* 总线死锁恢复: 若 SDA 被从机拉低, 发送9个SCL脉冲释放总线 */
    if(I2C_SDA_READ(bus) == 0)
    {
        for(i = 0; i < 9; i++)
        {
            I2C_SCL_L(bus);
            i2c_delay(bus->half_period);
            I2C_SCL_H(bus);
            i2c_delay(bus->half_period);
            if(I2C_SDA_READ(bus) != 0) break;
        }
    }

    soft_i2c_stop(bus);
}

void soft_i2c_start(const SoftI2C_t *bus)
{
    I2C_SDA_H(bus);
    I2C_SCL_H(bus);
    i2c_delay(bus->half_period);
    I2C_SDA_L(bus);
    i2c_delay(bus->half_period);
    I2C_SCL_L(bus);
    i2c_delay(bus->half_period);
}

void soft_i2c_stop(const SoftI2C_t *bus)
{
    I2C_SCL_L(bus);
    I2C_SDA_L(bus);
    i2c_delay(bus->half_period);
    I2C_SCL_H(bus);
    i2c_delay(bus->half_period);
    I2C_SDA_H(bus);
    i2c_delay(bus->half_period);
}

/* 写1字节并在第9个时钟读 ACK: 返回 0=ACK(设备响应), 1=NACK */
uint8_t soft_i2c_write_byte(const SoftI2C_t *bus, uint8_t data)
{
    int8_t i;
    uint8_t ack;

    for(i = 7; i >= 0; i--)
    {
        I2C_SCL_L(bus);
        if(data & (1u << i)) I2C_SDA_H(bus);
        else                 I2C_SDA_L(bus);
        i2c_delay(bus->half_period);
        I2C_SCL_H(bus);
        i2c_delay(bus->half_period);
    }

    /* 第9个时钟: SDA 释放, 读从机 ACK (低电平=ACK) */
    I2C_SCL_L(bus);
    I2C_SDA_H(bus);
    i2c_delay(bus->half_period);
    I2C_SCL_H(bus);
    i2c_delay(bus->half_period);
    ack = (I2C_SDA_READ(bus) != 0) ? 1 : 0;
    I2C_SCL_L(bus);
    i2c_delay(bus->half_period);

    return ack;
}

/* 读1字节; ack=1 时第9个时钟发 ACK(继续读), ack=0 发 NACK(最后字节) */
uint8_t soft_i2c_read_byte(const SoftI2C_t *bus, uint8_t ack)
{
    int8_t i;
    uint8_t value = 0;

    I2C_SDA_H(bus);
    for(i = 7; i >= 0; i--)
    {
        I2C_SCL_L(bus);
        i2c_delay(bus->half_period);
        I2C_SCL_H(bus);
        i2c_delay(bus->half_period);
        if(I2C_SDA_READ(bus)) value |= (1u << i);
    }

    /* 第9个时钟: 发送 ACK/NACK */
    I2C_SCL_L(bus);
    if(ack) I2C_SDA_L(bus);
    else    I2C_SDA_H(bus);
    i2c_delay(bus->half_period);
    I2C_SCL_H(bus);
    i2c_delay(bus->half_period);
    I2C_SCL_L(bus);
    I2C_SDA_H(bus);
    i2c_delay(bus->half_period);

    return value;
}

/* 探测 7bit 地址设备: 返回 0=存在(ACK), 1=不存在 */
uint8_t soft_i2c_check(const SoftI2C_t *bus, uint8_t addr)
{
    uint8_t ack;

    soft_i2c_start(bus);
    ack = soft_i2c_write_byte(bus, (uint8_t)((addr << 1) | 0x00));
    soft_i2c_stop(bus);
    return ack;
}

/* 引脚→模拟输入(高阻): 释放总线用 (断电前调用, 防止向未上电器件倒灌) */
void soft_i2c_bus_release(const SoftI2C_t *bus)
{
    if(bus == NULL) return;
    gpio_mode_set(bus->scl_port, GPIO_MODE_ANALOG, GPIO_PUPD_NONE, bus->scl_pin);
    gpio_mode_set(bus->sda_port, GPIO_MODE_ANALOG, GPIO_PUPD_NONE, bus->sda_pin);
}

/* 遍历已使能的传感器总线 (I2C0~I2C3; EEPROM 长供电, 由 EEPROM 驱动自管理, 不参与):
 * release=1 → 引脚转模拟释放; release=0 → 开漏初始化并释放总线。
 * "哪些总线属于传感器"只在这里定义一次, 释放/初始化两条路径不会走偏。 */
static void sensor_buses_apply(uint8_t release)
{
    uint8_t i;
    for(i = 0; i < (uint8_t)IIC_BUS_COUNT; i++)
    {
        const SoftI2C_t *bus;
        if(i == (uint8_t)IIC_BUS_EEPROM) continue;
        bus = iic_bus((IicBusId_t)i);
        if(bus == NULL) continue;
        if(release) soft_i2c_bus_release(bus);
        else        soft_i2c_init(bus);
    }
}

/* 释放全部已使能的传感器总线 */
void soft_i2c_sensor_buses_release(void) { sensor_buses_apply(1); }

/* 初始化全部已使能的传感器总线 GPIO (开漏释放); 采集前调用 */
void soft_i2c_sensors_init(void)         { sensor_buses_apply(0); }

/* ==================== 传感器电源控制 (PC10, 高电平供电) ====================
 * 四条传感器总线(I2C0~I2C3)共用一个电源域: 上电后 4 路压变可同时在线。
 * 采集流程: sensor_pwr_on() → 等待上电稳定 → I2C 采集 → sensor_pwr_off()
 * 引脚映射收口在 BSP/power.c (PWR_SENSOR_PORT/PIN), 本驱动不出现裸引脚。 */
void sensor_pwr_on(void)
{
    power_sensor_set(1);
    trea_delay_ms(SENSOR_PWR_SETTLE_MS);   /* 传感器与 I2C 上拉网络上电稳定时间 */
}

void sensor_pwr_off(void)
{
    power_sensor_set(0);
}

#ifndef SOFT_I2C_H
#define SOFT_I2C_H

#include "gd32l23x.h"
#include "app_config.h"
#include <stddef.h>

/* =====================================================================
 * 软件 I2C 总线驱动 (GPIO 模拟, 五组独立实例)
 *
 * 总线与硬件对应 (引脚宏见 app_config.h, 网络名与原理图一致):
 *   I2C0  中压传感器  SCL=PC11 SDA=PC12   电源: PC10 门控(正逻辑)
 *   I2C1  低压传感器  SCL=PB6  SDA=PB7    电源: PC10 门控(正逻辑)
 *   I2C2  压变预留    SCL=PB8  SDA=PB9    电源: PC10 门控(正逻辑)
 *   I2C3  压变预留    SCL=PC0  SDA=PC1    电源: PC10 门控(正逻辑)
 *   I2CM  EEPROM     SCL=PD0  SDA=PD1    长供电, 不受 PC10 影响
 *
 * 四条传感器总线共用 PC10 电源域: 上电后 4 路压变可同时在线, 各总线独立寻址。
 * 总线是否实例化(占用引脚)由 app_config.h 的 IICx_ENABLED 决定:
 * 用 iic_bus() 取总线, 未使能的返回 NULL (调用方需判空)。
 * 引脚映射收敛在 app_config.h, 换板只改宏, 本驱动代码零改动。
 * ===================================================================== */

/* 总线描述符: 一条 GPIO 模拟 I2C 总线 = 一组 SCL/SDA 引脚 */
typedef struct {
    uint32_t rcu;          /* GPIO 时钟使能位 (RCU_GPIOx) */
    uint32_t scl_port;     /* SCL 端口 */
    uint32_t scl_pin;      /* SCL 引脚 */
    uint32_t sda_port;     /* SDA 端口 */
    uint32_t sda_pin;      /* SDA 引脚 */
    uint16_t half_period;  /* 半周期延时计数(空循环), 值越大速率越慢 */
} SoftI2C_t;

/* 总线 ID (顺序与实例表一致, 供 iic_bus()/多路传感器通道表使用) */
typedef enum {
    IIC_BUS_MID = 0,       /* I2C0: 中压传感器 (PT304D S2) */
    IIC_BUS_LOW,           /* I2C1: 低压传感器 (PT304D S1) */
    IIC_BUS_RSV0,          /* I2C2: 压变预留 */
    IIC_BUS_RSV1,          /* I2C3: 压变预留 */
    IIC_BUS_EEPROM,        /* I2CM: EEPROM */
    IIC_BUS_COUNT
} IicBusId_t;

/* 五组总线实例 (定义于 soft_i2c.c; 未使能的总线只是数据, 不会被初始化) */
extern const SoftI2C_t g_iic_mid;     /* I2C0: 中压传感器 (PC11/PC12) */
extern const SoftI2C_t g_iic_low;     /* I2C1: 低压传感器 (PB6/PB7)  */
extern const SoftI2C_t g_iic_rsv0;    /* I2C2: 压变预留    (PB8/PB9)  */
extern const SoftI2C_t g_iic_rsv1;    /* I2C3: 压变预留    (PC0/PC1)  */
extern const SoftI2C_t g_iic_eeprom;  /* I2CM: EEPROM      (PD0/PD1, 长供电) */

/* 按 ID 取总线描述符; 该总线未使能(IICx_ENABLED=0)时返回 NULL */
const SoftI2C_t *iic_bus(IicBusId_t id);

/* 底层引脚操作宏 (寄存器直操, 单指令置位/清零, 效率最高) */
#define I2C_SCL_H(bus)   GPIO_BOP((bus)->scl_port) = (bus)->scl_pin
#define I2C_SCL_L(bus)   GPIO_BC((bus)->scl_port)  = (bus)->scl_pin
#define I2C_SDA_H(bus)   GPIO_BOP((bus)->sda_port) = (bus)->sda_pin
#define I2C_SDA_L(bus)   GPIO_BC((bus)->sda_port)  = (bus)->sda_pin
#define I2C_SDA_READ(bus)  ((GPIO_ISTAT((bus)->sda_port) & (bus)->sda_pin) != 0)

/* I2C 读写方向位 (兼容旧宏名) */
#ifndef IIC_WR
#define IIC_WR    0   /* 写操作 */
#define IIC_RD    1   /* 读操作 */
#endif

/* ---- 接口函数 ---- */
void    soft_i2c_init(const SoftI2C_t *bus);                     /* 开漏配置+总线死锁恢复+Stop */
void    soft_i2c_start(const SoftI2C_t *bus);
void    soft_i2c_stop(const SoftI2C_t *bus);
uint8_t soft_i2c_write_byte(const SoftI2C_t *bus, uint8_t data); /* 写1字节并读ACK: 0=ACK, 1=NACK */
uint8_t soft_i2c_read_byte(const SoftI2C_t *bus, uint8_t ack);   /* 读1字节, ack=1发送ACK */
uint8_t soft_i2c_check(const SoftI2C_t *bus, uint8_t addr);      /* 探测设备(7bit地址): 0=存在 */

/* ---- 总线释放 / 传感器总线管理 ----
 * 传感器 IIC 电源由 PC10 开关控制 (HIGH=供电, 见 BSP/power.h), 四条传感器总线共用;
 * 采集前 sensor_pwr_on() 上电并等待稳定, 采集结束 sensor_pwr_off() 断电。
 * 断电前先 soft_i2c_sensor_buses_release() 释放引脚(转模拟), 避免向未上电器件倒灌。 */
/* 引脚→模拟输入(高阻): 断电前释放总线用 */
void    soft_i2c_bus_release(const SoftI2C_t *bus);
/* 释放全部已使能的传感器总线(I2C0~I2C3) */
void    soft_i2c_sensor_buses_release(void);
#define SENSOR_PWR_SETTLE_MS   50      /* 传感器上电到可通信的稳定时间(ms) */
void soft_i2c_sensors_init(void);   /* 初始化全部已使能的传感器总线 GPIO (开漏释放) */
void sensor_pwr_on(void);           /* 传感器 IIC 上电 (PC10=HIGH) + 稳定延时 */
void sensor_pwr_off(void);          /* 传感器 IIC 断电 (PC10=LOW) */

#endif /* SOFT_I2C_H */

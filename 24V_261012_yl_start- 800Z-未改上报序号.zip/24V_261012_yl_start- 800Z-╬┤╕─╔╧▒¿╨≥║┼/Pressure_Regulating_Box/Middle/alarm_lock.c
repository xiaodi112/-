/**
 * @file alarm_lock.c
 * @brief 告警锁 / 恢复去抖 (三条报警路径共用, 持久化到 EEPROM)
 *
 * 锁语义:
 *   s_last_r[ch] = 最后一次"已上报"的通道结果码 (压力/温度/突变, 不含电压码)
 *   s_last_t[ch] = 最后一次"已上报"的温度状态码
 *   本次等级与最后已上报不同 → 新告警(升级/降级都算); 相同 → 去重不报。
 *
 * 恢复去抖:
 *   在线 && r==OK && ts==NORMAL 连续 ALARM_LOCK_CLEAR_COUNT 次 → 清该通道锁 + 返回 1;
 *   任意一次异常/离线 → 计数归零; 单次正常不清锁。
 *
 * 电压锁 (1 bit, 独立恢复计数):
 *   VPROTECT/VOLT_HIGH/VOLT_LOW 不进入通道锁; 只有电压判定过的路径才可置位/清除。
 *
 * EEPROM 布局 (与"上报周期防重锁" 0x500-0x504 不重叠, 落在同一 32B 物理页):
 *   0x520        magic 0xCE
 *   0x521..0x525 last_r[0], last_r[1], last_t[0], last_t[1], volt_flag
 *   0x526        CRC8 (0x07, 覆盖 0x521..0x525)
 *   写入顺序: 数据+CRC 先写, magic 最后写 (半写失效 → 下次上电判无效)
 */
#include "alarm_lock.h"
#include "app_config.h"
#include "eeprom_config.h"     /* g_sensor_count */
#include "config_store.h"      /* EE_READ / EE_WRITE / EE_WRITE_BYTE */
#include "tim.h"               /* rtc_get_hhmmss */
#include "usart.h"             /* printf_debug */
#include <string.h>

/* ==================== EEPROM 布局 ==================== */
#define ALK_EE_MAGIC_ADDR     0x520u
#define ALK_EE_DATA_ADDR      0x521u
#define ALK_EE_CRC_ADDR       0x526u
#define ALK_EE_MAGIC          0xCEu
#define ALK_EE_DATA_LEN       5u
#define ALK_SAVE_INTERVAL_MIN 5u

/* ==================== 内部状态 ==================== */
static uint8_t  s_last_r[2];      /* 最后已上报结果码 */
static uint8_t  s_last_t[2];      /* 最后已上报温度状态 */
static uint8_t  s_streak[2];      /* 连续全正常次数 */
static uint8_t  s_volt_latched;   /* 电压锁 (1=已上报电压告警) */
static uint8_t  s_volt_streak;    /* 电压连续正常次数 */
static uint8_t  s_dirty;          /* RAM 有变化待落盘 */
static uint16_t s_last_save_min;  /* 上次落盘的"当日分钟" (0xFFFF=从未保存) */

/* ==================== CRC8 (poly 0x07, 与历史记录一致) ==================== */
static uint8_t alk_crc8(const uint8_t *data, uint16_t len)
{
    uint8_t crc = 0x00;
    uint16_t i;
    uint8_t  b;

    for(i = 0; i < len; i++)
    {
        crc ^= data[i];
        for(b = 0; b < 8u; b++)
            crc = (crc & 0x80u) ? (uint8_t)((crc << 1) ^ 0x07u) : (uint8_t)(crc << 1);
    }
    return crc;
}

/* 当日分钟 (0~1439); RTC 非法值时裁剪, 仅用于写入节流 */
static uint16_t alk_now_min(void)
{
    uint32_t hhmmss = rtc_get_hhmmss();
    uint16_t hh = (uint16_t)(hhmmss / 10000u);
    uint16_t mm = (uint16_t)((hhmmss / 100u) % 100u);

    if(hh > 23u) hh = (uint16_t)(hh % 24u);
    if(mm > 59u) mm = 59u;
    return (uint16_t)(hh * 60u + mm);
}

static uint8_t alk_r_valid(uint8_t v)
{
    return (v <= (uint8_t)THRESHOLD_VOLT_LOW &&
            !alarm_lock_is_volt_code((ThresholdResult_t)v)) ? 1u : 0u;
}

static uint8_t alk_t_valid(uint8_t v)
{
    return (v <= (uint8_t)TEMP_VERY_LOW) ? 1u : 0u;
}

static void alk_reset_ch(uint8_t ch)
{
    s_last_r[ch] = (uint8_t)THRESHOLD_OK;
    s_last_t[ch] = (uint8_t)TEMP_NORMAL;
    s_streak[ch] = 0;
}

/* ==================== 初始化 ==================== */
void alarm_lock_init(void)
{
    uint8_t magic = 0;
    uint8_t buf[ALK_EE_DATA_LEN + 1u];   /* 5B 锁数据 + 1B CRC */
    uint8_t valid = 0;

    /* 先从 RAM 复位, EEPROM 无效时即为默认值 */
    alk_reset_ch(0);
    alk_reset_ch(1);
    s_volt_latched = 0;
    s_volt_streak  = 0;
    s_dirty        = 0;
    s_last_save_min = 0xFFFFu;

    if(EE_READ(ALK_EE_MAGIC_ADDR, &magic, 1u) == 0 && magic == ALK_EE_MAGIC)
    {
        if(EE_READ(ALK_EE_DATA_ADDR, buf, sizeof(buf)) == 0 &&
           alk_crc8(buf, ALK_EE_DATA_LEN) == buf[ALK_EE_DATA_LEN])
        {
            valid = 1;
        }
    }

    if(valid)
    {
        s_last_r[0] = alk_r_valid(buf[0]) ? buf[0] : (uint8_t)THRESHOLD_OK;
        s_last_r[1] = alk_r_valid(buf[1]) ? buf[1] : (uint8_t)THRESHOLD_OK;
        s_last_t[0] = alk_t_valid(buf[2]) ? buf[2] : (uint8_t)TEMP_NORMAL;
        s_last_t[1] = alk_t_valid(buf[3]) ? buf[3] : (uint8_t)TEMP_NORMAL;
        s_volt_latched = (buf[4] != 0u) ? 1u : 0u;
        printf_debug("[ALK] init: restore r=%d/%d t=%d/%d volt=%d\r\n",
                     s_last_r[0], s_last_r[1], s_last_t[0], s_last_t[1], s_volt_latched);
    }
    else
    {
        printf_debug("[ALK] init: no valid lock, cleared\r\n");
    }

    /* 单路机型: 通道1锁位强制清零 (raw2 为陈旧值, 不参与判定) */
    if(!alarm_lock_ch_enabled(1))
    {
        alk_reset_ch(1);
        s_dirty = 1;   /* 让下一次正常采样把通道1清掉 */
    }
}

/* ==================== 通道锁 ==================== */
uint8_t alarm_lock_ch_enabled(uint8_t ch)
{
    if(ch == 0u) return 1u;
    if(ch == 1u) return (g_sensor_count >= 2u) ? 1u : 0u;
    return 0u;
}

uint8_t alarm_lock_has_new(uint8_t ch, ThresholdResult_t r, TempStatus_t ts)
{
    if(!alarm_lock_ch_enabled(ch)) return 0u;

    if(r != THRESHOLD_OK && !alarm_lock_is_volt_code(r) &&
       (uint8_t)r != s_last_r[ch])
        return 1u;

    if(ts != TEMP_NORMAL && (uint8_t)ts != s_last_t[ch])
        return 1u;

    return 0u;
}

void alarm_lock_latch(uint8_t ch, ThresholdResult_t r, TempStatus_t ts)
{
    if(!alarm_lock_ch_enabled(ch))
    {
        alk_reset_ch(ch);
        return;
    }

    if(r != THRESHOLD_OK && !alarm_lock_is_volt_code(r))
        s_last_r[ch] = (uint8_t)r;

    s_last_t[ch] = (uint8_t)ts;
    s_streak[ch] = 0;    /* 异常拍打断恢复计数 */
    s_dirty      = 1;
}

uint8_t alarm_lock_feed_normal(uint8_t ch, uint8_t online,
                               ThresholdResult_t r, TempStatus_t ts)
{
    if(!alarm_lock_ch_enabled(ch))
    {
        alk_reset_ch(ch);
        return 0u;
    }

    if(!online || r != THRESHOLD_OK || ts != TEMP_NORMAL)
    {
        s_streak[ch] = 0;
        return 0u;
    }

    /* 未锁等级时无需恢复流程 */
    if(s_last_r[ch] == (uint8_t)THRESHOLD_OK && s_last_t[ch] == (uint8_t)TEMP_NORMAL)
    {
        s_streak[ch] = 0;
        return 0u;
    }

    if(s_streak[ch] < ALARM_LOCK_CLEAR_COUNT)
        s_streak[ch]++;

    if(s_streak[ch] >= ALARM_LOCK_CLEAR_COUNT)
    {
        alk_reset_ch(ch);
        s_dirty = 1;
        printf_debug("[ALK] unlocked ch%d (%u/%u normal)\r\n",
                     ch, ALARM_LOCK_CLEAR_COUNT, ALARM_LOCK_CLEAR_COUNT);
        return 1u;
    }
    return 0u;
}

/* ==================== 电压锁 ==================== */
uint8_t alarm_lock_volt_has_new(ThresholdResult_t r)
{
    return (alarm_lock_is_volt_code(r) && !s_volt_latched) ? 1u : 0u;
}

void alarm_lock_volt_latch(void)
{
    if(!s_volt_latched)
    {
        s_volt_latched = 1u;
        s_volt_streak  = 0;
        s_dirty        = 1;
        printf_debug("[ALK] volt latched\r\n");
    }
}

uint8_t alarm_lock_volt_feed_normal(ThresholdResult_t r, uint8_t voltage_checked)
{
    if(!voltage_checked)
        return 0u;                 /* 本路径未做电压判定: 不触碰电压锁 */

    if(alarm_lock_is_volt_code(r))
    {
        s_volt_streak = 0;
        return 0u;
    }

    if(!s_volt_latched)
    {
        s_volt_streak = 0;
        return 0u;
    }

    if(s_volt_streak < ALARM_LOCK_CLEAR_COUNT)
        s_volt_streak++;

    if(s_volt_streak >= ALARM_LOCK_CLEAR_COUNT)
    {
        s_volt_latched = 0u;
        s_volt_streak  = 0u;
        s_dirty        = 1;
        printf_debug("[ALK] volt unlocked\r\n");
        return 1u;
    }
    return 0u;
}

/* ==================== 查询/清空 ==================== */
uint8_t alarm_lock_any(void)
{
    if(s_volt_latched) return 1u;
    if(s_last_r[0] != (uint8_t)THRESHOLD_OK || s_last_t[0] != (uint8_t)TEMP_NORMAL) return 1u;
    if(s_last_r[1] != (uint8_t)THRESHOLD_OK || s_last_t[1] != (uint8_t)TEMP_NORMAL) return 1u;
    return 0u;
}

uint8_t alarm_lock_ch_latched(uint8_t ch)
{
    if(!alarm_lock_ch_enabled(ch)) return 0u;
    return (s_last_r[ch] != (uint8_t)THRESHOLD_OK ||
            s_last_t[ch] != (uint8_t)TEMP_NORMAL) ? 1u : 0u;
}

void alarm_lock_clear_all(void)
{
    alk_reset_ch(0);
    alk_reset_ch(1);
    s_volt_latched = 0u;
    s_volt_streak  = 0u;
    printf_debug("[ALK] clear all (manual override)\r\n");
    alarm_lock_save(1u);           /* 手动清锁: 立即持久化 */
}

/* ==================== 持久化 ==================== */
static uint8_t alk_save_due(void)
{
    uint16_t now;

    if(s_last_save_min == 0xFFFFu) return 1u;
    now = alk_now_min();
    return ((uint16_t)((now + 1440u - s_last_save_min) % 1440u) >= ALK_SAVE_INTERVAL_MIN) ? 1u : 0u;
}

void alarm_lock_save(uint8_t force)
{
    uint8_t buf[ALK_EE_DATA_LEN + 1u];

    if(!force && !s_dirty) return;
    if(!force && !alk_save_due()) return;

    buf[0] = s_last_r[0];
    buf[1] = s_last_r[1];
    buf[2] = s_last_t[0];
    buf[3] = s_last_t[1];
    buf[4] = s_volt_latched;
    buf[5] = alk_crc8(buf, ALK_EE_DATA_LEN);

    if(EE_WRITE(ALK_EE_DATA_ADDR, buf, sizeof(buf)) != 0)
    {
        printf_debug("[ALK] save failed (data)\r\n");
        return;
    }
    if(EE_WRITE_BYTE(ALK_EE_MAGIC_ADDR, ALK_EE_MAGIC) != 0)
    {
        printf_debug("[ALK] save failed (magic)\r\n");
        return;
    }

    s_dirty         = 0;
    s_last_save_min = alk_now_min();
    printf_debug("[ALK] saved: r=%d/%d t=%d/%d volt=%d\r\n",
                 s_last_r[0], s_last_r[1], s_last_t[0], s_last_t[1], s_volt_latched);
}

#ifndef ALARM_LOCK_H
#define ALARM_LOCK_H

#include <stdint.h>
#include "threshold.h"

/* ==================== 告警锁 / 恢复去抖 (Middle/alarm_lock.c) ====================
 * 设计要点:
 *   1) 每通道记录"最后一次已上报的等级"(压力/温度结果码 + 温度状态码):
 *        与最后已上报等级不同 → 视为新告警(升级/降级都报); 相同 → 不报。
 *   2) 恢复去抖: 该通道在线且 r==OK 且 temp==NORMAL 连续 ALARM_LOCK_CLEAR_COUNT 次
 *        → 清空该通道最后等级并返回 1 (由调用方上报一次恢复)。
 *        任意一次异常/离线 → 计数归零; 单次正常不清锁。
 *   3) 电压类结果码(VPROTECT/VOLT_HIGH/VOLT_LOW)不进入通道锁, 用独立的 1 bit 电压锁 +
 *      独立恢复计数; 只有真正做了电压判定的路径才能置位/清除。
 *   4) 锁持久化到 EEPROM (0x520, 7B: magic+5B+CRC8), 写入节流(>=5min) + dirty + 正常采样 flush;
 *      手动清锁立即写入; 不走 config_save_ext() 以免重写整个 EXT 区块。
 * ================================================================================= */

#define ALARM_LOCK_CLEAR_COUNT   3u   /* 连续全正常次数 → 解锁 */

/* 电压类结果码: 不进入通道锁 */
static inline uint8_t alarm_lock_is_volt_code(ThresholdResult_t r)
{
    return (r == THRESHOLD_VPROTECT ||
            r == THRESHOLD_VOLT_HIGH ||
            r == THRESHOLD_VOLT_LOW) ? 1u : 0u;
}

/* 上电读取锁 (config_load_all / rtc_init_all 之后调用) */
void    alarm_lock_init(void);

/* 清空所有锁与恢复计数并立即持久化 (用户手动开阀时调用) */
void    alarm_lock_clear_all(void);

/* 通道是否启用: ch0 恒启用; ch1 仅在 g_sensor_count>=2 时启用 (未启用通道锁位强制清零) */
uint8_t alarm_lock_ch_enabled(uint8_t ch);

/* 本次等级是否为"新等级"(与最后已上报不同); 电压码不参与通道判定 */
uint8_t alarm_lock_has_new(uint8_t ch, ThresholdResult_t r, TempStatus_t ts);

/* 记录该通道最后已上报等级 (确认报警后调用; 未启用通道自动清零) */
void    alarm_lock_latch(uint8_t ch, ThresholdResult_t r, TempStatus_t ts);

/* 恢复计数: 离线/异常 → 归零; 在线全正常 → +1; 达到 3 次且该通道有等级 → 清零并返回 1 */
uint8_t alarm_lock_feed_normal(uint8_t ch, uint8_t online,
                               ThresholdResult_t r, TempStatus_t ts);

/* 电压锁: 是否为新电压告警 / 置位 / 恢复计数(voltage_checked=0 时不触碰) */
uint8_t alarm_lock_volt_has_new(ThresholdResult_t r);
void    alarm_lock_volt_latch(void);
uint8_t alarm_lock_volt_feed_normal(ThresholdResult_t r, uint8_t voltage_checked);

/* 是否存在任一已锁等级 (通道/电压) */
uint8_t alarm_lock_any(void);

/* 该通道当前是否有已锁等级 */
uint8_t alarm_lock_ch_latched(uint8_t ch);

/* 持久化 (force=0: dirty + 5min 节流; force=1: 立即写) */
void    alarm_lock_save(uint8_t force);

#endif /* ALARM_LOCK_H */

/**
 * @file downlink.c
 * @brief MQTT下行指令处理模块 (优化版)
 * @details 负责接收处理云平台下发的MQTT消息, 执行对应指令并上报结果
 */

#include "downlink.h"
#include "report.h"
#include "ec800e.h"
#include "eeprom_config.h"
#include "calib_mode.h"
#include "valve_timing.h"
#include "app_config.h"
#include "threshold.h"
#include "sensor_record.h"
#include "PT_304_35.h"
#include "main.h"
#include "alarm_lock.h"
#include "adc_bat.h"
#include "ota_app.h"
#include "valve.h"
#include "usart.h"
#include "delay.h"
#include "tim.h"
#include "json_builder.h"
#include "gd32l23x.h"
#include "leak_task.h"
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <stddef.h>

// ==================== 跨模块外部变量 (定义在main.c) ====================
extern uint8_t fourG_user_off;
extern uint8_t g_need_adc_sampling;
extern volatile uint8_t g_ch4_request;

// ==================== 模块内静态缓冲区 ====================
static char json_buf[1024];
static char ts_buf[32];
static JsonBuilder jb;

// ==================== 内部: JSON字段提取 ====================
static int extract_json_field(const char *buf, const char *field, char *out, uint16_t out_size)
{
    char *p;
    char *q;
    char *r;
    uint16_t len;

    out[0] = '\0';
    p = strstr(buf, field);
    if(!p) return 0;
    q = strchr(p + strlen(field), '"');
    if(!q) return 0;
    q++;
    r = strchr(q, '"');
    if(!r) return 0;
    len = (uint16_t)(r - q);
    if(len >= out_size) len = out_size - 1;
    memcpy(out, q, len);
    out[len] = '\0';
    return (len > 0) ? 1 : 0;
}

// 提取 "key","value":"xxx" 格式字段值 (平台 set 指令格式)
static int extract_key_value(const char *buf, const char *key, char *out, uint16_t out_size)
{
    char pat[64];
    char *p;
    char *q;
    uint16_t len;

    out[0] = '\0';
    snprintf(pat, sizeof(pat), "\"%s\",\"value\"", key);
    p = strstr(buf, pat);
    if(!p) return 0;
    p += strlen(pat);
    if(*p == ':') p++;
    if(*p != '"') return 0;
    p++;
    q = strchr(p, '"');
    if(!q) return 0;
    len = (uint16_t)(q - p);
    if(len >= out_size) len = out_size - 1;
    memcpy(out, p, len);
    out[len] = '\0';
    return (len > 0) ? 1 : 0;
}

// ==================== commandStr 映射表 ====================
typedef struct {
    const char *cmd_str;     // commandStr 值
    const char *id;          // 映射到 id_val
    const char *value;       // 固定值, NULL 表示从 raw_buf 提取
    const char *extract;     // 提取字段名 (value 为 NULL 时使用)
} CmdMap;

static const CmdMap s_cmd_map[] = {
    {"valve-open",        "valve",           "open",  NULL},
    {"valve-close",       "valve",           "close", NULL},
    {"get-pressure",      "get_pressure",    "1",     NULL},
    {"get-pressure1",     "get_pressure",    "1",     NULL},
    {"get-sim",           "get_sim",         "1",     NULL},
    {"get-ip",            "get_ip",          "1",     NULL},
    {"sensor-status",     "sensor_status",   "1",     NULL},
    {"restart",           "restart",         "1",     NULL},
    {"restart-off",       "restart_off",     "1",     NULL},
    {"4Gpower-off",       "4Gpower_off",     "1",     NULL},
    {"temp-get1",         "temp_status",     "1",     NULL},
    {"temp-get2",         "temp_status2",    "1",     NULL},
    {"LY06-get",          "LY06_get",        "1",     NULL},
    {"gas-get",           "gas_get",         "1",     NULL},
    {"laser-get",         "laser_get",       "",      NULL},
    {"laser-set",         "laser_set",       NULL,    "laser_switch"},
    {"msh-get",           "msh_get",         "",      NULL},
    {"msh-set",           "msh_set",         NULL,    "msh_threshold"},
    {"get-pressure2",     "get_pressure2",   "1",     NULL},
    {"threshold-get1",    "threshold",       "",      NULL},
    {"collectcycle-get",  "collect_cycle",   "",      NULL},
    {"report-get",        "report_cycle",    "",      NULL},
    {"window-get",        "window_pattern",  "",      NULL},
    {"abnormal-get",      "abnormal_close",  "",      NULL},
    {"abnormal2-get",     "abnormal2_close", "",      NULL},
    {"abnormal3-get",     "abnormal3_close", "",      NULL},
    {"first-ip-get",      "get_ip",          "1",     NULL},
    {"scend-ip-get",      "get_scend_ip",    "1",     NULL},
    {"valve-last-get",    "valve_last_order","1",     NULL},
    {"real-get",          "real_get",        "",      NULL},
    {"user-ip-get",       "user_ip_get",     "1",     NULL},
    {"MQTT-get",          "user_mqtt_get",   "1",     NULL},
    // 带参数提取的命令
    {"collectspeed-set",  "collect_cycle",   NULL,    "collect_once"},
    {"report-set",        "report_cycle",    NULL,    "report_once"},
    {"window-set",        "window_pattern",  NULL,    "window_pattern"},
    {"abnormal-set",      "abnormal_close",  NULL,    "abnormal_close"},
    {"abnormal2-set",     "abnormal2_close", NULL,    "abnormal2_close"},
    {"abnormal3-set",     "abnormal3_close", NULL,    "abnormal3_close"},
    {"first-ip-set",      "first_ip_set",    NULL,    "first-ip"},
    {"scend-ip-set",      "scend_ip_set",    NULL,    "scend-ip"},
    {"real-set",          "real_set",        NULL,    "real_enabled"},
    {"install-status-set","install_status_set",NULL,  "install_status"},
    {"user-ip-set",       "user_ip_set",     NULL,    "user-ip"},
    {"MQTT-set",          "user_mqtt_set",   "1",     NULL},
    // 阈值 set/get
    {"vpthreshold-set1",  "vpthreshold",     "1",     NULL},
    {"vpthreshold-get1",  "vpthreshold",     "",      NULL},
    {"Tthreshold-set",    "Tthreshold",      "1",     NULL},
    {"Tthreshold-get",    "Tthreshold",      "",      NULL},
    {"spupower-set",      "spupower",        "1",     NULL},
    {"spupower-get",      "spupower",        "",      NULL},
    {"delay-set",         "delay",           "1",     NULL},
    {"delay-get",         "delay",           "",      NULL},
    {"vpthreshold-set2",  "vpthreshold2",    "1",     NULL},
    {"vpthreshold-get2",  "vpthreshold2",    "",      NULL},
    {"Tthreshold-set2",   "Tthreshold2",     "1",     NULL},
    {"Tthreshold-get2",   "Tthreshold2",     "",      NULL},
    {"lcd-switch",        "lcd_switch",      NULL,    "lcd_switch"},
    // 阀门及定时开关
    {"valve-get",         "valve_status",    "1",     NULL},
    {"closeoropen-get",   "closeoropen",     "",      NULL},
    {"closeoropen-set",   "closeoropen",     "1",     NULL},
    // 表号
    {"table-get",         "table",           "",      NULL},
    {"table-set",         "table",           NULL,    "table"},
};
#define CMD_MAP_COUNT (sizeof(s_cmd_map) / sizeof(s_cmd_map[0]))

// ==================== 通用辅助函数 ====================

// 采集所有传感器
static void collect_all_sensors(void)
{
    PT304D_CollectAll((g_sensor_count >= 2) ? &g_sensor.raw2 : NULL, &g_sensor.raw);
}

// ==================== 取数指令公共安全检查 (协议 6.6 ~ 6.9 统一) ====================
/* 三条路径共用 Middle/alarm_lock.c 的"告警锁": 与最后已上报等级不同才算新告警。
 * 查询路径的职责:
 *   - 可以"锁上新等级"(否则平台每次轮询都会重复报);
 *   - 不推进通道恢复计数 (避免一轮 6.6~6.9 轮询把 3 次恢复计数凑满);
 *   - 电压用独立锁: 只判"是否新电压告警"并随报警补发 LY06, 不推进其恢复计数。 */
static uint8_t run_full_threshold_check(void)
{
    float prev_p1, prev_p2;
    ThresholdResult_t r1, r2, result;
    ThresholdResult_t rv;
    uint8_t i;
    uint8_t mask;
    uint8_t volt_new;
    uint8_t online0, online1;
    uint8_t still_abnormal = 1;
    AlarmConfirmCtx_t ctx;

    /* 离线通道不参与阈值检查: 两路都离线才整条查询路径跳过;
     * 单路在线时只判在线的那一路 (驱动失败会写哨兵 -1000Pa/-50C, 绝不能进阈值) */
    online0 = (g_sensor.raw.err == PT304D_OK) ? 1u : 0u;
    online1 = (g_sensor_count >= 2 && g_sensor.raw2.err == PT304D_OK) ? 1u : 0u;
    if(!online0 && !online1)
    {
        printf_debug("[SM] QUERY CHK: both sensors offline, skip threshold check\r\n");
        return 0;
    }

    /* 上拍值快照: 首次检查与重采确认期间保持不变, 结束时统一更新 */
    prev_p1 = g_sensor.last_pressure_collect;
    prev_p2 = g_sensor.last_pressure_collect2;

    /* 电压: 新鲜采样 (ADC 失败回退上次正常值); 仅用于 LY06 判据 + 电压锁,
     * 不参与 threshold_check (避免 VPROTECT 抢占压力/温度报警优先级) */
    {
        float v_now = adc_bat_read_voltage();
        g_sensor.voltage = (v_now >= 0.0f) ? v_now : g_sensor.last_normal_voltage;
    }
    rv = (threshold_voltage_alarm(g_sensor.voltage) == 1) ? THRESHOLD_VPROTECT : THRESHOLD_OK;
    volt_new = alarm_lock_volt_has_new(rv);

    /* 首次检查: 在线通道全项 (压力/温度/压力骤变); 离线通道 r 置 OK */
    r1 = online0 ? threshold_check(g_sensor.raw.pressure, g_sensor.raw.temperature,
                                   g_sensor.voltage, prev_p1, 0, 0) : THRESHOLD_OK;
    r2 = online1 ? threshold_check2(g_sensor.raw2.pressure, g_sensor.raw2.temperature,
                                    prev_p2, 0) : THRESHOLD_OK;
    result = (r1 != THRESHOLD_OK) ? r1 : r2;

    /* 新等级判定 (只读锁, 不推进恢复计数) */
    mask = alarm_new_mask(r1, r2, 0);

    if(mask == 0)
    {
        if(result != THRESHOLD_OK)
            printf_debug("[SM] QUERY CHK: same level as last reported, skip\r\n");
        /* 上报去重 ≠ 不动作: 等级已报过也按当前策略补一次关阀 (幂等; 平台改策略后轮询即生效) */
        (void)alarm_safety_close_now(r1, r2, online0, online1);
        sensor_baseline_update_collect();
        return 0;
    }

    /* 3 次重采确认异常 (任一拍恢复正常即判偶发; 骤变基准固定为进入时的上拍值) */
    printf_debug("[SM] QUERY CHK: abnormal(%d, mask=0x%02X), rechecking %d times...\r\n",
                 (int)result, mask, APP_ALARM_RECHECK_COUNT);
    for(i = 0; i < APP_ALARM_RECHECK_COUNT; i++)
    {
        trea_delay_ms(APP_ALARM_RECHECK_DELAY_MS);
        PT304D_CollectAll((g_sensor_count >= 2) ? &g_sensor.raw2 : NULL, &g_sensor.raw);

        /* 每拍重算在线状态 (重采期间可能掉线); 离线通道不参与判定 */
        online0 = (g_sensor.raw.err == PT304D_OK) ? 1u : 0u;
        online1 = (g_sensor_count >= 2 && g_sensor.raw2.err == PT304D_OK) ? 1u : 0u;
        r1 = online0 ? threshold_check(g_sensor.raw.pressure, g_sensor.raw.temperature,
                                       g_sensor.voltage, prev_p1, 0, 0) : THRESHOLD_OK;
        r2 = online1 ? threshold_check2(g_sensor.raw2.pressure, g_sensor.raw2.temperature,
                                        prev_p2, 0) : THRESHOLD_OK;
        result = (r1 != THRESHOLD_OK) ? r1 : r2;

        printf_debug("[SM] QUERY CHK recheck %d/%d: P1=%.2f T1=%.2f P2=%.2f T2=%.2f result=%d\r\n",
                     i + 1, APP_ALARM_RECHECK_COUNT,
                     g_sensor.raw.pressure, g_sensor.raw.temperature,
                     g_sensor.raw2.pressure, g_sensor.raw2.temperature, (int)result);

        if(result == THRESHOLD_OK)
        {
            still_abnormal = 0;
            printf_debug("[SM] QUERY CHK: recovered at recheck %d, false alarm\r\n", i + 1);
            break;
        }
    }

    if(!still_abnormal)
    {
        sensor_baseline_update_collect();
        return 0;
    }

    /* 确认异常: 用重采后的最终等级再判一次新告警 (等级可能已变化) */
    mask = alarm_new_mask(r1, r2, 0);
    rv = (threshold_voltage_alarm(g_sensor.voltage) == 1) ? THRESHOLD_VPROTECT : THRESHOLD_OK;
    volt_new = alarm_lock_volt_has_new(rv);

    if(mask != 0)
    {
        /* 统一确认+上报: 记录锁 → 关阀 → 批量/电压/阀门状态报文 (追加在指令应答之后) */
        ctx.check_voltage = 0;   /* threshold_check 未做电压判定: 不使用 mask bit2 */
        ctx.sensor_err    = 0;
        ctx.volt_new      = volt_new;
        ctx.tag           = "QRY";
        (void)alarm_confirm_and_report(&ctx, mask, r1, r2, prev_p1, prev_p2);
    }
    else
    {
        printf_debug("[SM] QUERY CHK: level already reported, skip\r\n");
    }

    /* 统一更新上拍值 (所有出口: 去重跳过 / 偶发恢复 / 确认异常) */
    sensor_baseline_update_collect();

    return (mask != 0) ? 1u : 0u;
}

// 双重JSON字段提取: 先查短格式 "key", 再查长格式 "key","value"
static int extract_field_dual(const char *raw_buf, const char *key_short,
                              const char *key_long, char *out, uint16_t out_size)
{
    char key1[48];
    char pat[64];
    snprintf(key1, sizeof(key1), "\"%s\"", key_short);
    if(extract_json_field(raw_buf, key1, out, out_size))
        return 1;
    snprintf(pat, sizeof(pat), "\"%s\",\"value\"", key_long);
    return extract_json_field(raw_buf, pat, out, out_size);
}

// 解析 "IP.port" 字符串 (按最后一个'.'分割)
static int parse_ip_port(const char *str, char *ip_out, uint16_t *port_out)
{
    char buf[MQTT_FIELD_MAX];
    char *dot;
    strncpy(buf, str, sizeof(buf) - 1);
    buf[sizeof(buf) - 1] = '\0';
    dot = strrchr(buf, '.');
    if(!dot) return 0;
    *dot = '\0';
    *port_out = (uint16_t)atoi(dot + 1);
    strncpy(ip_out, buf, MQTT_FIELD_MAX - 1);
    ip_out[MQTT_FIELD_MAX - 1] = '\0';
    return 1;
}

// 发布JSON并延时+反馈
static void publish_json_df(int fb_code)
{
    jb_end(&jb);
    EC801E_PublishRawJson(json_buf);
    trea_delay_ms(300);
    report_publish_feedback(fb_code);
}

// 仅发布JSON (无延时无反馈)
static void publish_json_only(void)
{
    jb_end(&jb);
    EC801E_PublishRawJson(json_buf);
}

// ==================== 阈值表驱动处理 ====================
typedef enum { FT_U8_BOOL, FT_FLOAT, FT_U16_CLAMP } ThrFieldType;

typedef struct {
    const char  *name;          // 字段名后缀 (如 "switch", "ppmax")
    uint16_t     offset;        // 结构体内偏移量
    ThrFieldType type;
    uint16_t     clamp_max;     // FT_U16_CLAMP时的最大值
} ThrField;

typedef struct {
    const char     *prefix;     // 字段前缀 (如 "vpthreshold")
    void           *config;     // 配置结构体指针
    const ThrField *fields;
    uint8_t         field_count;
    void          (*save_fn)(void);
    uint8_t         use_float1; // 1=jb_add_float1, 0=jb_add_float
    uint8_t         has_guard;  // 1=需要cmd_val非空守卫
    uint8_t         fb_set;     // set成功反馈码
    uint8_t         fb_get;     // get反馈码
} ThrGroup;

// 各阈值字段表
static const ThrField vp_fields[] = {
    {"switch",  offsetof(PressureThresholdConfig_t, enabled),  FT_U8_BOOL,   0},
    {"ppmax",   offsetof(PressureThresholdConfig_t, ppmax),     FT_FLOAT,     0},
    {"pmax",    offsetof(PressureThresholdConfig_t, pmax),      FT_FLOAT,     0},
    {"ppmin",   offsetof(PressureThresholdConfig_t, ppmin),     FT_FLOAT,     0},
    {"pmin",    offsetof(PressureThresholdConfig_t, pmin),      FT_FLOAT,     0},
    {"mutation",offsetof(PressureThresholdConfig_t, mutation), FT_FLOAT,     0},
    {"shock",   offsetof(PressureThresholdConfig_t, shock),     FT_FLOAT,     0},
};

static const ThrField tt_fields[] = {
    {"switch", offsetof(TempThresholdConfig_t, enabled), FT_U8_BOOL, 0},
    {"high",   offsetof(TempThresholdConfig_t, high),    FT_FLOAT,   0},
    {"low",    offsetof(TempThresholdConfig_t, low),     FT_FLOAT,   0},
    {"vhigh",  offsetof(TempThresholdConfig_t, vhigh),   FT_FLOAT,   0},
    {"vlow",   offsetof(TempThresholdConfig_t, vlow),    FT_FLOAT,   0},
};

static const ThrField sp_fields[] = {
    {"switch",  offsetof(VoltagePowerConfig_t, enabled), FT_U8_BOOL, 0},
    {"high",    offsetof(VoltagePowerConfig_t, high),    FT_FLOAT,   0},
    {"low",     offsetof(VoltagePowerConfig_t, low),     FT_FLOAT,   0},
    {"protect", offsetof(VoltagePowerConfig_t, protect), FT_FLOAT,   0},
};

static const ThrField vd_fields[] = {
    {"switch", offsetof(ValveDelayConfig_t, enabled),  FT_U8_BOOL,   0},
    {"time",   offsetof(ValveDelayConfig_t, delay_ms), FT_U16_CLAMP, VDLY_DELAY_MS_MAX},
};

// 阈值组定义表
static const ThrGroup thr_groups[] = {
    {"vpthreshold",  &g_pthreshold,  vp_fields, 7, config_save_vpthreshold,  0, 0, 8, 7},
    {"Tthreshold",   &g_tthreshold,  tt_fields, 5, config_save_tthreshold,  0, 0, 6, 5},
    {"spupower",     &g_spupower,    sp_fields, 4, config_save_spupower,    0, 0, 16, 15},
    {"delay",        &g_vdelay,      vd_fields, 2, config_save_vdelay,      0, 0, 20, 19},
    {"vpthreshold2", &g_pthreshold2, vp_fields, 7, config_save_vpthreshold2, 1, 1, 8, 7},
    {"Tthreshold2",  &g_tthreshold2, tt_fields, 5, config_save_tthreshold2, 1, 1, 6, 5},
};
#define THR_GROUP_COUNT (sizeof(thr_groups) / sizeof(thr_groups[0]))

// 发布阈值组当前值
static void publish_threshold_group(const ThrGroup *grp)
{
    uint8_t i;
    rtc_get_time_str(ts_buf, sizeof(ts_buf));
    jb_begin(&jb, json_buf, sizeof(json_buf));
    for(i = 0; i < grp->field_count; i++)
    {
        const ThrField *f = &grp->fields[i];
        char key[48];
        uint8_t *p = (uint8_t*)grp->config + f->offset;
        snprintf(key, sizeof(key), "%s_%s", grp->prefix, f->name);
        switch(f->type)
        {
            case FT_U8_BOOL:
                jb_add_int(&jb, key, *(uint8_t*)p, ts_buf);
                break;
            case FT_U16_CLAMP:
                jb_add_int(&jb, key, *(uint16_t*)p, ts_buf);
                break;
            case FT_FLOAT:
                if(grp->use_float1)
                    jb_add_float1(&jb, key, *(float*)p, ts_buf);
                else
                    jb_add_float(&jb, key, *(float*)p, ts_buf);
                break;
        }
    }
    jb_end(&jb);
    EC801E_PublishRawJson(json_buf);
}

// 处理阈值 set/get
static void process_threshold(const ThrGroup *grp, const char *cmd_val, const char *raw_buf)
{
    char tv[16];
    int changed = 0;
    int do_set = !grp->has_guard || (cmd_val[0] != '\0');

    if(do_set)
    {
        uint8_t i;
        for(i = 0; i < grp->field_count; i++)
        {
            const ThrField *f = &grp->fields[i];
            char key[48];
            uint8_t *p = (uint8_t*)grp->config + f->offset;
            snprintf(key, sizeof(key), "%s_%s", grp->prefix, f->name);
            if(extract_key_value(raw_buf, key, tv, sizeof(tv)))
            {
                switch(f->type)
                {
                    case FT_U8_BOOL:
                        *p = (uint8_t)atoi(tv);
                        if(*p > 1) *p = 0;
                        break;
                    case FT_FLOAT:
                        *(float*)p = (float)atof(tv);
                        break;
                    case FT_U16_CLAMP:
                    {
                        uint32_t v = (uint32_t)atoi(tv);
                        if(v > f->clamp_max) v = f->clamp_max;
                        *(uint16_t*)p = (uint16_t)v;
                        break;
                    }
                }
                changed = 1;
            }
        }
        if(changed || grp->has_guard)
        {
            grp->save_fn();
            printf_debug("[SM] %s updated\r\n", grp->prefix);
        }
    }

    if(EC801E_EnsureConnected() == EC_OK)
    {
        publish_threshold_group(grp);
        trea_delay_ms(300);
        if(grp->has_guard)
            report_publish_feedback(do_set ? grp->fb_set : grp->fb_get);
        else
            report_publish_feedback(changed ? grp->fb_set : grp->fb_get);
    }
}




// ==================== 指令处理函数 (每个分支一个handler, 表驱动) ====================
static void h_valve(const char *id_val, const char *cmd_val, const char *raw_buf)
{
// ---- 阀门控制 ----
        const char *result = valve_execute(cmd_val, 1);
        printf_debug("[SM] Valve result: %s\r\n", result);

        /* 用户手动开阀 → 清告警锁并立即持久化 (手动关阀不清锁) */
        if(strcmp(cmd_val, "open") == 0 || strcmp(cmd_val, "1") == 0)
            alarm_lock_clear_all();

        if(g_valve_alarm_closed)
        {
            g_valve_alarm_closed = 0;
            g_valve_pre_alarm_order = g_valve_pos_state;   /* 关阀前的物理状态 */
            config_save_ext();
            printf_debug("[SM] Valve user override: cleared alarm_closed flag\r\n");
        }
        if(g_ch4_alarm_closed)
        {
            g_ch4_alarm_closed = 0;
            config_save_ext();   // 持久化清除关阀标志, 防止重启后仍处于告警闭锁
            printf_debug("[SM] Valve user override: cleared ch4_alarm_closed flag\r\n");
        }
        g_alarm_recover_reported = 0;   // 手动操作视为新一轮, 恢复上报标志复位

        if(EC801E_EnsureConnected() == EC_OK)
        {
            EC801E_PublishValveStatus(result, g_valve_last_order);
            trea_delay_ms(300);
            report_publish_feedback(23);
        }
        else
            printf_debug("[SM] Valve publish skipped: MQTT not connected\r\n");
}

static void h_sensor_read(const char *id_val, const char *cmd_val, const char *raw_buf)
{
// ---- 即时采集+阈值校验+压力状态上报 ----
        PressureStatus_t ps;
        const char *ps_str;

        collect_all_sensors();
        {
            float v_now = adc_bat_read_voltage();
            g_sensor.voltage = (v_now >= 0.0f) ? v_now : g_sensor.last_normal_voltage;
        }
        printf_debug("[SM] sensor_read: P=%.2f T=%.2f V=%.2f err=%d\r\n",
                     g_sensor.raw.pressure, g_sensor.raw.temperature, g_sensor.voltage, g_sensor.raw.err);

        if(EC801E_EnsureConnected() == EC_OK)
            report_publish_sensor_status();

        ps = threshold_get_pressure_status(g_sensor.raw.pressure, g_sensor.last_pressure_collect);
        ps_str = threshold_pressure_status_str(ps);

        if(EC801E_EnsureConnected() == EC_OK)
        {
            EC801E_PublishSensorData(&g_sensor.raw, g_sensor.voltage);
            rtc_get_time_str(ts_buf, sizeof(ts_buf));
            jb_begin(&jb, json_buf, sizeof(json_buf));
            jb_add_str(&jb, "pressure-status", ps_str, ts_buf);
            publish_json_only();
            trea_delay_ms(300);
            report_publish_feedback(30);   /* 压力状态获取成功 */
        }

        // 公共安全检查: 完整阈值检查 + 去重 + 重采确认 + 关阀 + 报警上报(追加在应答之后)
        // (last_pressure_* 上拍值由该函数统一更新, 保证骤变判定用"上次值")
        run_full_threshold_check();
}

static void h_collect_cycle(const char *id_val, const char *cmd_val, const char *raw_buf)
{
if(cmd_val[0] != '\0')
        {
            char type_buf[16] = {0};
            g_collect_cycle.once = (uint16_t)atoi(cmd_val);
            extract_field_dual(raw_buf, "type", "collect_type", type_buf, sizeof(type_buf));
            if(type_buf[0]) g_collect_cycle.type = cycle_type_from_str(type_buf);
            /* 越界钳制: 防止 (uint16)atoi 静默截断后写入不可执行的大周期 */
            if(cycle_clamp(&g_collect_cycle))
                printf_debug("[SM] collect cycle out of range, clamped to %u*%s\r\n",
                             g_collect_cycle.once, cycle_type_to_str(g_collect_cycle.type));
            g_interval.collect_interval_hours = (float)cycle_to_seconds(&g_collect_cycle) / 3600.0f;
            config_save_interval();
            config_save_ext();
            config_recalc_interval();
            upload_schedule_reset();   /* 周期变更: 重置网格防重锁, 严格等到下一目标 */
            printf_debug("[SM] collect_cycle -> %d*%s\r\n",
                         g_collect_cycle.once, cycle_type_to_str(g_collect_cycle.type));
        }
        if(EC801E_EnsureConnected() == EC_OK)
        {
            rtc_get_time_str(ts_buf, sizeof(ts_buf));
            jb_begin(&jb, json_buf, sizeof(json_buf));
            jb_add_int(&jb, "collect_once", g_collect_cycle.once, ts_buf);
            jb_add_str(&jb, "collect_type", cycle_type_to_str(g_collect_cycle.type), ts_buf);
            publish_json_df(cmd_val[0] != '\0' ? 12 : 11);
        }
}

static void h_report_cycle(const char *id_val, const char *cmd_val, const char *raw_buf)
{
if(cmd_val[0] != '\0')
        {
            char type_buf[16] = {0};
            g_report_cycle.once = (uint16_t)atoi(cmd_val);
            extract_field_dual(raw_buf, "type", "report_type", type_buf, sizeof(type_buf));
            if(type_buf[0]) g_report_cycle.type = cycle_type_from_str(type_buf);
            /* 越界钳制: 防止 (uint16)atoi 静默截断后写入不可执行的大周期 */
            if(cycle_clamp(&g_report_cycle))
                printf_debug("[SM] report cycle out of range, clamped to %u*%s\r\n",
                             g_report_cycle.once, cycle_type_to_str(g_report_cycle.type));
            g_interval.upload_interval_hours = (float)cycle_to_seconds(&g_report_cycle) / 3600.0f;
            config_save_interval();
            config_save_ext();
            config_recalc_interval();
            upload_schedule_reset();   /* 周期变更: 重置网格防重锁, 严格等到下一目标 */
            printf_debug("[SM] report_cycle -> %d*%s\r\n",
                         g_report_cycle.once, cycle_type_to_str(g_report_cycle.type));
        }
        if(EC801E_EnsureConnected() == EC_OK)
        {
            rtc_get_time_str(ts_buf, sizeof(ts_buf));
            jb_begin(&jb, json_buf, sizeof(json_buf));
            jb_add_int(&jb, "report_once", g_report_cycle.once, ts_buf);
            jb_add_str(&jb, "report_type", cycle_type_to_str(g_report_cycle.type), ts_buf);
            publish_json_df(cmd_val[0] != '\0' ? 10 : 9);
        }
}

static void h_vpthreshold(const char *id_val, const char *cmd_val, const char *raw_buf)
{
process_threshold(&thr_groups[0], cmd_val, raw_buf);
}

static void h_tthreshold(const char *id_val, const char *cmd_val, const char *raw_buf)
{
process_threshold(&thr_groups[1], cmd_val, raw_buf);
}

static void h_spupower(const char *id_val, const char *cmd_val, const char *raw_buf)
{
process_threshold(&thr_groups[2], cmd_val, raw_buf);
}

static void h_gas_get(const char *id_val, const char *cmd_val, const char *raw_buf)
{
#if LASER_CH4_ENABLED
    /* 置位CH4采集请求: do_downlink 检测到后进入 STATE_CH4 执行采集+上报 */
    g_ch4_request = 1;
    printf_debug("[SM] gas_get: CH4 collect requested\r\n");
#else
    printf_debug("[SM] gas_get: laser sensor not supported\r\n");
#endif
}

/* 激光甲烷定时采集配置上报: laser_switch + laser_time (协议示例格式)
 * TODO: 平台反馈码待定, 后续在 set/get 成功后调用 report_publish_feedback(fb_code) */
#if LASER_CH4_ENABLED
static void laser_publish_config(void)
{
    char time_str[96] = {0};
    char sw_str[4] = {0};
    window_dottime_to_str(g_laser_time_mask, time_str, sizeof(time_str));
    snprintf(sw_str, sizeof(sw_str), "%d", g_laser_switch);
    rtc_get_time_str(ts_buf, sizeof(ts_buf));
    jb_begin(&jb, json_buf, sizeof(json_buf));
    jb_add_str(&jb, "laser_switch", sw_str, ts_buf);
    jb_add_str(&jb, "laser_time", time_str, ts_buf);
    publish_json_only();
}

static void h_laser_get(const char *id_val, const char *cmd_val, const char *raw_buf)
{
    printf_debug("[SM] laser_get: switch=%d time=%s\r\n",
                 g_laser_switch, (window_dottime_first(g_laser_time_mask) == 0xFF) ? "(none)" : "mask");
    if(EC801E_EnsureConnected() == EC_OK)
    {
        laser_publish_config();
        trea_delay_ms(300);
        report_publish_feedback(33);   /* 激光时间点读取成功 */
    }
}

static void h_laser_set(const char *id_val, const char *cmd_val, const char *raw_buf)
{
    char tv[96] = {0};
    if(extract_key_value(raw_buf, "laser_switch", tv, sizeof(tv)))
    {
        g_laser_switch = (uint8_t)atoi(tv);
        if(g_laser_switch > 1) g_laser_switch = 0;
    }
    if(extract_key_value(raw_buf, "laser_time", tv, sizeof(tv)))
        window_dottime_from_str(tv, g_laser_time_mask);
    config_save_laser();
    printf_debug("[SM] laser_set: switch=%d time=%s\r\n",
                 g_laser_switch, tv);
    if(EC801E_EnsureConnected() == EC_OK)
    {
        laser_publish_config();
        trea_delay_ms(300);
        report_publish_feedback(34);   /* 激光时间点配置成功 */
    }
}
#else
static void h_laser_get(const char *id_val, const char *cmd_val, const char *raw_buf)
{
    printf_debug("[SM] laser_get: laser sensor not supported\r\n");
}

static void h_laser_set(const char *id_val, const char *cmd_val, const char *raw_buf)
{
    printf_debug("[SM] laser_set: laser sensor not supported\r\n");
}
#endif

/* 激光甲烷门限值 (msh_threshold) 获取与配置
 * 反馈码: 35=门限值获取成功, 36=门限值配置成功 */
#if LASER_CH4_ENABLED
static void msh_publish_config(void)
{
    rtc_get_time_str(ts_buf, sizeof(ts_buf));
    jb_begin(&jb, json_buf, sizeof(json_buf));
    jb_add_float(&jb, "msh_threshold", g_ch4_threshold.threshold, ts_buf);
    publish_json_only();
}

static void h_msh_get(const char *id_val, const char *cmd_val, const char *raw_buf)
{
    printf_debug("[SM] msh_get: threshold=%.2f\r\n", g_ch4_threshold.threshold);
    if(EC801E_EnsureConnected() == EC_OK)
    {
        msh_publish_config();
        trea_delay_ms(300);
        report_publish_feedback(35);   /* 甲烷门限值获取成功 */
    }
}

static void h_msh_set(const char *id_val, const char *cmd_val, const char *raw_buf)
{
    char tv[16] = {0};
    if(extract_key_value(raw_buf, "msh_threshold", tv, sizeof(tv)))
    {
        float th = (float)atof(tv);
        /* 非法值(NaN/越界 0~999)回退默认 0.5 */
        if(!(th >= DEF_CH4_THRESHOLD_MIN && th <= DEF_CH4_THRESHOLD_MAX))
            th = DEF_CH4_THRESHOLD;
        g_ch4_threshold.threshold = th;
        config_save_ch4_threshold();
    }
    printf_debug("[SM] msh_set: threshold=%.2f\r\n", g_ch4_threshold.threshold);
    if(EC801E_EnsureConnected() == EC_OK)
    {
        msh_publish_config();
        trea_delay_ms(300);
        report_publish_feedback(36);   /* 甲烷门限值配置成功 */
    }
}
#else
static void h_msh_get(const char *id_val, const char *cmd_val, const char *raw_buf)
{
    printf_debug("[SM] msh_get: laser sensor not supported\r\n");
}

static void h_msh_set(const char *id_val, const char *cmd_val, const char *raw_buf)
{
    printf_debug("[SM] msh_set: laser sensor not supported\r\n");
}
#endif

static void h_threshold(const char *id_val, const char *cmd_val, const char *raw_buf)
{
// 批量阈值查询: 依次发布压力/温度/电压阈值
        if(EC801E_EnsureConnected() == EC_OK)
        {
            publish_threshold_group(&thr_groups[0]);
            trea_delay_ms(300);
            publish_threshold_group(&thr_groups[1]);
            trea_delay_ms(300);
            publish_threshold_group(&thr_groups[2]);
            trea_delay_ms(300);
            report_publish_feedback(5);
        }
}

static void h_delay(const char *id_val, const char *cmd_val, const char *raw_buf)
{
process_threshold(&thr_groups[3], cmd_val, raw_buf);
}

static void h_window_pattern(const char *id_val, const char *cmd_val, const char *raw_buf)
{
if(cmd_val[0] != '\0')
        {
            char tmp[16] = {0};
            strncpy(g_window.pattern, cmd_val, 7); g_window.pattern[7] = '\0';
            if(extract_field_dual(raw_buf, "end_result", "window_end_result", tmp, sizeof(tmp)))
                g_window.end_result = (uint8_t)atoi(tmp);
            if(extract_field_dual(raw_buf, "start", "window_start", tmp, sizeof(tmp)))
            { strncpy(g_window.start, tmp, 7); g_window.start[7] = '\0'; }
            if(extract_field_dual(raw_buf, "stop", "window_stop", tmp, sizeof(tmp)))
            { strncpy(g_window.stop, tmp, 7); g_window.stop[7] = '\0'; }
            if(extract_field_dual(raw_buf, "dottime", "window_dottime", tmp, sizeof(tmp)))
                window_dottime_from_str(tmp, g_window.dottime_mask);
            config_save_ext();
            char dot_str4[64]; window_dottime_to_str(g_window.dottime_mask, dot_str4, sizeof(dot_str4));
            printf_debug("[SM] window: %s er=%d s=%s e=%s dot=%s\r\n",
                         g_window.pattern, g_window.end_result, g_window.start, g_window.stop, dot_str4);
        }
        if(EC801E_EnsureConnected() == EC_OK)
        {
            rtc_get_time_str(ts_buf, sizeof(ts_buf));
            jb_begin(&jb, json_buf, sizeof(json_buf));
            jb_add_str(&jb, "window_pattern", g_window.pattern, ts_buf);
            jb_add_int(&jb, "window_end_result", g_window.end_result, ts_buf);
            jb_add_str(&jb, "window_start", g_window.start, ts_buf);
            jb_add_str(&jb, "window_stop", g_window.stop, ts_buf);
            char dot_str2[64]; window_dottime_to_str(g_window.dottime_mask, dot_str2, sizeof(dot_str2));
            jb_add_str(&jb, "window_dottime", dot_str2, ts_buf);
            publish_json_df(cmd_val[0] != '\0' ? 4 : 3);
        }
}

static void h_abnormal_close(const char *id_val, const char *cmd_val, const char *raw_buf)
{
// ---- 异常自动关阀设置 (cmd_val非空=设置, 空=查询) ----
        if(cmd_val[0] != '\0')
        {
            strncpy(g_abnormal_close, cmd_val, 15); g_abnormal_close[15] = '\0';
            config_save_ext();
            printf_debug("[SM] abnormal_close -> %s\r\n", g_abnormal_close);
        }
        if(EC801E_EnsureConnected() == EC_OK)
            EC801E_PublishResponse("abnormal_close", g_abnormal_close);
        report_publish_feedback(cmd_val[0] != '\0' ? 29 : 28);
}

/* 出气端异常自动关阀 (abnormal2_close pv* 策略) */
static void h_abnormal2_close(const char *id_val, const char *cmd_val, const char *raw_buf)
{
        if(cmd_val[0] != '\0')
        {
            strncpy(g_abnormal2_close, cmd_val, 15); g_abnormal2_close[15] = '\0';
            config_save_abn23();
            printf_debug("[SM] abnormal2_close -> %s\r\n", g_abnormal2_close);
        }
        if(EC801E_EnsureConnected() == EC_OK)
            EC801E_PublishResponse("abnormal2_close", g_abnormal2_close);
        report_publish_feedback(cmd_val[0] != '\0' ? 29 : 28);
}

/* 激光甲烷异常自动关阀 (abnormal3_close: 0=关 1=开) */
static void h_abnormal3_close(const char *id_val, const char *cmd_val, const char *raw_buf)
{
        if(cmd_val[0] != '\0')
        {
            g_abnormal3_close = (uint8_t)atoi(cmd_val);
            if(g_abnormal3_close > 1) g_abnormal3_close = 0;
            config_save_abn23();
            printf_debug("[SM] abnormal3_close -> %d\r\n", g_abnormal3_close);
        }
        if(EC801E_EnsureConnected() == EC_OK)
        {
            char v[4];
            snprintf(v, sizeof(v), "%d", g_abnormal3_close);
            EC801E_PublishResponse("abnormal3_close", v);
        }
        report_publish_feedback(cmd_val[0] != '\0' ? 29 : 28);
}

/* 平台强制状态转换: install_status_set=1 → 置已安装(幂等)
 * 值在 commandParms 的 id/value 对中, 直接从原始报文解析 */
static void h_install_status_set(const char *id_val, const char *cmd_val, const char *raw_buf)
{
#if CALIB_MODE_ENABLED
    const char *p;
    char val_buf[8] = {0};
    uint16_t i = 0;

    (void)id_val;
    (void)cmd_val;
    p = strstr(raw_buf, "install_status");
    if(p) p = strstr(p, "\"value\":\"");
    if(p)
    {
        p += 9;
        while(*p && *p != '"' && i < sizeof(val_buf) - 1)
            val_buf[i++] = *p++;
    }
    printf_debug("[SM] install_status_set value='%s'\r\n", val_buf);

    if(strcmp(val_buf, "1") == 0)
    {
        if(calib_force_install())
        {
            install_event_report();                 /* 一次性: 传感器记录 + product-status=1 */
            report_publish_feedback(37);            /* 状态强制转换成功 */
            printf_debug("[SM] install_status forced OK (37)\r\n");
        }
    }
    else
    {
        printf_debug("[SM] install_status value ignored (only 1 supported)\r\n");
    }
#else
    printf_debug("[SM] install_status_set ignored (CALIB_MODE_ENABLED=0)\r\n");
#endif
}

static void h_valve_last_order(const char *id_val, const char *cmd_val, const char *raw_buf)
{
char v[4];
        snprintf(v, sizeof(v), "%d", g_valve_last_order);
        if(EC801E_EnsureConnected() == EC_OK)
            EC801E_PublishResponse("valve-last-order", v);
}

static void h_keepalive(const char *id_val, const char *cmd_val, const char *raw_buf)
{
uint16_t ka = (uint16_t)atoi(cmd_val);
        if(ka >= 30)
        {
            g_keepalive_sec = ka;
            config_save_vpthreshold();
            char at_cmd[64];
            snprintf(at_cmd, sizeof(at_cmd), "AT+QMTCFG=\"keepalive\",0,%d\r\n", ka);
            EC801E_Wakeup();
            printf_cat1("%s", at_cmd);
            trea_delay_ms(500);
            printf_debug("[SM] keepalive -> %d s\r\n", ka);
        }
}

static void h_get_sim(const char *id_val, const char *cmd_val, const char *raw_buf)
{
char iccid[32] = {0}, csq[8] = {0}, imei_buf[24] = {0};
        char rsrp_buf[8], sinr_buf[8], cereg_buf[4] = {0};
        uint8_t cereg = 0;
        report_query_signal_info(csq, sizeof(csq), rsrp_buf, sizeof(rsrp_buf), sinr_buf, sizeof(sinr_buf));
        EC801E_QueryCEREG(&cereg);
        snprintf(cereg_buf, sizeof(cereg_buf), "%d", cereg);
        EC801E_QueryICCID(iccid, sizeof(iccid));
        EC801E_QueryIMEI(imei_buf, sizeof(imei_buf));
        if(EC801E_EnsureConnected() == EC_OK)
        {
            rtc_get_time_str(ts_buf, sizeof(ts_buf));
            jb_begin(&jb, json_buf, sizeof(json_buf));
            jb_add_str(&jb, "csq", csq, ts_buf);
            jb_add_str(&jb, "rsrp", rsrp_buf, ts_buf);
            jb_add_str(&jb, "snr", sinr_buf, ts_buf);
            jb_add_str(&jb, "cereg", cereg_buf, ts_buf);
            jb_add_str(&jb, "soft-version", APP_FIRMWARE_VERSION, ts_buf);
            jb_add_str(&jb, "ICCID", iccid, ts_buf);
            jb_add_str(&jb, "IMEI", imei_buf, ts_buf);
            publish_json_only();
        }
}

static void h_get_ip(const char *id_val, const char *cmd_val, const char *raw_buf)
{
report_publish_ip_field("first-ip", g_mqtt.server, g_mqtt.port, 1);
}

static void h_get_scend_ip(const char *id_val, const char *cmd_val, const char *raw_buf)
{
report_publish_ip_field("scend-ip", g_mqtt.server2, g_mqtt.port2, 1);
}

static void h_first_ip_set(const char *id_val, const char *cmd_val, const char *raw_buf)
{
char ip_buf[MQTT_FIELD_MAX];
        uint16_t port;
        if(parse_ip_port(cmd_val, ip_buf, &port))
        {
            strncpy(g_mqtt.server, ip_buf, MQTT_FIELD_MAX - 1);
            g_mqtt.server[MQTT_FIELD_MAX - 1] = '\0';
            g_mqtt.port = port;
            config_save_mqtt();
            printf_debug("[SM] Primary IP set: %s:%d\r\n", g_mqtt.server, g_mqtt.port);
            EC801E_DisconnectMQTT();
            trea_delay_ms(500);
            EC801E_ConnectMQTT();
            EC801E_SubscribeAll();      /* 改IP重连后重订阅全部主题(含OTA/测漏) */
            if(EC801E_EnsureConnected() == EC_OK)
            {
                EC801E_PublishResponse("first-ip-set", cmd_val);
                trea_delay_ms(300);
                report_publish_feedback(2);
            }
        }
        else
        {
            if(EC801E_EnsureConnected() == EC_OK)
                report_publish_feedback(24);
        }
}

static void h_scend_ip_set(const char *id_val, const char *cmd_val, const char *raw_buf)
{
char ip_buf[MQTT_FIELD_MAX];
        uint16_t port;
        if(parse_ip_port(cmd_val, ip_buf, &port))
        {
            strncpy(g_mqtt.server2, ip_buf, MQTT_FIELD_MAX - 1);
            g_mqtt.server2[MQTT_FIELD_MAX - 1] = '\0';
            g_mqtt.port2 = port;
            config_save_mqtt();
            printf_debug("[SM] Secondary IP set: %s:%d\r\n", g_mqtt.server2, g_mqtt.port2);
            if(EC801E_EnsureConnected() == EC_OK)
            {
                EC801E_PublishResponse("scend-ip-set", cmd_val);
                trea_delay_ms(300);
                report_publish_feedback(2);
            }
        }
        else
        {
            if(EC801E_EnsureConnected() == EC_OK)
                report_publish_feedback(24);
        }
}

static void h_sensor_status(const char *id_val, const char *cmd_val, const char *raw_buf)
{
collect_all_sensors();
        {
            uint8_t cur_online = (g_sensor.raw.err == PT304D_OK) ? 1 : 0;
            if(cur_online != g_sensor.prev_online)
                g_sensor.prev_online = cur_online;
        }
        printf_debug("[SM] sensor_status queried\r\n");
        if(EC801E_EnsureConnected() == EC_OK)
            report_publish_sensor_status();
}

static void h_temp_status(const char *id_val, const char *cmd_val, const char *raw_buf)
{
collect_all_sensors();
        TempStatus_t ts = threshold_get_temp_status(g_sensor.raw.temperature);
        const char *ts_str = threshold_temp_status_str(ts);
        printf_debug("[SM] temp_status: T=%.2f -> %s\r\n", g_sensor.raw.temperature, ts_str);
        if(EC801E_EnsureConnected() == EC_OK)
        {
            rtc_get_time_str(ts_buf, sizeof(ts_buf));
            jb_begin(&jb, json_buf, sizeof(json_buf));
            jb_add_str(&jb, "temp-status", ts_str, ts_buf);
            jb_add_float(&jb, "temp", g_sensor.raw.temperature, ts_buf);
            publish_json_only();
            trea_delay_ms(300);
            report_publish_feedback(31);   /* 温度状态获取成功 */
        }

        // 公共安全检查: 完整阈值检查 + 去重 + 重采确认 + 关阀 + 报警上报(追加在应答之后)
        run_full_threshold_check();
}

static void h_ly06_get(const char *id_val, const char *cmd_val, const char *raw_buf)
{
char val_buf[8];
        float v = adc_bat_read_voltage();
        int volt_alarm = threshold_voltage_alarm(v);
        snprintf(val_buf, sizeof(val_buf), "%d", volt_alarm);
        printf_debug("[SM] LY06_get: V=%.2f -> %d\r\n", v, volt_alarm);
        if(EC801E_EnsureConnected() == EC_OK)
        {
            char v_buf[8];
            snprintf(v_buf, sizeof(v_buf), "%.2f", v);
            rtc_get_time_str(ts_buf, sizeof(ts_buf));
            jb_begin(&jb, json_buf, sizeof(json_buf));
            jb_add_str(&jb, "LY06", val_buf, ts_buf);
            jb_add_str(&jb, "voltage", v_buf, ts_buf);
            publish_json_only();
        }
}

//static void h_restart(const char *id_val, const char *cmd_val, const char *raw_buf)
//{
//printf_debug("[SM] Restart commanded\r\n");
//        if(EC801E_EnsureConnected() == EC_OK)
//            EC801E_PublishResponse("restart", "0");
//        trea_delay_ms(200);
//        NVIC_SystemReset();
//}

static void h_restart_off(const char *id_val, const char *cmd_val, const char *raw_buf)
{
printf_debug("[SM] Restart_off: closing valve then reset\r\n");
//        valve_execute("close", 1);
        if(EC801E_EnsureConnected() == EC_OK)
            EC801E_PublishResponse("restart", "0");
        trea_delay_ms(50);
        NVIC_SystemReset();
}

//static void h_4gpower_off(const char *id_val, const char *cmd_val, const char *raw_buf)
//{
//printf_debug("[SM] 4G power off\r\n");
//        report_4g_power_state(0);
//        trea_delay_ms(200);
//        EC801E_PowerOff();
//        fourG_user_off = 1;
//}

static void h_real_set(const char *id_val, const char *cmd_val, const char *raw_buf)
{
if(strcmp(id_val, "real_set") == 0 && cmd_val[0] != '\0')
        {
            g_real_enabled = (uint8_t)atoi(cmd_val);
            if(g_real_enabled > 1) g_real_enabled = 0;
            char freq_buf[8] = {0};
            extract_key_value(raw_buf, "real_frequency", freq_buf, sizeof(freq_buf));
            if(freq_buf[0])
            {
                g_real_frequency = (uint8_t)atoi(freq_buf);
                if(g_real_frequency < 1 || g_real_frequency > 10)
                    g_real_frequency = 5;
            }
            config_save_ext();
            /* 注: 切换实时模式不再清告警锁 (锁定等级跨路径/跨模式共用, 去重语义由 alarm_lock 统一维护) */
            printf_debug("[SM] real_set: enabled=%d frequency=%ds\r\n", g_real_enabled, g_real_frequency);
        }
        if(EC801E_EnsureConnected() == EC_OK)
        {
            rtc_get_time_str(ts_buf, sizeof(ts_buf));
            jb_begin(&jb, json_buf, sizeof(json_buf));
            jb_add_int(&jb, "real_enabled", g_real_enabled, ts_buf);
            jb_add_int(&jb, "real_frequency", g_real_frequency, ts_buf);
            publish_json_df(strcmp(id_val, "real_set") == 0 ? 14 : 13);
        }
}

static void h_lcd_switch(const char *id_val, const char *cmd_val, const char *raw_buf)
{
if(cmd_val[0] != '\0')
        {
            g_lcd_enabled = (uint8_t)atoi(cmd_val);
            if(g_lcd_enabled > 1) g_lcd_enabled = 1;
            if(!g_lcd_enabled) lcd_shutdown();
            config_save_ext();
            printf_debug("[SM] lcd_switch: %d (saved)\r\n", g_lcd_enabled);
        }
        if(EC801E_EnsureConnected() == EC_OK)
        {
            rtc_get_time_str(ts_buf, sizeof(ts_buf));
            jb_begin(&jb, json_buf, sizeof(json_buf));
            jb_add_int(&jb, "lcd_switch", g_lcd_enabled, ts_buf);
            publish_json_only();
        }
}

static void h_vpthreshold2(const char *id_val, const char *cmd_val, const char *raw_buf)
{
process_threshold(&thr_groups[4], cmd_val, raw_buf);
}

static void h_tthreshold2(const char *id_val, const char *cmd_val, const char *raw_buf)
{
process_threshold(&thr_groups[5], cmd_val, raw_buf);
}

static void h_temp_status2(const char *id_val, const char *cmd_val, const char *raw_buf)
{
        /* 单路机型: 无通道2, 不读 raw2 陈旧值 → 回温度异常状态 (不产生假数据/假告警) */
        if(g_sensor_count < 2)
        {
            printf_debug("[SM] temp_status2: single-channel product, reply temp-err\r\n");
            if(EC801E_EnsureConnected() == EC_OK)
            {
                rtc_get_time_str(ts_buf, sizeof(ts_buf));
                jb_begin(&jb, json_buf, sizeof(json_buf));
                jb_add_str(&jb, "temp2-status", "temp-err", ts_buf);
                publish_json_only();
            }
            return;
        }

        collect_all_sensors();
        TempStatus_t ts2 = threshold_get_temp_status2(g_sensor.raw2.temperature);
        const char *ts2_str = threshold_temp_status_str(ts2);
        printf_debug("[SM] temp_status2: T2=%.2f -> %s\r\n", g_sensor.raw2.temperature, ts2_str);
        if(EC801E_EnsureConnected() == EC_OK)
        {
            rtc_get_time_str(ts_buf, sizeof(ts_buf));
            jb_begin(&jb, json_buf, sizeof(json_buf));
            jb_add_str(&jb, "temp2-status", ts2_str, ts_buf);
            jb_add_float(&jb, "temp2", g_sensor.raw2.temperature, ts_buf);
            publish_json_only();
            trea_delay_ms(300);
            report_publish_feedback(31);   /* 温度状态获取成功 */
        }

        // 公共安全检查: 完整阈值检查 + 去重 + 重采确认 + 关阀 + 报警上报(追加在应答之后)
        run_full_threshold_check();
}

static void h_get_pressure2(const char *id_val, const char *cmd_val, const char *raw_buf)
{
        /* 单路机型: 无通道2, 不读 raw2 陈旧值 → 回压力异常状态 (不产生假数据/假告警) */
        if(g_sensor_count < 2)
        {
            printf_debug("[SM] get_pressure2: single-channel product, reply pressure-err\r\n");
            if(EC801E_EnsureConnected() == EC_OK)
            {
                rtc_get_time_str(ts_buf, sizeof(ts_buf));
                jb_begin(&jb, json_buf, sizeof(json_buf));
                jb_add_str(&jb, "pressure2-status", "pressure-err", ts_buf);
                publish_json_only();
            }
            return;
        }

        collect_all_sensors();
        PressureStatus_t ps2 = threshold_get_pressure_status2(g_sensor.raw2.pressure,
                                                              g_sensor.last_pressure_collect2);
        const char *ps2_str = threshold_pressure_status_str(ps2);
        printf_debug("[SM] get_pressure2: P2=%.2f -> %s\r\n", g_sensor.raw2.pressure, ps2_str);
        if(EC801E_EnsureConnected() == EC_OK)
        {
            rtc_get_time_str(ts_buf, sizeof(ts_buf));
            jb_begin(&jb, json_buf, sizeof(json_buf));
            jb_add_str(&jb, "pressure2-status", ps2_str, ts_buf);
            jb_add_float(&jb, "pressure2", g_sensor.raw2.pressure, ts_buf);
            jb_add_float(&jb, "temp2", g_sensor.raw2.temperature, ts_buf);
            publish_json_only();
            trea_delay_ms(300);
            report_publish_feedback(30);   /* 压力状态获取成功 */
        }

        // 公共安全检查: 完整阈值检查 + 去重 + 重采确认 + 关阀 + 报警上报(追加在应答之后)
        run_full_threshold_check();
}

static void h_user_ip_get(const char *id_val, const char *cmd_val, const char *raw_buf)
{
report_publish_ip_field("user-ip", g_user_mqtt.server, g_user_mqtt.port, 1);
}

static void h_user_ip_set(const char *id_val, const char *cmd_val, const char *raw_buf)
{
char ip_buf[MQTT_FIELD_MAX];
        uint16_t port;
        if(parse_ip_port(cmd_val, ip_buf, &port))
        {
            strncpy(g_user_mqtt.server, ip_buf, MQTT_FIELD_MAX - 1);
            g_user_mqtt.server[MQTT_FIELD_MAX - 1] = '\0';
            g_user_mqtt.port = port;
            // topic为空时自动用client_id拼接
            if(g_user_mqtt.topic_up[0] == '\0' && g_user_mqtt.client_id[0])
                snprintf(g_user_mqtt.topic_up, MQTT_TOPIC_MAX, "/155/%s/property/post", g_user_mqtt.client_id);
            config_save_user_mqtt();
            printf_debug("[SM] User IP set: %s:%d\r\n", g_user_mqtt.server, g_user_mqtt.port);
            if(EC801E_EnsureConnected() == EC_OK)
            {
                EC801E_PublishResponse("user-ip-set", cmd_val);
                trea_delay_ms(300);
                report_publish_feedback(2);
            }
        }
        else
        {
            if(EC801E_EnsureConnected() == EC_OK)
                report_publish_feedback(24);
        }
}

static void h_user_mqtt_get(const char *id_val, const char *cmd_val, const char *raw_buf)
{
if(strcmp(id_val, "user_mqtt_set") == 0)
        {
            char tv[MQTT_TOPIC_MAX];
            uint8_t topic_explicit = 0;
            if(extract_key_value(raw_buf, "MQTT_username", tv, sizeof(tv)))
                strncpy(g_user_mqtt.username, tv, MQTT_FIELD_MAX - 1);
            if(extract_key_value(raw_buf, "MQTT_password", tv, sizeof(tv)))
                strncpy(g_user_mqtt.password, tv, MQTT_FIELD_MAX - 1);
            if(extract_key_value(raw_buf, "MQTT_subject", tv, sizeof(tv)))
            {
                strncpy(g_user_mqtt.topic_up, tv, MQTT_TOPIC_MAX - 1);
                topic_explicit = 1;
            }
            if(extract_key_value(raw_buf, "MQTT_client_id", tv, sizeof(tv)))
            {
                strncpy(g_user_mqtt.client_id, tv, MQTT_FIELD_MAX - 1);
                // 下发未显式指定topic且当前topic为空时, 自动用client_id拼接
                if(!topic_explicit && g_user_mqtt.topic_up[0] == '\0' && g_user_mqtt.server[0])
                    snprintf(g_user_mqtt.topic_up, MQTT_TOPIC_MAX, "/155/%s/property/post", g_user_mqtt.client_id);
            }
            config_save_user_mqtt();
            printf_debug("[SM] User MQTT set: user=%s client=%s topic=%s\r\n",
                         g_user_mqtt.username, g_user_mqtt.client_id, g_user_mqtt.topic_up);
        }
        if(EC801E_EnsureConnected() == EC_OK)
        {
            rtc_get_time_str(ts_buf, sizeof(ts_buf));
            jb_begin(&jb, json_buf, sizeof(json_buf));
            jb_add_str(&jb, "MQTT_username", g_user_mqtt.username, ts_buf);
            jb_add_str(&jb, "MQTT_password", g_user_mqtt.password, ts_buf);
            jb_add_str(&jb, "MQTT_client_id", g_user_mqtt.client_id, ts_buf);
            jb_add_str(&jb, "MQTT_subject", g_user_mqtt.topic_up, ts_buf);
            publish_json_df(strcmp(id_val, "user_mqtt_set") == 0 ? 18 : 17);
        }
}

static void h_valve_status(const char *id_val, const char *cmd_val, const char *raw_buf)
{
const char *vs = valve_get_status();
        printf_debug("[SM] valve_get: %s\r\n", vs);
        if(EC801E_EnsureConnected() == EC_OK)
        {
            EC801E_PublishResponse("valve-control", vs);
            trea_delay_ms(300);
            report_publish_feedback(25);
        }
}

static void h_closeoropen(const char *id_val, const char *cmd_val, const char *raw_buf)
{
// ---- 定时开关阀 set/get (YYMMDDHHMM, 开/关开关独立) ----
        if(cmd_val[0] != '\0')
        {
            char tv[16];
            char new_open[11], new_close[11];
            uint8_t new_on  = g_valve_timing.on_switch;
            uint8_t new_off = g_valve_timing.off_switch;
            uint8_t changed = 0;

            if(extract_key_value(raw_buf, "timing_onswitch", tv, sizeof(tv)))
            { new_on = (uint8_t)atoi(tv); if(new_on > 1) new_on = 0; changed = 1; }
            if(extract_key_value(raw_buf, "timing_offswitch", tv, sizeof(tv)))
            { new_off = (uint8_t)atoi(tv); if(new_off > 1) new_off = 0; changed = 1; }

            strncpy(new_open,  g_valve_timing.open_time,  10); new_open[10]  = 0;
            strncpy(new_close, g_valve_timing.close_time, 10); new_close[10] = 0;

            if(extract_key_value(raw_buf, "timing_open", tv, sizeof(tv)))
            {
                strncpy(new_open, tv, 10); new_open[10] = 0;
                if(valve_timing_time_valid(new_open)) changed = 1;
                else
                {
                    strncpy(new_open, g_valve_timing.open_time, 10); new_open[10] = 0;
                    printf_debug("[SM] closeoropen: invalid timing_open=%s rejected\r\n", tv);
                }
            }
            if(extract_key_value(raw_buf, "timing_close", tv, sizeof(tv)))
            {
                strncpy(new_close, tv, 10); new_close[10] = 0;
                if(valve_timing_time_valid(new_close)) changed = 1;
                else
                {
                    strncpy(new_close, g_valve_timing.close_time, 10); new_close[10] = 0;
                    printf_debug("[SM] closeoropen: invalid timing_close=%s rejected\r\n", tv);
                }
            }

            if(changed)
            {
                g_valve_timing.on_switch  = new_on;
                g_valve_timing.off_switch = new_off;
                strncpy(g_valve_timing.open_time,  new_open,  10); g_valve_timing.open_time[10]  = 0;
                strncpy(g_valve_timing.close_time, new_close, 10); g_valve_timing.close_time[10] = 0;
                config_save_valve_timing();
                timing_open_done_today  = 0;
                timing_close_done_today = 0;
            }
            printf_debug("[SM] closeoropen_set: on=%d off=%d open=%s close=%s (flags reset)\r\n",
                         g_valve_timing.on_switch, g_valve_timing.off_switch,
                         g_valve_timing.open_time, g_valve_timing.close_time);
        }
        if(EC801E_EnsureConnected() == EC_OK)
        {
            char v_str[4];
            rtc_get_time_str(ts_buf, sizeof(ts_buf));
            jb_begin(&jb, json_buf, sizeof(json_buf));
            snprintf(v_str, sizeof(v_str), "%d", g_valve_timing.on_switch);
            jb_add_str(&jb, "timing_onswitch", v_str, ts_buf);
            snprintf(v_str, sizeof(v_str), "%d", g_valve_timing.off_switch);
            jb_add_str(&jb, "timing_offswitch", v_str, ts_buf);
            jb_add_str(&jb, "timing_open", g_valve_timing.open_time, ts_buf);
            jb_add_str(&jb, "timing_close", g_valve_timing.close_time, ts_buf);
            publish_json_df(cmd_val[0] != '\0' ? 22 : 21);
        }
}

static void h_table(const char *id_val, const char *cmd_val, const char *raw_buf)
{
// ---- 表号 get/set ----
        if(cmd_val[0] != '\0')
        {
            // SET: 替换 client_id 中的第2段(设备ID/表号)
            char new_id[MQTT_FIELD_MAX];
            const char *src = g_mqtt.client_id;
            const char *amp1 = strchr(src, '&');
            if(amp1)
            {
                const char *amp2 = strchr(amp1 + 1, '&');
                if(amp2)
                {
                    uint16_t prefix_len = (uint16_t)(amp1 - src + 1);
                    memcpy(new_id, src, prefix_len);
                    new_id[prefix_len] = '\0';
                    strncat(new_id, cmd_val, MQTT_FIELD_MAX - prefix_len - 1);
                    strncat(new_id, amp2, MQTT_FIELD_MAX - strlen(new_id) - 1);
                    new_id[MQTT_FIELD_MAX - 1] = '\0';
                    strncpy(g_mqtt.client_id, new_id, MQTT_FIELD_MAX - 1);
                    g_mqtt.client_id[MQTT_FIELD_MAX - 1] = '\0';
                    derive_topic_from_client_id();
                    config_save_mqtt();
                    printf_debug("[SM] table set: %s\r\n", g_mqtt.client_id);
                }
            }
        }
        // 上报当前表号 (读取client_id第2段)
        if(EC801E_EnsureConnected() == EC_OK)
        {
            char table_val[MQTT_FIELD_MAX] = {0};
            const char *a1 = strchr(g_mqtt.client_id, '&');
            if(a1)
            {
                const char *a2 = strchr(a1 + 1, '&');
                uint16_t len = a2 ? (uint16_t)(a2 - a1 - 1) : (uint16_t)strlen(a1 + 1);
                if(len >= MQTT_FIELD_MAX) len = MQTT_FIELD_MAX - 1;
                memcpy(table_val, a1 + 1, len);
                table_val[len] = '\0';
            }
            rtc_get_time_str(ts_buf, sizeof(ts_buf));
            jb_begin(&jb, json_buf, sizeof(json_buf));
            jb_add_str(&jb, "table", table_val, ts_buf);
            publish_json_df(cmd_val[0] != '\0' ? 27 : 26);
        }
}

/* ==================== 指令分发表 ==================== */
typedef struct {
    const char *id;                                              /* 指令 id (格式A) 或 CmdMap 映射后的 id */
    void (*handler)(const char *id_val, const char *cmd_val, const char *raw_buf);
} CmdHandler_t;

static const CmdHandler_t s_cmd_handlers[] = {
    { "valve", h_valve },
    { "sensor_read", h_sensor_read },
    { "get_pressure", h_sensor_read },
    { "collect_cycle", h_collect_cycle },
    { "report_cycle", h_report_cycle },
    { "vpthreshold", h_vpthreshold },
    { "Tthreshold", h_tthreshold },
    { "spupower", h_spupower },
    { "threshold", h_threshold },
    { "delay", h_delay },
    { "window_pattern", h_window_pattern },
    { "abnormal_close", h_abnormal_close },
    { "abnormal2_close", h_abnormal2_close },
    { "abnormal3_close", h_abnormal3_close },
    { "valve_last_order", h_valve_last_order },
    { "keepalive", h_keepalive },
    { "get_sim", h_get_sim },
    { "get_ip", h_get_ip },
    { "get_scend_ip", h_get_scend_ip },
    { "first_ip_set", h_first_ip_set },
    { "scend_ip_set", h_scend_ip_set },
    { "sensor_status", h_sensor_status },
    { "temp_status", h_temp_status },
    { "LY06_get", h_ly06_get },
    { "restart", h_restart_off },
    { "restart_off", h_restart_off },
//    { "4Gpower_off", h_4gpower_off },
    { "real_set", h_real_set },
    { "real_get", h_real_set },
    { "install_status_set", h_install_status_set },
    { "lcd_switch", h_lcd_switch },
    { "vpthreshold2", h_vpthreshold2 },
    { "Tthreshold2", h_tthreshold2 },
    { "temp_status2", h_temp_status2 },
    { "get_pressure2", h_get_pressure2 },
    { "gas_get", h_gas_get },
    { "laser_get", h_laser_get },
    { "laser_set", h_laser_set },
    { "msh_get", h_msh_get },
    { "msh_set", h_msh_set },
    { "user_ip_get", h_user_ip_get },
    { "user_ip_set", h_user_ip_set },
    { "user_mqtt_get", h_user_mqtt_get },
    { "user_mqtt_set", h_user_mqtt_get },
    { "valve_status", h_valve_status },
    { "closeoropen", h_closeoropen },
    { "table", h_table },
};
#define CMD_HANDLER_COUNT (sizeof(s_cmd_handlers) / sizeof(s_cmd_handlers[0]))
	
/* ==================== 取数指令门禁 ====================
 * 指令依赖"对应通道有有效数据": 该通道离线 → 回"状态=*-err + 数值=哨兵 + 反馈码",
 * 不调用任何阈值/状态计算 (驱动失败会写哨兵 -1000Pa/-50C; 设备侧不做无效通道的判定)。
 * 单路机型 (g_sensor_count<2) 时 ch1 恒按"无数据"处理。
 * 新增取数指令时在 s_sensor_req_ids[] 补一行即可(用的是归一化后的 id, 见 s_cmd_map)。 */
typedef enum {
    SREQ_TEMP1 = 0,     /* 6.6 进气端温度: temp-status + temp,            fb 31 */
    SREQ_PRESS1,        /* 6.7 进气端压力: pressure-status + pressure,    fb 30 */
    SREQ_TEMP2,         /* 6.8 出气端温度: temp2-status + temp2,          fb 31 */
    SREQ_PRESS2         /* 6.9 出气端压力: pressure2-status + pressure2 + temp2, fb 30 */
} SensorReqKind_t;

typedef struct {
    const char     *id;      /* 归一化后的 id */
    uint8_t         ch;      /* 0=进气端(raw) 1=出气端(raw2) */
    SensorReqKind_t kind;    /* 应答字段/反馈码 */
} SensorReqId_t;

static const SensorReqId_t s_sensor_req_ids[] = {
    { "sensor_read",   0, SREQ_PRESS1 },   /* 兼容 id: sensor_read */
    { "get_pressure",  0, SREQ_PRESS1 },   /* get-pressure / get-pressure1 */
    { "temp_status",   0, SREQ_TEMP1  },   /* temp-get1 */
    { "get_pressure2", 1, SREQ_PRESS2 },   /* get-pressure2 */
    { "temp_status2",  1, SREQ_TEMP2  },   /* temp-get2 */
};
#define SENSOR_REQ_ID_COUNT (sizeof(s_sensor_req_ids) / sizeof(s_sensor_req_ids[0]))

/* 该通道当前是否无有效数据 (单路机型 ch1 恒为无效) */
static uint8_t sensor_ch_is_invalid(uint8_t ch)
{
    if(ch == 0u)
        return (g_sensor.raw.err != PT304D_OK) ? 1u : 0u;
    return (g_sensor_count < 2 || g_sensor.raw2.err != PT304D_OK) ? 1u : 0u;
}

/* 无有效数据时的应答: 状态=*-err + 数值=哨兵(-1000Pa/-50C) + 反馈码 30/31 */
static void reply_sensor_data_error(const SensorReqId_t *e)
{
    printf_debug("[SM] %s: ch%u no valid data (err=%d) -> err status + sentinel\r\n",
                 e->id, (unsigned)e->ch,
                 (int)((e->ch == 0u) ? g_sensor.raw.err : g_sensor.raw2.err));
    if(EC801E_EnsureConnected() == EC_OK)
    {
        rtc_get_time_str(ts_buf, sizeof(ts_buf));
        jb_begin(&jb, json_buf, sizeof(json_buf));
        switch(e->kind)
        {
            case SREQ_TEMP1:
                jb_add_str(&jb, "temp-status", "temp-err", ts_buf);
                jb_add_float(&jb, "temp", PT304D_INVALID_TEMP_C, ts_buf);
                break;
            case SREQ_PRESS1:
                jb_add_str(&jb, "pressure-status", "pressure-err", ts_buf);
                jb_add_float(&jb, "pressure", PT304D_INVALID_PRESSURE_PA, ts_buf);
                break;
            case SREQ_TEMP2:
                jb_add_str(&jb, "temp2-status", "temp-err", ts_buf);
                jb_add_float(&jb, "temp2", PT304D_INVALID_TEMP_C, ts_buf);
                break;
            case SREQ_PRESS2:
            default:
                jb_add_str(&jb, "pressure2-status", "pressure-err", ts_buf);
                jb_add_float(&jb, "pressure2", PT304D_INVALID_PRESSURE_PA, ts_buf);
                jb_add_float(&jb, "temp2", PT304D_INVALID_TEMP_C, ts_buf);
                break;
        }
        publish_json_only();
        trea_delay_ms(300);
        report_publish_feedback((e->kind == SREQ_TEMP1 || e->kind == SREQ_TEMP2) ? 31 : 30);
    }
}

/* 处理单条下行指令 (表驱动分发) */
static void process_downlink_cmd(const char *id_val, const char *cmd_val, const char *raw_buf)
{
    uint8_t i;
	
    /* 取数指令门禁: 该指令对应通道无有效数据 → 只回异常状态+哨兵, 不进 handler */
    for(i = 0; i < SENSOR_REQ_ID_COUNT; i++)
    {
        if(strcmp(id_val, s_sensor_req_ids[i].id) == 0)
        {
            if(sensor_ch_is_invalid(s_sensor_req_ids[i].ch))
            {
                reply_sensor_data_error(&s_sensor_req_ids[i]);
                return;
            }
            break;   /* 通道有有效数据 → 继续走 handler */
        }
    }

    for(i = 0; i < CMD_HANDLER_COUNT; i++)
    {
        if(strcmp(id_val, s_cmd_handlers[i].id) == 0)
        {
            s_cmd_handlers[i].handler(id_val, cmd_val, raw_buf);
            return;
        }
    }
    printf_debug("[SM] Unknown cmd: %s\r\n", id_val);
}
// ==================== 排空处理所有MQTT下行消息 ====================
/* ==================== 下行报文解析 ==================== */
typedef enum {
    CMD_KIND_NORMAL = 0,
    CMD_KIND_OTA
} CmdKind_t;

typedef struct {
    char id[32];
    char value[192];
} CmdRequest_t;

/* 解析单条下行报文: OTA检测 + 格式B(commandStr映射) + 格式A(id/value) 归一 */
static CmdKind_t parse_cmd(const char *raw, CmdRequest_t *req)
{
    char cs[64] = {0};

    req->id[0] = '\0';
    req->value[0] = '\0';

    /* OTA 升级指令 */
    if(strstr(raw, "downloadUrl") != NULL)
        return CMD_KIND_OTA;

    /* 格式B: commandStr 查映射表 */
    if(extract_json_field(raw, "\"commandStr\"", cs, sizeof(cs)))
    {
        uint8_t i;
        uint8_t found = 0;
        for(i = 0; i < CMD_MAP_COUNT; i++)
        {
            if(strcmp(cs, s_cmd_map[i].cmd_str) == 0)
            {
                strcpy(req->id, s_cmd_map[i].id);
                if(s_cmd_map[i].value != NULL)
                    strcpy(req->value, s_cmd_map[i].value);
                else
                    extract_key_value(raw, s_cmd_map[i].extract, req->value, sizeof(req->value));
                found = 1;
                break;
            }
        }
        if(!found)
        {
            strncpy(req->id, cs, sizeof(req->id) - 1);
            req->id[sizeof(req->id) - 1] = '\0';
        }
        return CMD_KIND_NORMAL;
    }

    /* 格式A: 直接取 id / value */
    extract_json_field(raw, "\"id\"", req->id, sizeof(req->id));
    extract_json_field(raw, "\"value\"", req->value, sizeof(req->value));
    return CMD_KIND_NORMAL;
}

// ==================== 排空处理所有MQTT下行消息 ====================
/* 处理一条已读取出来的下行 payload (解析 + 分发 + 回执)
 * 供 drain_pending_downlink() 与静态测漏任务(任务期间轮询到的常规指令)共用 */
void downlink_handle_raw(const char *raw)
{
    CmdRequest_t req;

    if(raw == NULL) return;

    if(parse_cmd(raw, &req) == CMD_KIND_OTA)
    {
        printf_debug("[SM] OTA upgrade cmd detected\r\n");
        ota_app_handle_upgrade_cmd(raw);
        return;
    }

    printf_debug("[SM] CMD id=%s value=%s\r\n", req.id, req.value);
    process_downlink_cmd(req.id, req.value, raw);
}

uint8_t drain_pending_downlink(void)
{
    static char dl_buf[1024];
    static char dl_topic[MQTT_TOPIC_MAX];
    uint8_t flags[5];
    uint8_t msg_count = 0;
    uint8_t round;

    /* 模块接收缓冲是 5 个固定槽位: 必须"先查槽位标志, 再按槽位读",
     * 盲读 AT+QMTRECV=0 只能拿到槽位 0, 落在 1..4 的指令会永久滞留。
     * 单轮最多读 5 条; 读完再查一轮(平台密发时本轮新到达的消息), 上限 20 条/6 轮。 */
    for(round = 0; round <= 5 && msg_count < 20; round++)
    {
        uint8_t i, n = 0;

        if(EC801E_QueryRecvSlots(flags) != EC_OK)
            break;                       /* 查询失败: 缓存保持不动, 下次再读 */

        for(i = 0; i < 5; i++) if(flags[i]) n++;
        if(n == 0) break;                /* 缓冲区已空 */

        for(i = 0; i < 5 && msg_count < 20; i++)
        {
            if(!flags[i]) continue;

            if(EC801E_ReadDownlinkById(i, dl_topic, sizeof(dl_topic),
                                       dl_buf, sizeof(dl_buf)) != EC_OK)
            {
                printf_debug("[SM] slot %d read fail, re-query\r\n", i);
                break;
            }
            msg_count++;

            /* 静态测漏专用 topic (leak/set): 交给 leak_task, 不进入常规指令表 */
            if(leak_task_on_msg(dl_topic, dl_buf))
                continue;

            downlink_handle_raw(dl_buf);   /* 内含 OTA 判据 + 解析 + 分发 */
        }
    }

    return msg_count;
}

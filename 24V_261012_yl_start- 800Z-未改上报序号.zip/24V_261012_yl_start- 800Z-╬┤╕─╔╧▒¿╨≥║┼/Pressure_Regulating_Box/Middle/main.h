#ifndef MAIN_H
#define MAIN_H

#include "stdint.h"
#include "PT_304_35.h"
#include "ota_info.h"
#include "threshold.h"

#define APP_FW_VERSION_NUM     1

/* ==================== State Machine ==================== */
typedef enum {
    STATE_INIT = 0,
    STATE_SLEEP,
    STATE_WAKEUP,
    STATE_COLLECT,
    STATE_UPLOAD,
    STATE_DOWNLINK,
    STATE_ALARM,
    STATE_BLE_OTA,
    STATE_CH4,
    STATE_LEAK          /* 静态测漏任务: 采集→分包上报→清除 (独立链路) */
} AppState_t;

extern AppState_t app_state;

/* CH4 request flag (set by downlink gas_get, checked by do_downlink) */
extern volatile uint8_t g_ch4_request;
extern uint8_t g_alarm_recover_reported; /* 报警关阀恢复"已上报一次"标志 (RAM) */
typedef struct {
    PT304D_Data raw;
    PT304D_Data raw2;
    float       voltage;
    float       last_pressure_collect;
    float       last_pressure_realtime;
    float       last_pressure_collect2;
    float       last_pressure_realtime2;
    float       last_normal_voltage;
    uint8_t     prev_online;
    uint8_t     offline_cnt;
    uint8_t     online_cnt;
    uint8_t     prev_online2;
    uint8_t     offline_cnt2;
    uint8_t     online_cnt2;
} SensorContext_t;

extern SensorContext_t g_sensor;
extern uint8_t g_lcd_active;   // LCD当前是否显示 (运行状态, 区别于配置项; main.c 维护)

// 供其他模块使用 (main.c 实现, downlink.c 等模块调用)
void lcd_shutdown(void);
/* 安装事件一次性上报: 传感器记录 + product-status=1 (未安装→已安装瞬间调用) */
void install_event_report(void);

const char* alarm_try_close_valve_all(const char *policy_str, ThresholdResult_t result);

const char* alarm_try_close_valve(ThresholdResult_t result);
const char* alarm_try_close_valve2(ThresholdResult_t result);   /* 出气端 (abnormal2_close) */
const char* ch4_alarm_try_close_valve(void);
void upload_schedule_reset(void);   /* 上报周期/后延配置变更后调用, 重置延迟上报锁存 */

/* ==================== 告警新等级判定 + 统一确认上报 (三条路径共用) ====================
 * 判据来自 alarm_lock (Middle/alarm_lock.c): 与"最后已上报等级"不同即为新告警。
 * mask: bit0=通道0(进气端) bit1=通道1(出气端) bit2=电压(仅 check_voltage=1 时可能置位)
 * 注: 电压码不进入通道锁; 电压由独立 1 bit 锁维护。 */
uint8_t alarm_new_mask(ThresholdResult_t r1, ThresholdResult_t r2, uint8_t check_voltage);

/* 压力上拍值(突变基线)更新: 通道在线取当前值, 离线置 -1.0f (首次采样约定, 跳过突变)。
 * 供 main.c / downlink.c 各路径统一调用, 避免把哨兵值(-1000)当基线。 */
void sensor_baseline_update_collect(void);
void sensor_baseline_update_realtime(void);

/* 统一"确认异常"处理上下文 */
typedef struct {
    uint8_t     check_voltage;   /* 1=本路径做了电压判定(可用 mask bit2 置电压锁) */
    uint8_t     sensor_err;      /* 1=附带 rtu-status 上报 (传感器离线) */
    uint8_t     volt_new;        /* 1=本路径判定出"新的电压告警"(查询路径用) */
    const char *tag;             /* 调试打印前缀, 如 "RT"/"SM"/"QRY" */
} AlarmConfirmCtx_t;

/* 确认异常: 记录锁 → 按策略关阀 → 上报(报警批量 + 电压报警 + 阀门状态)。
 * 返回关阀结果串(未关阀为 NULL)。关阀不依赖 4G; 上报部分受连接状态门控。 */
const char *alarm_confirm_and_report(const AlarmConfirmCtx_t *ctx, uint8_t mask,
                                     ThresholdResult_t r1, ThresholdResult_t r2,
                                     float last_p1, float last_p2);

/* 每拍安全动作 (与"上报去重"解耦): 当前等级满足 abnormal_close/abnormal2_close 策略
 * 即关阀 (内部幂等, 同一轮告警只关一次), 并上报阀门状态。
 * 用途: 告警已上报(锁住)后策略才改为自动关阀、或首次关阀未成功时补动作。
 * 返回: 1=本拍发生了关阀, 0=无动作。 */
uint8_t alarm_safety_close_now(ThresholdResult_t r1, ThresholdResult_t r2,
                               uint8_t ch0_online, uint8_t ch1_online);

/* 定时开关阀检查: 最高优先级, 立刻执行到期的定时开关阀事件
 * 静态测漏任务运行期间也需周期调用, 否则 RTC ISR 置位的 g_timing_pending
 * 不清零会导致所有 AT 指令返回 EC_PREEMPT (4G 通信失效) */
void vtiming_check_now(void);

#endif

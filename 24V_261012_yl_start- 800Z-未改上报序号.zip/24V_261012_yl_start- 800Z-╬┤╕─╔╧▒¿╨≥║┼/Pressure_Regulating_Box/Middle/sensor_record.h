#ifndef SENSOR_RECORD_H
#define SENSOR_RECORD_H

#include <stdint.h>

/**
 * @file sensor_record.h
 * @brief 传感器记录结构定义 (EEPROM 历史 / 上报接口共用)
 */

/* 记录标志位 */
#define SENSOR_FLAG_ALARM        0x01   /* 报警记录 */

/* 单条传感器记录 (44 字节)
 * 注: 通道语义以 PT_304D_CHANNEL_COUNT 为准 —— 当前 2 路:
 *     第1路 = 中压/进气端 (I2C0: PC11/PC12), 第2路 = 低压/出气端 (I2C1: PB6/PB7)。
 *     后期 4 路压变时本结构需按新物模型扩展。 */
typedef struct {
    float pressure;             /* 中压/进气端 (CH2) 压力 (Pa) */
    float temperature;          /* 中压/进气端 (CH2) 温度 (C) */
    float pressure2;            /* 低压/出气端 (CH1) 压力 (Pa) */
    float temperature2;         /* 低压/出气端 (CH1) 温度 (C) */
    float voltage;              /* 电池电压 (V) */
    char  timestamp[20];        /* "20xx-xx-xx xx:xx:xx" */
    uint8_t flags;              /* SENSOR_FLAG_xxx */
    uint8_t reserved[3];        /* 对齐到 4 字节 */
} SensorRecord_t;

#endif /* SENSOR_RECORD_H */

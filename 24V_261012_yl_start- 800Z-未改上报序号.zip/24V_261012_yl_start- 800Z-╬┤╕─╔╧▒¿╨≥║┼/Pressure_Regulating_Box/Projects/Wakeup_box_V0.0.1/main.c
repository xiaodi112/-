/**
 * @file main.c
 * @brief 调压箱物联网控制器 + 状态机驱动低功耗主程序
 *
 * 架构: MQTT持久连接 + MCU深休眠 + LPUART唤醒接收下发
 *
 * 状态机 (10个状态):
 *   STATE_INIT     → 上电初始化 → MQTT连接+订阅+首次上报 → STATE_SLEEP
 *   STATE_SLEEP    → 设闹钟 → 深休眠 → 模块QSCLK保持MQTT) → STATE_WAKEUP
 *   STATE_WAKEUP   → 恢复外设+判断唤醒源
 *                     RTC闹钟 → STATE_COLLECT
 *                     LPUART  → STATE_DOWNLINK
 *   STATE_COLLECT  → 采集+阈值检查 → 存入缓冲区 → STATE_UPLOAD/ALARM/SLEEP
 *   STATE_UPLOAD   → 批量逐条上报+清空缓冲区 → STATE_SLEEP
 *   STATE_DOWNLINK → 读取+处理MQTT下发指令+立即上报结果 → STATE_SLEEP
 *   STATE_ALARM    → 5次重采确认 → 报警上报 → STATE_SLEEP
 *   STATE_BLE_OTA  → BLE蓝牙固件升级(等待连接→接收数据→写Flash→提交)
 *   STATE_CH4  	→ 激光甲烷传感器采集: 上电→预热(20s)→采集→阈值判断→上报→断电。
 *   STATE_LEAK 	→ 静态测漏: 平台下发任务→按频率采集(不休眠/传感器不断电)→
 *                  每5条一包上报→回执3→清空暂存区→补执行阀门指令→回睡。
 */

#include "gd32l23x.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "systick.h"
#include "usart.h"
#include "delay.h"
#include "ec800e.h"
#include "mygpio.h"
#include "power.h"
#include "wakeup.h"
#include "tim.h"
#include "valve_timing.h"
#include "PT_304_35.h"
#include "valve.h"
#include "downlink.h"
#include "report.h"
#include "app_config.h"
#include "eeprom_config.h"
#include "config_policy.h"
#include "calib_mode.h"
#include "m24m01.h"
#include "main.h"
#include "adc_bat.h"
#include "adc.h"
#include "soft_i2c.h"
#include "motor.h"
#include "sensor_record.h"
#include "threshold.h"
#include "ota_app.h"
#include "slcd_seg.h"
#include "lcd_ui.h"
#include "buzzer.h"
#include "output.h"
#include "ble_ota.h"
#include "json_builder.h"
#include "eeprom_history.h"
#include "ch4_alarm.h"
#include "zero_cal.h"
#include "leak_task.h"
#include "leak_store.h"
#include "alarm_lock.h"

// ==================== 状态机 ====================
/* AppState_t moved to main.h */

// ==================== 全局变量 ====================
SensorContext_t g_sensor = { .last_pressure_collect = -1.0f, .last_pressure_realtime = -1.0f, .last_pressure_collect2 = -1.0f, .last_pressure_realtime2 = -1.0f, .prev_online = 1, .offline_cnt = 0, .online_cnt = 0, .prev_online2 = 1, .offline_cnt2 = 0, .online_cnt2 = 0, .last_normal_voltage = 3.6f };

#if CALIB_MODE_ENABLED
/* 未安装校零期: 不写历史, 只保留最新一条实时记录供周期上报 */
static SensorRecord_t s_calib_latest;
static uint8_t s_calib_latest_valid = 0;
#endif

#define SENSOR_OFFLINE_DEBOUNCE  3   // 连续N次离线才确认状态变化
#define SENSOR_ONLINE_DEBOUNCE   2   // 连续N次在线才确认状态变化(比离线快)
#define	one_by_one_delay		 900	// 逐条上报间隔延时

static volatile uint16_t wakeup_count = 0;
AppState_t app_state = STATE_INIT;
volatile uint8_t g_ch4_request = 0;
uint8_t g_alarm_recover_reported = 0;   // 报警关阀恢复"已上报一次"标志 (RAM, 防重复上报)
static uint8_t dot_uploaded_mask[3] = {0};
static uint16_t dot_uploaded_day = 0xFFFF;  // RTC day of uploaded bitmap (cross-day reset)  // dot pattern: uploaded-hour bitmap

/* ==================== 周期上报: 整点网格 + 标志位式调度 ====================
 * 上报点 = 绝对分钟轴(upload_interval_min 整数倍, 与采集点同轴, 0 点起算)
 *          → 固定对齐整点/整周期点(如采集20min+上报2h → 00:00,02:00,04:00...),
 *            与"上电时刻/上次上报时刻"无关, 不会因重启把相位带偏。
 * 触发**不依赖时间窗口/目标点**, 只看"待上报标志":
 *   s_upload_pending      : 1 = 有数据待上报(未确认成功); 只有"上报成功(缓冲清空)"才清零
 *   s_last_upload_idx     : 上次成功上报的"上报周期序号" = 绝对分钟/上报周期分钟 (持久化, 防重)
 *   s_pending_due_abs_min : 后延到期(绝对分钟), 只在 pending 时比较
 * 进入新的上报周期且该周期未上报 → 置 pending; 失败自动重试(标志不清), 成功即清 → 不漏不重。
 * 命中容差 = 整个上报周期(周期内任意一拍判定都命中), 抗长流程/被抢占/重启补报。
 * 好处: RTC 校时跳变/窗口外/唤醒被占用都不会造成"永久漏报" */
static uint8_t  s_upload_pending      = 0;
static uint32_t s_last_upload_idx     = 0xFFFFFFFFu;
static uint32_t s_pending_due_abs_min = 0;

/* 上报调度辅助函数 (定义在下方, 但实时循环里已使用, 故前置声明) */
static uint8_t  upload_due_now(void);
/* 用户端MQTT同步上报 (定义在下方, alarm_confirm_and_report 提前使用) */
static void user_mqtt_try_publish(void);
/* 4G 掉线巡检 (定义在文件末尾): 休眠闹钟与实时节拍都要用, 故前置声明 */
static void     check_4g_connection_supervision(void);
static uint16_t s_last_supervise_min = 0xFFFFu;   /* 上次巡检的"当日分钟" (0xFFFF=尚未建立基准) */
// valve_alarm_closed / valve_pre_alarm_order / ch4_alarm_closed 定义为 g_* 全局 (EEPROM 持久化, OTA 升级后自动恢复), 见 eeprom_config.h
uint8_t voltage_low_power = 0;              // 低电压省电模式; 8:00/18:00上报
uint8_t fourG_user_off = 0;                 // 用户手动关闭4G标志(防止do_wakeup盲目恢复PD9)
static uint8_t fourG_init_failed = 0;       // 4G注册失败标志(防止do_sleep保持4G在线, 下次上报重新尝试)
static uint8_t fourG_weak_signal = 0;       // 弱信号软关机标志(long模式按CSQ判断, 平时保持关机)
#define CSQ_WEAK_THRESHOLD  8               // CSQ<该值则软关机省电(8约-97dBm)
static uint8_t vlp_uploaded_this_hour = 0;  // 低电压模式: 防止同一小时重复上报

/* ==================== 告警新等级判定 (三条路径共用) ====================
 * 语义见 Middle/alarm_lock.c: 每通道记录"最后一次已上报等级", 等级变化(升级/降级)才报;
 * 相同等级去重; 恢复由连续 3 次全正常解锁。
 * mask: bit0=通道0(进气端) bit1=通道1(出气端) bit2=电压(仅 check_voltage=1 时)
 * 注: 电压码(VPROTECT/VOLT_HIGH/VOLT_LOW)不进入通道锁, 由独立 1 bit 电压锁维护。 */
uint8_t alarm_new_mask(ThresholdResult_t r1, ThresholdResult_t r2, uint8_t check_voltage)
{
    TempStatus_t t1, t2;
    uint8_t mask = 0;
    uint8_t online0 = (g_sensor.raw.err == PT304D_OK) ? 1u : 0u;
    uint8_t online1 = (g_sensor_count >= 2 && g_sensor.raw2.err == PT304D_OK) ? 1u : 0u;

    /* 离线通道不参与: 温度状态取 NORMAL, 且不产生该通道的新等级
     * (驱动失败会写哨兵 -1000Pa/-50C, 这里绝不能让哨兵进入任何判定) */
    t1 = online0 ? threshold_get_temp_status(g_sensor.raw.temperature) : TEMP_NORMAL;
    t2 = online1 ? threshold_get_temp_status2(g_sensor.raw2.temperature) : TEMP_NORMAL;

    if(online0 && alarm_lock_has_new(0, r1, t1)) mask |= 0x01;
    if(online1 && alarm_lock_has_new(1, r2, t2)) mask |= 0x02;
    if(check_voltage && alarm_lock_volt_has_new(r1)) mask |= 0x04;

    return mask;
}

/* ==================== 压力上拍值(突变基线)更新 ====================
 * 在线才更新; 离线置 -1.0f —— threshold_check/threshold_get_pressure_status 约定
 * last<0 为"首次采样", 会跳过突变判定, 保证传感器恢复后的第一拍不会因为
 * "哨兵 -> 真实值"的跳变而误报压力突变。 */
void sensor_baseline_update_collect(void)
{
    g_sensor.last_pressure_collect  = (g_sensor.raw.err == PT304D_OK)
                                    ? g_sensor.raw.pressure : -1.0f;
    g_sensor.last_pressure_collect2 = (g_sensor_count >= 2 && g_sensor.raw2.err == PT304D_OK)
                                    ? g_sensor.raw2.pressure : -1.0f;
}

void sensor_baseline_update_realtime(void)
{
    g_sensor.last_pressure_realtime  = (g_sensor.raw.err == PT304D_OK)
                                     ? g_sensor.raw.pressure : -1.0f;
    g_sensor.last_pressure_realtime2 = (g_sensor_count >= 2 && g_sensor.raw2.err == PT304D_OK)
                                     ? g_sensor.raw2.pressure : -1.0f;
}

#if BLE_ENABLED
static uint32_t g_ble_on_hhmmss = 0;                          // BLE开启时的RTC时间 (HHMMSS), 超过60s未连接超时自动关闭
#endif
static uint8_t g_is_minimal_wakeup = 0;            // 标志是否为最小唤醒(纯RTC采集或按键快检状态)
uint8_t g_need_adc_sampling = 1;                   // 标志当前唤醒是否需要执行电池电压采样
static uint32_t last_grid_collect_abs_min = 0xFFFFFFFF;  // 最后一次网格采集的"绝对分钟"(跨天不误判/不重复)
#if LASER_CH4_ENABLED
static uint8_t s_laser_done_hour = 0xFF;           // 激光定时采集: 本小时已触发标志(跨小时自动恢复)
#endif

// ==================== 定时开关阀 当日执行标志 ====================
uint8_t timing_open_done_today  = 0;   // 当日已执行开阀
uint8_t timing_close_done_today = 0;   // 当日已执行关阀
static uint8_t timing_last_reset_hour  = 0xFF;// 上次重置标志的小时(防止重复)
volatile uint8_t g_timing_pending = 0;   /* timing valve pending (set by RTC ISR) */
volatile uint8_t g_timing_alarm_set = 0; /* current RTC alarm is a timing-valve alarm */

// ==================== LCD 超时关闭 ====================
uint8_t  g_lcd_active     = 0;      // LCD当前是否正在显示(运行状态, 区别于产品配置g_lcd_enabled)
static uint32_t g_lcd_on_hhmmss = 0; // LCD开启时的RTC时间 (HHMMSS格式)
#define LCD_DISPLAY_TIMEOUT_SEC  60  // LCD无操作显示超时

/* LCD 硬件初始化 (无 LCD 产品为空操作) — 前向声明, 供 install_event_report/main 调用 */
static void lcd_hw_init(void);

static uint32_t hhmmss_to_seconds(uint32_t hhmmss)
{
    uint8_t h = (uint8_t)(hhmmss / 10000);
    uint8_t m = (uint8_t)((hhmmss / 100) % 100);
    uint8_t s = (uint8_t)(hhmmss % 100);
    return (uint32_t)h * 3600 + (uint32_t)m * 60 + s;
}

/* 有效采集间隔(分钟): 未安装校零期使用 CALIB_SAMPLE_MIN, 其它情况用配置值 */
static uint16_t sched_collect_min(void)
{
#if CALIB_MODE_ENABLED
    return calib_is_active() ? CALIB_SAMPLE_MIN : g_interval.collect_interval_min;
#else
    return g_interval.collect_interval_min;
#endif
}

/* ==================== 跨天周期调度 (绝对时间轴) ====================
 * 到期点 = 绝对分钟轴上的 collect_min 整数倍; 支持 2 天/1 周等 >1 天的周期。 */

/* 当前时刻是否为采集到期点 (同一分钟只算一次) */
static uint8_t sched_collect_due_now(void)
{
    uint16_t cm = sched_collect_min();
    uint32_t abs_min = sched_abs_min();

    if(cm == 0u) return 1u;
    if(abs_min == last_grid_collect_abs_min) return 0u;   /* 本分钟已采集过, 防重复 */
    return ((abs_min % (uint32_t)cm) == 0u) ? 1u : 0u;
}

/* 下一个采集到期点(绝对分钟) */
static uint32_t sched_next_collect_abs_min(void)
{
    uint16_t cm = sched_collect_min();
    uint32_t now_abs = sched_abs_min();

    if(cm == 0u) cm = 1u;
    return ((now_abs / (uint32_t)cm) + 1u) * (uint32_t)cm;
}

/* ==================== 4G 30分钟巡检: 适用条件与剩余时间 ====================
 * 巡检场景与 do_sleep 的"保持在线"条件一致: long 模式 且 (窗口内 或 end_result=1),
 * 且不处于 低电压省电 / 用户关4G / 已失败 / 弱信号 状态。 */
static uint8_t supervise_is_applicable(void)
{
    if(voltage_low_power || fourG_user_off || fourG_init_failed || fourG_weak_signal)
        return 0u;
    if(strcmp(g_window.pattern, "long") != 0)
        return 0u;
    return (config_is_active_window() || g_window.end_result == 1) ? 1u : 0u;
}

/* 当日分钟 (0~1439), 与巡检节流口径一致 */
static uint16_t supervise_now_min(void)
{
    uint32_t hhmmss = rtc_get_hhmmss();
    return (uint16_t)((hhmmss / 10000u) * 60u + ((hhmmss / 100u) % 100u));
}

/* 距下次巡检还剩多少分钟 (0=已到期); 0xFFFFFFFF=当前不需要巡检 */
static uint32_t supervise_wait_min(void)
{
    uint16_t now_min;
    uint16_t elapsed;

    if(!supervise_is_applicable())
        return 0xFFFFFFFFu;
    if(s_last_supervise_min == 0xFFFFu)
        return 0u;                      /* 还没有基准: 尽快巡检一次建立基准 */

    now_min = supervise_now_min();
    elapsed = (uint16_t)(now_min - s_last_supervise_min);
    if(elapsed >= FOURG_SUPERVISE_INTERVAL_MIN)
        return 0u;
    return (uint32_t)(FOURG_SUPERVISE_INTERVAL_MIN - elapsed);
}

/* 设定下一个采集闹钟: 锚定"到期时刻", 但最多睡 24h
 * —— 跨天周期在到期日之前每天醒一次判定(非到期点由 do_wakeup 直接回睡)
 * —— 一直在线模式下额外保证 ≤30 分钟醒一次做 4G 掉线巡检(只提前唤醒, 不改采集/上报网格) */
static void sched_set_next_collect_alarm(void)
{
    uint32_t now_abs  = sched_abs_min();
    uint32_t due      = sched_next_collect_abs_min();
    uint32_t wait_min;
    uint32_t tod;

    /* 待上报且配了后延: 若后延点早于下一个采集点, 把唤醒提前到后延点(保证后延精度) */
    if(s_upload_pending && s_pending_due_abs_min > now_abs && s_pending_due_abs_min < due)
        due = s_pending_due_abs_min;

    wait_min = due - now_abs;
    if(wait_min > 1440u) wait_min = 1440u;

    /* 30分钟巡检: 若巡检比采集/上报更早到期, 把本次睡眠缩短到巡检时刻 */
    {
        uint32_t sv_wait = supervise_wait_min();
        if(sv_wait < wait_min)
            wait_min = sv_wait;
    }
    if(wait_min == 0u)
        wait_min = 1u;                  /* 已到期: 1 分钟后醒 (避免 0 分钟闹钟) */

    tod = (now_abs + wait_min) % 1440u;
    rtc_set_alarm_at_hhmmss((tod / 60u) * 10000u + (tod % 60u) * 100u);
    printf_debug("[SM] RTC collect alarm: in %lumin (abs_due=%lu)\r\n",
                 (unsigned long)wait_min, (unsigned long)due);
}

/* 有效实时模式: 未安装校零期禁止秒级实时采集, 只用分钟节拍 */
static uint8_t real_mode_active(void)
{
#if CALIB_MODE_ENABLED
    return (g_real_enabled && !calib_is_active()) ? 1 : 0;
#else
    return g_real_enabled;
#endif
}

#if CALIB_MODE_ENABLED
/* 未安装校零诊断日志: 每个节拍样本打印一条 */
static void calib_log_sample(float p_raw, float p_cal)
{
    CalibStatus_t st;
    char ts[24];

    calib_get_status(&st);
    rtc_get_time_str(ts, sizeof(ts));
    printf_debug("[CALIB] sample %s P_raw=%.0fPa P_cal=%.0fPa zero=%ldPa(%d) "
                 "warm=%u hi=%u med=%u/%u cnt=%lu\r\n",
                 ts, p_raw, p_cal, (long)st.zero_pa, st.zero_valid,
                 st.warm, st.hi, st.med_n, (unsigned)CALIB_MEDIAN_CNT,
                 (unsigned long)st.samples);
}
#endif

#if (CALIB_MODE_ENABLED && LCD_ENABLED)
/* ==================== 未安装期LCD: 非阻塞短亮 ====================
 * 单路: 压力页亮5s → 息屏; 双路: 进口压力2s → 出口压力3s → 息屏.
 * (RTC闹钟秒级分辨, 双路2.5s近似为2s+3s, 合计5s)
 * 按键/下行事件优先: 按键点亮并允许翻页, 5s无操作再息屏. */
#define CALIB_LCD_PAGE_SEC       5u

/* 前向声明: LCD开关函数定义在本块之后 */
static void lcd_activate(void);
void lcd_shutdown(void);

static uint8_t  s_cal_lcd_wait = 0;       /* 1=有待处理LCD定时事件 */
static uint8_t  s_cal_lcd_state = 0;      /* 1=AUTO, 3=MANUAL */
static uint8_t  s_cal_lcd_step = 0;       /* 自动序列当前页序号 */
static uint32_t s_cal_lcd_deadline = 0;   /* 当日秒 */

static uint32_t calib_lcd_now(void)
{
    return hhmmss_to_seconds(rtc_get_hhmmss());
}

static void calib_lcd_deadline_set(uint16_t sec)
{
    s_cal_lcd_deadline = (calib_lcd_now() + sec) % 86400u;
    s_cal_lcd_wait = 1;
}

static int32_t calib_lcd_left(void)
{
    int32_t d = (int32_t)s_cal_lcd_deadline - (int32_t)calib_lcd_now();

    if(d >= 0)
        return d;                       /* 未到期 */
    if(d >= -3600)
        return 0;                       /* 短时已过期: 立即处理, 不跨天 */
    return d + 86400;                   /* 跨天: 明天该时刻 */
}

static void calib_lcd_alarm_set(void)
{
    uint32_t t = s_cal_lcd_deadline;
    rtc_set_alarm_at_hhmmss((t / 3600u) * 10000u + ((t / 60u) % 60u) * 100u + (t % 60u));
}

static void calib_lcd_refresh(void)
{
    lcd_ui_update_data(&g_sensor.raw, &g_sensor.raw2, g_sensor.voltage);
}

/* 自动序列长度: 单路 压力→温度; 双路 S2压力→S2温度→S1压力→S1温度 */
static uint8_t calib_lcd_seq_len(void)
{
#if LCD_SINGLE_SENSOR
    return 2u;
#else
    return 4u;
#endif
}

static void calib_lcd_show_step(uint8_t step)
{
#if LCD_SINGLE_SENSOR
    switch(step)
    {
        case 0: lcd_ui_set_page(LCD_PAGE_OUTLET_PRESSURE); break;
        case 1: lcd_ui_set_page(LCD_PAGE_OUTLET_TEMP);     break;
        default: break;
    }
#else
    switch(step)
    {
        case 0: lcd_ui_set_page(LCD_PAGE_INLET_PRESSURE);  break;
        case 1: lcd_ui_set_page(LCD_PAGE_INLET_TEMP);      break;
        case 2: lcd_ui_set_page(LCD_PAGE_OUTLET_PRESSURE); break;
        case 3: lcd_ui_set_page(LCD_PAGE_OUTLET_TEMP);     break;
        default: break;
    }
#endif
}

/* 默认页(退出未安装/恢复正常显示时使用) */
static void calib_lcd_page_a(void)
{
#if LCD_SINGLE_SENSOR
    lcd_ui_set_page(LCD_PAGE_OUTLET_PRESSURE);
#else
    lcd_ui_set_page(LCD_PAGE_INLET_PRESSURE);
#endif
}

static void calib_lcd_off(void)
{
    if(g_lcd_active) lcd_shutdown();
    s_cal_lcd_wait = 0;
    s_cal_lcd_state = 0;
    printf_debug("[CALIB] LCD off (blank)\r\n");
}

/* 节拍点亮: 自动序列开始 (每页5s; 压力页显示0, 温度页真实值) */
static void calib_lcd_auto_begin(void)
{
    if(!calib_is_active() || !g_lcd_enabled) return;
    lcd_activate();
    s_cal_lcd_step = 0;
    calib_lcd_show_step(0);
    calib_lcd_refresh();
    s_cal_lcd_state = 1;
    calib_lcd_deadline_set(CALIB_LCD_PAGE_SEC);
    printf_debug("[CALIB] LCD seq start: %u page(s), %us each\r\n",
                 calib_lcd_seq_len(), CALIB_LCD_PAGE_SEC);
}

/* LCD定时到期: 自动序列切下一页或息屏; 手动模式到期直接息屏 */
static void calib_lcd_next_step(void)
{
    if(s_cal_lcd_state == 3)                 /* 手动模式: 5s无操作 → 息屏 */
    {
        calib_lcd_off();
        return;
    }

    s_cal_lcd_step++;
    if(s_cal_lcd_step >= calib_lcd_seq_len())
    {
        calib_lcd_off();
        return;
    }
    calib_lcd_show_step(s_cal_lcd_step);
    calib_lcd_refresh();
    calib_lcd_deadline_set(CALIB_LCD_PAGE_SEC);
    printf_debug("[CALIB] LCD page %u/%u, next in %us\r\n",
                 s_cal_lcd_step + 1, calib_lcd_seq_len(), CALIB_LCD_PAGE_SEC);
}

/* 按键等人工事件: 点亮并重置5秒无操作计时 */
static void calib_lcd_activity(void)
{
    if(!calib_is_active() || !g_lcd_enabled) return;
    lcd_activate();
    s_cal_lcd_state = 3;                 /* 手动模式: 不再自动切页 */
    calib_lcd_deadline_set(5u);
}

/* 锁定/退出未安装: 取消短亮逻辑, 恢复默认页与正常LCD策略 */
static void calib_lcd_exit_to_normal(void)
{
    if(!s_cal_lcd_wait && s_cal_lcd_state == 0) return;
    s_cal_lcd_wait = 0;
    s_cal_lcd_state = 0;
    if(g_lcd_enabled)
    {
        lcd_activate();
        calib_lcd_page_a();
        calib_lcd_refresh();
    }
}

#define CALIB_LCD_BLOCKED()   (calib_is_active())
#else
#define CALIB_LCD_BLOCKED()   (0)
#endif /* CALIB_MODE_ENABLED && LCD_ENABLED */

#if CALIB_MODE_ENABLED
/* ==================== 安装事件上报 (未安装→已安装 一次性) ====================
 * 立即尝试一次4G(必要时冷启动), 上报:
 *   1) 单条传感器记录(双路自动带 temp/temp2/pressure/pressure2)
 *   2) product-status=1
 * 失败不重试; 引脚的初始化按 调试串口→GPIO→LPUART→4G→传感器→ADC 顺序处理 */
void install_event_report(void)
{
    PT304D_Data d1, d2;
    SensorRecord_t rec;
    float v;
    uint8_t was_online;
    uint8_t ok;

    /* 1. 恢复调试串口(休眠后PC4/PC5为Analog) */
    trea_uart_init();
    /* 2. 恢复电源/控制引脚(PA0/PC10/PF1等) */
    gpio_init();
    /* 3. 恢复4G LPUART (PD8/PD9) */
    com_lpuart_init();
    trea_delay_ms(50);

    /* 4. 4G: 在线则唤醒确认, 断电则冷启动一次; 失败不重试 */
    was_online = EC801E_IsAlive();
    if(was_online)
    {
        EC801E_Wakeup();
        ok = (EC801E_EnsureConnected() == EC_OK);
    }
    else
    {
        ok = (EC801E_InitAndConnect() == EC_OK);
    }
    if(!ok)
    {
        if(!was_online) EC801E_PowerOff();
        printf_debug("[CALIB] install event report: 4G unavailable, skip\r\n");
#if LCD_ENABLED
        calib_lcd_exit_to_normal();
#endif
        return;
    }

    /* 5. 现场采集压力/温度 (双路一起采) 与电压 */
    memset(&d1, 0, sizeof(d1));
    memset(&d2, 0, sizeof(d2));
    PT304D_CollectAll((g_sensor_count >= 2) ? &d2 : NULL, &d1);
    v = adc_bat_read_voltage();
    if(v < 0.0f) v = g_sensor.last_normal_voltage;

    memset(&rec, 0, sizeof(rec));
	if(g_sensor_count >= 2)
	{
		rec.pressure     = d1.pressure;
		rec.temperature  = d1.temperature;
		rec.pressure2    = d2.pressure;
		rec.temperature2 = d2.temperature;
		if(d1.pressure<=0) d1.pressure = 0;
		if(d2.pressure<=0) d2.pressure = 0;
	}
	else
	{
		rec.pressure     = d1.pressure;
		rec.temperature  = d1.temperature;
		if(d1.pressure<=0) d1.pressure = 0;
	}
	rec.voltage      = v;
    rtc_get_time_str(rec.timestamp, sizeof(rec.timestamp));

    /* 6. 上报: 传感器记录 + 安装状态 */
    EC801E_PublishSingleRecord(&rec);
    trea_delay_ms(300);
    report_publish_field("product-status", "1");
    printf_debug("[CALIB] install event reported: P=%.2f T=%.2f V=%.2f status=1\r\n",
                 rec.pressure, rec.temperature, rec.voltage);

    /* 7. 收尾: 长连接保持在线 / 短连接断电 */
    if(was_online) EC801E_SetSleepMode(1);
    else
    {
        fourG_drain_before_power_off();   /* 断电前必读: 防排队指令随断电丢失 */
        EC801E_PowerOff();
    }

    /* 8. LCD: 退出未安装短亮状态, 显示真实压力 (无 LCD 产品为空操作) */
    lcd_hw_init();
#if LCD_ENABLED
    calib_lcd_exit_to_normal();
#endif
}
#else
void install_event_report(void) { }
#endif /* CALIB_MODE_ENABLED */

// ==================== 周期上报: 整点网格 + 标志位式调度 ====================
/* 上报周期序号 = 绝对分钟 / 上报周期分钟 (00:00 起算): 整个上报周期内取值不变
 *   → 命中容差 = 整个上报周期(周期内任意一拍判定都命中), 抗阀动作等长流程推迟/
 *     被抢占/重启补报; 跨出周期才等下一个上报点。
 *   注: 判定与采集节拍解耦(不用采集点序号), 采集周期变化/校零期都不影响上报网格 */
static uint32_t upload_grid_index(void)
{
    uint32_t um = (uint32_t)g_interval.upload_interval_min;
    if(um == 0u) return 0xFFFFFFFFu;
    return sched_abs_min() / um;
}

/* 上报周期起点(绝对分钟): 后延的基准 */
static uint32_t upload_period_start(void)
{
    uint32_t um = (uint32_t)g_interval.upload_interval_min;
    if(um == 0u) return sched_abs_min();
    return (sched_abs_min() / um) * um;
}

/* 采集完成后调用: 进入新的上报周期且该周期未上报 → 置"待上报"标志(并算出到期时刻)
 *   上报点 = 绝对时间轴上"上报周期"的整数倍(00:00 起算) → 固定整点, 与上电/重启时刻无关 */
static void upload_pending_update(void)
{
    uint32_t idx;

    if(g_interval.upload_interval_min == 0u)
        return;

    idx = upload_grid_index();
    if(s_last_upload_idx == 0xFFFFFFFFu)
    {
        s_last_upload_idx = idx;         /* 首次上电: 以当前周期为基准, 严格等一个完整周期 */
        return;
    }
    if(idx == s_last_upload_idx)
        return;                          /* 本周期已成功上报过(防重, 跨重启保持) */

    if(!s_upload_pending)
    {
        /* 后延到期时刻 = 本上报周期起点 + 后延:
         *   1) 单位必须与 sched_abs_min() 一致(绝对分钟) —— 不能乘 60 (那是秒);
         *   2) 以"周期起点"为基准而非"判定拍": 判定拍被阀动作等长流程推迟时,
         *      上报时刻仍是"网格点+后延", 不会跟着往后漂; 若该时刻已过则下一拍立即上报;
         *   3) 唤醒闹钟按分钟设置 → 后延分辨率为 1 分钟 (1.5min 四舍五入为 2min) */
        s_upload_pending      = 1;
        s_pending_due_abs_min = upload_period_start()
                              + (uint32_t)(g_report_delay_min + 0.5f);
        printf_debug("[SM] UPLOAD pending set (period=%lu um=%umin delay=%.1fmin due=%lu)\r\n",
                     (unsigned long)idx, (unsigned)g_interval.upload_interval_min,
                     g_report_delay_min,
                     (unsigned long)s_pending_due_abs_min);
    }
}

/* 是否该执行上报: 只看"待上报标志 + 后延" (与时间窗口/目标点无关) */
static uint8_t upload_due_now(void)
{
    if(!s_upload_pending)
        return 0;
    if(sched_abs_min() < s_pending_due_abs_min)
        return 0;                     /* 后延未到 */
    return 1;
}

/* 上报成功(历史缓冲清空)后提交: 清标志 + 记录本周期序号(持久化, 跨重启防重) */
static void upload_commit(void)
{
    if(!s_upload_pending)
        return;
    s_upload_pending  = 0;
    s_last_upload_idx = upload_grid_index();
    config_save_upload_idx(s_last_upload_idx);
    printf_debug("[SM] UPLOAD committed (period=%lu)\r\n", (unsigned long)s_last_upload_idx);
}

/* LCD 硬件初始化: 必须在 rtc_init_all 之后 (LXTAL 已启动)。
 * 无 LCD 产品 (LCD_ENABLED=0) 为空操作, g_lcd_active 恒为 0。 */
static void lcd_hw_init(void)
{
#if LCD_ENABLED
    if(!g_lcd_enabled) return;
    slcd_seg_configuration();
    lcd_ui_init();
    g_lcd_active = 1;
    g_lcd_on_hhmmss = rtc_get_hhmmss();
#endif
}

static void lcd_activate(void)
{
#if LCD_ENABLED
    if(!g_lcd_enabled) return;
    if(!g_lcd_active)
    {
        slcd_seg_configuration();
        lcd_ui_init();
    }
    g_lcd_active = 1;
    g_lcd_on_hhmmss = rtc_get_hhmmss();
#endif
}

void lcd_shutdown(void)
{
#if LCD_ENABLED
    if(!g_lcd_active) return;
    slcd_shutdown();   /* 关闭SLCD并释放引脚 (硬件关屏由BSP实现) */
    g_lcd_active = 0;
#endif
}

static void lcd_check_timeout(void)
{
#if LCD_ENABLED
#if CALIB_MODE_ENABLED
    if(calib_is_active()) return;       /* 未安装期用5s短亮逻辑, 不走正常超时 */
#endif
#if LCD_LOCK_ENABLED
    /* LCD锁定模式: 取消60s超时, 改用lcd_shutdown关闭 */
    if(!g_lcd_active) return;
    uint32_t now_sec = hhmmss_to_seconds(rtc_get_hhmmss());
    uint32_t on_sec  = hhmmss_to_seconds(g_lcd_on_hhmmss);
    uint32_t elapsed;
    if(now_sec >= on_sec)
        elapsed = now_sec - on_sec;
    else
        elapsed = (86400 - on_sec) + now_sec;  // 跨过午夜
    if(elapsed >= LCD_DISPLAY_TIMEOUT_SEC)
        lcd_shutdown();
#else
    /* LCD常亮模式: 不做超时, 保持常开 */
    (void)0;
#endif
#endif /* LCD_ENABLED */
}

// 传感器在线/离线消抖状态机 (进气端raw + 出气端raw2 共用; do_collect/do_realtime_check 复用)
// 更新 offline_cnt/offline_cnt2; 消抖通过后更新 prev_online/prev_online2.
// 返回: 1 = 发生经消抖确认的状态变化 0 = 无变化
static uint8_t sensor_debounce_update(uint8_t cur_online, uint8_t cur_online2)
{
    uint8_t state_changed = 0;

    // --- 进气端(raw, PT304D #2) ---
    if(cur_online && !g_sensor.prev_online)
    {
        g_sensor.offline_cnt = 0;
        g_sensor.online_cnt++;
        if(g_sensor.online_cnt >= SENSOR_ONLINE_DEBOUNCE)
            state_changed = 1;
    }
    else if(!cur_online && g_sensor.prev_online)
    {
        g_sensor.online_cnt = 0;
        g_sensor.offline_cnt++;
        if(g_sensor.offline_cnt >= SENSOR_OFFLINE_DEBOUNCE)
            state_changed = 1;
    }
    else
    {
        g_sensor.offline_cnt = cur_online ? 0 : g_sensor.offline_cnt;
        g_sensor.online_cnt  = cur_online ? g_sensor.online_cnt : 0;
    }

    // --- 出气端(raw2, PT304D #1) --- // 双传感器时才参与消抖
    if(g_sensor_count >= 2)
    {
        if(cur_online2 && !g_sensor.prev_online2)
        {
            g_sensor.offline_cnt2 = 0;
            g_sensor.online_cnt2++;
            if(g_sensor.online_cnt2 >= SENSOR_ONLINE_DEBOUNCE)
                state_changed = 1;
        }
        else if(!cur_online2 && g_sensor.prev_online2)
        {
            g_sensor.online_cnt2 = 0;
            g_sensor.offline_cnt2++;
            if(g_sensor.offline_cnt2 >= SENSOR_OFFLINE_DEBOUNCE)
                state_changed = 1;
        }
        else
        {
            g_sensor.offline_cnt2 = cur_online2 ? 0 : g_sensor.offline_cnt2;
            g_sensor.online_cnt2  = cur_online2 ? g_sensor.online_cnt2 : 0;
        }
    }

    if(state_changed)
    {
        // 同时更新两个通道的 prev 状态
        if(cur_online != g_sensor.prev_online &&
           (cur_online  ? (g_sensor.online_cnt  >= SENSOR_ONLINE_DEBOUNCE)
                        : (g_sensor.offline_cnt >= SENSOR_OFFLINE_DEBOUNCE)))
        {
            g_sensor.prev_online = cur_online;
            g_sensor.offline_cnt = 0;
            g_sensor.online_cnt  = 0;
        }
        if(g_sensor_count >= 2 &&
           cur_online2 != g_sensor.prev_online2 &&
           (cur_online2 ? (g_sensor.online_cnt2  >= SENSOR_ONLINE_DEBOUNCE)
                        : (g_sensor.offline_cnt2 >= SENSOR_OFFLINE_DEBOUNCE)))
        {
            g_sensor.prev_online2 = cur_online2;
            g_sensor.offline_cnt2 = 0;
            g_sensor.online_cnt2  = 0;
        }
    }
    return state_changed;
}

// ==================== 硬件恢复 ====================
static void sys_init(void)
{
    /* 重定位中断向量表到 App 运行地址 (Bootloader 跳转后必须设置, Cortex-M23 支持 VTOR) */
    SCB->VTOR = OTA_APP_ADDR;


    systick_config();
    my_systick_config();
    timer1_delay_init();
    trea_uart_init();

    gpio_init();

    /* 4G 常供电(新板): 模块开关机状态不再由 MCU 引脚维持, 此处无需"恢复供电"。
     * 需要模块上线时, 由连接路径 fourG_ensure_ready → EC801E_InitAndConnect
     * 探测状态后软开机 (PWRKEY 脉冲); 已在线则只做唤醒/确认。 */

    motor_init(MOTOR_ENABLED);
    soft_i2c_sensors_init();
    adc_bat_init();
    // 4G 模块开关机由连接路径软控制 (PWRKEY), 此处不涉及
    // PA5 (M_SLP 电机使能) 由 valve_execute() 内部控制，此处不做提前处理
    // PD4 (I2C 传感器接口) 默认保持 LOW; 由采集点按需 set/reset

    debug_rx_init();   // USART0 RX中断缓冲初始化
}

// ==================== 前向声明 ====================
static void ensure_full_init(void);
static void fourG_drain_before_power_off(void);   /* 断电前必读下行(定义在 4G 电源管理段) */

// ==================== LCD信号强度更新 (仅在线时调用, 同时上报给平台) ====================
static void lcd_update_csq(void)
{
    char csq_buf[8] = {0};
	EC801E_Wakeup();
	trea_delay_ms(120);
    if(EC801E_QueryCSQ(csq_buf, sizeof(csq_buf)) == EC_OK)
    {
        uint8_t csq_val = (uint8_t)atoi(csq_buf);
        if(g_lcd_active) lcd_ui_update_signal(csq_val);

        // 上报CSQ信号给平台
        report_publish_field("csq", csq_buf);
    }

    // 附加信息: LTE信号质量 + 网络注册状态
    {
        int rsrp = 0, sinr = 0;
        uint8_t cereg = 0;
        EC801E_QueryQCSQ(&rsrp, &sinr);
        EC801E_QueryCEREG(&cereg);
        printf_debug("[SM] Signal: CSQ=%s RSRP=%d SINR=%d CEREG=%d\r\n",
                     csq_buf, rsrp, sinr, cereg);
    }
}

// ==================== 4G 电源管理模块: 上电/唤醒 + 恢复 ====================
// 确保4G模块通道可用: 已通电则直接唤醒, 未通电则开机并初始化
// 返回: 1=连接成功, 0=失败; *p_was_online: 之前4G是否在线(供fourG_restore)
static int fourG_ensure_ready(int *p_was_online)
{
    int was_online = EC801E_IsAlive();
    *p_was_online = was_online;

    com_lpuart_init();
    trea_delay_ms(100);
    gpio_init();

    if(was_online)
    {
        EC801E_Wakeup();
        return (EC801E_EnsureConnected() == EC_OK);
    }
    else
    {
        fourG_user_off = 0;
        /* InitAndConnect 内含完整冷启动时序 (探测 + PWRKEY 开机脉冲), 不再单独 PowerOn */
        int ok = (EC801E_InitAndConnect() == EC_OK);
        if(ok)
        {
            fourG_init_failed = 0;
            EC801E_SetSleepMode(0);
            ri_exti_init();   /* 冷启动这一路此前 RI 未布防 → 本周期到达的下行脉冲可锁存 */
//            trea_delay_ms(300);
//            report_4g_power_state(1);
        }
        return ok;
    }
}

// ==================== 弱信号检测 (单次 CSQ 查询) ====================
/* 单次探测: 返回 1 = 本次信号"不好"; *out_csq 输出本次值(查询失败记 0xFF)
 * 注: 曾用过"两次确认"(第一次不好时延时 1s 再读一次, 两次都不好才断电),
 *     现按现场要求退回单次判定 —— 每次判定只发一条 AT+CSQ, 无额外延时。 */
static uint8_t fourG_csq_probe_bad(uint8_t *out_csq)
{
    char csq_buf[8] = {0};

    if(EC801E_QueryCSQ(csq_buf, sizeof(csq_buf)) != EC_OK)
    {
        *out_csq = 0xFF;
        return 1;
    }
    *out_csq = (uint8_t)atoi(csq_buf);
    return (*out_csq < CSQ_WEAK_THRESHOLD || *out_csq == 99) ? 1 : 0;
}

/* 断电前必读下行: 模块 QMTRECV 缓冲在模块 RAM 里, 断电即消失 → "临时连一次就断电"的
 * 业务路径必须在断电前把已缓存的平台指令读出来, 否则指令永久丢失(QoS0 平台不补发)。 */
static void fourG_drain_before_power_off(void)
{
    uint8_t n;

    if(!EC801E_IsAlive())
        return;                     /* 已断电: 无缓冲可读 */

    n = drain_pending_downlink();
    printf_debug("[SM] PWR-OFF drain: %d msg(s)\r\n", n);
}

// 恢复4G到休眠状态:
//   success=0 (连接失败): 无论之前是否在线, 统一软关机 (不再尝试PowerOn)
//   success=1 且之前在线: SetSleepMode(1) 恢复轻休眠保持在线
//   success=1 且之前关机: 上报下线后软关机 (临时连接用完即关)
static void fourG_restore(int was_online, int success)
{
    if(!success)
    {
        EC801E_PowerOff();
        return;
    }
    if(was_online)
    {
        // long模式: 根据信号强度决定是否保持在线 (单次 CSQ 查询)
        if(strcmp(g_window.pattern, "long") == 0)
        {
            uint8_t csq_val = 0;

            if(fourG_csq_probe_bad(&csq_val))
            {
                printf_debug("[SM] CSQ weak, power off 4G\r\n");
                fourG_weak_signal = 1;
//                    report_4g_power_state(0);
                fourG_drain_before_power_off();   /* 断电前必读: 防排队指令随断电丢失 */
                EC801E_PowerOff();
                return;
            }
            if(fourG_weak_signal)
            {
                printf_debug("[SM] CSQ=%d recovered, restoring long mode\r\n", csq_val);
                fourG_weak_signal = 0;
            }
        }
        EC801E_SetSleepMode(1);
    }
    else
    {
        // 之前断电(冷启动): 判断是否为弱信号恢复路径
        if(fourG_weak_signal && strcmp(g_window.pattern, "long") == 0)
        {
            uint8_t csq_val = 0;

            /* 弱信号断电后重新检查信号是否恢复: 单次查询正常即算恢复 */
            if(!fourG_csq_probe_bad(&csq_val))
            {
                printf_debug("[SM] CSQ=%d recovered (was weak), keep 4G online\r\n", csq_val);
                fourG_weak_signal = 0;
                EC801E_SetSleepMode(1);
                return;
            }
            // 否则: 断电
            printf_debug("[SM] Still weak signal, power off\r\n");
        }
//        report_4g_power_state(0);
        fourG_drain_before_power_off();   /* 断电前必读: 防排队指令随断电丢失 */
        EC801E_PowerOff();
    }
}

// ==================== 弱信号检测+决策 (do_upload/do_downlink 收尾专用) ====================
// 上报/下行处理完后调用, 决定是否让4G去休眠
// 返回: 1=信号OK(调用方应 SetSleepMode), 0=信号弱(内部已软关机)
static int fourG_signal_check_and_decide(void)
{
    uint8_t csq_val = 0;

    if(strcmp(g_window.pattern, "long") != 0)
        return 1;  // 非long模式不适用该逻辑

    /* 单次 CSQ 查询: 不好即判弱信号断电 */
    if(fourG_csq_probe_bad(&csq_val))
    {
        if(csq_val == 0xFF) printf_debug("[SM] CSQ query failed, 4G power off\r\n");
        else                printf_debug("[SM] CSQ=%d < %d, 4G power off (weak signal)\r\n",
                                         csq_val, CSQ_WEAK_THRESHOLD);
        fourG_weak_signal = 1;
//        report_4g_power_state(0);
        fourG_drain_before_power_off();   /* 断电前必读: do_upload/do_downlink 收尾也会走到这里 */
        EC801E_PowerOff();
        return 0;
    }

    // 信号恢复
    if(fourG_weak_signal)
    {
        printf_debug("[SM] CSQ=%d, signal recovered\r\n", csq_val);
        fourG_weak_signal = 0;
    }
    return 1;
}

// ==================== 电压采样模块 ====================

// 统一ADC电压采样: 读取→有效性判断→写入g_sensor.voltage
// update_baseline: 1=同时更新last_normal_voltage(正常采集), 0=仅更新voltage(报警重采等)
// fallback: ADC无效时的回退值 (通常为g_sensor.last_normal_voltage, 首次启动用3.6f)
static void sensor_sample_voltage(uint8_t update_baseline, float fallback)
{
    float v_now = adc_bat_read_voltage();
    if(v_now >= 0.0f)
    {
        g_sensor.voltage = v_now;
        if(update_baseline)
            g_sensor.last_normal_voltage = v_now;
    }
    else
        g_sensor.voltage = fallback;
}

/**
 * 异常自动关阀（通用）
 * @param policy_str  策略字符串（g_abnormal_close 或 g_abnormal2_close）
 * @param result      阈值判断结果
 * @return            动作执行结果字符串（已关阀），NULL（未关阀）
 *
 * 安全说明: 此函数内部初始化 IIC/电机，确保任何调用点均可安全执行
 */
const char* alarm_try_close_valve_all(const char *policy_str, ThresholdResult_t result)
{
    if (policy_str == NULL) {
        return NULL;
    }

    AbnormalClose_t policy = abnormal_from_str(policy_str);

    /* 仅按异常关阀策略判定; 电压类报警(VPROTECT/VOLT_HIGH/VOLT_LOW)只上报不动阀 */
    if (abnormal_should_close_valve(policy, result) && !g_valve_alarm_closed)
    {
        g_valve_pre_alarm_order = g_valve_pos_state;   /* 记录"关阀前的物理状态"(非用户指令) */

        printf_debug("[SM] Auto-close valve (policy=%s, result=%d, pre=%d)\r\n",
                     policy_str, result, g_valve_pre_alarm_order);

        soft_i2c_sensors_init();
        motor_init(MOTOR_ENABLED);

        /* update_last_order=0: 异常关阀是"设备自动安全动作", 不改变用户的最后指令
         * (平台看到的 valve-last-order 仍保持用户最后一次下发值);
         * 阀门物理位置由 valve 模块内部记录到 g_valve_pos_state。 */
        const char *vr = valve_execute("close", 0);

        g_valve_alarm_closed     = 1;
        g_alarm_recover_reported = 0;   // 新一轮报警: 恢复上报标志复位
        config_save_ext();

        return vr;
    }

    return NULL;
}

const char* alarm_try_close_valve(ThresholdResult_t result)
{
    return alarm_try_close_valve_all(g_abnormal_close, result);
}

const char* alarm_try_close_valve2(ThresholdResult_t result)
{
    return alarm_try_close_valve_all(g_abnormal2_close, result);
}

/* ==================== 统一"确认异常"处理 (周期/实时/查询三条路径共用) ====================
 * 调用前提: 已完成 3 次重采确认; mask 为 alarm_new_mask() 的最终结果。
 * 顺序: 先记录锁(去重基准) → 按策略关阀(安全动作, 不依赖4G) → 上报。
 * 报文: 报警批量(实测值+状态) → (新电压告警)LY06 → (发生关阀)阀门状态;
 *       字段与顺序保持与原 do_alarm/do_realtime_check 一致。 */
const char *alarm_confirm_and_report(const AlarmConfirmCtx_t *ctx, uint8_t mask,
                                     ThresholdResult_t r1, ThresholdResult_t r2,
                                     float last_p1, float last_p2)
{
    uint8_t ch0_new = (mask & 0x01u) ? 1u : 0u;
    uint8_t ch1_new = (mask & 0x02u) ? 1u : 0u;
    uint8_t volt_new;
    TempStatus_t t1, t2;
    const char *vr1 = NULL;
    const char *vr2 = NULL;
    const char *vr;
    int was_online;
    int ec_ok;

    if(ctx == NULL) return NULL;

    volt_new = (uint8_t)(((ctx->check_voltage && (mask & 0x04u)) ? 1u : 0u) |
                         (ctx->volt_new ? 1u : 0u));

    /* 1) 记录"最后已上报等级" (即使因 4G 失败没发出去, 也按已确认处理, 避免每拍重报) */
    if(ch0_new)
    {
        /* mask bit0 只在 ch0 在线时才会置位; 这里仍按在线状态取状态码, 确保哨兵不参与判定 */
        t1 = (g_sensor.raw.err == PT304D_OK) ? threshold_get_temp_status(g_sensor.raw.temperature) : TEMP_NORMAL;
        alarm_lock_latch(0, r1, t1);
        printf_debug("[%s] latch ch0 r=%d t=%d\r\n",
                     ctx->tag ? ctx->tag : "ALK", (int)r1, (int)t1);
    }
    if(ch1_new)
    {
        t2 = (g_sensor_count >= 2 && g_sensor.raw2.err == PT304D_OK)
           ? threshold_get_temp_status2(g_sensor.raw2.temperature) : TEMP_NORMAL;
        alarm_lock_latch(1, r2, t2);
        printf_debug("[%s] latch ch1 r=%d t=%d\r\n",
                     ctx->tag ? ctx->tag : "ALK", (int)r2, (int)t2);
    }
    if(volt_new)
        alarm_lock_volt_latch();

    /* 2) 关阀 (安全动作, 先于 4G; 仅对新告警的通道按各自策略判定)
     *    关阀内部忙等最长 g_valve_timeout_ms, valve_execute 忙等期间自行喂狗;
     *    这里前后各喂一次, 覆盖 IIC/电机初始化与收尾。 */
    if(ch0_new || ch1_new)
        swdt_feed();
    if(ch0_new) vr1 = alarm_try_close_valve(r1);
    if(ch1_new) vr2 = alarm_try_close_valve2(r2);
    vr = vr1 ? vr1 : vr2;
    if(ch0_new || ch1_new)
        swdt_feed();

    printf_debug("[%s] ALARM confirmed: %s mask=0x%02X P=%.2f T=%.2f V=%.2f%s\r\n",
                 ctx->tag ? ctx->tag : "ALK",
                 threshold_alarm_type_str(r1 != THRESHOLD_OK ? r1 : r2),
                 mask, g_sensor.raw.pressure, g_sensor.raw.temperature, g_sensor.voltage,
                 vr ? " valve-closed" : "");

    /* 3) 上报 (4G 连接失败不影响锁与关阀) */
    ec_ok = fourG_ensure_ready(&was_online);
    if(ec_ok)
    {
        if(r1 != THRESHOLD_OK || r2 != THRESHOLD_OK)
        {
            report_publish_alarm_batch(last_p1, last_p2);
        }
        if(volt_new)
        {
            trea_delay_ms(300);
            report_publish_ly06(1, g_sensor.voltage);
        }
        if(ctx->sensor_err)
            report_publish_sensor_status();
        if(vr != NULL)
        {
            trea_delay_ms(300);
            EC801E_PublishValveStatus(vr, g_valve_last_order);
        }

        /* 用户端MQTT同步上报传感器数据 */
        user_mqtt_try_publish();
    }
    fourG_restore(was_online, ec_ok);

    /* 4) 锁变化落盘 (节流: 5min) */
    alarm_lock_save(0);

    return vr;
}

/* ==================== 每拍安全动作 (与"上报去重"解耦) ====================
 * 只要当前等级满足 abnormal_close / abnormal2_close 策略就关阀, 不依赖"是否为新告警"。
 * alarm_try_close_valve* 内部已有"策略匹配 + !g_valve_alarm_closed"双守卫, 天然幂等:
 * 同一轮告警只关一次, 不会重复动作。典型场景: 告警已上报(锁住)之后才把策略改成 pvlow
 * —— 下一个阈值拍即可补关阀, 无需等压力等级再次变化。
 * 返回: 1=本拍发生了关阀(并已上报阀门状态), 0=无动作。 */
uint8_t alarm_safety_close_now(ThresholdResult_t r1, ThresholdResult_t r2,
                               uint8_t ch0_online, uint8_t ch1_online)
{
    const char *vr1 = NULL;
    const char *vr2 = NULL;
    const char *vr;
    int was_online;
    int ec_ok;

    if(ch0_online) vr1 = alarm_try_close_valve(r1);
    if(ch1_online) vr2 = alarm_try_close_valve2(r2);
    vr = vr1 ? vr1 : vr2;

    if(vr == NULL)
        return 0;

    printf_debug("[SM] SAFETY close (dedup path, policy matched): %s\r\n", vr);

    /* 动作已发生: 上报阀门状态 (4G 不可用不影响关阀) */
    ec_ok = fourG_ensure_ready(&was_online);
    if(ec_ok)
    {
        trea_delay_ms(300);
        EC801E_PublishValveStatus(vr, g_valve_last_order);
    }
    fourG_restore(was_online, ec_ok);

    return 1;
}

//// 异常自动关阀 (进气端 abnormal_close pv* 策略): 根据策略判断是否关阀, 不依赖4G通信状态
//// 返回: 动作执行结果字符串(已关阀), NULL(未关阀)
//// 安全说明: 此函数内部初始化IIC/电机, 确保任何调用点的均可安全执行
//const char* alarm_try_close_valve(ThresholdResult_t result)
//{
//    AbnormalClose_t policy = abnormal_from_str(g_abnormal_close);
//    /* 仅按异常关阀策略判定; 电压类报警(VPROTECT/VOLT_HIGH/VOLT_LOW)只上报不动阀 */
//    if(abnormal_should_close_valve(policy, result) && !g_valve_alarm_closed)
//    {
//        g_valve_pre_alarm_order = g_valve_last_order;
//        printf_debug("[SM] Auto-close valve (policy=%s, result=%d, pre=%d)\r\n",
//                     g_abnormal_close, result, g_valve_pre_alarm_order);
//    soft_i2c_sensors_init();
//        motor_init(MOTOR_ENABLED);
//        const char *vr = valve_execute("close", 0);
//        g_valve_alarm_closed = 1;
//        g_alarm_recover_reported = 0;   // 新一轮报警: 恢复上报标志复位
//        config_save_ext();
//        return vr;
//    }
//    return NULL;
//}

//// 异常自动关阀 (出气端 abnormal2_close pv* 策略): 逻辑同进气端, 判定用 g_abnormal2_close
//// 返回: 动作执行结果字符串(已关阀), NULL(未关阀)
//const char* alarm_try_close_valve2(ThresholdResult_t result)
//{
//    AbnormalClose_t policy = abnormal_from_str(g_abnormal2_close);
//    if(abnormal_should_close_valve(policy, result) && !g_valve_alarm_closed)
//    {
//        g_valve_pre_alarm_order = g_valve_last_order;
//        printf_debug("[SM] Auto-close valve (outlet policy=%s, result=%d, pre=%d)\r\n",
//                     g_abnormal2_close, result, g_valve_pre_alarm_order);
//        soft_i2c_sensors_init();
//        motor_init(MOTOR_ENABLED);
//        const char *vr = valve_execute("close", 0);
//        g_valve_alarm_closed = 1;
//        g_alarm_recover_reported = 0;   // 新一轮报警: 恢复上报标志复位
//        config_save_ext();
//        return vr;
//    }
//    return NULL;
//}

// 激光甲烷异常自动关阀 (abnormal3_close: 1=开启): 报警即关阀, 关闭后保持
// 直到平台 valve_open 手动打开 (不参与压力/温度报警的自动恢复链)
// 关阀标志 EEPROM 持久化: 掉电/重启后保持关闭状态, 不会被下一次采集误判为"未关阀"
// 返回: 动作执行结果字符串(已关阀), NULL(策略未启用/已关闭)
const char* ch4_alarm_try_close_valve(void)
{
    if(g_abnormal3_close != 1)
        return NULL;
    if(g_ch4_alarm_closed)
        return NULL;

    g_ch4_alarm_closed = 1;
    g_alarm_recover_reported = 0;   // 新一轮报警: 恢复上报标志复位
    printf_debug("[SM] CH4 auto-close valve (abnormal3=1)\r\n");
    soft_i2c_sensors_init();
    motor_init(MOTOR_ENABLED);
    /* update_last_order=0: 激光甲烷报警关阀同样是自动安全动作, 不改用户最后指令 */
    const char *vr = valve_execute("close", 0);
    config_save_ext();   // 关阀动作结束后再持久化标志: 中途掉电则重启后重新关阀, 避免半开状态被当作已关
    return vr;
}

// 用户端MQTT上报 (id=1, LY格式双通道): 连接、发送、断开 (约1分钟耗时)
static void user_mqtt_try_publish(void)
{
    if(!EC801E_UserMqtt_IsConfigured())
        return;

    trea_delay_ms(500);
    if(EC801E_UserMqtt_Connect() != EC_OK)
    {
        printf_debug("[SM] UserMqtt: connect failed, retry once...\r\n");
        trea_delay_ms(1000);
        if(EC801E_UserMqtt_Connect() != EC_OK)
        {
            printf_debug("[SM] UserMqtt: retry failed, skip publish\r\n");
            return;
        }
    }

    trea_delay_ms(300);
    if(EC801E_UserMqtt_PublishSensorData(&g_sensor.raw, &g_sensor.raw2, g_sensor.voltage) != EC_OK)
        printf_debug("[SM] UserMqtt: publish sensor data failed\r\n");
    else
        printf_debug("[SM] UserMqtt: publish OK\r\n");

    trea_delay_ms(500);
    EC801E_UserMqtt_Disconnect();
}

// ==================== 状态上报汇总模块 ====================
// 上报实测值+状态 (temp/pressure/temp-status/pressure-status [+第二路])
// last_p1/last_p2: 上次压力值(用于突变判断)
static void publish_all_status(float last_p1, float last_p2)
{
    report_publish_status_all(last_p1, last_p2);
}

// ==================== 定时阀: 执行+上报(最高优先级) ====================
// action: "open" 或 "close"
// 执行阀门动作, 通过4G上报 valve-control + valve-last-order, 恢复PSM
static void vtiming_execute_and_report(const char *action);   /* forward */
/* timing valve immediate check: run during upload/blocking as fallback;
 * executes when within +-30s window and not yet done today */
/* 日期+1 (2000-2099, 4年一闰) */
static void vtiming_next_day(RtcDateTime_t *dt)
{
    static const uint8_t mdays[12] = {31,28,31,30,31,30,31,31,30,31,30,31};
    uint8_t maxd = mdays[dt->month - 1];

    if(dt->month == 2 && (dt->year % 4) == 0) maxd = 29;

    dt->day++;
    if(dt->day > maxd)
    {
        dt->day = 1;
        dt->month++;
        if(dt->month > 12)
        {
            dt->month = 1;
            dt->year++;
            if(dt->year > 99) dt->year = 0;   /* 2000年后回卷 */
        }
    }
}

/* 计算距离下一个匹配事件的时间 (YYMMDDHHMM, 支持通配); 无匹配返回 0xFFFFFFFF */
static uint32_t vtiming_next_wait(const char *t, const RtcDateTime_t *now)
{
    RtcDateTime_t cand;
    uint16_t days;
    uint32_t tgt_sec, now_sec;
    uint8_t y, mo, d, h, mi;

    if(!valve_timing_time_valid(t)) return 0xFFFFFFFF;

    y  = (uint8_t)((t[0] - '0') * 10 + (t[1] - '0'));
    mo = (uint8_t)((t[2] - '0') * 10 + (t[3] - '0'));
    d  = (uint8_t)((t[4] - '0') * 10 + (t[5] - '0'));
    h  = (uint8_t)((t[6] - '0') * 10 + (t[7] - '0'));
    mi = (uint8_t)((t[8] - '0') * 10 + (t[9] - '0'));

    tgt_sec = ((uint32_t)h * 60 + mi) * 60;
    now_sec = ((uint32_t)now->hour * 60 + now->minute) * 60 + now->second;

    cand = *now;
    for(days = 0; days <= 366; days++)
    {
        if((y == 0 || y == cand.year) &&
           (mo == 0 || mo == cand.month) &&
           (d == 0 || d == cand.day))
        {
            /* 目标已过 则从明天开始算 */
            if(days == 0 && tgt_sec <= now_sec) { }
            else
                return (uint32_t)days * 86400 + tgt_sec - now_sec;
        }
        vtiming_next_day(&cand);
    }
    return 0xFFFFFFFF;
}

/* timing valve immediate check: run during upload/blocking as fallback;
 * executes when date matches (wildcard) and within tolerance */
void vtiming_check_now(void)
{
    RtcDateTime_t dt;

    /* 消费定时阀挂起事件: RTC ISR 置位的 g_timing_pending 必须在此清零,
     * 否则 EC_SendCmd 永久返回 EC_PREEMPT (4G 通信失效, do_upload 死循环) */
    g_timing_pending = 0;

    if(!g_valve_timing.on_switch && !g_valve_timing.off_switch) return;

    rtc_get_datetime(&dt);

    /* 跨天重置当日执行标志 */
    if(dt.hour == 0 && timing_last_reset_hour != 0)
    {
        timing_open_done_today  = 0;
        timing_close_done_today = 0;
        timing_last_reset_hour  = 0;
    }
    else if(dt.hour != 0)
        timing_last_reset_hour = dt.hour;

    /* 开阀: 定时开 + 当日未执行 + 时间匹配(±30s) */
    if(!timing_open_done_today && g_valve_timing.on_switch &&
       valve_timing_time_match(g_valve_timing.open_time, &dt, 30))
    {
        vtiming_execute_and_report("open");
        timing_open_done_today = 1;
    }

    /* 关阀 */
    if(!timing_close_done_today && g_valve_timing.off_switch &&
       valve_timing_time_match(g_valve_timing.close_time, &dt, 30))
    {
        vtiming_execute_and_report("close");
        timing_close_done_today = 1;
    }
}

static void vtiming_execute_and_report(const char *action)
{
    g_timing_pending = 0;   /* 执行前消费挂起事件, 确保 4G 上报不被 EC_PREEMPT 拦截 */
    /* 报警自动关阀/激光甲烷关阀未恢复前禁止自动开阀 (工业安全) */
    if(strcmp(action, "open") == 0 && (g_ch4_alarm_closed || g_valve_alarm_closed))
    {
        printf_debug("[SM] VTIMING: open skipped (alarm latch active)\r\n");
        return;
    }
    ensure_full_init();
    soft_i2c_sensors_init();
    motor_init(MOTOR_ENABLED);
    const char *vr = valve_execute(action, 1);
    printf_debug("[SM] VTIMING: %s result=%s\r\n", action, vr);

    int was_online;
    int ec_ok = fourG_ensure_ready(&was_online);
    if(ec_ok)
        EC801E_PublishValveStatus(vr, g_valve_last_order);
    fourG_restore(was_online, ec_ok);
}

// ==================== 实时路径: 按用户选择进入休眠 ====================
static void realtime_enter_sleep(void)
{
    uint8_t lpuart_enabled = 0;

    sensor_pwr_off();   /* 传感器 IIC 断电 (PC10=LOW), 采集时由 PT304D 上电 */
    rtc_alarm_wakeup_init();
    rtc_set_next_alarm_sec(g_real_frequency);
    g_timing_alarm_set = 0;   /* realtime alarm, timing handled per-cycle */

    // 4G在线时启用LPUART唤醒 + RI中断 (可接收平台下发, 弱信号/已关机时禁用)
    if(!voltage_low_power && !fourG_user_off && !fourG_init_failed && !fourG_weak_signal &&
       strcmp(g_window.pattern, "long") == 0 &&
       (config_is_active_window() || g_window.end_result == 1))
    {
        /* 注: 4G 常供电, 模块开机状态不需 MCU 维持, 此处只布防唤醒通道 */
        com_lpuart_init();
        lpuart_wakeup_init();
        ri_exti_init();
        lpuart_enabled = 1;
    }

    button_exti_init();
#if BLE_ENABLED
    if(g_bt_on) ble_exti_init();
#endif
    lpuart_dma_rx_disable();
    {
        PmSleepCfg_t sc = { lpuart_enabled, g_lcd_active, 0 };   /* bt_on 恒 0: 本产品无蓝牙 */
        enter_deepsleep_mode(&sc);
    }
}

// ==================== 实时采集最小唤醒路径 ====================
// 最小化初始化 SysTick + I2C + PD4, 采集判断异常
// 异常时重采确认, 确认后通过4G上报; 正常时直接回睡
// ==================== ==================== ====================
static void do_realtime_check(void)
{
    ThresholdResult_t result;
    ThresholdResult_t r1, r2;
    uint8_t sensor_err;
    uint8_t still_abnormal = 1;
    uint8_t i;
    uint8_t online0, online1;
    uint8_t mask;
    uint8_t unlocked = 0;
    TempStatus_t t1, t2;
    AlarmConfirmCtx_t ctx;

    // === 最小初始化 (时钟恢复) ===
    system_wakeup_reinit();

    // 软件看门狗: 实时采集路径由 do_sleep 循环直接调用(非主循环入口), 需自行使能
    // SysTick 由 system_wakeup_reinit 重新启动; 休眠时 enter_deepsleep_mode 会关闭
    swdt_enable(SWDT_TIMEOUT_MS);

    /* 30分钟掉线巡检: 实时模式的 tick 循环在 do_sleep 内部, 不回主循环 → 在这里补一次。
     * 函数内部按 30 分钟节流, 未到期只做几次比较, 不影响 5s 节拍。 */
    check_4g_connection_supervision();

    // === 采集 (双通道, 不采ADC; PD4/IIC 由 CollectAll 内部处理) ===
    PT304D_CollectAll((g_sensor_count >= 2) ? &g_sensor.raw2 : NULL, &g_sensor.raw);

    // === LCD超时检查 + 采集后刷新显示 ===
    lcd_check_timeout();
#if LCD_LOCK_ENABLED
    if(g_lcd_active) lcd_ui_refresh(&g_sensor.raw, &g_sensor.raw2, g_sensor.voltage);
#else
    /* LCD常亮模式: 每个采集周期自动翻一页 */
    if(g_lcd_active) { lcd_ui_refresh(&g_sensor.raw, &g_sensor.raw2, g_sensor.voltage); lcd_ui_next_page(); }
#endif

    // === 传感器在线/离线状态变化检测(带消抖, 双路在线/离线) ===
    {
        uint8_t cur_online  = (g_sensor.raw.err  == PT304D_OK) ? 1 : 0;
        uint8_t cur_online2 = (g_sensor_count >= 2 && g_sensor.raw2.err == PT304D_OK) ? 1 : 0;
        uint8_t state_changed;

        online0 = (uint8_t)cur_online;
        online1 = (uint8_t)cur_online2;
        state_changed = sensor_debounce_update(cur_online, cur_online2);

        /* 离线通道: 恢复计数归零, 保留最后等级 (不参与阈值检查, 不计正常) */
        if(!cur_online)  (void)alarm_lock_feed_normal(0, 0, THRESHOLD_OK, TEMP_NORMAL);
        if(!cur_online2) (void)alarm_lock_feed_normal(1, 0, THRESHOLD_OK, TEMP_NORMAL);

        if(state_changed)
        {
            ensure_full_init();
            trea_uart_init();
            {
                char rt_ts[32];
                rtc_get_time_str(rt_ts, sizeof(rt_ts));
                printf_debug("[RT] %s SENSOR STATE CHANGED: S2=%s(err=%d) S1=%s(err=%d) freq=%ds\r\n",
                             rt_ts,
                             cur_online  ? "ON" : "OFF", g_sensor.raw.err,
                             cur_online2 ? "ON" : "OFF", g_sensor.raw2.err,
                             g_real_frequency);
            }

            // 启动4G上报
            {
                int was_online;
                int ec_ok = fourG_ensure_ready(&was_online);
                if(ec_ok)
                {
                    report_publish_sensor_status();
                    printf_debug("[RT] Sensor state reported\r\n");
                }
                fourG_restore(was_online, ec_ok);
            }

            // 两路都离线才停止采集/上报; 任一路在线都继续 (离线通道按哨兵值存/报, 不判阈值)
            if(!cur_online && !cur_online2)
            {
                sensor_baseline_update_realtime();
                realtime_enter_sleep();
                return;
            }
        }
        else if(!cur_online && !cur_online2)
        {
            // 两路仍离线: 不重复上报, 直接回睡
            realtime_enter_sleep();
            return;
        }
    }

    // === 阈值检查 ===
    // 实时路径不采 ADC: 电压占位-1.0f (配合 check_voltage=0 + threshold_check 跳过) 表示"未采样电压"
    // skip_mutation=1: 恢复判断时跳过突变项, 防止压力回正常时瞬间变化触发突变报警
    // 离线通道: r 直接置 OK, 不调用判定函数 (驱动失败时是哨兵 -1000/-50, 绝不能进阈值)
    r1 = online0 ? threshold_check(g_sensor.raw.pressure, g_sensor.raw.temperature, -1.0f,
                                  g_sensor.last_pressure_realtime, 0, 1) : THRESHOLD_OK;
    r2 = online1 ? threshold_check2(g_sensor.raw2.pressure, g_sensor.raw2.temperature,
                                   g_sensor.last_pressure_realtime2, 1) : THRESHOLD_OK;
    result = (r1 != THRESHOLD_OK) ? r1 : r2;   /* 有效报警: 通道1优先 (关阀/上报/恢复) */
    sensor_err = (!online0 || !online1) ? 1u : 0u;   /* 仅供 rtu 附带上报, 不再参与恢复判定 */

    /* 每拍推进通道恢复计数: 异常/离线 → 归零; 在线全正常 → +1 (连续 3 次解锁) */
    t1 = online0 ? threshold_get_temp_status(g_sensor.raw.temperature) : TEMP_NORMAL;
    t2 = online1 ? threshold_get_temp_status2(g_sensor.raw2.temperature) : TEMP_NORMAL;
    if(online0) unlocked |= alarm_lock_feed_normal(0, 1, r1, t1);
    if(online1) unlocked |= alarm_lock_feed_normal(1, 1, r2, t2);

    // === 正常 → 恢复上报(解锁) → 复检突变 → 回睡 ===
    // 注: 离线通道 r 已置 OK, 所以 result==OK 即"在线通道均正常"(掉线通道不影响恢复判定)
    if(result == THRESHOLD_OK)
    {
        /* 恢复上报: (a) 连续 3 次全正常解锁 (b) 报警关阀后恢复 (重试直到上报成功) */
        if(unlocked ||
           (g_valve_alarm_closed && !g_ch4_alarm_closed &&
            !g_alarm_recover_reported && !voltage_low_power))
        {
            const char *vr = NULL;

            ensure_full_init();
            if(g_valve_alarm_closed && !g_ch4_alarm_closed)
            {
                motor_pos_init();     /* 深休眠后到位检测引脚为 Analog, 读取/驱动前恢复 */
                vr = valve_get_status();   /* 上报真实阀门状态(保持关闭) */
                g_alarm_recover_reported = 1;
            }
            {
                int was_online;
                int ec_ok = fourG_ensure_ready(&was_online);
                if(ec_ok)
                {
                    if(vr != NULL)
                    {
                        EC801E_PublishValveStatus(vr, g_valve_last_order);
                        trea_delay_ms(300);
                    }
                    report_publish_ly06(0, g_sensor.last_normal_voltage);
                    publish_all_status(g_sensor.last_pressure_realtime, g_sensor.last_pressure_realtime2);
                    alarm_lock_save(1);   /* 解锁状态立即落盘 */
                }
                fourG_restore(was_online, ec_ok);
            }
        }
        else
        {
            alarm_lock_save(0);           /* 正常采样: dirty + 5min 节流 flush */
        }

        // 动态阈值再次检查, 包含突变项 (skip_mutation=0)
        // 恢复上报结束后, 此处再确认是否触发新的突变异常
        // 离线通道不参与 (哨兵值绝不能进 threshold_check)
        r1 = online0 ? threshold_check(g_sensor.raw.pressure, g_sensor.raw.temperature, -1.0f,
                                      g_sensor.last_pressure_realtime, 0, 0) : THRESHOLD_OK;
        r2 = online1 ? threshold_check2(g_sensor.raw2.pressure, g_sensor.raw2.temperature,
                                       g_sensor.last_pressure_realtime2, 0) : THRESHOLD_OK;
        result = (r1 != THRESHOLD_OK) ? r1 : r2;

        sensor_baseline_update_realtime();

        if(result == THRESHOLD_OK)
        {
            realtime_enter_sleep();
            return;
        }
        // 突变异常 → 继续走下方异常确认流程
    }

    // === 异常 → 新等级判定 (去重: 与最后已上报等级相同则不重复报警/关阀) ===
    mask = alarm_new_mask(r1, r2, 0);
    if(mask == 0)
    {
        printf_debug("[RT] THRESHOLD SAME AS LAST (mask=0), skip alarm\r\n");
        /* 上报去重 ≠ 不动作: 等级已报过也按当前策略补一次关阀 (幂等, 策略变更后下一拍生效) */
        (void)alarm_safety_close_now(r1, r2, online0, online1);
        sensor_baseline_update_realtime();
        realtime_enter_sleep();
        return;
    }

    // === 异常 → 走重采确认 (3次; 骤变基线固定为进入时的上拍值) ===
    for(i = 0; i < APP_ALARM_RECHECK_COUNT; i++)
    {
        trea_delay_ms(APP_ALARM_RECHECK_DELAY_MS);
        PT304D_CollectAll((g_sensor_count >= 2) ? &g_sensor.raw2 : NULL, &g_sensor.raw);

        /* 每拍重算在线状态 (重采期间可能掉线); 离线通道不参与判定 */
        online0 = (g_sensor.raw.err == PT304D_OK) ? 1u : 0u;
        online1 = (g_sensor_count >= 2 && g_sensor.raw2.err == PT304D_OK) ? 1u : 0u;
        r1 = online0 ? threshold_check(g_sensor.raw.pressure, g_sensor.raw.temperature, -1.0f,
                                      g_sensor.last_pressure_realtime, 0, 0) : THRESHOLD_OK;
        r2 = online1 ? threshold_check2(g_sensor.raw2.pressure, g_sensor.raw2.temperature,
                                       g_sensor.last_pressure_realtime2, 0) : THRESHOLD_OK;
        result = (r1 != THRESHOLD_OK) ? r1 : r2;
        sensor_err = (!online0 || !online1) ? 1u : 0u;

        if(result == THRESHOLD_OK)
        {
            still_abnormal = 0;
            break;
        }
    }

    if(!still_abnormal)
    {
        // 偶发异常 → 回睡
        printf_debug("[RT] ALARM recovered at recheck, false alarm\r\n");
        sensor_baseline_update_realtime();
        realtime_enter_sleep();
        return;
    }

    // === 确认异常 → 记录锁 + 关阀 + 上报 (统一入口) ===
    mask = alarm_new_mask(r1, r2, 0);
    if(mask != 0)
    {
        ensure_full_init();
        trea_uart_init();
        printf_debug("[RT] ALARM: %s P=%.2f T=%.2f freq=%ds\r\n",
                     threshold_alarm_type_str(result), g_sensor.raw.pressure,
                     g_sensor.raw.temperature, g_real_frequency);

        ctx.check_voltage = 0;      /* 实时路径不采 ADC: 不触碰电压锁 */
        ctx.sensor_err    = sensor_err;
        ctx.volt_new      = 0;
        ctx.tag           = "RT";
        alarm_confirm_and_report(&ctx, mask, r1, r2,
                                 g_sensor.last_pressure_realtime,
                                 g_sensor.last_pressure_realtime2);
    }
    else
    {
        printf_debug("[RT] confirmed but already latched, skip\r\n");
    }

    // === 回睡 ===
    sensor_baseline_update_realtime();
    realtime_enter_sleep();
}

// ==================== 休眠流程 ====================
static void do_sleep(void)
{
    int fourG_keep_on = 0;

#if (CALIB_MODE_ENABLED && LCD_ENABLED)
    if(!calib_is_active())
        calib_lcd_exit_to_normal();     /* 已锁定: 取消未安装期LCD短亮状态 */
#endif

    motor_stop();   /* 停 PWM + M_INH 禁用 + V24 断电 (深睡期间由 gpio_enter_low_power 保持) */
    sensor_pwr_off();   /* 传感器 IIC 断电 (PC10=LOW); 注意: 深睡眠期间 PC10 由 gpio_enter_low_power 保持低电平 */

    gpio_bit_reset(GPIOA, GPIO_PIN_2);
    gpio_bit_reset(GPIOA, GPIO_PIN_3);
    gpio_bit_reset(GPIOC, GPIO_PIN_4);
    gpio_bit_reset(GPIOC, GPIO_PIN_5);
    gpio_bit_reset(GPIOB, GPIO_PIN_8);
    // PB9 = SLCD COM3, 保持关闭
    // PB6/PB7(I2C0 SCL/SDA): 常供电总线, 由 gpio_enter_low_power 转 Analog
    // 避免休眠期间总线上残留异常 I2C 信号导致功耗异常

#if MOTOR_DRV_MODE == 0
    gpio_bit_reset(GPIOA, GPIO_PIN_6);
    gpio_bit_reset(GPIOA, GPIO_PIN_7);
#endif

    // 4G电源控制: 根据window pattern决定V4G_EN(PB13)状态
    // 低电压省电模式: 强制4G断电

    /* 大睡收口: RI 只在"平台新下发"时脉冲, 读历史缓存不会再脉冲 → 留下的指令不会自愈。
     * 常态 ri_wakeup_flag=0 → 一次 AT 都不发, 不影响功耗。 */
    if(ri_wakeup_flag)
    {
        ri_wakeup_flag = 0;      /* 先消费: 后面 ri_exti_init()/enter_deepsleep_mode() 都会清标志 */
        if(EC801E_IsAlive())
        {
            uint8_t drained;

            printf_debug("[SM] SLEEP: RI pending, drain before sleep\r\n");
            ensure_full_init();
            com_lpuart_init();
            trea_delay_ms(100);
            gpio_init();

            drained = drain_pending_downlink();
            if(ri_wakeup_flag)
            {
                ri_wakeup_flag = 0;
                drained += drain_pending_downlink();
            }
            printf_debug("[SM] SLEEP: drained %d msg(s)\r\n", drained);

            EC801E_SetSleepMode(1);    /* 补读把 DTR 拉低了: 必须恢复 QSCLK, 否则模块整夜不睡 */
        }
        else
        {
            printf_debug("[SM] SLEEP: RI pending but 4G off, skip\r\n");
        }
    }

    if(voltage_low_power)
    {
        EC801E_PowerOff();          /* VLP: 软关机省电 */
    }
    else if(strcmp(g_window.pattern, "long") == 0)
    {
        // long模式: 活动窗口或end_result=1时保持4G (用户手动关闭/弱信号除外)
        if(!fourG_user_off && !fourG_init_failed && !fourG_weak_signal && (config_is_active_window() || g_window.end_result == 1))
        {
            fourG_keep_on = 1;
            /* 4G 常供电: 模块保持在线无需 MCU 操作, 只需 DTR 允许其轻休眠 */
            power_4g_dtr_set(1);   /* DTR HIGH: 允许模块进入轻休眠 (深睡时 PA0 保持输出) */
        }
        else
            EC801E_PowerOff();   // long+er=0+非窗口 / user_off / weak_signal: 4G 软关机
    }
    else
    {
        // short/dot: 4G 睡眠期软关机 (由do_upload上报时临时 PowerOn 后 PowerOff)
        EC801E_PowerOff();
    }

#if LCD_LOCK_ENABLED
    // === LCD 超时关闭: LCD处于显示时, 先短睡, 60秒超时后再关闭 ===
    // 实时模式(1-10s频率): do_realtime_check + lcd_check_timeout() 会处理, 此处跳过
    if(g_lcd_active && !real_mode_active() && !CALIB_LCD_BLOCKED())
    {
        uint32_t now_sec = hhmmss_to_seconds(rtc_get_hhmmss());
        uint32_t on_sec  = hhmmss_to_seconds(g_lcd_on_hhmmss);
        uint32_t elapsed = (now_sec >= on_sec) ? (now_sec - on_sec) : (86400 - on_sec + now_sec);

		
        if(elapsed < LCD_DISPLAY_TIMEOUT_SEC)
        {
			
            uint32_t remain = LCD_DISPLAY_TIMEOUT_SEC - elapsed;
            if(remain < 1) remain = 1;

            rtc_alarm_wakeup_init();
            rtc_set_next_alarm_sec((uint8_t)remain);
            g_timing_alarm_set = 0;   /* LCD timeout sleep: normal alarm */
            button_exti_init();
#if BLE_ENABLED
            if(g_bt_on) ble_exti_init();
#endif
            if(fourG_keep_on) { com_lpuart_init(); lpuart_wakeup_init(); ri_exti_init(); }
            lpuart_dma_rx_disable();

            printf_debug("[SM] LCD timeout sleep %ds\r\n", (int)remain);
            trea_delay_ms(20);
            {
                PmSleepCfg_t sc = { (uint8_t)fourG_keep_on, g_lcd_active, 0 };
                enter_deepsleep_mode(&sc);
            }

            // 唤醒: 按键/LPUART/RI/BLE事件 → 直接进入 STATE_WAKEUP
            if(button_wakeup_flag || counter0 || ri_wakeup_flag || ble_connect_wakeup_flag)
            {
                app_state = STATE_WAKEUP;
                return;
            }
        }
        // RTC 超时唤醒后继续: 关闭 LCD
        lcd_shutdown();
        printf_debug("[SM] LCD off after timeout\r\n");
    }
#endif /* LCD_LOCK_ENABLED */

    // 重设RTC闹钟: 计算好下次采集时刻, 防止超时唤醒错过窗口
    rtc_alarm_wakeup_init();

    // 定时阀门: 计算最近一个未执行的阀门事件距当前的时间
    // 定时阀门: 计算最近一个未执行的阀门事件距当前的时间
    {
        uint8_t use_valve_alarm = 0;
        uint32_t valve_wait_sec = 0xFFFFFFFF;

        if((g_valve_timing.on_switch || g_valve_timing.off_switch) && !real_mode_active())
        {
            RtcDateTime_t dt;
            rtc_get_datetime(&dt);

            if(!timing_open_done_today && g_valve_timing.on_switch)
            {
                uint32_t w = vtiming_next_wait(g_valve_timing.open_time, &dt);
                if(w < valve_wait_sec) valve_wait_sec = w;
            }
            if(!timing_close_done_today && g_valve_timing.off_switch)
            {
                uint32_t w = vtiming_next_wait(g_valve_timing.close_time, &dt);
                if(w < valve_wait_sec) valve_wait_sec = w;
            }

            // 阀门事件更早: 可等待到目标时间, 直接设定秒级闹钟
            uint32_t collect_sec = (uint32_t)sched_collect_min() * 60;
            /* 30分钟巡检优先: 若巡检比阀门事件更早, 放弃秒级阀门闹钟, 改走下面的分钟闹钟
             * (sched_set_next_collect_alarm 会把唤醒提前到巡检时刻; 阀门事件在后续唤醒补执行) */
            uint32_t sv_wait_min = supervise_wait_min();
            uint32_t sv_sec = (sv_wait_min == 0xFFFFFFFFu) ? 0xFFFFFFFFu : sv_wait_min * 60u;
            if(valve_wait_sec < collect_sec && valve_wait_sec < sv_sec && valve_wait_sec < 0xFFFFFFFF)
            {
                // 计算目标绝对时间(可能跨天), 换算为HHMMSS
                uint32_t t_abs = ((uint32_t)dt.hour * 60 + dt.minute) * 60 + dt.second + valve_wait_sec;
                uint32_t target_hhmmss;
                t_abs %= 86400;
                target_hhmmss = (t_abs / 3600) * 10000 + ((t_abs / 60) % 60) * 100 + (t_abs % 60);

                rtc_set_alarm_at_hhmmss(target_hhmmss);
                g_timing_alarm_set = 1;   /* timing valve alarm */
                use_valve_alarm = 1;
            }
        }

        if(!use_valve_alarm)
        {
            /* 注: 后延点唤醒由 sched_set_next_collect_alarm() 统一并入(见该函数内
             * s_pending_due_abs_min 提前量), 这里不再单独设秒级闹钟 */
            if(real_mode_active())
                rtc_set_next_alarm_sec(g_real_frequency);
            else
                sched_set_next_collect_alarm();   /* 绝对轴: 跨天周期锚定到期时刻(最多提前1天判定) */
            g_timing_alarm_set = 0;   /* normal collect alarm */
        }

#if (CALIB_MODE_ENABLED && LCD_ENABLED)
        /* 未安装期LCD截止事件: 若比阀门/后延闹钟更近, 用秒级闹钟覆盖 */
        if(calib_is_active() && s_cal_lcd_wait)
        {
            int32_t left = calib_lcd_left();
            if(left <= 0)
                calib_lcd_next_step();          /* 已过期: 立即切页/息屏 */
            if(s_cal_lcd_wait)
            {
                left = calib_lcd_left();
                if(!use_valve_alarm ||
                   (valve_wait_sec != 0xFFFFFFFFu && (uint32_t)left < valve_wait_sec))
                {
                    calib_lcd_alarm_set();
                    g_timing_alarm_set = 0;
                    use_valve_alarm = 1;        /* 防止被后续collect闹钟覆盖 */
                }
            }
        }
#endif

    }

    // LPUART唤醒 + RI中断: 4G在线时允许接收(可接收下行URC)
    if(fourG_keep_on)
    {
        com_lpuart_init();
        lpuart_wakeup_init();
        ri_exti_init();
    }

    // PB11(Btn1)按键唤醒: 始终使能(可手动唤醒4G)
    button_exti_init();

    // BLE连接事件未触发(与按键同时到达), 回到WAKEUP处理
    if(ble_connect_wakeup_flag)
    {
        app_state = STATE_WAKEUP;
        return;
    }

    // BLE超时: 超过60s未连接超时, 未超时则使用PD2 EXTI等待
#if BLE_ENABLED
    if(g_bt_on)
    {
        uint32_t now_sec = hhmmss_to_seconds(rtc_get_hhmmss());
        uint32_t on_sec  = hhmmss_to_seconds(g_ble_on_hhmmss);
        uint32_t elapsed = (now_sec >= on_sec) ? (now_sec - on_sec) : (86400 - on_sec + now_sec);
        if(elapsed >= 60)
        {
            printf_debug("[SM] BLE timeout (%ds), auto power off\r\n", (int)elapsed);
            g_bt_on = 0;
            power_ble_set(0);
            if(g_lcd_active) slcd_seg_icon_display(SLCD_ICON_LY, RESET);
        }
        else
        {
            ble_exti_init();
        }
    }
#endif /* BLE_ENABLED */

    // 关闭接收DMA(休眠期间DMA时钟被关闭, 唤醒后重新配置)
    lpuart_dma_rx_disable();

    if(real_mode_active())
        printf_debug("[SM] SLEEP %ds-RT (buf=%d 4G=%s)\r\n",
                     g_real_frequency, ee_hist_count(),
                     fourG_keep_on ? "ON" : "OFF");
    else
        printf_debug("[SM] SLEEP %dmin (buf=%d 4G=%s)\r\n",
                     sched_collect_min(), ee_hist_count(),
                     fourG_keep_on ? "ON" : "OFF");
    trea_delay_ms(20);

    {
        PmSleepCfg_t sc = { (uint8_t)fourG_keep_on, g_lcd_active, 0 };
        enter_deepsleep_mode(&sc);
    }

#if (CALIB_MODE_ENABLED && LCD_ENABLED)
    /* 未安装期LCD定时事件(非阻塞): 到期唤醒切页/息屏, 不采样 */
    while(calib_is_active() && s_cal_lcd_wait &&
          rtc_alarm_flag && !counter0 && !ri_wakeup_flag && !button_wakeup_flag && !ble_connect_wakeup_flag)
    {
        if(calib_lcd_left() > 0)
            break;                              /* 非LCD事件(阀门/后延等): 交回正常流程 */

        system_wakeup_reinit();
        trea_uart_init();
        calib_lcd_next_step();
        rtc_alarm_flag = 0;                     /* 消费LCD定时唤醒 */

        if(!calib_is_active() || !s_cal_lcd_wait)
            break;                              /* 息屏完成 */

        calib_lcd_alarm_set();
        {
            PmSleepCfg_t sc2 = { (uint8_t)fourG_keep_on, g_lcd_active, g_bt_on };
            enter_deepsleep_mode(&sc2);
        }
    }
    if(calib_is_active() && !s_cal_lcd_wait &&
       !rtc_alarm_flag && !counter0 && !ri_wakeup_flag && !button_wakeup_flag && !ble_connect_wakeup_flag)
    {
        app_state = STATE_SLEEP;                /* 息屏完成: 直接回睡, 避免误入采集 */
        return;
    }
#endif

    // 实时采集循环: RTC秒级唤醒 → 判断是否到采集分钟 → 否则最小实时采集→睡
    while(real_mode_active() && rtc_alarm_flag && !counter0 && !ri_wakeup_flag && !button_wakeup_flag && !ble_connect_wakeup_flag)
    {
        // 最小时钟恢复 → 查RTC中断是否到达网格采集时刻
        system_wakeup_reinit();
        rtc_register_sync_wait();

        {
            uint32_t now_hhmmss = rtc_get_hhmmss();
            uint8_t cur_sec = (uint8_t)(now_hhmmss % 100);
            uint32_t abs_min = sched_abs_min();

            // 网格采集时刻到 (绝对分钟对齐 + 5s 容差, 且当前分钟未执行过采集 → 转 STATE_WAKEUP)
            if(sched_collect_min() > 0 &&
               (abs_min % (uint32_t)sched_collect_min()) == 0 &&
               cur_sec < 6 &&
               abs_min != last_grid_collect_abs_min)
                break;

            // 待上报(进入新的上报周期且到期时刻已到) → 退出实时循环转上报(不采集)
            if(upload_due_now())
            {
                printf_debug("[SM] RT upload due, break to upload\r\n");
                ensure_full_init();          /* 最小唤醒时升级(上报需 EEPROM/4G) */
                app_state = STATE_UPLOAD;
                return;
            }

            // ---- 实时模式下的定时阀门检查 ----
            // ---- 实时模式下的定时阀门检查 ----
            if(g_valve_timing.on_switch || g_valve_timing.off_switch)
            {
                RtcDateTime_t dt;
                rtc_get_datetime(&dt);

                // 跨天重置当日执行标志
                if(dt.hour == 0 && timing_last_reset_hour != 0)
                {
                    timing_open_done_today  = 0;
                    timing_close_done_today = 0;
                    timing_last_reset_hour  = 0;
                }
                else if(dt.hour != 0)
                    timing_last_reset_hour = dt.hour;

                // 检查开阀 (容差5秒, 实时模式频率高于30s)
                if(!timing_open_done_today && g_valve_timing.on_switch &&
                   valve_timing_time_match(g_valve_timing.open_time, &dt, 5))
                {
                    printf_debug("[SM] VTIMING-RT: OPEN at %02u:%02u\r\n", dt.hour, dt.minute);
                    vtiming_execute_and_report("open");
                    timing_open_done_today = 1;
                }
                // 检查关阀 (容差5秒)
                if(!timing_close_done_today && g_valve_timing.off_switch &&
                   valve_timing_time_match(g_valve_timing.close_time, &dt, 5))
                {
                    printf_debug("[SM] VTIMING-RT: CLOSE at %02u:%02u\r\n", dt.hour, dt.minute);
                    vtiming_execute_and_report("close");
                    timing_close_done_today = 1;
                }
            }

#if LASER_CH4_ENABLED
            // ---- 实时模式下的激光甲烷定时采集检查 ----
            // 命中时间点 → 置 g_ch4_request 并退出实时循环;
            // 由主循环在网格采集/整点上传完成后执行 STATE_CH4 (不抢占采集)
            if(g_laser_switch &&
               ((uint8_t)(now_hhmmss / 10000)) != s_laser_done_hour &&
               window_dottime_hit(g_laser_time_mask, (uint8_t)(now_hhmmss / 10000)))
            {
                printf_debug("[SM] LASER schedule trigger at %02u:00\r\n", (uint8_t)(now_hhmmss / 10000));
                g_ch4_request = 1;
                break;
            }
#endif
        }

        // 非采集分钟 → 最小实时采集 (内部: 采集→判断→[异常上报]→上电→进入睡眠→唤醒后返回)
        do_realtime_check();
        // do_realtime_check 返回后, 新的唤醒标志已被复位, while再次判断
    }

    // 唤醒后统一转入 WAKEUP 状态
    app_state = STATE_WAKEUP;
}

#if BLE_ENABLED
/* ==================== 蓝牙电源开关 ====================
 * 切换 BLE 电源 (g_bt_on 由 power_ble_set 内部同步); 有 LCD 时同步蓝牙图标。 */
static void ble_power_toggle(void)
{
    power_ble_set(g_bt_on ? 0 : 1);
#if LCD_ENABLED
    if(g_lcd_active) slcd_seg_icon_display(SLCD_ICON_LY, g_bt_on ? SET : RESET);
#endif
}
#endif /* BLE_ENABLED */

#if 0   /* ===== 旧按键功能: 双击手动上报, 已停用 (按键现仅用于零点校准手势) ===== */
// ==================== 按键短按流程处理模块 ====================
// 按键短按 PA12小于1秒释放时触发：打印配置、采集实时数据并上报，同时等待 4G 平台下发返回状态
static void do_button_short_press(void)
{
    printf_debug("\r\n==================================================\r\n");
    printf_debug("[SM] BUTTON SHORT PRESS: Starting manual report & config dump\r\n");

    // 1. 打印当前系统配置
    config_print_current();
    
    // 2. 采集当前实时传感器数据并打印
    printf_debug("[SM] Sampling live sensor data...\r\n");
    PT304D_CollectAll((g_sensor_count >= 2) ? &g_sensor.raw2 : NULL, &g_sensor.raw);
    
    sensor_sample_voltage(1, g_sensor.last_normal_voltage);
    
    printf_debug("--- Live Data ---\r\n");
    printf_debug("  S2(inlet):  P=%.2f Pa  T=%.2f C  err=%d\r\n", g_sensor.raw.pressure, g_sensor.raw.temperature, g_sensor.raw.err);
    printf_debug("  S1(outlet): P=%.2f Pa  T=%.2f C  err=%d\r\n", g_sensor.raw2.pressure, g_sensor.raw2.temperature, g_sensor.raw2.err);
    printf_debug("  Voltage:    %.2f V\r\n", g_sensor.voltage);
    printf_debug("==================================================\r\n\r\n");

    // 3. 4G上报 (使用通用模块)
    int was_online;
    int ec_ok = fourG_ensure_ready(&was_online);

    if(ec_ok)
    {
        lcd_update_csq();

        // A. 上报传感器实时数据
        EC801E_PublishSensorData(&g_sensor.raw, g_sensor.voltage);
        trea_delay_ms(700);

        // B. 上报传感器在线状态
        report_publish_sensor_status();
        trea_delay_ms(700);

        // C. 上报压力+温度状态 (使用通用模块)
        publish_all_status(g_sensor.last_pressure_collect, g_sensor.last_pressure_collect2);
        trea_delay_ms(700);

        // D. 上报阀门状态指令
        {
            char v_order[4];
            snprintf(v_order, sizeof(v_order), "%d", g_valve_last_order);
            EC801E_PublishResponse("valve-last-order", v_order);
        }
        trea_delay_ms(700);

        // E. 用户端MQTT上报
        user_mqtt_try_publish();

        printf_debug("[SM] BUTTON SHORT PRESS: Manual status reporting success!\r\n");
    }
    else
    {
        printf_debug("[SM] BUTTON SHORT PRESS: manual report FAILED (MQTT connection failed)\r\n");
    }

    // 4. 等待按键释放, 防止释放抖动再次触发
    while(button_is_pressed())
        trea_delay_ms(100);
    trea_delay_ms(50);

    // 5. 结尾再等待5s 接收平台下发指令
    printf_debug("[SM] BUTTON: waiting 5s for downlink...\r\n");
    trea_delay_ms(5000);
    {
        uint8_t dl_count = drain_pending_downlink();
        if(dl_count > 0)
            printf_debug("[SM] BUTTON: processed %d downlink msg(s)\r\n", dl_count);
        else
            printf_debug("[SM] BUTTON: no downlink within 5s\r\n");
    }

    // 6. 恢复4G状态 (使用通用模块)
    fourG_restore(was_online, ec_ok);
}

#endif /* 旧按键功能停用 (do_button_short_press) */

/* ==================== 按键手势: 零点重校 ====================
 * 长按满 ZERO_CAL_HOLD_MS(默认8s)不松手 → 蜂鸣 1 声 进入待确认;
 * 从"满 8 秒"起算 ZERO_CAL_CONFIRM_MS(默认3s)窗口内需 ZERO_CAL_CONFIRM_PRESSES(默认2)次
 * 完整短按 (8 秒那次按住的松手不计次) → 执行零点重校。
 * 成功: 蜂鸣 2 声;  失败/超时: 蜂鸣 3 声 (本板无指示灯, 反馈全靠蜂鸣器)。
 * 说明: 交互全程阻塞(约 8~12s), 内部持续喂狗; 结束后由调用方回 STATE_SLEEP。
 * 返回: 1 = 已进入手势流程(按住满 8 秒); 0 = 未满 8 秒即松手(由调用方按"短按"处理) */
static uint8_t zero_cal_gesture(void)
{
    uint32_t t0;
    uint32_t window_start;
    uint8_t  released = 0;
    uint8_t  presses  = 0;
    uint8_t  confirmed = 0;

    /* ---- 阶段1: 等待按住满 ZERO_CAL_HOLD_MS (中途松手 = 无动作) ---- */
    t0 = trea_millis();
    while((trea_millis() - t0) < ZERO_CAL_HOLD_MS)
    {
        trea_delay_ms(20);
        swdt_feed();
        if(!button_is_pressed())
        {
            printf_debug("[ZERO] released before %ums -> treat as short press\r\n", ZERO_CAL_HOLD_MS);
            return 0;
        }
    }

    /* ---- 阶段2: 待确认 (蜂鸣 1 声提示进入确认窗口) ---- */
    printf_debug("[ZERO] hold %ums OK; need %u short press(es) within %ums\r\n",
                 ZERO_CAL_HOLD_MS, (unsigned)ZERO_CAL_CONFIRM_PRESSES, ZERO_CAL_CONFIRM_MS);
    buzzer_init();
    buzzer_beep(1, 200);

    window_start = trea_millis();

    while((trea_millis() - window_start) < ZERO_CAL_CONFIRM_MS)
    {
        trea_delay_ms(20);
        swdt_feed();

        /* 8 秒那次按住的松手: 不计入确认次数 */
        if(!released)
        {
            if(!button_is_pressed())
                released = 1;
            continue;
        }

        /* 统计短按: 按下 >50ms 去抖, 等释放后计数 */
        if(button_is_pressed())
        {
            trea_delay_ms(50);
            if(button_is_pressed())
            {
                presses++;
                printf_debug("[ZERO] confirm press %u/%u\r\n",
                             presses, (unsigned)ZERO_CAL_CONFIRM_PRESSES);
                while(button_is_pressed())
                {
                    trea_delay_ms(20);
                    swdt_feed();
                }
                if(presses >= ZERO_CAL_CONFIRM_PRESSES)
                {
                    confirmed = 1;
                    break;
                }
            }
        }
    }

    if(!confirmed)
    {
        printf_debug("[ZERO] confirm timeout, cancelled (baseline unchanged)\r\n");
        return 1;
    }

    /* ---- 阶段3: 执行校准 ---- */
    if(zero_cal_run())
    {
        buzzer_beep(2, 200);
        printf_debug("[ZERO] gesture calibration SUCCESS\r\n");
    }
    else
    {
        buzzer_beep(3, 200);
        printf_debug("[ZERO] gesture calibration FAILED (baseline unchanged)\r\n");
    }
    return 1;
}

// ==================== 唤醒恢复 ====================
static void do_wakeup(void)
{
    // 判断是否为纯RTC网格采集唤醒 (非按键且非LPUART且非RI且非BLE唤醒)
    if(button_wakeup_flag == 0 && counter0 == 0 && ri_wakeup_flag == 0 && ble_connect_wakeup_flag == 0)
    {
        g_is_minimal_wakeup = 1;
        g_need_adc_sampling = 0;
        
        system_wakeup_reinit();
        
        // 最小采集初始化: Systick和Debug 串口未启动, 仅初始化 I2C; 母线电压(PC2)采样由 adc_bat 内部保证
        systick_config();
//        my_systick_config();
        trea_uart_init();
        
        if(g_need_adc_sampling)
        {
            adc_bat_init();
        }
        
        button_exti_disable();
        
        rtc_show_time();
        printf_debug("[SM] PURE RTC WAKEUP: minimal init (ADC=%d)\r\n", g_need_adc_sampling);
    }
    else if(button_wakeup_flag && counter0 == 0 && ri_wakeup_flag == 0)
    {
        // === 按键唤醒 (快速检测路径: 最小初始化, 不执行 sys_init() 约1s 延时 ===
        // GPIO 状态在休眠期间保持不变, PB11 作为按键输入(外部上拉), button_is_pressed() 可直接使用
        // 需要完整功能时由 ensure_full_init() 升级处理
        g_is_minimal_wakeup = 1;
        g_need_adc_sampling = 1;
        
        system_wakeup_reinit();
        trea_uart_init();
		buzzer_init();
        button_exti_disable();
        
        rtc_show_time();
        printf_debug("[SM] WAKEUP: BUTTON (fast detect)\r\n");
    }
    else
    {
        // === LPUART/RI 唤醒或恢复会话: 完整初始化 ===
        g_is_minimal_wakeup = 0;
        g_need_adc_sampling = 1;
        
        system_wakeup_reinit();
        sys_init();
        
        // 禁用按键EXTI(唤醒后立即禁用防止抖动重复触发)
        button_exti_disable();
        
        /* 4G 常供电(新板): 模块开关机状态不随 MCU 复位/唤醒改变, 此处无需"恢复供电"。
         * 保持在线的情形(long+窗口内/er=1)由 do_sleep 布防唤醒通道;
         * 需要模块上线时由连接路径探测后软开机 (EC801E_InitAndConnect)。 */
        
        rtc_show_time();
        printf_debug("\r\n");
    }

    // === 按键唤醒: 检测按键 + 启动4G电源 ===
    if(button_wakeup_flag)
    {
        /* ==================== 按键 ====================
         * 短按(未满 ZERO_CAL_HOLD_MS 即松手): 仅打印日志 (本板无指示灯, 无额外反馈)。
         * 长按满 ZERO_CAL_HOLD_MS(8s): 蜂鸣 1 声, 从"满 8 秒"起算 3 秒窗口内
         *   连续 2 次短按 (8 秒那次的松手不计次) → 重校零点。
         * 旧按键功能(双击上报/三击蓝牙/四击开4G/长按开4G)整体停用, 见下方 #if 0。 */
        button_wakeup_flag = 0;
        printf_debug("[SM] WAKEUP: BUTTON\r\n");
        if(!zero_cal_enabled())
        {
            /* 零点手势仅适用于需要大气基准的协议(PT304D_DRV_SENSOR) —— 其它协议按普通短按处理 */
            printf_debug("[ZERO] gesture unavailable: current protocol needs no baseline\r\n");
        }
        else if(!zero_cal_gesture())
        {
            printf_debug("[BTN] short press\r\n");
        }

        /* 按键分支是提前 return 的(不走 do_wakeup 末尾的统一布防), 而按键交互期间
         * (8s 手势/零点重校)可能收到平台下行脉冲 → 必须在这里补一次 RI 布防。
         * 注: ri_exti_init() 会清 ri_wakeup_flag, 若本轮已有挂起的下行脉冲需保留标志,
         *     交给 do_sleep 的"大睡收口补读"消费。 */
        if(EC801E_IsAlive())
        {
            uint8_t ri_pending = ri_wakeup_flag;

            ri_exti_init();
            if(ri_pending)
                ri_wakeup_flag = 1;     /* 恢复挂起标志(布防时被清), 由 do_sleep 补读 */
        }

        app_state = STATE_SLEEP;
        return;

#if 0   /* ===== 旧按键功能整体停用 ===== */
        printf_debug("[SM] WAKEUP: BUTTON\r\n");

        // 按键唤醒恢复LCD显示 (唤醒后关闭需重新初始化)
        uint8_t lcd_was_off = !g_lcd_active;
        lcd_activate();
        if(g_lcd_active)
            lcd_ui_refresh(&g_sensor.raw, &g_sensor.raw2, g_sensor.voltage);
#if (CALIB_MODE_ENABLED && LCD_ENABLED)
        if(calib_is_active())
            calib_lcd_activity();       /* 未安装期: 按键点亮并重置5s计时 */
#endif

        /* 三路状态灯代码已随 LED 硬件移除 (原按键唤醒短亮逻辑)
         * ADC 在按键快速唤醒路径未初始化, 这里补一次, 供"换电池"判电压。 */
        adc_bat_init();

        button_wakeup_flag = 0;

        // LCD从关闭恢复: 首次按键唤醒点亮屏幕, 完成UI初始化(翻页)
        if(lcd_was_off && g_lcd_active)
        {
            buzzer_beep(1, 200);
            printf_debug("[SM] BUTTON: LCD activated (consume press)\r\n");
            app_state = STATE_SLEEP;
            return;
        }

        // 按键抖动: 20ms等待消除前抖动
        trea_delay_ms(20);

        // 确认当前按键状态
        uint8_t is_short_press = 0;

        if(!button_is_pressed())
        {
            // 20ms内已松开 → 短按
            is_short_press = 1;
        }
        else
        {
            // 按键仍按住, 检查是否长按4s)
            uint8_t i;
            for(i = 0; i < 40; i++)
            {
                trea_delay_ms(100);
                if(!button_is_pressed())
                {
                    // 4s内松开 → 短按
                    is_short_press = 1;
                    break;
                }
            }
        }

        if(is_short_press)
        {
            // === 短按: 统计连续按键次数 (500ms窗口内) ===
            uint8_t press_count = 1;
            uint16_t wait_ms;

            // 等待按键释放 (消除抖动)
            while(button_is_pressed())
                trea_delay_ms(20);
            trea_delay_ms(30);  // 按键稳定

            // 500ms窗口内继续检测下一次按键
            while(press_count < 4)
            {
                uint8_t got_press = 0;
                for(wait_ms = 0; wait_ms < 500; wait_ms += 20)
                {
                    trea_delay_ms(20);
                    if(button_is_pressed())
                    {
                        got_press = 1;
                        break;
                    }
                }

                if(!got_press)
                    break;  // 500ms内无新按键, 结束统计

                press_count++;
                // 等待本次按键释放
                while(button_is_pressed())
                    trea_delay_ms(20);
                trea_delay_ms(30);  // 按键稳定
            }

            printf_debug("[SM] BUTTON: %d press(es) detected\r\n", press_count);

            switch(press_count)
            {
                
                case 1:
                    // 1次短按: LCD页切换 + 按键确认
                    buzzer_beep(1, 200);
#if (CALIB_MODE_ENABLED && LCD_ENABLED)
                    calib_lcd_activity();   /* 未安装期: 重置5s无操作计时 */
#endif
#if LCD_ENABLED
                    if(g_lcd_active) lcd_ui_next_page();
                    printf_debug("[SM] BUTTON: LCD page -> %d\r\n", g_lcd_page);
#else
                    printf_debug("[SM] BUTTON: single press (LED flash)\r\n");
#endif
                    break;

                case 2:
                    // 2次短按: 手动上报 (完整初始化)
                    ensure_full_init();
                    do_button_short_press();
                    break;

                case 3:
                    // 3次短按: 蓝牙开关切换 (控制: 开/关, 不进入BLE_OTA)
                    ble_power_toggle();
                    buzzer_beep(1, 200);
                    printf_debug("[SM] BUTTON: Bluetooth %s\r\n", g_bt_on ? "ON" : "OFF");
                    if(g_bt_on)
                    {
                        ble_link_gpio_init();           /* PD2输入+上拉 */
                        ble_set_name_from_device_id();  /* AT指令设置BLE名称 */
                        g_ble_on_hhmmss = rtc_get_hhmmss(); /* 记录开启时间, 用于60s超时 */
                        printf_debug("[SM] BLE powered on, waiting connect via EXTI\r\n");
                    }
                    else
                    {
                        ble_exti_disable();
                        ble_uart_deinit();
                        printf_debug("[SM] BLE powered off\r\n");
                    }
                    break;
				case 4:
                    // 4次短按: 打开4G
                    fourG_user_off = 0;
                    fourG_weak_signal = 0;  // 清除弱信号标志
                    /* 4x short press: really power on 4G and init the module.
                     * Old code only cleared flags; V4G_EN stayed LOW so
                     * do_sleep treated 4G as online while it was powered off.
                     * InitAndConnect 内含 V4G_EN+PWRKEY 完整开机时序. */
                    ensure_full_init();
                    com_lpuart_init();
                    trea_delay_ms(100);
                    if(EC801E_InitAndConnect() == EC_OK)
                    {
                        fourG_init_failed = 0;
//                        report_4g_power_state(1);
                        lcd_update_csq();
                        buzzer_beep(2, 200);
                        printf_debug("[SM] BUTTON: 4G powered on OK\r\n");
                    }
                    else
                    {
                        printf_debug("[SM] BUTTON: 4G power on FAILED (no AT response)\r\n");
                    }
                    break;

                default:
                    break;
            }

            app_state = STATE_SLEEP;
            return;
        }

        // === 长按4s确认 → 4G电源开启(强制打开) ===
        ensure_full_init();
        printf_debug("[SM] BUTTON: 4s confirmed, powering on 4G\r\n");
        fourG_user_off = 0;  // 清除用户关闭标志
        fourG_weak_signal = 0;  // 手动打开同时清除弱信号标志
        com_lpuart_init();
        trea_delay_ms(100);
        EC801E_InitAndConnect();

        // 验证4G模块AT响应 + 上报电源状态
        if(EC801E_EnsureConnected() == EC_OK)
        {
            fourG_init_failed = 0;  // 手动连接成功, 清除失败标志
//            report_4g_power_state(1);
            lcd_update_csq();
            buzzer_beep(2, 200);
            printf_debug("[SM] BUTTON: 4G power on OK, reported\r\n");
        }
        else
        {
            printf_debug("[SM] BUTTON: 4G power on FAILED (no AT response)\r\n");
        }

        // 等待按键释放, 防止释放抖动再次触发下次唤醒
        while(button_is_pressed())
            trea_delay_ms(100);
        trea_delay_ms(50);

        // === 统一等待 20s 接收平台下发指令 (强制模式) ===
        printf_debug("[SM] BUTTON: %s mode, waiting 20s for downlink...\r\n",
                     g_window.pattern);
        trea_delay_ms(20000);
        {
            uint8_t dl_count = drain_pending_downlink();
            if(dl_count > 0)
                printf_debug("[SM] BUTTON: processed %d downlink msg(s)\r\n", dl_count);
            else
                printf_debug("[SM] BUTTON: no downlink within 20s\r\n");
        }

        // === 模式化收尾 ===
        if(strcmp(g_window.pattern, "long") == 0)
        {
            // long模式: 保持4G在线 (do_sleep 中 fourG_keep_on 路径已接管)
            EC801E_SetSleepMode(1);
            printf_debug("[SM] BUTTON: long mode, keep 4G online (PSM)\r\n");
        }
        else
        {
            // short/dot模式: 断电后休眠
//            report_4g_power_state(0);
            EC801E_PowerOff();
            printf_debug("[SM] BUTTON: %s mode, 4G powered off\r\n", g_window.pattern);
        }

       app_state = STATE_SLEEP;
        return;
#endif /* 旧按键功能停用 */
    }

    // debug串口命令由主循环统一处理

#if BLE_OTA_ENABLED
    // === BLE连接唤醒: PD2 EXTI下降沿 (手机连接BLE模块) ===
    if(ble_connect_wakeup_flag)
    {
        ble_connect_wakeup_flag = 0;
        ble_exti_disable();

        if(g_bt_on && ble_link_is_connected())
        {
            printf_debug("[SM] WAKEUP: BLE connected (PD2=LOW), entering OTA mode\r\n");
            ensure_full_init();
            ble_uart_init();
            ble_uart_rx_flush();
            ble_ota_init();
            g_ble_ota.state = BLE_OTA_IDLE;
            g_ble_ota.last_rx_ms = trea_millis();
            app_state = STATE_BLE_OTA;
            return;
        }
        else
        {
            printf_debug("[SM] WAKEUP: BLE EXTI but not connected (glitch?)\r\n");
        }
    }
#endif /* BLE_OTA_ENABLED (蓝牙OTA关闭时: 连接唤醒不进入OTA流程) */

    if(counter0 || ri_wakeup_flag)
    {
        printf_debug("[SM] WAKEUP: %s (downlink)\r\n", counter0 ? "LPUART" : "RI");
        app_state = STATE_DOWNLINK;
    }
    else if(rtc_alarm_flag)
    {
        printf_debug("[SM] WAKEUP: RTC\r\n");
        /* 阀定时闹钟 / 校零 LCD 等待 / 实时模式: 保持原行为(交由 do_collect 处理) */
        if(g_timing_alarm_set == 0
#if (CALIB_MODE_ENABLED && LCD_ENABLED)
                && !s_cal_lcd_wait
#endif
                && !real_mode_active())
        {
            /* 采集到期点优先: 后延到期点与采集点重合时先采集(否则该采集点会被整拍跳过, 历史缺一格);
             * 未到采集点但"待上报+后延已到"(后延点唤醒) → 直接上报, 不采集
             * (否则会多出一条网格外历史记录); 两者都不是 → 回睡 */
            if(sched_collect_due_now())
                app_state = STATE_COLLECT;
            else if(upload_due_now())
            {
                printf_debug("[SM] WAKEUP: upload pending due, direct upload\r\n");
                ensure_full_init();      /* 最小唤醒时升级(上报需 EEPROM/4G) */
                app_state = STATE_UPLOAD;
            }
            else
            {
                /* 跨天周期(>1天): 到期日之前每天只醒一次做判定, 非到期点直接回睡 */
                printf_debug("[SM] WAKEUP: not collect due, back to sleep\r\n");
                app_state = STATE_SLEEP;
            }
        }
        else
            app_state = STATE_COLLECT;
    }
    else
    {
        printf_debug("[SM] WAKEUP: unknown\r\n");
        app_state = STATE_COLLECT;
    }

    /* RI EXTI 是一次性闭锁: 唤醒后必须重新布防, 否则本周期长流程(上报/阀动作/OTA/按键等待)
     * 期间到达的下行脉冲没人接收。布防后脉冲锁存到 ri_wakeup_flag, 由 do_sleep 大睡收口补读。
     * 注: ri_exti_init() 会清 ri_wakeup_flag, 故必须放在上面唤醒源判断之后。 */
    if(EC801E_IsAlive())
        ri_exti_init();
}

// ==================== 确认完整初始化 ====================
static void ensure_full_init(void)
{
    if(g_is_minimal_wakeup)
    {
        printf_debug("[SM] Escalating to FULL INIT (need 4G/Motor/EEPROM)\r\n");
        sys_init();
        g_is_minimal_wakeup = 0;
        g_need_adc_sampling = 1;
    }
}

// ==================== 上报调度判断 (do_collect / do_alarm 共用) ====================
// 上报周期/后延配置变更后调用: 重置延迟上报锁存, 避免换周期后漏一次或重一次
void upload_schedule_reset(void)
{
    s_upload_pending      = 0;
    s_pending_due_abs_min = 0;
    s_last_upload_idx     = 0xFFFFFFFFu;    /* 换周期后重新起算: 严格等一个完整周期 */
    config_save_upload_idx(0xFFFFFFFFu);
}

// 根据当前模式和时间判断是否需要批量上报历史数据, 设置 app_state
static void check_upload_schedule(void)
{
    // === 低电压省电模式: 不执行常规上报, 8:00/18:00上报 ===
    if(voltage_low_power)
    {
        uint32_t now_hhmmss = rtc_get_hhmmss();
        uint8_t current_hour = (uint8_t)(now_hhmmss / 10000);
        if((current_hour == 8 || current_hour == 18) && !vlp_uploaded_this_hour)
        {
            vlp_uploaded_this_hour = 1;
            if(ee_hist_count() > 0)
            {
                printf_debug("[SM] VLP trigger: hour=%d, uploading %d records\r\n", current_hour, ee_hist_count());
                ensure_full_init();
                app_state = STATE_UPLOAD;
            }
            else
            {
                printf_debug("[SM] VLP trigger: hour=%d, buf empty, skip 4G\r\n", current_hour);
                app_state = STATE_SLEEP;
            }
        }
        else
        {
            if(current_hour != 8 && current_hour != 18)
                vlp_uploaded_this_hour = 0;
            app_state = STATE_SLEEP;
        }
        return;
    }

    // 判断是否需要上报(网格模式, 对齐时间网格)
    if(strcmp(g_window.pattern, "dot") == 0)
    {
        // dot pattern: any configured hour in 24h bitmap triggers upload once per day
        uint32_t now_hhmmss = rtc_get_hhmmss();
        uint8_t current_hour = (uint8_t)(now_hhmmss / 10000);
        rtc_parameter_struct tp;
        rtc_current_time_get(&tp);
        uint16_t day_key = (uint16_t)(((tp.year & 0xFF) << 8) | ((tp.month & 0xFF) << 4) | (tp.date & 0xFF));
        if(day_key != dot_uploaded_day)
        {
            memset(dot_uploaded_mask, 0, sizeof(dot_uploaded_mask));
            dot_uploaded_day = day_key;
        }
        if(window_dottime_hit(g_window.dottime_mask, current_hour) &&
           !window_dottime_hit(dot_uploaded_mask, current_hour))
        {
            printf_debug("[SM] DOT trigger: hour=%d (mask hit)\r\n", current_hour);
            window_dottime_set(dot_uploaded_mask, current_hour);
            ensure_full_init();
            app_state = STATE_UPLOAD;
        }
        else
        {
            app_state = STATE_SLEEP;
        }
    }
    else
    {
        // long/short: 整点网格 + 标志位式调度
        //   进入新的上报周期 → 置"待上报"标志; 置位后一路上报直到成功(缓冲清空)
        //   不依赖时间窗口/目标点 → 长流程推迟、被抢占、RTC 校时跳变都不会永久漏报
        uint32_t now_hhmmss = rtc_get_hhmmss();

        upload_pending_update();            /* 本次是否该置"待上报" */

        if(upload_due_now())
        {
            printf_debug("[SM] UPLOAD trigger: %02u:%02u:%02u (um=%umin every_n=%u)\r\n",
                         (unsigned)(now_hhmmss / 10000),
                         (unsigned)((now_hhmmss / 100) % 100),
                         (unsigned)(now_hhmmss % 100),
                         (unsigned)g_interval.upload_interval_min,
                         (unsigned)g_interval.upload_every_n);
            ensure_full_init();
            app_state = STATE_UPLOAD;
        }
        else
            app_state = STATE_SLEEP;
    }
}

// ==================== 采集传感器 + 阈值检查 ====================
static void do_collect(void)
{
    SensorRecord_t record;
    ThresholdResult_t result;
    ThresholdResult_t r1, r2;
    ThresholdResult_t rv;
    uint8_t vlp_just_exited = 0;
    uint8_t online0, online1;
    uint8_t mask;
    uint8_t unlocked = 0;
    uint8_t volt_unlocked = 0;
    uint8_t volt_checked = 0;
    TempStatus_t t1, t2;

    // ========== 定时开关阀检查 ==========
    // ========== 定时开关阀检查 ==========
    if(g_valve_timing.on_switch || g_valve_timing.off_switch)
    {
        RtcDateTime_t dt;
        rtc_get_datetime(&dt);
        uint8_t cur_hour = dt.hour;

        // 跨天重置当日执行标志 (00:00~00:59, 若未重置过)
        if(cur_hour == 0 && timing_last_reset_hour != 0)
        {
            timing_open_done_today  = 0;
            timing_close_done_today = 0;
            timing_last_reset_hour  = 0;
            printf_debug("[SM] VTIMING: daily flags reset\r\n");
        }
        else if(cur_hour != 0)
            timing_last_reset_hour = cur_hour;

        // 检查开阀时间 (容差30秒)
        if(!timing_open_done_today && g_valve_timing.on_switch &&
           valve_timing_time_match(g_valve_timing.open_time, &dt, 30))
        {
            printf_debug("[SM] VTIMING: OPEN triggered at %02u:%02u\r\n", dt.hour, dt.minute);
            vtiming_execute_and_report("open");
            timing_open_done_today = 1;
        }

        // 检查关阀时间 (容差30秒)
        if(!timing_close_done_today && g_valve_timing.off_switch &&
           valve_timing_time_match(g_valve_timing.close_time, &dt, 30))
        {
            printf_debug("[SM] VTIMING: CLOSE triggered at %02u:%02u\r\n", dt.hour, dt.minute);
            vtiming_execute_and_report("close");
            timing_close_done_today = 1;
        }
    }

    /* 记录本次网格采集的绝对分钟: 防止与实时唤醒循环在同一分钟重复巡检, 跨天也不会误判 */
    last_grid_collect_abs_min = sched_abs_min();

    PT304D_CollectAll((g_sensor_count >= 2) ? &g_sensor.raw2 : NULL, &g_sensor.raw);
#if CALIB_MODE_ENABLED
    {
        /* 未安装自动校零: 喂样本; 零点成熟时同拍修正当前读数 */
        uint8_t was_calib = calib_is_active();
        float p_raw = g_sensor.raw.pressure;
        float corr = calib_feed_sample(p_raw);
        if(corr != 0.0f)
            g_sensor.raw.pressure -= corr;
        if(was_calib)
        {
            calib_log_sample(p_raw, g_sensor.raw.pressure);
            if(!calib_is_active())
                install_event_report();         /* 自动锁定: 一次性安装事件上报 */
        }
    }
#endif
    /* 本次唤醒初始化过 ADC (g_need_adc_sampling=1) → 取新鲜电压并允许电压判定;
     * 纯 RTC 最小唤醒 → 沿用上次正常值 (不采 ADC, 不触碰电压锁) */
    if(g_need_adc_sampling)
    {
        sensor_sample_voltage(1, g_sensor.last_normal_voltage);
        volt_checked = 1;
    }
    else
    {
        g_sensor.voltage = g_sensor.last_normal_voltage;
    }

    printf_debug("[SM] COLLECT (buf=%d) V=%.2f S2:P=%.2f T=%.2f err=%d S1:P=%.2f T=%.2f err=%d (ADC=%d)\r\n",
                 ee_hist_count() + 1, g_sensor.voltage,
                 g_sensor.raw.pressure, g_sensor.raw.temperature, g_sensor.raw.err,
                 g_sensor.raw2.pressure, g_sensor.raw2.temperature, g_sensor.raw2.err,
                 g_need_adc_sampling);

    // 实时模式关闭时, 采集周期结束后 LCD 刷新 (实时模式常亮时由 do_realtime_check 刷新)
#if (CALIB_MODE_ENABLED && LCD_ENABLED)
    if(calib_is_active())
    {
        calib_lcd_auto_begin();         /* 未安装期: 压力页短亮 + 定时息屏 */
    }
    else
    {
        calib_lcd_exit_to_normal();     /* 锁定后: 取消短亮, 恢复正常LCD策略 */
    }
#endif
#if LCD_LOCK_ENABLED
    if(g_lcd_active && !real_mode_active() && !CALIB_LCD_BLOCKED())
        lcd_ui_refresh(&g_sensor.raw, &g_sensor.raw2, g_sensor.voltage);
#else
    /* LCD常亮模式: 每个采集周期自动翻一页 */
    if(g_lcd_active && !real_mode_active() && !CALIB_LCD_BLOCKED())
    { lcd_ui_refresh(&g_sensor.raw, &g_sensor.raw2, g_sensor.voltage); lcd_ui_next_page(); }
#endif

    // ========== 传感器在线/离线状态变化检测(带消抖, 双路在线/离线) ==========
    {
        uint8_t cur_online  = (g_sensor.raw.err  == PT304D_OK) ? 1 : 0;
        uint8_t cur_online2 = (g_sensor_count >= 2 && g_sensor.raw2.err == PT304D_OK) ? 1 : 0;
        uint8_t state_changed;

        online0 = (uint8_t)cur_online;
        online1 = (uint8_t)cur_online2;
        state_changed = sensor_debounce_update(cur_online, cur_online2);

        /* 离线通道: 恢复计数归零, 保留最后等级 (不参与阈值检查, 不计正常) */
        if(!cur_online)  (void)alarm_lock_feed_normal(0, 0, THRESHOLD_OK, TEMP_NORMAL);
        if(!cur_online2) (void)alarm_lock_feed_normal(1, 0, THRESHOLD_OK, TEMP_NORMAL);

        if(state_changed)
        {
            ensure_full_init();

            printf_debug("[SM] SENSOR STATE CHANGED: S2=%s(err=%d) S1=%s(err=%d) debounce=%d\r\n",
                         cur_online  ? "ON" : "OFF", g_sensor.raw.err,
                         cur_online2 ? "ON" : "OFF", g_sensor.raw2.err,
                         SENSOR_OFFLINE_DEBOUNCE);

            // 启动4G上报
            {
                int was_online;
                int ec_ok = fourG_ensure_ready(&was_online);
                if(ec_ok)
                {
                    report_publish_sensor_status();
                    printf_debug("[SM] Sensor state reported\r\n");
                }
                fourG_restore(was_online, ec_ok);
            }

            // 两路都离线才停止采集/上报; 任一路在线都继续 (离线通道按哨兵值存/报, 不判阈值)
            if(!cur_online && !cur_online2)
            {
                app_state = STATE_SLEEP;
                return;
            }
        }
        else if(!cur_online && !cur_online2)
        {
            // 两路仍离线: 不重复上报, 直接回睡
            printf_debug("[SM] SENSOR still OFFLINE (cnt=%d/%d cnt2=%d/%d), skip\r\n",
                         g_sensor.offline_cnt, SENSOR_OFFLINE_DEBOUNCE,
                         g_sensor.offline_cnt2, SENSOR_OFFLINE_DEBOUNCE);
            app_state = STATE_SLEEP;
            return;
        }
    }

    // 阈值检查 (双通道全项检查: 压力/温度/突变; 电压不参与 threshold_check)
    // 离线通道: r 直接置 OK, 不调用判定函数 (驱动失败时是哨兵 -1000/-50, 绝不能进阈值)
    r1 = online0 ? threshold_check(g_sensor.raw.pressure, g_sensor.raw.temperature, g_sensor.voltage,
                                  g_sensor.last_pressure_collect, 0, 0) : THRESHOLD_OK;
    r2 = online1 ? threshold_check2(g_sensor.raw2.pressure, g_sensor.raw2.temperature,
                                   g_sensor.last_pressure_collect2, 0) : THRESHOLD_OK;
    result = (r1 != THRESHOLD_OK) ? r1 : r2;

    /* 每拍推进通道恢复计数 (离线通道已在状态检测段归零) */
    t1 = online0 ? threshold_get_temp_status(g_sensor.raw.temperature) : TEMP_NORMAL;
    t2 = online1 ? threshold_get_temp_status2(g_sensor.raw2.temperature) : TEMP_NORMAL;
    if(online0) unlocked |= alarm_lock_feed_normal(0, 1, r1, t1);
    if(online1) unlocked |= alarm_lock_feed_normal(1, 1, r2, t2);

    /* 电压独立恢复计数 (仅本次唤醒确实采了 ADC 时; 电压码不进通道锁) */
    if(volt_checked)
    {
        rv = (threshold_voltage_alarm(g_sensor.voltage) == 1) ? THRESHOLD_VPROTECT : THRESHOLD_OK;
        volt_unlocked = alarm_lock_volt_feed_normal(rv, 1);
        if(volt_unlocked)
            printf_debug("[SM] VOLT lock released\r\n");
    }

    if(result != THRESHOLD_OK)
    {
        /* 新等级判定 (去重): 与最后已上报等级相同 → 只记录入库/走上报调度, 不重复报警 */
        mask = alarm_new_mask(r1, r2, 0);
        if(mask != 0)
        {
            // 低电压省电模式: 已进入VPROTECT保护, 不重复VPROTECT报警上报
            if(voltage_low_power && result == THRESHOLD_VPROTECT)
            {
                printf_debug("[SM] VLP: still low voltage, skip alarm\r\n");
                // 不进入ALARM, 保持低电压省电状态
            }
            else
            {
                // 首次VPROTECT报警进ALARM(关阀+上报), 同时标记低电压模式
                if(result == THRESHOLD_VPROTECT && !voltage_low_power)
                {
                    voltage_low_power = 1;
                    config_save_ext();
                    printf_debug("[SM] VLP: entering low voltage power-save mode\r\n");
                }
                printf_debug("[SM] THRESHOLD ABNORMAL (%d, mask=0x%02X), entering ALARM\r\n", result, mask);
                ensure_full_init();
                app_state = STATE_ALARM;
                return;
            }
        }
        else
        {
            printf_debug("[SM] THRESHOLD SAME AS LAST, skip alarm repeat\r\n");
            /* 上报去重 ≠ 不动作: 等级已报过也按当前策略补一次关阀 (幂等, 策略变更后下一拍生效) */
            (void)alarm_safety_close_now(r1, r2, online0, online1);
        }
    }

    // 低电压恢复: 电压恢复到正常时退出VLP
    //   (a) 电压回到 vprotect 以上 (正常恢复)
    //   (b) spupower.switch 被用户关闭(不再执行电压检查, 不能残留 VLP 状态锁定)
    if(voltage_low_power && (!g_spupower.enabled || g_sensor.voltage >= g_spupower.protect + 0.15f))
    {
        voltage_low_power = 0;
        config_save_ext();
        vlp_uploaded_this_hour = 0;
        vlp_just_exited = 1;     // 标记: 本次 collect 时 VLP 刚退出, 走 normal 上报
        if(!g_spupower.enabled)
            printf_debug("[SM] VLP: spupower disabled by user, exiting low power mode\r\n");
        else
            printf_debug("[SM] VLP: voltage recovered (%.2fV >= %.2fV), exiting low power mode\r\n",
                         g_sensor.voltage, g_spupower.protect);
    }

    // 恢复状态上报: (a) 连续 3 次全正常解锁 (b) 报警自动关阀后恢复 (c) VLP 刚退出
    // 放在进入 STATE_ALARM 的分支之后, 避免被提前 return 吞掉; 不依赖 4G 是否在线。
    // 仅在"全正常"拍上报: 去重命中(同等级异常)的拍不报恢复, 避免告警持续时误发 normal。
    if(result == THRESHOLD_OK && !voltage_low_power &&
       (unlocked || volt_unlocked ||
        (g_valve_alarm_closed && !g_ch4_alarm_closed && !g_alarm_recover_reported) ||
        vlp_just_exited))
    {
        ensure_full_init();
        const char *vr = NULL;

        // (a) 报警关阀后恢复正常: 只上报一次, 不自动操作阀门 (工业安全)
        if(g_valve_alarm_closed && !g_ch4_alarm_closed)
        {
            g_alarm_recover_reported = 1;
            motor_pos_init();     /* 深休眠后到位检测引脚为 Analog, 读取/驱动前恢复 */
            vr = valve_get_status();   /* 上报真实阀门状态(保持关闭) */
            printf_debug("[SM] ALARM recovered, valve stays closed (report only)\r\n");
        }
        else if(unlocked || volt_unlocked)
        {
            printf_debug("[SM] ALARM lock released (%u normal samples)\r\n",
                         ALARM_LOCK_CLEAR_COUNT);
        }
        else if(vlp_just_exited)
        {
            printf_debug("[SM] VLP recovered, publishing normal status\r\n");
        }

        // 4G 临时连接 + 对称恢复上报
        {
            int was_online;
            int ec_ok = fourG_ensure_ready(&was_online);
            if(ec_ok)
            {
                if(vr != NULL)
                {
                    EC801E_PublishValveStatus(vr, g_valve_last_order);
                    trea_delay_ms(300);
                }
                report_publish_ly06(0, g_sensor.voltage);
                publish_all_status(g_sensor.last_pressure_collect, g_sensor.last_pressure_collect2);
                alarm_lock_save(1);   /* 解锁状态立即落盘 */
            }
            fourG_restore(was_online, ec_ok);
        }
    }
    else
    {
        alarm_lock_save(0);   /* 正常采样: dirty + 5min 节流 flush */
    }

    // 记录: 存入缓冲区
    record.pressure = g_sensor.raw.pressure;
    record.temperature = g_sensor.raw.temperature;
    record.pressure2 = g_sensor.raw2.pressure;
    record.temperature2 = g_sensor.raw2.temperature;
    record.voltage = g_sensor.voltage;
    rtc_get_time_str(record.timestamp, sizeof(record.timestamp));
    record.flags = 0;
    memset(record.reserved, 0, sizeof(record.reserved));

#if CALIB_MODE_ENABLED
    if(calib_is_active())
    {
        /* 未安装校零期: 不写历史, 只保留最新一条供周期上报 */
        s_calib_latest = record;
        s_calib_latest_valid = 1;
    }
    else
#endif
    {
        ee_hist_push(record.pressure, record.temperature,
                     record.pressure2, record.temperature2,
                     record.voltage, record.flags);
    }
    sensor_baseline_update_collect();
    wakeup_count++;

    // 报警确认
    check_upload_schedule();
}

// ==================== 报警确认 ====================
static void do_alarm(void)
{
    uint8_t i;
    uint8_t still_abnormal = 1;
    SensorRecord_t record;
    ThresholdResult_t result;
    ThresholdResult_t r1, r2;
    const char *alarm_type = "unknown";
    uint8_t mask;
    uint8_t online0, online1;
    AlarmConfirmCtx_t ctx;

    ensure_full_init();

    printf_debug("[SM] ALARM: rechecking %d times...\r\n", APP_ALARM_RECHECK_COUNT);

    for(i = 0; i < APP_ALARM_RECHECK_COUNT; i++)
    {
        trea_delay_ms(APP_ALARM_RECHECK_DELAY_MS);

        PT304D_CollectAll((g_sensor_count >= 2) ? &g_sensor.raw2 : NULL, &g_sensor.raw);
        sensor_sample_voltage(0, g_sensor.last_normal_voltage);

        /* 离线通道不参与判定 (驱动失败写哨兵 -1000/-50, 不能进 threshold_check) */
        online0 = (g_sensor.raw.err == PT304D_OK) ? 1u : 0u;
        online1 = (g_sensor_count >= 2 && g_sensor.raw2.err == PT304D_OK) ? 1u : 0u;
        r1 = online0 ? threshold_check(g_sensor.raw.pressure, g_sensor.raw.temperature, g_sensor.voltage,
                                      g_sensor.last_pressure_collect, 1, 0) : THRESHOLD_OK;
        r2 = online1 ? threshold_check2(g_sensor.raw2.pressure, g_sensor.raw2.temperature,
                                       g_sensor.last_pressure_collect2, 0) : THRESHOLD_OK;
        result = (r1 != THRESHOLD_OK) ? r1 : r2;
        printf_debug("[SM] ALARM recheck %d/%d: P=%.2f T=%.2f V=%.2f P2=%.2f T2=%.2f result=%d\r\n",
                     i + 1, APP_ALARM_RECHECK_COUNT, g_sensor.raw.pressure, g_sensor.raw.temperature, g_sensor.voltage,
                     g_sensor.raw2.pressure, g_sensor.raw2.temperature, result);

        if(result == THRESHOLD_OK)
        {
            // 恢复判断: 正常状态
            printf_debug("[SM] ALARM: recovered at recheck %d, false alarm\r\n", i + 1);
            still_abnormal = 0;
            break;
        }
    }

    // 报警记录
    record.pressure = g_sensor.raw.pressure;
    record.temperature = g_sensor.raw.temperature;
    record.pressure2 = g_sensor.raw2.pressure;
    record.temperature2 = g_sensor.raw2.temperature;
    record.voltage = g_sensor.voltage;
    rtc_get_time_str(record.timestamp, sizeof(record.timestamp));
    memset(record.reserved, 0, sizeof(record.reserved));

    if(still_abnormal)
    {
        // 判断报警类型 (与 do_realtime_check/downlink 共用 threshold_alarm_type_str)
        alarm_type = threshold_alarm_type_str(result);

        /* 新等级判定 (与采集/实时/查询共用同一把锁): 相同等级已在别处上报 → 不重复 */
        mask = alarm_new_mask(r1, r2, 1);
        if(mask == 0)
        {
            printf_debug("[SM] *** ALARM confirmed (%s) but already latched, skip ***\r\n", alarm_type);
            record.flags = 0;
            /* 等级已锁: 仍按当前策略补一次关阀 (幂等, 策略变更后下一拍生效) */
            (void)alarm_safety_close_now(r1, r2, online0, online1);
        }
        else
        {
            // 确认报警
            record.flags = SENSOR_FLAG_ALARM;

            printf_debug("[SM] *** ALARM CONFIRMED: %s (mask=0x%02X) ***\r\n", alarm_type, mask);
            printf_debug("[SM] ALARM: P=%.2f T=%.2f V=%.2f @%s\r\n",
                         g_sensor.raw.pressure, g_sensor.raw.temperature, g_sensor.voltage, record.timestamp);

            ctx.check_voltage = 1;   /* 本路径做了电压判定: 可置电压锁 */
            ctx.sensor_err    = (!online0 || !online1) ? 1u : 0u;   /* 任一路离线: 附带 rtu 状态 */
            ctx.volt_new      = 0;
            ctx.tag           = "SM";
            (void)alarm_confirm_and_report(&ctx, mask, r1, r2,
                                           g_sensor.last_pressure_collect,
                                           g_sensor.last_pressure_collect2);
        }
    }
    else
    {
        // 偶发报警, 不记录报警
        record.flags = 0;
    }

    // 存入EEPROM历史记录
#if CALIB_MODE_ENABLED
    if(calib_is_active())
    {
        s_calib_latest = record;
        s_calib_latest_valid = 1;
    }
    else
#endif
    {
        ee_hist_push(record.pressure, record.temperature,
                     record.pressure2, record.temperature2,
                     record.voltage, record.flags);
    }
    sensor_baseline_update_collect();
    wakeup_count++;

    // 上报调度判断 (若报警上报后仍到上报时刻, 历史数据再补上报)
    check_upload_schedule();
}

// ==================== 批量上报 (历史数据, 各模式) ====================
static void do_upload(void)
{
    uint16_t n, i;
    int is_coldstart = 0;

    // === 窗口检查(dot/VLP模式由do_collect已确认时间点, 直接通过) ===
    // 后延只推迟上报时刻, 数据仍属于"窗口内网格点": 以(当前时刻-后延)的网格时刻判断窗口,
    // 窗口外网格点(如夜间)不上报, 数据累积到次日窗口内网格点补报
    if(!voltage_low_power && strcmp(g_window.pattern, "dot") != 0)
    {
        uint32_t now_hhmmss = rtc_get_hhmmss();
        uint32_t now_sec = hhmmss_to_seconds(now_hhmmss);
        uint32_t delay_sec = (uint32_t)(g_report_delay_min * 60.0f);
        uint32_t grid_sec = (now_sec >= delay_sec) ? (now_sec - delay_sec)
                                                   : (now_sec + 86400u - delay_sec);
        uint32_t grid_hhmmss = (grid_sec / 3600) * 10000
                             + ((grid_sec / 60) % 60) * 100 + (grid_sec % 60);
        if(!config_is_active_window_at(grid_hhmmss))
        {
            printf_debug("[SM] UPLOAD: outside window (grid %02u:%02u:%02u), skip\r\n",
                         grid_sec / 3600, (grid_sec / 60) % 60, grid_sec % 60);
            app_state = STATE_SLEEP;
            return;
        }
    }

    printf_debug("[SM] UPLOAD: %d records (pattern=%s%s)\r\n",
                 ee_hist_count(), g_window.pattern,
                 voltage_low_power ? " VLP" : "");

    // === 确保4G模块连接 ===
    com_lpuart_init();
    trea_delay_ms(100);
    gpio_init();   /* 最小唤醒后 PA0(DTR) 被深休眠配置为 Analog, 必须恢复输出才能唤醒4G */

    // 低电压省电模式 / 弱信号模式: 强制走冷启动路径
    if(voltage_low_power || strcmp(g_window.pattern, "long") != 0 ||
       fourG_weak_signal || fourG_init_failed)
    {
        // short/dot/VLP/weak_signal: 4G断电状态, InitAndConnect 冷启动 (V4G_EN+PWRKEY 完整时序)
        is_coldstart = 1;
        if(EC801E_InitAndConnect() != EC_OK)
        {
            printf_debug("[SM] UPLOAD: cold start failed, power off\r\n");
            EC801E_PowerOff();
            fourG_init_failed = 1;   /* 下次上报冷启动重试 (do_upload 冷启动分支已含此标志) */
            app_state = STATE_SLEEP;
            return;
        }
        fourG_init_failed = 0;  // 连接成功, 清除失败标志
        fourG_weak_signal = 0;  // 冷启动成功: 同时清除弱信号标志, 防止下个do_sleep再次断电
        EC801E_SetSleepMode(0);
//        trea_delay_ms(300);
//        report_4g_power_state(1);
    }
    else
    {
        // long模式(无VLP, 无弱信号): 4G应保持在线(QSCLK), 直接确认
        if(EC801E_EnsureConnected() != EC_OK)
        {
            printf_debug("[SM] UPLOAD: connect failed, power off\r\n");
            EC801E_PowerOff();
            fourG_init_failed = 1;   /* 挂死模块: 断电并标记, 下次上报走冷启动真复位 */
            app_state = STATE_SLEEP;
            return;
        }
        fourG_init_failed = 0;  // EnsureConnected 成功, 清除失败标志
    }

    // 4G连接成功后才更新LCD信号强度
    lcd_update_csq();
#if CALIB_MODE_ENABLED
    report_publish_field("product-status", calib_is_active() ? "0" : "1");  /* 每次周期上传带状态 */
#else
    report_publish_field("product-status", "1");
#endif

    // === 用户端MQTT: 预连接 (历史记录同步上报, 约1分钟耗时) ===
    uint8_t user_mqtt_on = 0;
    if(EC801E_UserMqtt_IsConfigured())
    {
        trea_delay_ms(500);
        if(EC801E_UserMqtt_Connect() == EC_OK)
        {
            user_mqtt_on = 1;
        }
        else
        {
            printf_debug("[SM] UserMqtt: 1st connect failed, retry...\r\n");
            trea_delay_ms(1000);
            user_mqtt_on = (EC801E_UserMqtt_Connect() == EC_OK);
            if(!user_mqtt_on)
                printf_debug("[SM] UserMqtt: 2nd connect failed, skip user mqtt\r\n");
        }
    }

    // === 批量上传 (双通道: 平台id=0 + 用户端id=1, 从EEPROM读取) ===
#if CALIB_MODE_ENABLED
    if(calib_is_active())
    {
        /* 未安装校零期: 只上报最新值, 不读历史批量 */
        if(s_calib_latest_valid)
        {
            if(EC801E_PublishSingleRecord(&s_calib_latest) == EC_OK)
            {
                /* 未安装期不弹历史, 需在此提交防重锁: 保证一个上报周期只发一次最新值 */
                printf_debug("[CALIB] upload latest OK, commit period lock\r\n");
                upload_commit();
            }
            trea_delay_ms(300);
        }
    }
    else
#endif
    while(ee_hist_count() > 0)
    {
        vtiming_check_now();   /* timing valve preempts upload */
        EeHistRecord_t ee_rec;
        SensorRecord_t rec;
        uint8_t rd_ret;

        swdt_feed();
        rd_ret = ee_hist_read(0, &ee_rec);
        if(rd_ret == 0)
        {
            ee_hist_to_sensor_record(&ee_rec, &rec);

            EC_Status_t pub_ret = EC801E_PublishSingleRecord(&rec);
            if(pub_ret == EC_PREEMPT)
            {
                vtiming_check_now();   /* run timing valve, then resend current record */
                continue;
            }
            if(pub_ret == EC_OK)
            {
                if(user_mqtt_on)
                {
                    trea_delay_ms(300);
                    if(EC801E_UserMqtt_PublishRecord(&rec) != EC_OK)
                    {
                        printf_debug("[SM] UserMqtt: publish failed, try reconnect\r\n");
                        EC801E_UserMqtt_Disconnect();
                        trea_delay_ms(500);
                        if(EC801E_UserMqtt_Connect() == EC_OK)
                        {
                            trea_delay_ms(300);
                            EC801E_UserMqtt_PublishRecord(&rec);
                        }
                        else
                        {
                            printf_debug("[SM] UserMqtt: reconnect failed, disable\r\n");
                            user_mqtt_on = 0;
                        }
                    }
                }
                ee_hist_pop();

                if(ee_hist_count() > 0)
                    trea_delay_ms(one_by_one_delay);
            }
            else
            {
                printf_debug("[SM] UPLOAD: Publish record failed, stop remaining uploads\r\n");
                break;
            }
        }
        else
        {
            // CRC校验失败或读取异常, 跳过损坏记录
            printf_debug("[SM] UPLOAD: EEPROM read error (ret=%d), skip record\r\n", rd_ret);
            ee_hist_pop();
        }
    }

    // === 用户端MQTT: 断开 ===
    if(user_mqtt_on)
    {
        trea_delay_ms(500);
        EC801E_UserMqtt_Disconnect();
    }

    // 上报汇总状态 (含传感器状态+信号+压力温度状态+阀门+IP+电压)
    trea_delay_ms(200);
    report_publish_upload_summary();
    printf_debug("[SM] upload summary published\r\n");

    // 上次上传过程结束点位清零重新开始统计计数
    wakeup_count = 0;
    /* 周期上报成功(历史缓冲清空)才提交: 清"待上报"标志 + 记录本周期序号(持久化);
     * 失败/部分失败则保持标志, 下次唤醒自动重试 */
#if CALIB_MODE_ENABLED
    if(!calib_is_active() && ee_hist_count() == 0)
#else
    if(ee_hist_count() == 0)
#endif
        upload_commit();
    printf_debug("[SM] UPLOAD finished, remaining records in buffer: %d\r\n", ee_hist_count());

    // === RTC校准: 通过4G网络时间同步本地时钟 ===
    {
        trea_delay_ms(200);
        EC_Status_t sync_ret = EC801E_SyncTime();
        if(sync_ret == EC_OK)
            printf_debug("[SM] RTC calibrated from network\r\n");
        else
            printf_debug("[SM] RTC calibration failed (non-critical)\r\n");
    }

    // === 模式化收尾 ===
    if(is_coldstart)
    {
        // 冷启动模式(VLP/short/dot/weak_signal): 等待20s接收平台下发指令
        printf_debug("[SM] Waiting 20s for downlink...\r\n");
        trea_delay_ms(20000);
        {
            uint8_t dl_count = drain_pending_downlink();
            if(dl_count > 0)
                printf_debug("[SM] Processed %d downlink msg(s)\r\n", dl_count);
        }

        // long模式弱信号恢复路径: 检查信号是否恢复, 决定是否保持在线
        if(fourG_weak_signal && strcmp(g_window.pattern, "long") == 0)
        {
            if(fourG_signal_check_and_decide())
            {
                // 信号恢复, 保持4G在线(long模式正常行为)
                EC801E_SetSleepMode(1);
                printf_debug("[SM] UPLOAD: signal OK, keep 4G online\r\n");
            }
            // else: 内部已断电
        }
        else
        {
//            report_4g_power_state(0);
            EC801E_PowerOff();
        }
    }
    else
    {
        // long(无弱信号): 按信号强弱决定去留
        trea_delay_ms(500);
        if(fourG_signal_check_and_decide())
            EC801E_SetSleepMode(1);
        // else: 信号弱, 内部已断电
    }

    app_state = STATE_SLEEP;
}



// ==================== 处理MQTT下行指令 (下行最高优先级) ====================
static void do_downlink(void)
{
    uint8_t msg_count;

    printf_debug("[SM] DOWNLINK\r\n");
    com_lpuart_init();
    trea_delay_ms(100);

    msg_count = drain_pending_downlink();

    if(msg_count == 0)
    {
        printf_debug("[SM] No downlink, check MQTT...\r\n");
        if(EC801E_EnsureConnected() == EC_OK)
            printf_debug("[SM] MQTT OK\r\n");
    }
    else
    {
        printf_debug("[SM] Processed %d msg(s)\r\n", msg_count);
    }

    /* gas_get 指令: 优先进入 CH4 采集状态机。
     * 放在 SetSleepMode/弱信号判断之前: 此时 4G 刚被 QMTRECV 唤醒且 MQTT 在线,
     * 直接进入 CH4 可保证采集完成后的上报通道可用; 若先 SetSleepMode(1), 暖机
     * 30s 后模块已 QSCLK 休眠, 上报首条 AT 会丢失。 */
    if(g_ch4_request) {
        g_ch4_request = 0;
        app_state = STATE_CH4;
        return;
    }

    /* 静态测漏任务: 保持 4G 在线进入测漏状态, 不做弱信号断电判断
     * (任务全程需要 MQTT 收阀门指令/发数据包, 断电会导致整批数据丢失) */
    if(leak_task_pending())
    {
        app_state = STATE_SLEEP;    /* 由主循环转入 STATE_LEAK */
        return;
    }

    // 如果信号OK则保持在线 (弱信号断电时已内部处理)
    trea_delay_ms(500);
    if(fourG_signal_check_and_decide())
        EC801E_SetSleepMode(1);
    // else: 信号弱, 内部已断电

    app_state = STATE_SLEEP;
}

// ==================== BLE OTA 状态处理 ====================
static void do_ble_ota(void)
{
#if BLE_OTA_ENABLED
    /* 第一阶段: 等待手机连接BLE (PD2=LOW) */
    if(g_ble_ota.state == BLE_OTA_WAIT_CONNECT)
    {
        if(ble_link_is_connected())
        {
            /* 手机已连接BLE模块 -> 初始化UART开始处理OTA指令 */
            printf_debug("[SM] BLE connected (PD2=LOW), init UART4\r\n");
            ble_uart_init();
            ble_uart_rx_flush();
            g_ble_ota.state = BLE_OTA_IDLE;
            g_ble_ota.last_rx_ms = trea_millis();  /* 重置超时计时 */
            trea_delay_ms(500);
            printf_debug("[SM] BLE connected (PD2=LOW), init UART4---OK\r\n");
        }
        else
        {
            /* 尚未连接, 检查超时 (ble_ota_process内部处理) */
            ble_ota_process();
        }
    }
    else
    {
        /* 第二阶段: 数据接收, 处理OTA指令 */
        ble_ota_process();

        if(g_ble_ota.state == BLE_OTA_DOWNLOADING)
        {
            ota_wdt_feed();
        }
    }
	
#if BUTTON_ENABLED
    /* 按键退出: 3次按键关闭蓝牙 (需3次按键不松手) */
    if(button_is_pressed())
    {
        uint8_t ble_press_count = 1;
        uint16_t ble_wait;

        while(button_is_pressed()) trea_delay_ms(20);
        trea_delay_ms(30);

        while(ble_press_count < 3)
        {
            uint8_t ble_got = 0;
            for(ble_wait = 0; ble_wait < 500; ble_wait += 20)
            {
                trea_delay_ms(20);
                if(button_is_pressed()) { ble_got = 1; break; }
            }
            if(!ble_got) break;
            ble_press_count++;
            while(button_is_pressed()) trea_delay_ms(20);
            trea_delay_ms(30);
        }

        if(ble_press_count >= 3)
        {
            printf_debug("[SM] BLE_OTA: 3-press detected, turning off BLE\r\n");
            g_bt_on = 0;
            power_ble_set(0);
            if(g_lcd_active) slcd_seg_icon_display(SLCD_ICON_LY, RESET);
        }
    }
#endif

    /* 退出条件: OTA完成/超时, 关闭蓝牙并返回 */
    if(g_ble_ota.state == BLE_OTA_ERROR || !g_bt_on)
    {
        printf_debug("[SM] BLE_OTA exit: state=%d, bt=%d\r\n", g_ble_ota.state, g_bt_on);
        ble_uart_deinit();
        if(g_bt_on)
        {
            ble_power_toggle();
        }
        app_state = STATE_SLEEP;
    }
    /* 注: OTA_COMPLETE不会走到这里, handle_end()已调用NVIC_SystemReset() */
#else
    /* BLE OTA 停用 (BLE_OTA_ENABLED=0): 本状态不会被进入 */
    app_state = STATE_SLEEP;
#endif /* BLE_OTA_ENABLED */
}

// ==================== Debug串口命令处理(需要硬件上下文) ====================
static void debug_check_cmd(void)
{
    static char line_buf[512];
    uint16_t len;

    while((len = debug_rx_read_line(line_buf, sizeof(line_buf), 0)) > 0)
    {
        printf_debug("[DBG] %s\r\n", line_buf);

        // ---- commands requiring main.c hardware context ----
        if(strcmp(line_buf, "status") == 0)
        {
            const char *state_names[] = {"INIT","SLEEP","WAKEUP","COLLECT","UPLOAD","DOWNLINK","ALARM","BLE_OTA","CH4","LEAK"};
            printf_debug("  state=%s wakeup=%d buf=%d\r\n",
                         (app_state <= STATE_LEAK) ? state_names[app_state] : "?",
                         wakeup_count, ee_hist_count());
            printf_debug("  P=%.2f T=%.2f V=%.2f last_Pc=%.2f last_Pr=%.2f\r\n",
                         g_sensor.raw.pressure, g_sensor.raw.temperature, g_sensor.voltage, g_sensor.last_pressure_collect, g_sensor.last_pressure_realtime);
            printf_debug("  valve=%d abnormal=%s\r\n", g_valve_last_order, g_abnormal_close);
            printf_debug("  4G: user_off=%d init_fail=%d weak_sig=%d\r\n", fourG_user_off, fourG_init_failed, fourG_weak_signal);
#if BLE_ENABLED
            printf_debug("  BLE: on=%d\r\n", g_bt_on);
#else
            printf_debug("  BLE: disabled (BLE_ENABLED=0)\r\n");
#endif
            printf_debug("  ZERO: baseline=%ldPa valid=%d\r\n",
                         (long)zero_cal_get(), zero_cal_is_valid());
            printf_debug("  PT304D err=%d stat=0x%02X\r\n", g_sensor.raw.err, g_sensor.raw.stat_raw);
            continue;
        }
        if(strcmp(line_buf, "sensor") == 0)
        {
            PT304D_CollectAll((g_sensor_count >= 2) ? &g_sensor.raw2 : NULL, &g_sensor.raw);
            g_sensor.voltage = adc_bat_read_voltage();
            printf_debug("  err=%d stat=0x%02X P=%.2f T=%.2f V=%.2f\r\n",
                         g_sensor.raw.err, g_sensor.raw.stat_raw, g_sensor.raw.pressure, g_sensor.raw.temperature, g_sensor.voltage);
            if(g_sensor.raw.err != PT304D_OK)
                printf_debug("  press_raw=0x%06X temp_raw=0x%06X\r\n", g_sensor.raw.press_raw, g_sensor.raw.temp_raw);
            continue;
        }
        if(strcmp(line_buf, "sensor_status") == 0)
        {
            PT304D_CollectAll((g_sensor_count >= 2) ? &g_sensor.raw2 : NULL, &g_sensor.raw);
            const char *have   = (g_sensor.raw.err != PT304D_ERR_I2C) ? "1" : "0";
            const char *status = (g_sensor.raw.err == PT304D_OK)       ? "1" : "0";
            printf_debug("  have=%s status=%s err=%d stat=0x%02X\r\n",
                         have, status, g_sensor.raw.err, g_sensor.raw.stat_raw);
            continue;
        }
        if(strcmp(line_buf, "temp_status") == 0)
        {
            PT304D_CollectAll((g_sensor_count >= 2) ? &g_sensor.raw2 : NULL, &g_sensor.raw);
            TempStatus_t ts = threshold_get_temp_status(g_sensor.raw.temperature);
            printf_debug("  T=%.2f -> %s\r\n", g_sensor.raw.temperature, threshold_temp_status_str(ts));
            continue;
        }
        if(strcmp(line_buf, "pressure_status") == 0)
        {
            PT304D_CollectAll((g_sensor_count >= 2) ? &g_sensor.raw2 : NULL, &g_sensor.raw);
            PressureStatus_t ps = threshold_get_pressure_status(g_sensor.raw.pressure, g_sensor.last_pressure_collect);
            printf_debug("  P=%.2f -> %s\r\n", g_sensor.raw.pressure, threshold_pressure_status_str(ps));
            continue;
        }
        if(strcmp(line_buf, "sim") == 0)
        {
            char csq[8] = {0}, iccid[32] = {0}, imei[24] = {0};
            int rsrp = 0, sinr = 0;
            uint8_t cereg = 0;
            EC801E_Wakeup();
            EC801E_QueryCSQ(csq, sizeof(csq));
            EC801E_QueryQCSQ(&rsrp, &sinr);
            EC801E_QueryCEREG(&cereg);
            EC801E_QueryICCID(iccid, sizeof(iccid));
            EC801E_QueryIMEI(imei, sizeof(imei));
            printf_debug("  CSQ=%s RSRP=%d SINR=%d CEREG=%d\r\n", csq, rsrp, sinr, cereg);
            printf_debug("  ICCID=%s IMEI=%s\r\n", iccid, imei);
            continue;
        }
        if(strcmp(line_buf, "restart") == 0)
        {
            printf_debug("[DBG] Restarting...\r\n");
            trea_delay_ms(50);
            NVIC_SystemReset();
        }
        /* ---- 电机电流/堵转标定 (阶段2/3) ---- */
        if(strcmp(line_buf, "zero_cal") == 0)
        {
            if(!zero_cal_enabled())
            {
                printf_debug("  zero_cal -> N/A: current protocol needs no atmospheric baseline\r\n");
                continue;
            }
            uint8_t ok = zero_cal_run();
            printf_debug("  zero_cal -> %s, baseline=%ldPa\r\n",
                         ok ? "OK (saved)" : "FAILED (baseline unchanged)",
                         (long)zero_cal_get());
            continue;
        }
        if(strcmp(line_buf, "zero_show") == 0)
        {
            printf_debug("  baseline=%ldPa valid=%d enabled=%d (default %dPa)\r\n",
                         (long)zero_cal_get(), zero_cal_is_valid(),
                         zero_cal_enabled(), ZERO_CAL_DEFAULT_PA);
            continue;
        }
        if(strcmp(line_buf, "motor_cs") == 0)
        {
#if MOTOR_ENABLED
    #if MOTOR_CS_ENABLED
            {
                uint16_t raw = motor_current_raw();
                uint32_t mv  = adc_svc_raw_to_mv(raw);
                uint32_t ma  = (MOTOR_CS_R_SHUNT > 0.0f) ? (uint32_t)((float)mv / MOTOR_CS_R_SHUNT)
                                                         : 0xFFFFFFFFu;
                printf_debug("  motor_cs: raw=%u mV=%lu mA=%lu th=%u R=%.2f ohm\r\n",
                             raw, (unsigned long)mv, (unsigned long)ma,
                             g_motor_cs_th, (double)MOTOR_CS_R_SHUNT);
            }
    #else
            printf_debug("  motor_cs: N/A (电流采样未实施, MOTOR_CS_ENABLED=0)\r\n");
    #endif
            printf_debug("  valve: pos_valid=%d pos_state=%d last_order(%s)=%d status=%s\r\n",
                         g_valve_pos_valid, g_valve_pos_state,
                         "user cmd", g_valve_last_order, valve_get_status());
#else
            printf_debug("  motor not present (MOTOR_ENABLED=0)\r\n");
#endif
            continue;
        }
        if(strncmp(line_buf, "motor_cs_th:", 12) == 0)
        {
#if (MOTOR_ENABLED && MOTOR_CS_ENABLED)
            uint32_t v = (uint32_t)atoi(line_buf + 12);
            if(v > 4095u) v = 4095u;             /* 12 位 ADC 上限 */
            g_motor_cs_th = (uint16_t)v;
            config_save_motor_cs_th();
            printf_debug("  motor_cs_th = %u raw (%lumA) saved\r\n",
                         g_motor_cs_th, (unsigned long)MOTOR_CS_RAW_TO_MA(g_motor_cs_th));
#else
            printf_debug("  motor_cs_th: N/A (电流采样未实施)\r\n");
#endif
            continue;
        }
        if(strncmp(line_buf, "motor_cs_ma:", 12) == 0)
        {
#if (MOTOR_ENABLED && MOTOR_CS_ENABLED)
            uint32_t ma = (uint32_t)atoi(line_buf + 12);
            g_motor_cs_th = MOTOR_CS_MA_TO_RAW(ma);      /* mA → raw */
            config_save_motor_cs_th();
            printf_debug("  motor_cs_th = %u raw (%lumA) saved\r\n",
                         g_motor_cs_th, (unsigned long)MOTOR_CS_RAW_TO_MA(g_motor_cs_th));
#else
            printf_debug("  motor_cs_ma: N/A (电流采样未实施)\r\n");
#endif
            continue;
        }
        if(strncmp(line_buf, "valve_cal:", 10) == 0)
        {
#if (MOTOR_ENABLED && MOTOR_CS_ENABLED)
            const char *dir = line_buf + 10;
            uint8_t open_dir = (strcmp(dir, "open") == 0) ? 1u : 0u;
            uint32_t t0 = trea_millis();

            printf_debug("  calibrating %s: 250ms/sample, max %ums (motor will drive!)\r\n",
                         open_dir ? "OPEN" : "CLOSE", MOTOR_CS_CAL_MAX_MS);
            motor_init(MOTOR_ENABLED);
            if(open_dir) motor_drive_open(); else motor_drive_close();

            while((trea_millis() - t0) < MOTOR_CS_CAL_MAX_MS)
            {
                trea_delay_ms(250);
                swdt_feed();
                {
                    uint16_t raw = motor_current_raw();
                    uint32_t mv  = adc_svc_raw_to_mv(raw);
                    uint32_t ma  = (MOTOR_CS_R_SHUNT > 0.0f) ? (uint32_t)((float)mv / MOTOR_CS_R_SHUNT)
                                                             : 0xFFFFFFFFu;
                    printf_debug("  t=%4ums raw=%4u mV=%4lu mA=%5lu\r\n",
                                 (unsigned)(trea_millis() - t0), raw,
                                 (unsigned long)mv, (unsigned long)ma);
                }
            }
            motor_stop();
            printf_debug("  calibration drive finished (motor stopped)\r\n");
#else
            printf_debug("  valve_cal: N/A (电流采样未实施)\r\n");
#endif
            continue;
        }
        if(strcmp(line_buf, "valve_home") == 0)
        {
            uint8_t ok = valve_home();
            printf_debug("  valve_home -> %s\r\n", ok ? "OK (closed, position valid)" : "FAILED");
            continue;
        }

        if(strncmp(line_buf, "valve:", 6) == 0)
        {
            const char *action = line_buf + 6;  // "open" or "close"
            const char *result = valve_execute(action, 1);

            /* 用户手动开阀 → 清告警锁并立即持久化 (手动关阀不清锁) */
            if(strcmp(action, "open") == 0 || strcmp(action, "1") == 0)
                alarm_lock_clear_all();
            if(g_valve_alarm_closed)
            {
                g_valve_alarm_closed = 0;
                g_valve_pre_alarm_order = g_valve_pos_state;   /* 物理状态 */
                config_save_ext();
                printf_debug("  cleared alarm_closed flag (user override)\r\n");
            }
            g_ch4_alarm_closed = 0;
            g_alarm_recover_reported = 0;
            printf_debug("  valve(%s) -> %s  last_order=%d\r\n", action, result, g_valve_last_order);
            continue;
        }
        if(strncmp(line_buf, "first_ip:", 9) == 0)
        {
            char ip_buf[MQTT_FIELD_MAX];
            strncpy(ip_buf, line_buf + 9, sizeof(ip_buf) - 1);
            ip_buf[sizeof(ip_buf) - 1] = '\0';
            char *last_dot = strrchr(ip_buf, '.');
            if(last_dot)
            {
                *last_dot = '\0';
                g_mqtt.port = (uint16_t)atoi(last_dot + 1);
                strncpy(g_mqtt.server, ip_buf, MQTT_FIELD_MAX - 1);
                config_save_mqtt();
                printf_debug("  Primary IP set: %s:%d, reconnecting...\r\n", g_mqtt.server, g_mqtt.port);
                EC801E_DisconnectMQTT();
                trea_delay_ms(500);
                EC801E_ConnectMQTT();
                EC801E_SubscribeAll();   /* 重连后重订阅全部主题(含OTA/测漏) */
            }
            else
                printf_debug("  Invalid format, use: first_ip:IP.port\r\n");
            continue;
        }
        if(strncmp(line_buf, "scend_ip:", 9) == 0)
        {
            char ip_buf[MQTT_FIELD_MAX];
            strncpy(ip_buf, line_buf + 9, sizeof(ip_buf) - 1);
            ip_buf[sizeof(ip_buf) - 1] = '\0';
            char *last_dot = strrchr(ip_buf, '.');
            if(last_dot)
            {
                *last_dot = '\0';
                g_mqtt.port2 = (uint16_t)atoi(last_dot + 1);
                strncpy(g_mqtt.server2, ip_buf, MQTT_FIELD_MAX - 1);
                config_save_mqtt();
                printf_debug("  Secondary IP set: %s:%d\r\n", g_mqtt.server2, g_mqtt.port2);
            }
            else
                printf_debug("  Invalid format, use: scend_ip:IP.port\r\n");
            continue;
        }
        if(strcmp(line_buf, "4Gpower_off") == 0)
        {
            printf_debug("  4G power off\r\n");
//            report_4g_power_state(0);
//            trea_delay_ms(200);
            fourG_drain_before_power_off();   /* 人工断电前必读: 前面可能还有排队指令 */
            EC801E_PowerOff();
            fourG_user_off = 1;
            continue;
        }
        if(strcmp(line_buf, "4Gpower_on") == 0)
        {
            printf_debug("  4G power on\r\n");
            fourG_user_off = 0;
            fourG_weak_signal = 0;
            com_lpuart_init();
            trea_delay_ms(100);
            /* InitAndConnect 内含完整冷启动时序 (V4G_EN+PWRKEY) */
            EC801E_InitAndConnect();
            if(EC801E_EnsureConnected() == EC_OK)
            {
//                report_4g_power_state(1);
                printf_debug("  4G power on OK, reported\r\n");
            }
            else
                printf_debug("  4G power on FAILED\r\n");
            EC801E_SetSleepMode(1);
            continue;
        }
        if(strcmp(line_buf, "mqtt_reconnect") == 0)
        {
            printf_debug("  MQTT reconnecting...\r\n");
            EC801E_Wakeup();
            EC801E_DisconnectMQTT();
            trea_delay_ms(500);
            if(EC801E_ConnectMQTT() == EC_OK)
            {
                EC801E_SubscribeAll();   /* 重连后重订阅全部主题(含OTA/测漏) */
                printf_debug("  MQTT reconnected OK\r\n");
            }
            else
                printf_debug("  MQTT reconnect FAILED\r\n");
            continue;
        }
        if(strcmp(line_buf, "vlp") == 0)
        {
            printf_debug("  voltage_low_power=%d vlp_uploaded=%d valve_alarm_closed=%d pre=%d\r\n",
                         voltage_low_power, vlp_uploaded_this_hour,
                         g_valve_alarm_closed, g_valve_pre_alarm_order);
            printf_debug("  fourG: user_off=%d init_failed=%d weak_signal=%d\r\n",
                         fourG_user_off, fourG_init_failed, fourG_weak_signal);
            printf_debug("  spupower en=%d vprotect=%.2f\r\n",
                         g_spupower.enabled, g_spupower.protect);
            continue;
        }
        if(strcmp(line_buf, "buf") == 0)
        {
            printf_debug("  ee_hist: %d records\r\n", ee_hist_count());
            continue;
        }
        if(strcmp(line_buf, "time") == 0)
        {
            rtc_show_time();
            continue;
        }

        // ---- commands without hardware context, delegated to eeprom_config.c ----
        if(config_parse_and_apply(line_buf) == 0)
            printf_debug("[DBG] Unknown: %s\r\n", line_buf);
    }
}

#if LASER_CH4_ENABLED
// ==================== 激光甲烷定时采集调度 ====================
// laser_switch 仅管理读取时间点: 当前小时命中 laser_time 位图且本小时未执行过则触发 STATE_CH4
static void laser_schedule_check(void)
{
    RtcDateTime_t dt;

    if(!g_laser_switch) return;

    rtc_get_datetime(&dt);
    if(dt.hour != s_laser_done_hour && window_dottime_hit(g_laser_time_mask, dt.hour))
    {
        s_laser_done_hour = dt.hour;
        printf_debug("[SM] LASER schedule trigger at %02u:00\r\n", dt.hour);
        /* 仅置请求标志, 由主循环在 app_state==SLEEP 时转入 STATE_CH4,
         * 确保网格采集/整点上传先完成, 不再抢占 STATE_COLLECT */
        g_ch4_request = 1;
    }
}
#endif /* LASER_CH4_ENABLED */

// ==================== 4G连接主动巡检 (一直在线模式, 每30分钟) ====================
// long模式且(活动窗口或end_result=1)时4G应保持在线; 每30分钟主动确认与平台MQTT连接,
// 掉线自动重连; 重连失败断电并置失败标志, 等下次上报冷启动 (do_upload 冷启动分支已含 init_failed)
// 触发点两处(内部30分钟节流): ①主循环每次迭代(采集/上报/下行/按键唤醒) ②实时模式每个tick
//   —— 另由 sched_set_next_collect_alarm() 在"一直在线"模式下保证 ≤30 分钟唤醒一次
// 注意: 最小唤醒上下文 4G 的 LPUART/引脚未初始化, 巡检前必须 com_lpuart_init + gpio_init
static void check_4g_connection_supervision(void)
{
    uint16_t now_min;

    /* 非"一直在线"模式: 不巡检, 保持现状 */
    if(!supervise_is_applicable())
        return;

    now_min = supervise_now_min();

    if(s_last_supervise_min == 0xFFFFu)
    {
        s_last_supervise_min = now_min;   /* 上电后满30分钟再首次巡检 */
        return;
    }
    if((uint16_t)(now_min - s_last_supervise_min) < FOURG_SUPERVISE_INTERVAL_MIN)
        return;

    s_last_supervise_min = now_min;
    printf_debug("[SM] 4G supervision: checking MQTT connection...\r\n");

    /* 恢复 4G LPUART 与引脚 (否则 AT 全部 rx(0), 与 CH4 上报路径同一根因) */
    com_lpuart_init();
    gpio_init();

    if(EC801E_EnsureConnected() != EC_OK)
    {
        printf_debug("[SM] 4G supervision: reconnect failed, power off (next upload cold start)\r\n");
        EC801E_PowerOff();
        fourG_init_failed = 1;
        return;
    }

    fourG_init_failed = 0;
    EC801E_SetSleepMode(1);   /* 恢复QSCLK轻休眠, 保持在线 */
}


// ==================== 主函数 ====================
int main(void)
{
    SensorRecord_t init_record;		//首次采集记录

    // ==================== STATE_INIT ====================
    sys_init();

    /* 上电提示: LED1(PB5) 亮 1 秒 (沿用原"三灯全亮 1 秒"的时长; 蜂鸣器不参与)
     * 只在复位/上电路径执行, 深睡唤醒不会闪。swdt 尚未使能, 闪烁内喂狗无副作用。 */
    output_led_blink(1000);

	// ==================== 首次采集上报 ====================
#if APP_DEFAULT_SENSOR_COUNT >= 2
    PT304D_Init(PT304D_SENSOR_1);   /* S1 = 出气端低压 (I2C1: PB6/PB7), 双路及以上才有 */
    /* 4 路产品扩展时: 在此补 PT304D_Init(PT304D_SENSOR_3) / (PT304D_SENSOR_4) */
#endif
    PT304D_Init(PT304D_SENSOR_2);   /* S2 = 进气端中压 (I2C0: PC11/PC12), 单路产品也用它 */
    // 软件看门狗: SysTick 由 sys_init 启动, 可保护后续的 4G 连接/上报等耗时操作
    swdt_enable(SWDT_TIMEOUT_MS);
    com_lpuart_init();
    lpuart_wakeup_init();
	printf_debug("\r\n[OTA] yes%s \r\n", APP_FIRMWARE_VERSION);
	
    config_load_all();
    /* 上报周期防重锁: 从 EEPROM 读回上次成功上报的周期序号(跨重启保持, 防重复上报) */
    s_last_upload_idx     = config_load_upload_idx();
    s_upload_pending      = 0;
    s_pending_due_abs_min = 0;
    config_enter_setup_mode(0);
    config_print_current();

    rtc_init_all();
    rtc_alarm_wakeup_init();

    /* 告警锁: 上电读取 EEPROM 中的"最后已上报等级" (重启后持续中的告警不重报) */
    alarm_lock_init();

	
	
	
    ee_hist_init();
    /* 重启补报: 开机时刻若已进入新的上报周期(且该周期还没上报过), 立即置"待上报",
     * 防止"上报被打断(掉电/复位/OTA)后数据被推迟一整个上报周期" */
    upload_pending_update();
    /* 静态测漏暂存区: 上电一律清零 (本功能不做断点续传) */
    leak_store_init();
    /* 存储布局版本检查: 老固件升级上来时主动迁移(格式化受影响的区), 避免概率性误判 */
    eeprom_layout_check_and_migrate();

#if CALIB_MODE_ENABLED
    /* ============ 未安装自动校零: 提前置状态(显示/首次采集/上报都要用) ============ */
    calib_load_state();
    if(!calib_is_installed())
    {
        calib_set_active(1);
        printf_debug("[CALIB] uninstalled: auto-calibration active (sample=%umin)\r\n",
                     CALIB_SAMPLE_MIN);
    }
    calib_apply_zero_offsets();         /* 未安装: 有冻结零点先应用, 否则0偏移 */
#endif

    /* ==================== 零点(大气基准) ====================
     * 读 EEPROM 双槽并应用到传感器 (只读不改);
     * EEPROM 无有效基准时 (首次上电/更换传感器): 先用默认值保证测量可用, 随即尝试一次
     * 自动采集(5 次 x 500ms + 大气窗口校验), 失败则继续用默认值、不阻断运行。
     * 之后任何断电重启都只读取基准, 不会自动重新校零。 */
    zero_cal_load_apply();
    if(!zero_cal_is_valid())
    {
        printf_debug("[ZERO] first power-on: try auto calibration\r\n");
        if(!zero_cal_run())
            printf_debug("[ZERO] auto calibration failed, keep default %dPa\r\n",
                         ZERO_CAL_DEFAULT_PA);
    }
    // LCD硬件初始化 (无 LCD 产品为空操作; 有 LCD 时必须在 rtc_init_all 之后, LXTAL 已启动)
    lcd_hw_init();
	
	// 首次采集+存入缓冲区+上报
    PT304D_CollectAll((g_sensor_count >= 2) ? &g_sensor.raw2 : NULL, &g_sensor.raw);
#if CALIB_MODE_ENABLED
    {
        uint8_t was_calib = calib_is_active();
        float p_raw = g_sensor.raw.pressure;
        float corr = calib_feed_sample(p_raw);   /* 校零: 零点成熟同拍修正 */
        if(corr != 0.0f)
            g_sensor.raw.pressure -= corr;
        if(was_calib)
        {
            calib_log_sample(p_raw, g_sensor.raw.pressure);
            if(!calib_is_active())
                install_event_report();         /* 自动锁定(首次采集): 一次性上报 */
        }
    }
#endif
	// 首次采集后刷新LCD显示
    sensor_sample_voltage(1, g_sensor.last_normal_voltage);
#if (CALIB_MODE_ENABLED && LCD_ENABLED)
    if(calib_is_active())
        calib_lcd_auto_begin();         /* 未安装期首次采集: 短亮压力页 */
    else if(g_lcd_active)
        lcd_ui_refresh(&g_sensor.raw, &g_sensor.raw2, g_sensor.voltage);
#else
    if(g_lcd_active) lcd_ui_refresh(&g_sensor.raw, &g_sensor.raw2, g_sensor.voltage);
#endif

    
	
    printf_debug("\r\n[OTA] yes%s \r\n", APP_FIRMWARE_VERSION);
	
    printf_debug("\r\n========================================\r\n");
    printf_debug("  Household Valve Controller v%s\r\n", APP_FIRMWARE_VERSION);
    printf_debug("  Collect: %dmin  Upload: %dmin (grid-aligned)\r\n",
                 g_interval.collect_interval_min,
                 g_interval.upload_interval_min);
    char dot_str5[64]; window_dottime_to_str(g_window.dottime_mask, dot_str5, sizeof(dot_str5));
    printf_debug("  Window: pattern=%s start=%s stop=%s er=%d dot=%s\r\n",
                 g_window.pattern, g_window.start, g_window.stop,
                 g_window.end_result, dot_str5);
//    printf_debug("  VPTH en=%d ppmax=%.1f pmax=%.1f ppmin=%.1f pmin=%.1f mut=%.1f shock=%.1f\r\n",
//                 g_pthreshold.enabled, g_pthreshold.ppmax, g_pthreshold.pmax,
//                 g_pthreshold.ppmin, g_pthreshold.pmin,
//                 g_pthreshold.mutation, g_pthreshold.shock);
//    printf_debug("  TTH  en=%d high=%.1f low=%.1f vhigh=%.1f vlow=%.1f\r\n",
//                 g_tthreshold.enabled, g_tthreshold.high, g_tthreshold.low,
//                 g_tthreshold.vhigh, g_tthreshold.vlow);
    printf_debug("  SPUP en=%d high=%.2f low=%.2f protect=%.2f\r\n",
                 g_spupower.enabled, g_spupower.high, g_spupower.low, g_spupower.protect);
    printf_debug("  VDLY en=%d delay_ms=%d\r\n", g_vdelay.enabled, g_vdelay.delay_ms);
    printf_debug("  Keepalive: %d s\r\n", config_get_keepalive());
    printf_debug("========================================\r\n");

    // 检查debug串口是否有待处理命令
    if(debug_rx_line_ready())
            debug_check_cmd();

	// === 公共首次联网: 配置下发 + RTC网络时间同步 (非业务上报) ===
    uint8_t init_4g_ok = (EC801E_InitAndConnect() == EC_OK);
    if(init_4g_ok)
    {
        ri_exti_init();   /* 首次联网成功: 布防 RI, 保证本周期到达的下行脉冲可锁存 */
        EC801E_SyncTime();
    }
	
    if(init_4g_ok)
    {

        // 4G连接成功后, 再检查debug串口命令
        if(debug_rx_line_ready())
            debug_check_cmd();

        // 用户端MQTT连接 (id=1, 与本地服务器同一阶段建立)
        if(EC801E_UserMqtt_IsConfigured())
            EC801E_UserMqtt_Connect();
//        report_4g_power_state(1);

        // 4G连接后更新LCD信号强度图标
        lcd_update_csq();

        /* 连接成功提示: 蜂鸣器原样响 1 声(200ms), LED 同步点亮同长度后熄灭
         * (蜂鸣器逻辑/时长/时序均未改动, 灯只是外加的两条 GPIO 操作) */
        output_led_set(1);
        buzzer_beep(1, 200);
        output_led_set(0);
    }
    else
    {
        printf_debug("[SM] INIT: 4G connect failed, skip MQTT reports\r\n");
        fourG_init_failed = 1;
    }

    // OTA启动前debug串口命令
    config_check_cmd();

    // === OTA 启动回执: 按 InfoBlock 显示上次升级 SUCCESS/FAILED, 上报 mqttUpgradeReply ===
    ota_app_report_boot_status();

    
    trea_delay_ms(50);

    init_record.pressure = g_sensor.raw.pressure;
    init_record.temperature = g_sensor.raw.temperature;
    init_record.pressure2 = g_sensor.raw2.pressure;
    init_record.temperature2 = g_sensor.raw2.temperature;
    init_record.voltage = g_sensor.voltage;
    rtc_get_time_str(init_record.timestamp, sizeof(init_record.timestamp));
    init_record.flags = 0;
    memset(init_record.reserved, 0, sizeof(init_record.reserved));
#if CALIB_MODE_ENABLED
    if(calib_is_active())
    {
        s_calib_latest = init_record;
        s_calib_latest_valid = 1;
    }
    else
#endif
    {
        /* 两路都离线: 首采记录不写历史 (身份/汇总报文照常, 但不产生全无效记录) */
        if(g_sensor.raw.err == PT304D_OK ||
           (g_sensor_count >= 2 && g_sensor.raw2.err == PT304D_OK))
        {
            ee_hist_push(init_record.pressure, init_record.temperature,
                         init_record.pressure2, init_record.temperature2,
                         init_record.voltage, init_record.flags);
        }
        else
        {
            printf_debug("[SM] INIT: both sensors offline, skip history record\r\n");
        }
    }
    sensor_baseline_update_collect();
    sensor_baseline_update_realtime();

    printf_debug("[SM] INIT V=%.2f S2:P=%.2f T=%.2f err=%d S1:P=%.2f T=%.2f err=%d\r\n",
                 g_sensor.voltage,
                 g_sensor.raw.pressure, g_sensor.raw.temperature, g_sensor.raw.err,
                 g_sensor.raw2.pressure, g_sensor.raw2.temperature, g_sensor.raw2.err);

    

    // 将首次采集结果更新 prev_online (不论4G是否成功, 防止实时模式误判状态变化)
    g_sensor.prev_online  = (g_sensor.raw.err  == PT304D_OK) ? 1 : 0;
    g_sensor.prev_online2 = (g_sensor.raw2.err == PT304D_OK) ? 1 : 0;

    // ==================== 首次批量上报 (当4G连接成功时) ====================
    if(!init_4g_ok) goto init_skip_report;

    EC801E_PublishSensorData(&g_sensor.raw, g_sensor.voltage);
    trea_delay_ms(500);

    // 第1: restart=1 + valve-last-order
    {
        char v_order[4];
        snprintf(v_order, sizeof(v_order), "%d", g_valve_last_order);
        static char boot_json[100];
        static char boot_ts[32];
        rtc_get_time_str(boot_ts, sizeof(boot_ts));
        snprintf(boot_json, sizeof(boot_json),
            "[{\"id\":\"restart\",\"value\":\"1\",\"ts\":\"%s\",\"remark\":\"\"}]",
            boot_ts);
        EC801E_PublishRawJson(boot_json);
    }
    trea_delay_ms(300);

    // 第2: 设备信息 (csq + rsrp + sinr + cereg + soft-version + ICCID + IMEI)
    {
        static char info_json[530];
        char csq[8] = {0}, iccid[32] = {0}, imei[24] = {0};
        char rsrp_str[8] = {0}, sinr_str[8] = {0}, cereg_str[4] = {0};
        int rsrp = 0, sinr = 0;
        uint8_t cereg = 0;
        EC801E_Wakeup();
        EC801E_QueryCSQ(csq, sizeof(csq));
        if(EC801E_QueryQCSQ(&rsrp, &sinr) == EC_OK)
        {
            snprintf(rsrp_str, sizeof(rsrp_str), "%d", rsrp);
            snprintf(sinr_str, sizeof(sinr_str), "%d", sinr);
        }
        EC801E_QueryCEREG(&cereg);
        snprintf(cereg_str, sizeof(cereg_str), "%d", cereg);
        trea_delay_ms(200);
        EC801E_QueryICCID(iccid, sizeof(iccid));
        trea_delay_ms(200);
        EC801E_QueryIMEI(imei, sizeof(imei));
        static char info_ts[32];
        rtc_get_time_str(info_ts, sizeof(info_ts));
        snprintf(info_json, sizeof(info_json),
            "[{\"id\":\"csq\",\"value\":\"%s\",\"ts\":\"%s\",\"remark\":\"\"},"
            "{\"id\":\"rsrp\",\"value\":\"%s\",\"ts\":\"%s\",\"remark\":\"\"},"
            "{\"id\":\"snr\",\"value\":\"%s\",\"ts\":\"%s\",\"remark\":\"\"},"
            "{\"id\":\"soft-version\",\"value\":\"%s\",\"ts\":\"%s\",\"remark\":\"\"},"
            "{\"id\":\"ICCID\",\"value\":\"%s\",\"ts\":\"%s\",\"remark\":\"\"},"
            "{\"id\":\"IMEI\",\"value\":\"%s\",\"ts\":\"%s\",\"remark\":\"\"}]",
            csq, info_ts, rsrp_str, info_ts, sinr_str, info_ts, 
            APP_FIRMWARE_VERSION, info_ts, iccid, info_ts, imei, info_ts);
        EC801E_PublishRawJson(info_json);
        printf_debug("[SM] Device info:\r\n CSQ=%s RSRP=%s SINR=%s CEREG=%s\r\n ICCID=%s\r\n IMEI=%s\r\n",
                     csq, rsrp_str, sinr_str, cereg_str, iccid, imei);
    }

    // 第3: 传感器状态(在线+离线)字段
    {
//        report_publish_sensor_status();   // rtu-have/status 各 2 (传感器状态字段上报)
		report_publish_upload_summary();
        g_sensor.prev_online  = (g_sensor.raw.err  == PT304D_OK) ? 1 : 0;
        g_sensor.prev_online2 = (g_sensor.raw2.err == PT304D_OK) ? 1 : 0;
    }


    // === 用户端MQTT上报 (id=1, 与传感器数据同一阶段建立) ===
    if(EC801E_UserMqtt_IsConfigured())
    {
        trea_delay_ms(300);
        EC801E_UserMqtt_PublishSensorData(&g_sensor.raw, &g_sensor.raw2, g_sensor.voltage);
        trea_delay_ms(500);
        EC801E_UserMqtt_Disconnect();
    }
	

	// 注: 4G 首次联网成功提示(原"三灯同步闪一下")已随三路 LED 移除
        buzzer_beep(2, 200);
init_skip_report:
    if(init_4g_ok)
    {
        // 首次上报后也检查信号: 弱信号直接断电, 不再无效重试
        if(!fourG_signal_check_and_decide())
            printf_debug("[SM] INIT: weak signal, 4G powered off\r\n");
        else
            EC801E_SetSleepMode(1);
    }
    else
        EC801E_PowerOff();
    wakeup_count = 0;

    // INIT结束: 若 spupower 关闭或电压已恢复, 则清除退出时的 VLP 状态
    if(voltage_low_power && (!g_spupower.enabled || g_sensor.voltage >= g_spupower.protect + 0.15f))
    {
        voltage_low_power = 0;
        config_save_ext();
        printf_debug("[SM] VLP cleared on boot (spup_en=%d V=%.2f)\r\n", g_spupower.enabled, g_sensor.voltage);
    }
	// 检查debug串口是否有待处理命令
    if(debug_rx_line_ready())
            debug_check_cmd();

    // 初始化完成, 进入睡眠
    app_state = STATE_SLEEP;

    // ==================== 主状态机循环 ====================
    while(1)
    {
        // ISR置位标志后执行对应debug串口命令处理
        if(debug_rx_line_ready())
            debug_check_cmd();

        // 软件看门狗: 每个状态分支前重新使能并复位计时器(活跃阶段均被保护)
        // 注意: 进入 enter_deepsleep_mode() 内部会 swdt_disable() 关闭, 休眠期间不计时
        swdt_enable(SWDT_TIMEOUT_MS);

        vtiming_check_now();   /* timing valve highest priority */
#if LASER_CH4_ENABLED
        laser_schedule_check();  /* 激光甲烷定时采集: 置 g_ch4_request */
        if(g_ch4_request && app_state == STATE_SLEEP)
        {
            g_ch4_request = 0;
            app_state = STATE_CH4;
        }
#endif
        /* 静态测漏任务: 下行已接收并校验通过 → 进入专用状态(采集期间不休眠) */
        if(leak_task_pending() && app_state == STATE_SLEEP)
            app_state = STATE_LEAK;

        /* 30分钟掉线巡检 (主循环每次迭代判一次; 另有 30min RTC 唤醒保证周期) */
		check_4g_connection_supervision();
        switch(app_state)
        {
            case STATE_SLEEP:    do_sleep();    break;
            case STATE_WAKEUP:   do_wakeup();   break;
            case STATE_COLLECT:  do_collect();  break;
            case STATE_UPLOAD:   do_upload();   break;
            case STATE_DOWNLINK: do_downlink(); break;
            case STATE_ALARM:    do_alarm();    break;
            case STATE_BLE_OTA:  do_ble_ota();  break;
            case STATE_LEAK:     leak_task_run(); break;
            case STATE_CH4:
#if LASER_CH4_ENABLED
                do_ch4();
#else
                app_state = STATE_SLEEP;
#endif
                break;
            default:             app_state = STATE_SLEEP; break;
        }
    }
}

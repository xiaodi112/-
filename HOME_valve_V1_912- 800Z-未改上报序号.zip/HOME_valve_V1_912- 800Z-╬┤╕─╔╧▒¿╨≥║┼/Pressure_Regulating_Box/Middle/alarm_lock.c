/**
 * @file alarm_lock.c
 * @brief 告警锁: 等级去重 + 恢复去抖 + EEPROM 持久化
 *
 * 分层: Middle 层纯状态服务, 不含业务判定; 阈值判定/关阀/上报由调用方负责。
 * EEPROM: 0x540 magic(0xCE) + last_r[2] + last_t[2] + volt + CRC8
 *         先写数据+CRC, 最后写 magic (半写时 magic/CRC 不匹配 → 判无效)。
 */

#include "alarm_lock.h"
#include "config_store.h"     /* EE_READ / EE_WRITE / EE_WRITE_BYTE */
#include "eeprom_config.h"    /* g_sensor_count */
#include "tim.h"              /* rtc_get_hhmmss */
#include "usart.h"            /* printf_debug */

#define ALK_CH_NUM   2
#define ALK_BLOCK_LEN  7      /* magic(1) + 状态(5) + crc8(1) */

static uint8_t  s_last_r[ALK_CH_NUM];   /* 最后已上报的压力/温度结果码 */
static uint8_t  s_last_t[ALK_CH_NUM];   /* 最后已上报的温度状态 */
static uint8_t  s_streak[ALK_CH_NUM];   /* 连续全正常次数 */
static uint8_t  s_volt_latched;
static uint8_t  s_volt_streak;
static uint8_t  s_dirty;
static uint32_t s_last_save_sec = 0xFFFFFFFFu;   /* 上次持久化的当日秒 (0xFFFFFFFF=从未) */

/* ==================== 内部辅助 ==================== */

/* CRC8 (多项式 0x07, 与历史记录/测漏区一致) */
static uint8_t alk_crc8(const uint8_t *data, uint16_t len)
{
    uint8_t crc = 0x00;
    uint16_t i;
    uint8_t j;

    for(i = 0; i < len; i++)
    {
        crc ^= data[i];
        for(j = 0; j < 8; j++)
        {
            if(crc & 0x80) crc = (uint8_t)((crc << 1) ^ 0x07);
            else           crc = (uint8_t)(crc << 1);
        }
    }
    return crc;
}

/* 电压类结果码: 不进入通道锁 */
static uint8_t alk_is_volt_code(ThresholdResult_t r)
{
    return (r == THRESHOLD_VPROTECT ||
            r == THRESHOLD_VOLT_HIGH ||
            r == THRESHOLD_VOLT_LOW) ? 1 : 0;
}

/* 读回裁剪: 非法结果码/电压码按"无锁"处理 */
static uint8_t alk_sanitize_r(uint8_t v)
{
    if(v > (uint8_t)THRESHOLD_VOLT_LOW) return (uint8_t)THRESHOLD_OK;
    if(v == (uint8_t)THRESHOLD_VPROTECT ||
       v == (uint8_t)THRESHOLD_VOLT_HIGH ||
       v == (uint8_t)THRESHOLD_VOLT_LOW) return (uint8_t)THRESHOLD_OK;
    return v;
}

static uint8_t alk_sanitize_t(uint8_t v)
{
    return (v > (uint8_t)TEMP_VERY_LOW) ? (uint8_t)TEMP_NORMAL : v;
}

static void alk_ch_force_clear(uint8_t ch)
{
    if(ch >= ALK_CH_NUM) return;

    if(s_last_r[ch] != (uint8_t)THRESHOLD_OK || s_last_t[ch] != (uint8_t)TEMP_NORMAL)
    {
        s_last_r[ch] = (uint8_t)THRESHOLD_OK;
        s_last_t[ch] = (uint8_t)TEMP_NORMAL;
        s_dirty = 1;
    }
    s_streak[ch] = 0;
}

static uint32_t alk_now_sec(void)
{
    uint32_t t = rtc_get_hhmmss();
    return (t / 10000u) * 3600u + ((t / 100u) % 100u) * 60u + (t % 100u);
}

/* ==================== 对外接口 ==================== */

void alarm_lock_init(void)
{
    uint8_t buf[ALK_BLOCK_LEN];
    uint8_t i;

    for(i = 0; i < ALK_CH_NUM; i++)
    {
        s_last_r[i] = (uint8_t)THRESHOLD_OK;
        s_last_t[i] = (uint8_t)TEMP_NORMAL;
        s_streak[i] = 0;
    }
    s_volt_latched = 0;
    s_volt_streak  = 0;
    s_dirty        = 0;
    s_last_save_sec = 0xFFFFFFFFu;

    if(EE_READ(ALARM_LOCK_EEPROM_ADDR, buf, ALK_BLOCK_LEN) == 0 &&
       buf[0] == ALARM_LOCK_EEPROM_MAGIC &&
       buf[ALK_BLOCK_LEN - 1] == alk_crc8(buf, ALK_BLOCK_LEN - 1))
    {
        s_last_r[0] = alk_sanitize_r(buf[1]);
        s_last_r[1] = alk_sanitize_r(buf[2]);
        s_last_t[0] = alk_sanitize_t(buf[3]);
        s_last_t[1] = alk_sanitize_t(buf[4]);
        s_volt_latched = (buf[5] != 0) ? 1 : 0;
        printf_debug("[ALK] restored: r0=%u t0=%u r1=%u t1=%u volt=%u\r\n",
                     (unsigned)s_last_r[0], (unsigned)s_last_t[0],
                     (unsigned)s_last_r[1], (unsigned)s_last_t[1],
                     (unsigned)s_volt_latched);
    }
    else
    {
        printf_debug("[ALK] no valid lock record, defaults\r\n");
    }

    /* 单路机型: 通道1 锁位强制清零, 不得用 raw2 陈旧值参与判定 */
    if(!alarm_lock_ch_enabled(1))
        alk_ch_force_clear(1);
}

void alarm_lock_clear_all(void)
{
    uint8_t i;

    for(i = 0; i < ALK_CH_NUM; i++)
    {
        s_last_r[i] = (uint8_t)THRESHOLD_OK;
        s_last_t[i] = (uint8_t)TEMP_NORMAL;
        s_streak[i] = 0;
    }
    s_volt_latched = 0;
    s_volt_streak  = 0;
    s_dirty        = 1;

    printf_debug("[ALK] cleared all locks (manual valve open)\r\n");
    alarm_lock_save(1);            /* 手动清锁: 立即持久化 */
}

uint8_t alarm_lock_ch_enabled(uint8_t ch)
{
    if(ch == 0) return 1;
    if(ch == 1) return (g_sensor_count >= 2) ? 1 : 0;
    return 0;
}

uint8_t alarm_lock_has_new(uint8_t ch, ThresholdResult_t r, TempStatus_t ts)
{
    if(!alarm_lock_ch_enabled(ch)) return 0;

    /* 压力/温度等级变化 (电压码不进入通道锁) */
    if(r != THRESHOLD_OK && !alk_is_volt_code(r) && (uint8_t)r != s_last_r[ch])
        return 1;

    if(ts != TEMP_NORMAL && (uint8_t)ts != s_last_t[ch])
        return 1;

    return 0;
}

void alarm_lock_latch(uint8_t ch, ThresholdResult_t r, TempStatus_t ts)
{
    if(ch >= ALK_CH_NUM) return;

    if(!alarm_lock_ch_enabled(ch))
    {
        alk_ch_force_clear(ch);
        return;
    }

    if(r != THRESHOLD_OK && !alk_is_volt_code(r) && (uint8_t)r != s_last_r[ch])
    {
        s_last_r[ch] = (uint8_t)r;
        s_dirty = 1;
    }

    if((uint8_t)ts != s_last_t[ch])
    {
        s_last_t[ch] = (uint8_t)ts;
        s_dirty = 1;
    }

    s_streak[ch] = 0;
}

uint8_t alarm_lock_feed_normal(uint8_t ch, uint8_t online,
                               ThresholdResult_t r, TempStatus_t ts)
{
    if(ch >= ALK_CH_NUM) return 0;

    if(!alarm_lock_ch_enabled(ch))
    {
        alk_ch_force_clear(ch);
        return 0;
    }

    /* 离线 / 任一异常 → 计数归零 (电压码视作异常, 不推进通道恢复) */
    if(!online || r != THRESHOLD_OK || ts != TEMP_NORMAL)
    {
        s_streak[ch] = 0;
        return 0;
    }

    /* 没有锁定时无需计数 */
    if(!alarm_lock_ch_latched(ch))
    {
        s_streak[ch] = 0;
        return 0;
    }

    if(s_streak[ch] < ALARM_LOCK_CLEAR_COUNT)
        s_streak[ch]++;

    if(s_streak[ch] >= ALARM_LOCK_CLEAR_COUNT)
    {
        s_last_r[ch] = (uint8_t)THRESHOLD_OK;
        s_last_t[ch] = (uint8_t)TEMP_NORMAL;
        s_streak[ch] = 0;
        s_dirty = 1;
        printf_debug("[ALK] ch%u unlocked after %u normal samples\r\n",
                     (unsigned)ch, (unsigned)ALARM_LOCK_CLEAR_COUNT);
        return 1;
    }

    return 0;
}

uint8_t alarm_lock_volt_has_new(ThresholdResult_t r)
{
    if(!alk_is_volt_code(r)) return 0;
    return s_volt_latched ? 0 : 1;
}

void alarm_lock_volt_latch(void)
{
    s_volt_latched = 1;
    s_volt_streak  = 0;
    s_dirty        = 1;
}

uint8_t alarm_lock_volt_feed_normal(ThresholdResult_t r, uint8_t voltage_checked)
{
    if(!voltage_checked) return 0;          /* 未做电压判定: 不得触碰电压锁 */

    if(alk_is_volt_code(r))
    {
        s_volt_streak = 0;
        return 0;
    }

    if(!s_volt_latched)
    {
        s_volt_streak = 0;
        return 0;
    }

    if(s_volt_streak < ALARM_LOCK_CLEAR_COUNT)
        s_volt_streak++;

    if(s_volt_streak >= ALARM_LOCK_CLEAR_COUNT)
    {
        s_volt_latched = 0;
        s_volt_streak  = 0;
        s_dirty = 1;
        printf_debug("[ALK] voltage lock cleared\r\n");
        return 1;
    }

    return 0;
}

uint8_t alarm_lock_any(void)
{
    return (alarm_lock_ch_latched(0) || alarm_lock_ch_latched(1) ||
            s_volt_latched) ? 1 : 0;
}

uint8_t alarm_lock_ch_latched(uint8_t ch)
{
    if(ch >= ALK_CH_NUM) return 0;
    return (s_last_r[ch] != (uint8_t)THRESHOLD_OK ||
            s_last_t[ch] != (uint8_t)TEMP_NORMAL) ? 1 : 0;
}

void alarm_lock_save(uint8_t force)
{
    uint8_t buf[ALK_BLOCK_LEN];
    uint32_t now, delta;

    if(!s_dirty && !force) return;

    now = alk_now_sec();
    if(!force && s_last_save_sec != 0xFFFFFFFFu)
    {
        delta = (now >= s_last_save_sec) ? (now - s_last_save_sec)
                                         : (86400u - s_last_save_sec + now);
        if(delta < ALARM_LOCK_SAVE_MIN_SEC) return;
    }

    buf[0] = ALARM_LOCK_EEPROM_MAGIC;
    buf[1] = s_last_r[0];
    buf[2] = s_last_r[1];
    buf[3] = s_last_t[0];
    buf[4] = s_last_t[1];
    buf[5] = s_volt_latched ? 1u : 0u;
    buf[6] = alk_crc8(buf, ALK_BLOCK_LEN - 1);

    /* 先写数据+CRC (buf[1..6]), 最后写 magic: 半写时 magic/CRC 不匹配 → 判无效 */
    if(EE_WRITE(ALARM_LOCK_EEPROM_ADDR + 1, &buf[1], ALK_BLOCK_LEN - 1) == 0 &&
       EE_WRITE_BYTE(ALARM_LOCK_EEPROM_ADDR, buf[0]) == 0)
    {
        s_dirty = 0;
        s_last_save_sec = now;
        printf_debug("[ALK] saved: r0=%u t0=%u r1=%u t1=%u volt=%u\r\n",
                     (unsigned)s_last_r[0], (unsigned)s_last_t[0],
                     (unsigned)s_last_r[1], (unsigned)s_last_t[1],
                     (unsigned)s_volt_latched);
    }
    else
    {
        printf_debug("[ALK] save FAILED (keep dirty)\r\n");
    }
}

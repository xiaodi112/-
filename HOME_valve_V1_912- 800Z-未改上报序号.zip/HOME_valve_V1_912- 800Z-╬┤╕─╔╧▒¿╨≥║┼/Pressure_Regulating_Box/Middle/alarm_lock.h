#ifndef ALARM_LOCK_H
#define ALARM_LOCK_H

#include <stdint.h>
#include "threshold.h"

/**
 * @file alarm_lock.h
 * @brief 告警锁: 按"等级"去重 + 恢复去抖 (实时/周期/查询三条路径共用)
 *
 * 语义:
 *   每个通道记录"最后一次已上报的等级"(结果码 + 温度状态)。
 *   本次等级与最后等级不同 → 新告警(升级/降级都报); 相同 → 不报。
 *   恢复到正常不属于"新等级", 由恢复流程处理:
 *     在线 && r==OK && temp==NORMAL 连续 ALARM_LOCK_CLEAR_COUNT 次
 *     → 清空该通道最后等级并返回 1 (调用方报一次恢复)。
 *   离线/异常任意一次 → 该通道计数归零; 单次正常不会清锁。
 *
 * 电压: 电压码(VPROTECT/VOLT_HIGH/VOLT_LOW)不进入通道锁, 使用独立 1 bit 锁;
 *       只有真正做了电压判定的路径(voltage_checked=1)才能置位/推进清除。
 *
 * 持久化: EEPROM 0x540 (magic 0xCE + 5B 状态 + CRC8), 5 分钟写入节流,
 *         dirty 标志 + 调用方在正常采样时 flush; 手动开阀清锁立即写。
 * 地址选择: 配置区 0x000~0x7FF 中, 0x500~0x504 为上报防重锁, 0x560/0x580 为校零双槽;
 *           0x540 为 32 字节页对齐且 0x540~0x546 落在同一物理页。
 */

#define ALARM_LOCK_EEPROM_ADDR   0x540   /* 32 字节页对齐: 7 字节落在同一物理页 */
#define ALARM_LOCK_EEPROM_MAGIC  0xCE
#define ALARM_LOCK_CLEAR_COUNT   3       /* 连续全正常次数 → 解锁 */
#define ALARM_LOCK_SAVE_MIN_SEC  300u    /* 持久化最小间隔(秒) */

/* 上电初始化: 读回 EEPROM 锁 (必须在 config_load_all + rtc_init_all 之后调用) */
void    alarm_lock_init(void);

/* 清空全部锁(通道+电压)并立即持久化 (仅用户手动开阀调用) */
void    alarm_lock_clear_all(void);

/* 通道是否参与判定: 通道0 恒 1; 通道1 仅在 g_sensor_count>=2 时启用 */
uint8_t alarm_lock_ch_enabled(uint8_t ch);

/* 本次等级是否为新告警 (r 为电压码时不计入通道) */
uint8_t alarm_lock_has_new(uint8_t ch, ThresholdResult_t r, TempStatus_t ts);

/* 记录本次已上报等级 (确认报警后调用) */
void    alarm_lock_latch(uint8_t ch, ThresholdResult_t r, TempStatus_t ts);

/* 推进"连续全正常"计数; 达到 ALARM_LOCK_CLEAR_COUNT 时清锁并返回 1 */
uint8_t alarm_lock_feed_normal(uint8_t ch, uint8_t online,
                               ThresholdResult_t r, TempStatus_t ts);

/* 电压锁 (独立, 不进入通道锁) */
uint8_t alarm_lock_volt_has_new(ThresholdResult_t r);
void    alarm_lock_volt_latch(void);
/* voltage_checked=0 时不触碰电压锁; 返回 1=电压告警解除 */
uint8_t alarm_lock_volt_feed_normal(ThresholdResult_t r, uint8_t voltage_checked);

/* 查询 */
uint8_t alarm_lock_any(void);
uint8_t alarm_lock_ch_latched(uint8_t ch);

/* 持久化: force=1 立即写; force=0 时仅 dirty 且距上次 >=5 分钟才写 */
void    alarm_lock_save(uint8_t force);

#endif /* ALARM_LOCK_H */

#ifndef MAIN_H
#define MAIN_H

#include "stdint.h"
#include "PT_304_35.h"
#include "ota_info.h"
#include "threshold.h"

#define APP_FW_VERSION_NUM     1

/* ==================== State Machine ==================== */
typedef enum {
    STATE_INIT = 0,
    STATE_SLEEP,
    STATE_WAKEUP,
    STATE_COLLECT,
    STATE_UPLOAD,
    STATE_DOWNLINK,
    STATE_ALARM,
    STATE_BLE_OTA,
    STATE_CH4,
    STATE_LEAK          /* 静态测漏任务: 采集→分包上报→清除 (独立链路) */
} AppState_t;

extern AppState_t app_state;

/* CH4 request flag (set by downlink gas_get, checked by do_downlink) */
extern volatile uint8_t g_ch4_request;
typedef struct {
    PT304D_Data raw;
    PT304D_Data raw2;
    float       voltage;
    float       last_pressure_collect;
    float       last_pressure_realtime;
    float       last_pressure_collect2;
    float       last_pressure_realtime2;
    float       last_normal_voltage;
    uint8_t     prev_online;
    uint8_t     offline_cnt;
    uint8_t     online_cnt;
    uint8_t     prev_online2;
    uint8_t     offline_cnt2;
    uint8_t     online_cnt2;
} SensorContext_t;

extern SensorContext_t g_sensor;
extern uint8_t g_lcd_active;   // LCD当前是否显示 (运行状态, 区别于配置项; main.c 维护)

// 供其他模块使用 (main.c 实现, downlink.c 等模块调用)
void lcd_shutdown(void);
/* 安装事件一次性上报: 传感器记录 + product-status=1 (未安装→已安装瞬间调用) */
void install_event_report(void);

const char* alarm_try_close_valve_all(const char *policy_str, ThresholdResult_t result);

const char* alarm_try_close_valve(ThresholdResult_t result);
const char* alarm_try_close_valve2(ThresholdResult_t result);   /* 出气端 (abnormal2_close) */
const char* ch4_alarm_try_close_valve(void);

/* ==================== 告警锁 / 统一确认与上报 ====================
 * 三条路径(实时/周期/查询)共用: 等级变化才报, 恢复需连续 3 次全正常。 */
#define ALARM_MASK_CH0   0x01u   /* 通道0 */
#define ALARM_MASK_CH1   0x02u   /* 通道1 */
#define ALARM_MASK_VOLT  0x04u   /* 电压锁 */

typedef struct {
    ThresholdResult_t r1;      /* 进入确认时的通道0结果 */
    ThresholdResult_t r2;      /* 进入确认时的通道1结果 */
    uint8_t ch1_ok;            /* 通道0在线快照 */
    uint8_t ch2_ok;            /* 通道1在线快照 */
    float   base1;             /* 重采期间固定的通道0压力基线 */
    float   base2;             /* 重采期间固定的通道1压力基线 */
    uint8_t check_voltage;     /* 重采时是否做电压判定 (1=采样并判电压) */
    uint8_t ensure_init;       /* 1=确认后升级为完整初始化(实时最小唤醒路径) */
    uint8_t bring_up_4g;       /* 1=上报前按需初始化LPUART并冷启动4G(实时/周期路径)
                                * 0=仅校验连接(查询路径: 指令刚从MQTT下来) */
} AlarmConfirmCtx_t;

/* 计算新告警掩码 (bit0=通道0, bit1=通道1, bit2=电压) */
uint8_t alarm_new_mask(ThresholdResult_t r1, ThresholdResult_t r2, uint8_t check_voltage);

/* 3 次重采确认 → 记录最后等级 → 按策略关阀 → 报警上报
 * 返回 1=确认异常并已上报, 0=偶发恢复 */
uint8_t alarm_confirm_and_report(const AlarmConfirmCtx_t *ctx, uint8_t mask,
                                 float last_p1, float last_p2);

/* 最近一次报警报文是否仍挂起 (1=4G 不可用, 下个周期补发; 0=已送达) */
uint8_t alarm_report_pending(void);

void upload_schedule_reset(void);   /* 上报周期/后延配置变更后调用, 重置延迟上报锁存 */

/* 定时开关阀检查: 最高优先级, 立刻执行到期的定时开关阀事件
 * 静态测漏任务运行期间也需周期调用, 否则 RTC ISR 置位的 g_timing_pending
 * 不清零会导致所有 AT 指令返回 EC_PREEMPT (4G 通信失效) */
void vtiming_check_now(void);

#endif

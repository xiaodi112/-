./objects/lcd_ui.o: ..\..\..\App\lcd_ui.c ..\..\..\Middle\app_config.h

# 任务提示词：保证 30 分钟一次 4G 掉线巡检（HOME_valve_V1_912，不改动现有采集/上报/阀门/LED 行为）

> 适用工程：`HOME_valve_V1_912`（GD32L233RCT6 + Keil MDK）
> 参考代码位置为当前工作区实测，行号会随改动漂移，以函数名为准。

---

## 0. 角色与约束

你是资深嵌入式工程师，在本工程上工作。遵守现有分层：

- 应用层：`Pressure_Regulating_Box/Projects/Wakeup_box_V0.0.1/main.c`
- 中间层：`Pressure_Regulating_Box/Middle/`
- 驱动/BSP：`Pressure_Regulating_Box/Drivers/`、`Pressure_Regulating_Box/BSP/`、`Pressure_Regulating_Box/App/`

硬性要求：

- 先读代码再动手；跟随现有命名/风格；**不使用动态内存**；**ISR 只置标志**；
- **不改协议字段/反馈码**；**不改 `enter_deepsleep_mode()` / `BSP/wakeup.c` 的唤醒源配置**；**不新增硬件定时器**；
- 改完必须全量编译 0 Error / 0 Warning（命令见第 6 节）。

---

## 1. 现状（先确认）

1. 间隔宏：`FOURG_SUPERVISE_INTERVAL_MIN = 30`（`Middle/app_config.h:57`）。
2. 巡检函数：`check_4g_connection_supervision()`（约 main.c:3833），外层目前是
   `#if 1 /* 30分钟巡检临时屏蔽 (待现场验证后恢复) */` —— **代码是启用的，注释过期**。
3. **唯一调用点是"主循环每次迭代"**（约 main.c:4238，`switch(app_state)` 之前），注释还写着过期的 `#if 0`。
4. 主循环只在下列唤醒后迭代一次：
   - RTC 采集点 / 上报点 / 后延点（采集周期决定，常态下可能是几小时才一次）；
   - 平台下发（RI/LPUART）、按键、定时开关阀秒级闹钟、LED 提示截止闹钟（`LED_NOTICE_MS=5000`）。
5. **实时模式的 tick 循环在 `do_sleep()` 内部**（约 main.c:1947 的 `while(real_mode_active() && ...)` → `do_realtime_check()` 约 2028），每拍结束 `realtime_enter_sleep()`（约 1442）直接再睡，**不回主循环** → 不触发巡检。
6. 结论：现在的"30 分钟"只是**最小间隔**，不是定时器；平台无交互时实际可能要几小时才巡检一次。
7. 巡检失败语义（保持不变）：`EC801E_EnsureConnected()` 失败 → `EC801E_PowerOff()` + `fourG_init_failed = 1`，此后巡检早退，等下次上报冷启动恢复。
8. 本板其它相关开关：`LCD_ENABLED=0`、`LCD_LOCK_ENABLED=0`、`CALIB_MODE_ENABLED=0`、`LASER_CH4_ENABLED=0`、`BLE_ENABLED=0`；`APP_DEFAULT_REAL_ENABLED=1`（默认启用秒级实时采集）。

---

## 2. 目标

在不改变现有采集/上报网格、阀定时、LED 提示、VLP 省电策略的前提下：

- **"应保持在线"场景下，保证每 ≤30 分钟执行一次 4G/MQTT 巡检**；
- 实时模式（秒级 tick）与非实时模式都要覆盖；
- 巡检行为本身保持现状（先 `QMTCONN?` → 必要时整模块重启重连并重订阅；失败断电置标志；成功 `EC801E_SetPSM(1)`）。

"应保持在线"的判定沿用现有代码：

```
long 模式 && (窗口内 || end_result==1)
&& !voltage_low_power && !fourG_user_off && !fourG_init_failed && !fourG_weak_signal
```

---

## 3. 实现方案（两条腿 + 一处让位）

### 3.1 抽出巡检适用条件与剩余时间（放在文件作用域）

`voltage_low_power`（约 main.c:107）、`fourG_user_off`（108）、`fourG_init_failed`（109，static）、`fourG_weak_signal`（110，static）定义之后、`sched_set_next_collect_alarm()`（约 main.c:185）之前，新增：

```c
static uint16_t s_last_supervise_min = 0xFFFFu;   /* 上次巡检的"当日分钟" (从原函数内 static 移出) */

/* 是否处于"应保持在线"场景 (与 do_sleep / realtime_enter_sleep 的 4G 保持条件一致) */
static uint8_t supervise_is_applicable(void)
{
    if(voltage_low_power || fourG_user_off || fourG_init_failed || fourG_weak_signal)
        return 0u;
    if(strcmp(g_window.pattern, "long") != 0)
        return 0u;
    return (config_is_active_window() || g_window.end_result == 1) ? 1u : 0u;
}

/* 当日分钟 (0~1439), 与巡检节流口径一致 */
static uint16_t supervise_now_min(void)
{
    uint32_t hhmmss = rtc_get_hhmmss();
    return (uint16_t)((hhmmss / 10000u) * 60u + ((hhmmss / 100u) % 100u));
}

/* 距下次巡检还剩多少分钟 (0=已到期); 0xFFFFFFFF=当前不需要巡检 */
static uint32_t supervise_wait_min(void)
{
    uint16_t now_min, elapsed;
    if(!supervise_is_applicable())               return 0xFFFFFFFFu;
    if(s_last_supervise_min == 0xFFFFu)          return 0u;   /* 无基准: 尽快建立 */
    now_min = supervise_now_min();
    elapsed = (uint16_t)(now_min - s_last_supervise_min);
    if(elapsed >= FOURG_SUPERVISE_INTERVAL_MIN)  return 0u;
    return (uint32_t)(FOURG_SUPERVISE_INTERVAL_MIN - elapsed);
}
```

同时在文件靠前的函数声明区补一句前置声明（实时路径要用，函数本体在 3833）：

```c
static void check_4g_connection_supervision(void);
```

### 3.2 非实时模式：用 RTC 闹钟保证 ≤30 分钟醒一次

在 `sched_set_next_collect_alarm()`（约 main.c:185）里，`wait_min` 做完 1440 上限之后追加：

```c
    /* 30分钟巡检: 若巡检比采集/上报更早到期, 把本次睡眠缩短到巡检时刻 */
    {
        uint32_t sv_wait = supervise_wait_min();
        if(sv_wait < wait_min) wait_min = sv_wait;
    }
    if(wait_min == 0u) wait_min = 1u;     /* 已到期: 1 分钟后醒, 避免 0 分钟闹钟 */
```

- 这类唤醒不是采集点：`do_wakeup()` 会走"not collect due, back to sleep"（约 main.c:2622-2634），不会触发采集/上报；
- 主循环会在 `switch` 之前先执行巡检，然后回睡并重新布闹钟。

### 3.3 阀门秒级闹钟让位

`do_sleep()` 阀门定时分支（约 main.c:1751-1785）：

```c
uint32_t collect_sec = (uint32_t)sched_collect_min() * 60;
if(valve_wait_sec < collect_sec && valve_wait_sec < 0xFFFFFFFF)
    → rtc_set_alarm_at_hhmmss(阀门事件时刻); g_timing_alarm_set = 1; use_valve_alarm = 1;
```

改为：**只有阀门事件比巡检更早时才使用秒级闹钟**，否则走 `sched_set_next_collect_alarm()`：

```c
uint32_t sv_wait = supervise_wait_min();
uint32_t sv_sec  = (sv_wait == 0xFFFFFFFFu) ? 0xFFFFFFFFu : sv_wait * 60u;
if(valve_wait_sec < collect_sec && valve_wait_sec < sv_sec && valve_wait_sec < 0xFFFFFFFF)
    { ...原逻辑不变... }
```

> 阀门事件不会丢：下一次唤醒（巡检/采集）重新计算闹钟时，阀门事件已成为"最近事件"，到点仍会执行；采集点也一定会执行 `vtiming_check_now()`。

**不需要改动**的分支（说明理由即可，避免误改）：

- `LED 提示截止闹钟`（约 main.c:1817-1840）：`LED_NOTICE_MS = 5000`（5 秒），恒小于 30 分钟；即使被巡检闹钟挤后，下一次 `do_sleep` 计算时 `led_notice_left <= 0` 会立即 `led_notice_end()` 熄灭，自愈。
- `LCD 超时短睡`（约 main.c:1700）与 `CALIB LCD`（约 main.c:1796）：`LCD_ENABLED=0`、`CALIB_MODE_ENABLED=0`，当前不编译；若将来打开，按 3.3 同样让位。

### 3.4 实时模式：在 tick 里调用巡检

`do_realtime_check()`（约 main.c:1478）在 `swdt_enable()` 之后、采集之前加：

```c
    /* 30分钟掉线巡检: 实时模式 tick 在 do_sleep 内部循环, 不回主循环 → 在这里补一次。
     * 函数内部按 30 分钟节流, 未到期只做几次比较。 */
    check_4g_connection_supervision();
```

> 顺序务必在采集之前：巡检内部 `gpio_init()` 会把传感器电源脚拉低，紧随其后的 `PT304D_CollectAll()` 会重新上电；反过来会导致本次采集读不到数据。

### 3.5 巡检函数本身（只整理，不改行为）

`check_4g_connection_supervision()`（约 main.c:3833）：

- 删除函数内的 `static uint16_t s_last_supervise_min`，改用 3.1 的文件作用域变量；
- 适用条件改调 `supervise_is_applicable()`，时间改调 `supervise_now_min()`；
- 其余逻辑**原样保留**：`com_lpuart_init(); gpio_init();` → `EC801E_EnsureConnected()` → 失败 `EC801E_PowerOff(); fourG_init_failed = 1;` / 成功 `EC801E_SetPSM(1);`
- 去掉外层 `#if 1 /* 30分钟巡检临时屏蔽 */`（或把注释改为"已启用"），并修正主循环调用点（约 main.c:4237）的过期 `#if 0` 注释。

---

## 4. 必须避开的坑（逐条自检）

1. **只提前唤醒，不改判定**：30 分钟唤醒点不是采集点，必须走"非到期 → 回睡"，不得采集/上报。
2. **不适用状态不得额外唤醒**：VLP / 用户关 4G / `init_failed` / 弱信号 / short·dot 模式下 `supervise_wait_min()` 返回 0xFFFFFFFF，闹钟逻辑保持原样。
3. **节流必须在函数内部**：实时模式每秒调用，只有跨过 30 分钟的那一次才真正发 AT。
4. **不要改 `rtc_set_next_alarm_sec_quiet()` / `rtc_set_next_alarm_sec()` 的秒级实时闹钟**（约 1448/1791）：实时节拍不受影响。
5. **不要改 `fourG_init_failed` 后的策略**：失败断电、停止巡检、等下次上报冷启动（省电优先）。
6. **测漏任务（STATE_LEAK）期间不巡检**：任务内部自循环，本次不处理，写进交付说明。
7. 巡检重连会阻塞（整模块 `PowerOff→PowerOn→入网→MQTT→重订阅`，约 20s），期间不采集，属可接受代价。
8. 跨午夜：`(uint16_t)(now_min - last)` 会在 00:00 触发一次额外巡检，无害，不要"优化"掉。
9. 本板是**单路传感器**配置（`APP_DEFAULT_SENSOR_COUNT=1`），巡检与本功能无关，不要顺手改动采集逻辑。

---

## 5. 验收测试

| # | 操作 | 期望 |
|---|---|---|
| 1 | 长连接 + `end_result=1`，实时模式关闭，静置 2 小时 | 日志每 **30±1 分钟**出现 `[SM] RTC collect alarm: in 30min` 与 `[SM] 4G supervision: checking MQTT connection...`；采集/上报时刻与内容不变 |
| 2 | 同上，实时模式开启 | 巡检仍为 30 分钟一次；秒级采集节拍与上报不变 |
| 3 | short / dot 模式 | 不出现 30 分钟唤醒（闹钟仍按采集点） |
| 4 | 触发 VLP / 手动关 4G / 弱信号 | 巡检停止、唤醒不布防（与改前一致） |
| 5 | 模拟掉线（拔天线 / 关闭基站 / `AT+CFUN=4` 类操作） | **≤30 分钟**内自动重连；日志出现 `4G supervision`；重连后下发可正常接收 |
| 6 | 配置了定时开关阀且事件在 40 分钟后 | 先按 30 分钟巡检醒一次，阀门事件到点仍被正确执行（不丢） |
| 7 | 按键触发三灯提示（`LED_NOTICE_MS=5000`） | 5 秒后准时熄灭，不受巡检闹钟影响 |
| 8 | 巡检重连持续失败（无信号） | 断电 + `fourG_init_failed`；之后不巡检；下次上报冷启动恢复 |

---

## 6. 构建

```bat
cd Pressure_Regulating_Box\Projects\Wakeup_box_V0.0.1\MDK-ARM
"D:\keil\core\UV4\UV4.exe" -r GD32L233R_EVAL.uvprojx -j0 -o build_supervise30.log
```

期望：`0 Error(s), 0 Warning(s)`。**必须查看日志内容**，不能只看退出码。

---

## 7. 交付

1. 修改后的源码；
2. 说明：两条保证路径（RTC 闹钟 / 实时 tick）、适用条件、失败语义、日志关键字；
3. 明确列出未覆盖/已知限制：
   - 每 30 分钟多一次唤醒 + 一次 `AT+QMTCONN?`（约 1~3 s）的功耗代价；
   - 测漏任务运行期间不巡检；
   - 巡检重连失败后按原设计停止巡检，等下一次上报（采集周期决定等待时长）。

#include "adc_bat.h"

/* ADC分辨率 */
#define ADC_RESOLUTION         4095.0f

/* VREFINT典型值 */
#define ADC_VREFINT            1.20f

/* R3=2M, R5=2M */
#define DIVIDER_RATIO          2.0f

/* PC3: 电压采集使能脚 */
#define ADC_REF_PORT           GPIOC
#define ADC_REF_PIN            GPIO_PIN_3

/* PC2: AD_BAT, ADC_CHANNEL_12 */
#define ADC_BAT_PORT           GPIOC
#define ADC_BAT_PIN            GPIO_PIN_2
#define ADC_BAT_CHANNEL        ADC_CHANNEL_12

/* 内部参考电压 VREFINT, ADC_CHANNEL_17 */
#define ADC_VREFINT_CHANNEL    ADC_CHANNEL_17

/* ADC超时 */
#define ADC_TIMEOUT            100000U

/* 平均采样次数 */
#define ADC_SAMPLE_COUNT       4U


/* PC3配置为推挽输出并拉低，接通电池分压 */
static void adc_bat_ref_low(void)
{
    rcu_periph_clock_enable(RCU_GPIOC);

    gpio_mode_set(ADC_REF_PORT,
                  GPIO_MODE_OUTPUT,
                  GPIO_PUPD_NONE,
                  ADC_REF_PIN);

    gpio_output_options_set(ADC_REF_PORT,
                            GPIO_OTYPE_PP,
                            GPIO_OSPEED_2MHZ,
                            ADC_REF_PIN);

    gpio_bit_reset(ADC_REF_PORT, ADC_REF_PIN);
}


/* 采样结束后PC3设置为Analog，关闭分压通路 */
static void adc_bat_ref_disable(void)
{
    gpio_mode_set(ADC_REF_PORT,
                  GPIO_MODE_ANALOG,
                  GPIO_PUPD_NONE,
                  ADC_REF_PIN);
}


/* ADC单次采样 */
static int adc_bat_single_read(uint32_t channel, uint16_t *value)
{
    uint32_t timeout = 0;

    adc_routine_channel_config(0,
                               channel,
                               ADC_SAMPLETIME_239POINT5);

    adc_flag_clear(ADC_FLAG_EOC);

    adc_software_trigger_enable(ADC_ROUTINE_CHANNEL);

    while (!adc_flag_get(ADC_FLAG_EOC))
    {
        if (++timeout > ADC_TIMEOUT)
        {
            return -1;
        }
    }

    *value = adc_routine_data_read();

    adc_flag_clear(ADC_FLAG_EOC);

    return 0;
}


/* ADC多次采样平均 */
static int adc_bat_average_read(uint32_t channel, uint16_t *value)
{
    uint32_t sum = 0;
    uint16_t adc_value;
    uint8_t i;

    for (i = 0; i < ADC_SAMPLE_COUNT; i++)
    {
        if (adc_bat_single_read(channel, &adc_value) != 0)
        {
            return -1;
        }

        sum += adc_value;
    }

    *value = (uint16_t)(sum / ADC_SAMPLE_COUNT);

    return 0;
}


void adc_bat_init(void)
{
    /* 使能时钟 */
    rcu_periph_clock_enable(RCU_GPIOC);
    rcu_periph_clock_enable(RCU_ADC);

    /* 采集前拉低PC3 */
    adc_bat_ref_low();

    /* PC2配置为模拟输入 */
    gpio_mode_set(GPIOC,
                  GPIO_MODE_ANALOG,
                  GPIO_PUPD_NONE,
                  ADC_BAT_PIN);

    /* ADC时钟 = APB2/6 */
    rcu_adc_clock_config(RCU_ADCCK_APB2_DIV6);

    /* ADC复位 */
    adc_deinit();

    adc_special_function_config(ADC_CONTINUOUS_MODE, DISABLE);
    adc_special_function_config(ADC_SCAN_MODE, DISABLE);
    adc_data_alignment_config(ADC_DATAALIGN_RIGHT);

    /* 单通道 */
    adc_channel_length_config(ADC_ROUTINE_CHANNEL, 1);

    /* 默认配置AD_BAT */
    adc_routine_channel_config(0,
                               ADC_BAT_CHANNEL,
                               ADC_SAMPLETIME_239POINT5);

    /* 开启内部VREFINT */
    adc_channel_16_to_19(ADC_INTERNAL_CHANNEL_SWITCH, ENABLE);

    /* 软件触发 */
    adc_external_trigger_source_config(ADC_ROUTINE_CHANNEL,
                                        ADC_EXTTRIG_ROUTINE_NONE);

    adc_external_trigger_config(ADC_ROUTINE_CHANNEL, ENABLE);

    /* 使能ADC + 校准 */
    adc_enable();
    adc_calibration_enable();
}


float adc_bat_read_voltage(void)
{
    uint16_t adc_bat;
    uint16_t adc_vrefint;
    float v_bat;

    /* 接通电池分压 */
    adc_bat_ref_low();

    /* 读取AD_BAT */
    if (adc_bat_average_read(ADC_BAT_CHANNEL, &adc_bat) != 0)
    {
        adc_bat_ref_disable();
        return -1.0f;
    }

    /* 读取内部VREFINT */
    if (adc_bat_average_read(ADC_VREFINT_CHANNEL, &adc_vrefint) != 0)
    {
        adc_bat_ref_disable();
        return -1.0f;
    }

    if (adc_vrefint == 0)
    {
        adc_bat_ref_disable();
        return -1.0f;
    }

    /*
     * V_BAT =
     * ADC_BAT / ADC_VREFINT × VREFINT × 2
     */
    v_bat = ((float)adc_bat / (float)adc_vrefint)
            * ADC_VREFINT
            * DIVIDER_RATIO;

    /* 关闭分压 */
    adc_bat_ref_disable();

    return v_bat;
}
#include "power.h"

void power_gpio_init(void)
{
    rcu_periph_clock_enable(RCU_GPIOA);
    rcu_periph_clock_enable(RCU_GPIOB);
    rcu_periph_clock_enable(RCU_GPIOC);

    /* PA0 (4G_DTR): 默认 HIGH (允许模块进入轻休眠) */
    gpio_mode_set(PWR_4G_DTR_PORT, GPIO_MODE_OUTPUT, GPIO_PUPD_NONE, PWR_4G_DTR_PIN);
    gpio_output_options_set(PWR_4G_DTR_PORT, GPIO_OTYPE_PP, GPIO_OSPEED_2MHZ, PWR_4G_DTR_PIN);
    gpio_bit_set(PWR_4G_DTR_PORT, PWR_4G_DTR_PIN);

    /* PC0 (V4G_EN)*/
    gpio_mode_set(PWR_4G_PORT, GPIO_MODE_OUTPUT, GPIO_PUPD_NONE, PWR_4G_PIN);
    gpio_output_options_set(PWR_4G_PORT, GPIO_OTYPE_PP, GPIO_OSPEED_2MHZ, PWR_4G_PIN);

    /* PC1 (4G_PWRKEY): 高阻释放态(输入). NPN 低侧开关, 脉冲期间由 EC 驱动
     * 临时切换为推挽输出并拉高, 脉冲结束后回到此状态 */
    gpio_mode_set(PWR_4G_KEY_PORT, GPIO_MODE_INPUT, GPIO_PUPD_NONE, PWR_4G_KEY_PIN);

    /* PC12 (SW_BT): 默认 LOW (蓝牙默认断电) */
    gpio_mode_set(PWR_BLE_PORT, GPIO_MODE_OUTPUT, GPIO_PUPD_NONE, PWR_BLE_PIN);
    gpio_output_options_set(PWR_BLE_PORT, GPIO_OTYPE_PP, GPIO_OSPEED_2MHZ, PWR_BLE_PIN);

    /* PC13 (SW_Sensor/CH4_PWR): 默认 LOW */
    gpio_mode_set(PWR_CH4_PORT, GPIO_MODE_OUTPUT, GPIO_PUPD_NONE, PWR_CH4_PIN);
    gpio_output_options_set(PWR_CH4_PORT, GPIO_OTYPE_PP, GPIO_OSPEED_2MHZ, PWR_CH4_PIN);
}

/* 4G 电源使能: 1=PC0 推挽输出高(使能供电); 0=PC0 推挽输出低(关断) */
void power_4g_set(uint8_t on)
{
    gpio_mode_set(PWR_4G_PORT, GPIO_MODE_OUTPUT, GPIO_PUPD_NONE, PWR_4G_PIN);
    gpio_output_options_set(PWR_4G_PORT, GPIO_OTYPE_PP, GPIO_OSPEED_2MHZ, PWR_4G_PIN);
    if(on) gpio_bit_set(PWR_4G_PORT, PWR_4G_PIN);
    else   gpio_bit_reset(PWR_4G_PORT, PWR_4G_PIN);
}

uint8_t power_4g_is_on(void)
{
    return (gpio_input_bit_get(PWR_4G_PORT, PWR_4G_PIN) == SET) ? 1 : 0;
}

#if BLE_ENABLED
void power_ble_set(uint8_t on)
{
    if(on) gpio_bit_set(PWR_BLE_PORT, PWR_BLE_PIN);
    else   gpio_bit_reset(PWR_BLE_PORT, PWR_BLE_PIN);
}
#endif /* BLE_ENABLED */

void power_4g_dtr_set(uint8_t level)
{
    if(level) gpio_bit_set(PWR_4G_DTR_PORT, PWR_4G_DTR_PIN);
    else      gpio_bit_reset(PWR_4G_DTR_PORT, PWR_4G_DTR_PIN);
}

void power_ch4_set(uint8_t on)
{
    if(on) gpio_bit_set(PWR_CH4_PORT, PWR_CH4_PIN);
    else  gpio_bit_reset(PWR_CH4_PORT, PWR_CH4_PIN);
}

uint8_t power_ch4_is_on(void)
{
    return (gpio_input_bit_get(PWR_CH4_PORT, PWR_CH4_PIN) == SET) ? 1 : 0;
}

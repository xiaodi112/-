# YL 压力调节箱 MQTT 通信协议规范

> **文档版本**：V1.0
> **固件版本**：`APP_FIRMWARE_VERSION "1"` / `APP_FW_VERSION_NUM 1`
> **适用设备**：家用阀门物联网控制器（GD32L233RC + EC801E LTE Cat.1）
> **日期**：2026-10-15
> **依据**：
> 1. `指令集.xlsx`（功能 / 指令 / 备注，共 31 条指令）
> 2. 本工程固件源码（每条规范均标注 `文件:行号` 出处）
>
> **约定**：本文中「必须」= 平台/设备不做即不工作；「应」= 推荐且固件已按此实现；「可」= 可选。
> 凡与 `指令集.xlsx` 表述不一致处，一律以固件实测行为为准，差异集中列于第 14 章。

---

## 目录

1. [范围与对象](#1-范围与对象)
2. [系统模型](#2-系统模型)
3. [传输层规范](#3-传输层规范)
4. [主题（Topic）规范](#4-主题topic规范)
5. [报文编码规范](#5-报文编码规范)
6. [下行指令报文](#6-下行指令报文)
7. [上行报文](#7-上行报文)
8. [指令字典](#8-指令字典)
9. [数据字典](#9-数据字典)
10. [反馈码字典](#10-反馈码字典)
11. [OTA 升级协议](#11-ota-升级协议)
12. [报警与自动关阀](#12-报警与自动关阀)
13. [设备运行行为](#13-设备运行行为)
14. [与《指令集.xlsx》的差异说明](#14-与指令集xlsx的差异说明)
15. [附录](#15-附录)

---

## 1. 范围与对象

本规范定义 YL 压力调节箱（以下简称「设备」）与物联网平台（以下简称「平台」）之间基于 MQTT 的全部通信行为，包括：

- 传输层参数（MQTT 版本、QoS、Retain、心跳、主题）；
- 上行报文（设备 → 平台）：周期数据、报警、恢复、状态、查询应答、指令反馈、升级回执；
- 下行报文（平台 → 设备）：配置类、查询类、控制类、维护类指令；
- 指令字典（62 个 `commandStr`，覆盖 `指令集.xlsx` 全部 31 条功能）；
- 数据字典（全部上行字段、枚举取值、单位、量程）；
- 反馈码字典、OTA 独立协议、运行行为（状态机 / 唤醒源 / 上报调度 / 低电压保护）。

**不适用范围**：BLE 蓝牙 OTA 私有帧协议（见 `Docs/BLE_OTA_Upgrade_Solution.md`）、调试串口配置命令（见 15.1 附录，仅工程调试用）。

---

## 2. 系统模型

```
        ┌──────────────┐   MQTT/TCP    ┌──────────────────────────┐
        │  主平台       │◄─────────────►│                          │
        │ id=0         │  /property/   │   EC801E (LTE Cat.1)     │
        │ (FastBee)    │   post        │   MQTT 3.1.1 / QoS0      │
        └──────────────┘   /function/  │                          │
                           get         │           ▲ AT 115200     │
        ┌──────────────┐   /upgrade/   │           │ LPUART0       │
        │  用户平台     │◄──set         │   ┌───────┴──────────┐    │
        │ id=1         │              │   │  GD32L233RC      │    │
        │ (单向上报)    │◄─────────────│   │  状态机 + EEPROM  │    │
        └──────────────┘  /property/  │   └───────┬──────────┘    │
                           post        │           │               │
        ┌──────────────┐              │    PT304D ×1/2 (压力/温度) │
        │  OTA 服务器   │◄──HTTP GET───│    ADC 电池电压            │
        │ (HTTP)       │              │    DRV8837 阀门电机         │
        └──────────────┘              │    SLCD 段码液晶           │
                                      └──────────────────────────┘
```

**双通道模型**（`ec800e.c:775-852`、`ec800e.c:1444-1512`）：

| 通道 | MQTT client idx | 配置变量 | 方向 | 心跳 | 接收方式 |
|------|-----------------|----------|------|------|----------|
| 主平台 | `0` | `g_mqtt` | 双向 | 默认 300 s（可配，下限 30 s） | 缓冲模式，MCU 主动 `AT+QMTRECV` 轮询 |
| 用户平台 | `1` | `g_user_mqtt` | **仅上行** | 固定 600 s | URC 模式，不订阅（`ec800e.c:1470`） |

> 用户平台无下行能力：固件不为其订阅任何主题，平台无法通过该通道下发指令。

---

## 3. 传输层规范

### 3.1 硬件与串口

| 项目 | 参数 | 依据 |
|------|------|------|
| 主控 | GD32L233RC（Cortex-M23，256 KB Flash / 32 KB SRAM） | `Docs/PROJECT_SPECIFICATION.md` |
| 通信模组 | EC801E LTE Cat.1 | `ec800e.c:2-3` |
| AT 串口 | LPUART0，PD8(TX)/PD9(RX)，115200 8N1，DMA + IDLE 中断 | `usart.c:310-336` |
| 调试串口 | USART0，PC4/PC5，115200 8N1 | `usart.c:11,202-203` |
| 4G 供电控制 | PC0 (V4G_EN) 高有效；PA0 = DTR（低=唤醒） | `main.c:1596-1618` |
| 4G 唤醒冗余 | LPUART 唤醒中断 + RI(PA1) EXTI，二者互为冗余 | `mygpio.c:210-233` |

### 3.2 MQTT 会话参数

| 参数 | 取值 | 依据 |
|------|------|------|
| 协议版本 | MQTT 3.1.1（`AT+QMTCFG="version",<idx>,4`） | `ec800e.c:758-772` |
| 上行 QoS | **0**（`AT+QMTPUBEX=<idx>,0,0,0,...`） | `ec800e.c:986-987,1594-1607` |
| 上行 Retain | **0** | 同上 |
| 订阅 QoS | **0**（`AT+QMTSUB=0,1,...,0` / `=0,2,...,0`） | `ec800e.c:575,1134-1135` |
| Clean Session | 由模组默认（QMTCONN 未显式设置） | `ec800e.c:379-381` |
| 主通道心跳 | `g_keepalive_sec`，默认 300 s，有效下限 30 s | `app_config.h:54`、`config_store.c:427-430` |
| 用户通道心跳 | 固定 600 s | `ec800e.c:1464` |
| 主通道接收模式 | `AT+QMTCFG="recv/mode",0,1,0`（缓存，MCU 轮询） | `ec800e.c:823-824` |
| 用户通道接收模式 | `AT+QMTCFG="recv/mode",1,0,1`（URC） | `ec800e.c:1471` |

> QoS 0 意味着报文不保证送达。平台侧必须把「未收到反馈」视为可能失败，由平台自身重发机制补偿；固件仅在本地做「上报成功即出队」的持久化防重（见 13.3）。

### 3.3 连接流程（主通道）

`ec800e.c:775-852`：

```
AT+QMTCFG="version",0,4          → MQTT 3.1.1
AT+QMTCFG="keepalive",0,<ka>
AT+QMTCFG="recv/mode",0,1,0
AT+QMTDISC=0 / AT+QMTCLOSE=0     → 清理旧连接
AT+QMTOPEN=0,"<server>",<port>   → 等待 +QMTOPEN: 0,0
AT+QMTCONN=0,"<client_id>","<user>","<pass>" → 等待 OK
AT+QMTCONN?                      → 期望 +QMTCONN: 0,3（state=3 已连接）
AT+QMTSUB=0,1,"<function/get>",0 → 功能下行
AT+QMTSUB=0,2,"<upgrade/set>",0  → OTA 下行
```

主服务器失败时自动切换副服务器（同一组 client_id/username/password，仅 IP:Port 变化），`ec800e.c:403-422`：

```c
if(mqtt_connect_to(g_mqtt.server,  g_mqtt.port ) == EC_OK) return EC_OK;
if(g_mqtt.server2[0] != '\0')
    if(mqtt_connect_to(g_mqtt.server2, g_mqtt.port2) == EC_OK) return EC_OK;
```

---

## 4. 主题（Topic）规范

### 4.1 client_id 与主题派生

设备身份来自 `client_id`，格式为 **4 段 `&` 分隔**（`config_store.c:207-248`）：

```
<前缀>&<设备ID>&<产品ID>&<序号>
   ↑        ↑         ↑        ↑
  固定字符  表号     产品型号  序号
```

**上行主题**（设备 → 平台，`config_store.c:245-246`）：

```
/<产品ID>/<设备ID>/property/post
```

**下行功能主题**（平台 → 设备，`ec800e.c:564-576`）——由上行主题把 `/property/post` 就地替换为 `/function/get`：

```
/<产品ID>/<设备ID>/function/get
```

**OTA 主题**（`ec800e.c:1097-1124`）——同一基址下替换为 `/upgrade/...`：

| 用途 | 主题 |
|------|------|
| OTA 升级下发（设备订阅，msgid=2） | `/<产品ID>/<设备ID>/upgrade/set` |
| OTA 状态回执（设备发布） | `/<产品ID>/<设备ID>/upgrade/reply` |
| OTA 过程状态（设备发布，数据主题） | `/<产品ID>/<设备ID>/property/post` |

**用户平台上行主题**（`g_user_mqtt.topic_up`）：由 `MQTT-set` 的 `MQTT_subject` 参数显式指定；
若未显式给出且 `client_id` 已配置，则自动拼接为 `/155/<client_id>/property/post`
（`eeprom_config.c:108-109`、`downlink.c:1121,1157-1158`）。

**示例**（默认出厂值 `app_config.h:39-46`）：

```
client_id = "S&D54GRG29T5HB0&149&1"
  → 设备ID  = D54GRG29T5HB0
  → 产品ID  = 149
  → 上行    = /149/D54GRG29T5HB0/property/post
  → 下行    = /149/D54GRG29T5HB0/function/get
  → OTA下发 = /149/D54GRG29T5HB0/upgrade/set
  → OTA回执 = /149/D54GRG29T5HB0/upgrade/reply
```

> 主题**不支持通配符**（`#`/`+`）：两处 `AT+QMTSUB` 均传精确字符串（`ec800e.c:575,1135`）。平台必须逐台精确发布。

### 4.2 下行接收机制

固件采用**主动轮询**而非 URC 回调（`downlink.c:1480-1538`）：

1. `AT+QMTRECV?` 查询槽位占用 → 响应 `+QMTRECV: 0,<slot0>,<slot1>,<slot2>,<slot3>,<slot4>`，**5 个槽位**（`ec800e.c:606-646`）；
2. 仅读取「有消息」的槽位：`AT+QMTRECV=0,<slot>`；不读空槽（避免消息滞留）；
3. 单次排空最多 **20 条 / 6 轮**；处理期间新到消息由下一轮重查兜住；
4. 按主题分流：主题含 `/upgrade/` → OTA 处理；否则解析 JSON 指令。

**轮询时机**：唤醒后判定的 `STATE_DOWNLINK`、冷启动上报后的等待窗口（20 s）、以及长连接保持期间的巡检。设备在 `short`/`dot` 窗口或低电压保护期间通常离线，**平台下发指令前必须确认设备在线**。

### 4.3 指令队列深度与报文长度限制

| 项目 | 限制 | 依据 |
|------|------|------|
| 模块下行缓存槽位 | 5 | `ec800e.c:612-617` |
| 单次排空条数 | 20 条 / 6 轮 | `downlink.c:1493` |
| 单条下行报文缓冲 | 1024 B | `downlink.c:1482` |
| 下行主题缓冲 | 128 B | `downlink.c:1483` |
| `commandStr` 提取缓冲 | 64 B | `downlink.c:1438` |
| 单条指令 ID 缓冲 | 32 B | `downlink.c:1431` |
| 单条参数值缓冲 | 192 B | `downlink.c:1432` |
| 上行 JSON 组装缓冲 | 1024 B | `downlink.c:37`、`report.c:25` |

> 超长参数会被截断（`extract_key_value` 截到缓冲上限）；平台下发的单条报文应控制在 **1 KB 以内**。

---

## 5. 报文编码规范

### 5.1 上行通用格式

设备上行采用**对象数组**（`json_builder.c:24-52`、`report.c:30-45`），所有 `value` 均为**字符串类型**，固定带 `remark` 空字段：

```json
[{"id":"<字段名>","value":"<值>","ts":"2026-10-15 08:30:00","remark":""}]
```

- 多字段情形合并为同一数组一次发布（如报警批量、阈值回读、设备信息）；
- 单条报文内所有字段使用**同一时间戳**；
- 时间戳格式固定 `"20YY-MM-DD HH:MM:SS"`（`tim.c:316-322`）。

**例外格式**（非数组，见第 7、11 章）：

| 报文 | 格式 | 依据 |
|------|------|------|
| 用户平台数据上报 | `{"param":[{"deviceKey":"...","key":"LYxx","value":"...","ts":"..."}]}` | `ec800e.c:1529-1591` |
| OTA 回执 | `{"mqttUpgradeReply":<code>}`（数值型） | `ec800e.c:1147-1169` |

### 5.2 下行格式（两种，固件都支持）

**格式 B（`commandStr`，与 `指令集.xlsx` 一致，推荐）**

```json
{"commandParms":[{"id":"<参数名>","value":"<参数值>"}],"commandStr":"<指令名>","value":"0"}
```

**格式 A（`id`/`value` 直发，兼容旧平台）**

```json
{"id":"<内部指令id>","value":"<参数值>"}
```

解析优先级（`downlink.c:1436-1477`）：

1. 报文包含 `downloadUrl` → 判为 **OTA 指令**（`downlink.c:1443-1445`）；
2. 报文包含 `commandStr` → **格式 B**，查 `s_cmd_map` 映射表（`downlink.c:97-164`）；
3. 否则 → **格式 A**，直接取首个 `"id"` 与 `"value"`。

> **警告**：`commandStr` 存在时格式 A 的字段被完全忽略。混用两种格式时以 `commandStr` 为准。

### 5.3 ⚠ 参数提取的硬约束（必须遵守）

固件用**字符串匹配**解析 JSON，不使用 JSON 库。因此存在两条硬约束：

#### 约束 1：`id` 与 `value` 必须紧邻

参数提取函数要求报文里出现字面子串 `"<参数名>","value"`——**逗号后不能有空格、换行或任何字符**（`downlink.c:65-87`）：

```c
snprintf(pat, sizeof(pat), "\"%s\",\"value\"", key);   /* 字面匹配 */
p = strstr(buf, pat);
```

**实测验证**（用固件同源函数编译运行）：

| 参数名 | 报文 | 提取结果 |
|--------|------|----------|
| `vpthreshold_pmax` | `{"id":"vpthreshold_pmax","value":"1.20"}` | ✅ `1.20` |
| `vpthreshold_pmax` | `{\n "id": "vpthreshold_pmax",\n "value": "1.20"\n}`（美化排版） | ❌ 提取失败（空值） |
| `table` | `{"id":"table","value":"D94C86Z7RFBIS"}` | ✅ `D94C86Z7RFBIS` |
| `table` | 美化排版（`"id": "table",` 换行 `"value": ...`） | ❌ 提取失败（空值） |

**后果**：参数提不到时不会报错，而是**静默降级**：

- 「以 `cmd_val` 是否非空区分读写」的指令（表号、IP、窗口、周期、关阀策略、实时采样、MQTT 等）会被当成**查询**执行——回读当前值并返回 **get 反馈码**，配置不变；
- 阈值类指令（`vpthreshold-set*`、`Tthreshold-set*`、`spupower-set`、`delay-set`）不写入任何字段，仅回读当前值（反馈码按各自规则）。

因此：

> **平台必须发送紧凑 JSON（无空格、无换行）**。`指令集.xlsx` 中的示例为了可读性做了换行缩进，**不可直接作为报文模板使用**。

`commandStr` 本身的提取不受此约束（`extract_json_field` 取键名后的下一个引号内容），美化排版也能解析（`downlink.c:42-62`）。

#### 约束 2：`install-status-set` 需要紧凑的 `"id":"install-status"`

该指令使用独立解析路径，要求字面 `"id":"install-status"`（冒号后不能有空格），`downlink.c:779-787`：

```c
p = strstr(raw_buf, "\"id\":\"install-status\"");
if(!p) p = strstr(raw_buf, "\"id\":\"install_status\"");   /* 兼容下划线写法 */
if(p) p = strstr(p, "\"value\":\"");
```

---

## 6. 下行指令报文

### 6.1 标准下发模板（紧凑，可直接复用）

```
{"commandParms":[{"id":"<参数>","value":"<值>"}],"commandStr":"<指令名>","value":"0"}
```

顶层 `"value":"0"` 为固定占位，固件**不读取**（取值来自 `commandParms`）。

### 6.2 查询类与无参控制类

`get` 类指令只发 `commandStr` 即可：

```
{"commandStr":"table-get","value":"0"}
{"commandStr":"valve-open","value":"0"}
```

也可带空的 `commandParms`，两者等效。

### 6.3 多参数指令

```
{"commandParms":[{"id":"timing_onswitch","value":"1"},{"id":"timing_offswitch","value":"0"},{"id":"timing_open","value":"2603231230"},{"id":"timing_close","value":"0000000000"}],"commandStr":"closeoropen-set","value":"0"}
```

> 多参数**可部分下发**：未出现的参数保持原值（各 handler 逐个 `extract_key_value` 命中才覆盖）。

### 6.4 未知指令与异常处理

| 情形 | 设备行为 | 依据 |
|------|----------|------|
| `commandStr` 不在映射表 | 以该字符串作为内部 id 查处理函数，仍找不到 → 打印 `Unknown cmd`，**无任何应答** | `downlink.c:1465-1469,1421` |
| 格式 A 的 id 未知 | 同上，静默忽略 | `downlink.c:1421` |
| 参数值非法 | 多数指令按各自兜底规则修正（见指令字典「越界处理」列），**不返回错误码** | 各 handler |
| 传感器无有效数据时下发取数指令 | 只回 `${status}=pressure-err/temp-err`，不发现场值 | `downlink.c:1400-1411,1381-1393` |
| MQTT 未连接 | 执行本地动作（如写 EEPROM），但**跳过应答与反馈码** | 各 handler 的 `EC801E_EnsureConnected()` 判定 |

> 平台收到「无响应」时，应视为设备离线或指令非法，不可假定成功。

### 6.5 取数指令门禁

当压力传感器读数无效（`g_sensor.raw.err != PT304D_OK`）时，以下 4 条指令**禁止上报现场值**，只回错误状态（`downlink.c:1372-1393`）：

| 指令 | 无有效数据时的应答 |
|------|--------------------|
| `get-pressure1` / `get-pressure` | `pressure-status = "pressure-err"` |
| `temp-get1` | `temp-status = "temp-err"` |
| `get-pressure2` | `pressure2-status = "pressure-err"` |
| `temp-get2` | `temp2-status = "temp-err"` |

---

## 7. 上行报文

### 7.1 报文清单

| # | 报文名称 | 触发时机 | 字段 | 依据 |
|---|----------|----------|------|------|
| 1 | **周期记录上报** | 上报周期到，历史记录逐条上报 | `temp,pressure`（单路）/ `temp,temp2,pressure,pressure2`（双路），`ts` = 记录时刻 | `ec800e.c:855-886` |
| 2 | **开机首报** | 上电联网成功 | `temp,pressure`(+2) | `main.c:3460` |
| 3 | **重启标志** | 上电联网成功 | `restart = "1"` | `main.c:3466-3476` |
| 4 | **设备信息** | 上电联网成功 | `csq,rsrp,snr,soft-version,ICCID,IMEI` | `main.c:3480-3511` |
| 5 | **汇总上报** | 每次上报流程收尾（见 7.2） | 多组，见 7.2 | `report.c:205-344` |
| 6 | **传感器在线状态** | 状态变化消抖确认 / 查询 | `rtu-have,rtu-status`(+`rtu2-have,rtu2-status`) | `report.c:86-106` |
| 7 | **报警批量上报** | 重采确认的异常 | `temp,pressure,temp-status,pressure-status`(+2) | `report.c:111-160` |
| 8 | **恢复批量上报** | 报警恢复（同一格式） | 同 #7 | `report.c:163-166` |
| 9 | **电压状态上报** | 电压类报警/恢复/查询 | `LY06,voltage` | `report.c:169-178` |
| 10 | **单字段上报** | 采集周期状态 / 安装事件 | `product-status` 或 `csq` | `report.c:30-36` |
| 11 | **指令反馈** | 指令处理结果 | `feedback = <码>` | `report.c:39-45` |
| 12 | **指令查询应答** | 各类 `-get` 指令 | 见第 8 章各指令「应答报文」 | 各 handler |
| 13 | **CH4 甲烷上报**（选配） | `gas-get` 或定时采集 | `gas,mstate,mtemp,methane` | `report.c:182-202` |
| 14 | **OTA 过程状态** | 升级各阶段 | `upgrade = 0..9` | `ota_app.c:34-45` |
| 15 | **OTA 回执** | 接受/完成/失败 | `{"mqttUpgradeReply":<码>}` | `ec800e.c:1147-1169` |
| 16 | **用户平台数据** | 与 #1 同时（如已配置） | LY01…LY11，见 7.3 | `ec800e.c:1529-1591` |

### 7.2 汇总上报（#5）的报文分组

`report_publish_upload_summary()` 会**连续发布多条报文**（`report.c:205-344`），平台需按字段分别归并：

| 序 | 报文内字段 | 说明 | 依据 |
|----|------------|------|------|
| 1 | `rtu-have,rtu-status`(+`rtu2-have,rtu2-status`) | 传感器在线状态 | `report.c:214` |
| 2 | `csq,rsrp,snr,pressure-status,temp-status`(+`pressure2-status,temp2-status`) | 信号质量 + 阈值状态（**同一条报文**） | `report.c:215-257` |
| 3 | `MQTT_username,MQTT_password,MQTT_client_id,MQTT_subject` | **仅本机开机后首次汇总发送**（函数内 `static` 标志） | `report.c:260-269` |
| 4 | `window_pattern,window_end_result,window_start,window_stop,window_dottime` | **仅本机开机后首次汇总发送** | `report.c:271-280` |
| 5 | `valve-control` | 阀门当前状态 | `report.c:284-290` |
| 6 | `user-ip` | 用户端服务器 | `report.c:293-300` |
| 7 | `first-ip,scend-ip` | 主/副服务器（同一条报文） | `report.c:302-310` |
| 8 | `voltage,LY06,product-status` | 电池电压、电压报警、安装状态 | `report.c:314-342` |

> 一次汇总上报共产生 **6 条报文**（开机后首次为 8 条）。第 3、4 组使用函数内 `static` 标志，**重启后才会再次上报**；平台若需重新获取这些配置，应下发对应 `-get` 指令。

### 7.3 用户平台 LY 格式

用户平台使用**另一种键名体系**（`ec800e.c:1529-1591`）：

```json
{"param":[
 {"deviceKey":"<客户端client_id>","key":"LY01","value":"12.34","ts":"2026-10-15 08:30:00"},
 {"deviceKey":"<客户端client_id>","key":"LY02","value":"25.60","ts":"..."}
]}
```

| key | 含义 | 单位 | 单路机型 | 双路机型 |
|-----|------|------|----------|----------|
| `LY01` | 进口压力 | kPa | — | ✅ |
| `LY02` | 进口温度 | ℃ | — | ✅ |
| `LY03` | 电池电压 | V | ✅ | ✅ |
| `LY04` | 探头故障 | 0/1 | ✅ | ✅ |
| `LY05` | 信号强度 | CSQ | ✅ | ✅ |
| `LY06` | 电压报警 | 0/1 | ✅ | ✅ |
| `LY07` | 上报周期 | min | ✅ | ✅ |
| `LY08` | 出口压力 | kPa | ✅ | ✅ |
| `LY11` | 出口温度 | ℃ | ✅ | ✅ |

---

## 8. 指令字典

### 8.1 指令总表（按功能分组，覆盖全部 62 条 `commandStr`）

下表按**功能**聚合 `get`/`set` 对；固件映射表 `s_cmd_map[]` 共 **62 条 `commandStr`** 条目，另有 1 个仅格式 A 可用的内部 id（`sensor_read`）。

「反馈码」列中 `get`/`set` 分别对应查询/设置成功的反馈值；`—` 表示该指令无反馈码（仅回数据）。

| # | 功能 | `commandStr` | 类型 | 反馈码 | 表内 | 依据 |
|---|------|--------------|------|--------|------|------|
| 1 | 表号 | `table-get` / `table-set` | 读写 | 26 / 27 | ✅ | `downlink.c:162-163` |
| 2 | 主 IP | `first-ip-get` / `first-ip-set` | 读写 | 1 / 2（失败 24） | ✅ | `downlink.c:124,137` |
| 3 | 副 IP | `scend-ip-get` / `scend-ip-set` | 读写 | 1 / 2（失败 24） | ✅ | `downlink.c:125,138` |
| 4 | 用户端 IP | `user-ip-get` / `user-ip-set` | 读写 | 1 / 2（失败 24） | ✅ | `downlink.c:128,140` |
| 5 | 用户端 MQTT | `MQTT-get` / `MQTT-set` | 读写 | 17 / 18 | ✅ | `downlink.c:129,142` |
| 6 | 窗口周期 | `window-get` / `window-set` | 读写 | 3 / 4 | ✅ | `downlink.c:120,133` |
| 7 | 采集周期 | `collectcycle-get` / `collectspeed-set` | 读写 | 11 / 12 | ✅ | `downlink.c:118,131` |
| 8 | 上报周期 | `report-get` / `report-set` | 读写 | 9 / 10 | ✅ | `downlink.c:119,132` |
| 9 | 采样频率 | `real-get` / `real-set` | 读写 | 13 / 14 | ✅ | `downlink.c:127,139` |
| 10 | 进气端压力阈值 | `vpthreshold-get1` / `vpthreshold-set1` | 读写 | 7 / 8 | ✅ | `downlink.c:144-145` |
| 11 | 出气端压力阈值 | `vpthreshold-get2` / `vpthreshold-set2` | 读写 | 7 / 8 | ✅ | `downlink.c:152-153` |
| 12 | 进气端温度阈值 | `Tthreshold-get` / `Tthreshold-set` | 读写 | 5 / 6 | ✅ | `downlink.c:146-147` |
| 13 | 出气端温度阈值 | `Tthreshold-get2` / `Tthreshold-set2` | 读写 | 5 / 6 | ✅ | `downlink.c:154-155` |
| 14 | 电压监测保护 | `spupower-get` / `spupower-set` | 读写 | 15 / 16 | ✅ | `downlink.c:148-149` |
| 15 | 阀门动作延时 | `delay-get` / `delay-set` | 读写 | 19 / 20 | ✅ | `downlink.c:150-151` |
| 16 | 批量阈值查询 | `threshold-get1` | 只读 | 5 | ➕ | `downlink.c:117` |
| 17 | MQTT 心跳 | `keepalive`（仅格式 A） | 只写 | — | ➕ | `downlink.c:828-842` |
| 18 | 阀门控制 | `valve-open` / `valve-close` | 控制 | 23 | ✅ | `downlink.c:98-99` |
| 19 | 阀门状态 | `valve-get` | 只读 | 25 | ➕ | `downlink.c:158` |
| 20 | 阀门最后动作 | `valve-last-get` | 只读 | — | ➕ | `downlink.c:126` |
| 21 | 阀门定时开关 | `closeoropen-get` / `closeoropen-set` | 读写 | 21 / 22 | ✅ | `downlink.c:159-160` |
| 22 | 进气端异常自动关阀 | `abnormal-get` / `abnormal-set` | 读写 | 28 / 29 | ✅ | `downlink.c:121,134` |
| 23 | 出气端异常自动关阀 | `abnormal2-get` / `abnormal2-set` | 读写 | 28 / 29 | ✅ | `downlink.c:122,135` |
| 24 | 激光甲烷异常关阀 | `abnormal3-get` / `abnormal3-set` | 读写 | 28 / 29 | ✅ | `downlink.c:123,136` |
| 25 | 电压状态 | `LY06-get` | 只读 | — | ✅ | `downlink.c:110` |
| 26 | 进气端温度状态 | `temp-get1` | 只读 | 31 | ✅ | `downlink.c:108` |
| 27 | 出气端温度状态 | `temp-get2` | 只读 | 31 | ✅ | `downlink.c:109` |
| 28 | 进气端压力状态 | `get-pressure1`（`get-pressure` 同义） | 只读 | 30 | ✅ | `downlink.c:100-101` |
| 29 | 出气端压力状态 | `get-pressure2` | 只读 | 30 | ✅ | `downlink.c:116` |
| 30 | 传感器在线状态 | `sensor-status` | 只读 | — | ➕ | `downlink.c:104` |
| 31 | 通信/卡号信息 | `get-sim` | 只读 | — | ➕ | `downlink.c:102` |
| 32 | 主 IP 查询（别名） | `get-ip` | 只读 | 1 | ➕ | `downlink.c:103` |
| 33 | 阀门即时采集 | `sensor_read`（仅格式 A） | 只读 | 30 | ➕ | `downlink.c:1313` |
| 34 | 激光甲烷状态 | `gas-get` | 只读 | 32 | ✅ | `downlink.c:111` |
| 35 | 激光采集时间点 | `laser-get` / `laser-set` | 读写 | 33 / 34 | ✅ | `downlink.c:112-113` |
| 36 | 甲烷门限值 | `msh-get` / `msh-set` | 读写 | 35 / 36 | ✅ | `downlink.c:114-115` |
| 37 | 系统重启 | `restart-off`（`restart` 同义） | 控制 | — | ✅ | `downlink.c:105-106,992-1000` |
| 38 | 状态强制转换 | `install-status-set` | 只写 | 37 | ✅ | `downlink.c:141` |
| 39 | LCD 开关 | `lcd-switch` | 读写 | — | ➕ | `downlink.c:156` |
| 40 | 4G 断电 | `4Gpower-off` | — | — | ➕ | 已注释，**未实现**（`downlink.c:1002-1009,1338`） |

> 「表内 ✅」= 出现在 `指令集.xlsx`；「➕」= 仅固件支持、表内缺失，建议补入平台。

### 8.2 A 组 · 身份与服务器配置

#### A1 表号 `table-get` / `table-set`

| 项目 | 内容 |
|------|------|
| 功能 | 读取/配置设备表号（即 `client_id` 第 2 段「设备ID」） |
| 参数 | `table` |
| 取值 | 字符串（写入 `client_id` 时受 `MQTT_FIELD_MAX`=64 B 限制） |
| 默认值 | 出厂 `client_id = "S&D54GRG29T5HB0&149&1"` → 表号 `D54GRG29T5HB0` |
| 副作用 | 重建 `client_id` → **重新派生上行主题**（`derive_topic_from_client_id()`）→ 保存 EEPROM。⚠ 当前 MQTT 会话不会立即重连，故：**应答报文按新主题发布**，而 `client_id` 要等下一次重连（重启、掉线重连或 `first-ip-set`）才真正生效。改表号后平台必须同步切换订阅主题 |
| 应答 | `[{"id":"table","value":"<表号>",...}]` |
| 反馈码 | get=26 / set=27 |
| 依据 | `downlink.c:1257-1303`、`config_store.c:207-248` |

```
下发：{"commandParms":[{"id":"table","value":"D94C86Z7RFBIS"}],"commandStr":"table-set","value":"0"}
应答：[{"id":"table","value":"D94C86Z7RFBIS","ts":"...","remark":""}]
反馈：[{"id":"feedback","value":"27","ts":"...","remark":""}]
```

> 实现细节：读取/写入均针对 `client_id` 中第 1、2 个 `&` 之间的片段（`downlink.c:1263-1284,1288-1297`）。若 `client_id` 不足 2 个 `&`，写入被静默跳过。

#### A2/A3 主 IP、副 IP

| 项目 | 内容 |
|------|------|
| 参数 | `first-ip` / `scend-ip` |
| 取值格式 | **`IP.端口`**，按**最后一个 `.`** 分割（`downlink.c:190-203`）。域名亦可（原样传给 `AT+QMTOPEN`） |
| 示例 | `47.108.82.190.1883` → IP `47.108.82.190`，端口 `1883` |
| 默认值 | 主 `120.78.220.171:1883`；副 `120.78.220.171:1883`（副 IP 置空字符串即禁用故障切换） |
| 副作用 | `first-ip-set` 会**断开并立即重连 MQTT**（`downlink.c:890-893`）；`scend-ip-set` 不在线重连 |
| 应答 | 成功 `[{"id":"first-ip-set","value":"<原样参数>"}]`；失败则无数据应答 |
| 反馈码 | get=1 / set=2 / 格式非法=24 |
| 依据 | `downlink.c:869-931,1105-1136` |

> 参数格式非法（不含 `.`）时回反馈码 **24**，配置不变。

#### A4 用户端 IP `user-ip-get` / `user-ip-set`

| 项目 | 内容 |
|------|------|
| 参数 | `user-ip`，格式同 A2 |
| 副作用 | 若 `topic_up` 为空且 `client_id` 已配置，自动拼 `/155/<client_id>/property/post` |
| 反馈码 | get=1 / set=2 / 失败=24 |
| 依据 | `downlink.c:1105-1136` |

#### A5 用户端 MQTT `MQTT-get` / `MQTT-set`（只读部分）

| 项目 | 内容 |
|------|------|
| 参数 | `MQTT_username`、`MQTT_password`、`MQTT_client_id`、`MQTT_subject` |
| 应答 | `[{"id":"MQTT_username",...},{"id":"MQTT_password",...},{"id":"MQTT_client_id",...},{"id":"MQTT_subject",...}]` |
| 反馈码 | get=17 / set=18 |
| 依据 | `downlink.c:1138-1174` |
| 备注 | `MQTT_subject` 即用户平台上行主题；`client_id` 同时用作 `deviceKey` |

```
下发：{"commandParms":[{"id":"MQTT_username","value":"FastBee"},{"id":"MQTT_password","value":"PDY814445B24193C"},{"id":"MQTT_client_id","value":"S&12345678901&157&1"},{"id":"MQTT_subject","value":"/157/12345678901/property/post"}],"commandStr":"MQTT-set","value":"0"}
```

### 8.3 B 组 · 周期与在线策略

#### B1 采集周期 `collectcycle-get` / `collectspeed-set`

| 项目 | 内容 |
|------|------|
| 参数 | 数值 `collect_once`（uint16）、单位 `collect_type` |
| 单位取值 | `sec` / `minute` / `hour` / `day`（`week` 固件也接受） |
| 越界处理 | `collect_once = 0` → 修正为 1；超上限按单位钳制：sec/min ≤ 65535，hour ≤ 1092，day ≤ 45，week ≤ 6（`config_policy.c:117-149`） |
| 未知单位 | 回落 `minute`（`config_policy.c:78-86`） |
| 默认值 | `1 day`（`app_config.h:67-68`） |
| 应答 | `[{"id":"collect_once","value":"1"},{"id":"collect_type","value":"day"}]` |
| 反馈码 | get=11 / set=12 |
| 依据 | `downlink.c:466-494` |

```
下发：{"commandParms":[{"id":"collect_once","value":"30"},{"id":"collect_type","value":"minute"}],"commandStr":"collectspeed-set","value":"0"}
```

> 单位字段解析支持两种写法：紧凑的 `{"id":"collect_type","value":"minute"}`（推荐）或直接字面 `"type":"minute"`。

#### B2 上报周期 `report-get` / `report-set`

参数为 `report_once` / `report_type`，单位支持 `minute` / `hour` / `day` / `week`（`sec` 亦被接受）；钳制规则同 B1；默认 `1 day`。
应答 `[{"id":"report_once","value":"1"},{"id":"report_type","value":"day"}]`；反馈码 get=9 / set=10。依据 `downlink.c:496-524`。

#### B3 窗口周期 `window-get` / `window-set`

| 参数 | 取值 | 说明 |
|------|------|------|
| `window_pattern` | `long` / `short` / `dot` | 在线策略，见下表 |
| `window_end_result` | `0` / `1` | 仅 `long` 有效 |
| `window_start` | `HHMMSS` 6 位，如 `080000` | 仅 `short`/`long` 有效 |
| `window_stop` | `HHMMSS` 6 位，如 `180000` | 同上；停止时刻自动加 **2 分钟容差** |
| `window_dottime` | 逗号分隔小时列表，元素 0–23，如 `08,20`；空串=清空 | 仅 `dot` 有效 |

**三种模式的行为**（`main.c:780-781,1602-1618,2165-2190`、`config_policy.c:256-290`）：

| 模式 | 4G 供电 | 上报节奏 | 可收下行 |
|------|---------|----------|----------|
| `long` | 窗口内 或 `end_result=1` 时保持供电（QSCLK 轻睡眠）；否则断电 | 按上报周期 | **是**（支持 LPUART 唤醒接收） |
| `short` | 休眠期间始终断电，仅在上报周期到达且处于 `start`~`stop` 内才开机联网 | 窗口内按周期 | 否（离线期间） |
| `dot` | 休眠期间始终断电 | 每天在 `dottime` 命中的整点各上报一次 | 否（离线期间） |

- `start`/`stop` 全为 0（`000000/000000`，出厂默认）→ 视为**全天有效**（`config_policy.c:270-271`）；
- `start > stop` → 视为跨午夜窗口；
- `window_start`/`window_stop` 固件**不校验格式**（仅按 7 字符截断），平台必须保证 6 位 `HHMMSS`。

应答 `[{"id":"window_pattern",...},{"id":"window_end_result",...},{"id":"window_start",...},{"id":"window_stop",...},{"id":"window_dottime",...}]`；反馈码 get=3 / set=4。依据 `downlink.c:686-717`。

```
下发：{"commandParms":[{"id":"window_pattern","value":"dot"},{"id":"window_dottime","value":"08,20"}],"commandStr":"window-set","value":"0"}
```

#### B4 采样频率（秒级实时模式）`real-get` / `real-set`

| 参数 | 取值 | 默认 | 越界处理 |
|------|------|------|----------|
| `real_enabled` | `0` 关闭 / `1` 开启 | 1 | `>1` → 0 |
| `real_frequency` | 秒，1–10 | 5 | `<1` 或 `>10` → 5 |

**功能**：开启后，休眠期内按 `real_frequency` 秒设置 RTC 闹钟唤醒，最小化初始化后采集并即时判异常（`main.c:1715-1716,1841-1921`）；异常时 3 次重采确认 → 关阀 → 报警上报。校零未安装期间该模式自动禁用（`main.c:243-250`）。

应答 `[{"id":"real_enabled",...},{"id":"real_frequency",...}]`；反馈码 get=13 / set=14。依据 `downlink.c:1011-1037`。

### 8.4 C 组 · 阈值与保护

阈值组采用**表驱动**实现（`downlink.c:221-371`），组间规则一致：

- **部分下发**：只覆盖报文里出现的参数，其余保持原值；
- **`set` 与 `get` 的判定**：见各指令；`vpthreshold2`/`Tthreshold2` 组以「参数字段是否非空」判定，`vpthreshold`/`Tthreshold`/`spupower`/`delay` 组以「是否有字段被写入」判定；
- 成功即**写 EEPROM 持久化**并回读当前全组值。

#### C1 进气端压力阈值 `vpthreshold-get1` / `vpthreshold-set1`

| 参数 | 含义 | 类型 | 越界处理 |
|------|------|------|----------|
| `vpthreshold_switch` | 检测开关：`0` 关 / `1` 开 | uint8 | `>1` → 0 |
| `vpthreshold_ppmax` | 压力超高阈值 | float | 不校验 |
| `vpthreshold_pmax` | 压力上限 | float | 不校验 |
| `vpthreshold_ppmin` | 压力超低阈值 | float | 不校验 |
| `vpthreshold_pmin` | 压力下限 | float | 不校验 |
| `vpthreshold_mutation` | 压力突变阈值（\|Δp\|） | float | 不校验 |
| `vpthreshold_shock` | 静态阈值迟滞带 | float | 不校验 |

- **默认值**：开关 `1`（单路机型）/ 全部阈值 `0` / `shock = 100`（单路）或 `3000`（双路）（`eeprom_config.h:309-325`）
- **单位**：Pa（与压力上报一致）
- **迟滞规则**（`threshold.h:16-21`）：进入 `p > T + shock`，退出 `p < T - shock`，带内保持原档位；`mutation` 不受迟滞影响
- **检查优先级**：`ppmax/ppmin` > `pmax/pmin` > `mutation`（`threshold.c:99-150`）
- 应答：上述 7 字段全组回读（float 保留 2 位小数）；反馈码 get=7 / set=8
- 依据：`downlink.c:244-252,275-282,526-529`

#### C2 出气端压力阈值 `vpthreshold-get2` / `vpthreshold-set2`

参数同 C1，字段前缀改为 `vpthreshold2_*`；默认 `shock = 100`（`eeprom_config.h:329-335`）。
应答 float 保留 **1 位**小数（`use_float1`，`downlink.c:280`）；反馈码 get=7 / set=8。
**出气端不参与电压检查**（`threshold.h:76`）。

#### C3 进气端温度阈值 `Tthreshold-get` / `Tthreshold-set`

| 参数 | 含义 | 越界处理 |
|------|------|----------|
| `Tthreshold_switch` | 检测开关 0/1 | `>1` → 0 |
| `Tthreshold_high` | 温度上限 | 不校验 |
| `Tthreshold_low` | 温度下限 | 不校验 |
| `Tthreshold_vhigh` | 温度极高阈值 | 不校验 |
| `Tthreshold_vlow` | 温度极低阈值 | 不校验 |

- 默认：开关 `0`（关闭），阈值 `0.00`；单位 ℃
- 检查优先级：`vhigh/vlow` > `high/low`（`threshold.c:124-133`）
- 应答 float 2 位小数；反馈码 get=5 / set=6；依据 `downlink.c:254-260,277,531-534`

#### C4 出气端温度阈值 `Tthreshold-get2` / `Tthreshold-set2`

参数前缀 `Tthreshold2_*`，语义同 C3；默认全部 `0`。应答 float **1 位**小数；反馈码 get=5 / set=6。

#### C5 电压监测保护 `spupower-get` / `spupower-set`

| 参数 | 含义 | 默认 | 越界处理 |
|------|------|------|----------|
| `spupower_switch` | 电压检测总开关 0/1 | `1` | `>1` → 0 |
| `spupower_high` | 电压上限（高于报警） | `0.00`（不启用） | 不校验 |
| `spupower_low` | 电压下限（低于报警） | `2.80` | 不校验 |
| `spupower_protect` | 保护电压点（触发 VLP 省电） | `0.00`（不启用） | 不校验 |

- 单位 V；阈值「活跃」判定：值 ≠ 0 才参与（`THR_ACTIVE`）
- **VLP 进入条件**：`enabled=1` 且 `0 < protect` 且 `voltage < protect - 0.1`（`threshold.c:106-113`）
- **VLP 退出条件**：`!enabled` 或 `voltage >= protect + 0.15`（`main.c:2409-2419`）
- 应答 float 2 位小数；反馈码 get=15 / set=16；依据 `downlink.c:262-267,278,536-539`

#### C6 阀门动作延时 `delay-get` / `delay-set`

| 参数 | 含义 | 默认 | 越界处理 |
|------|------|------|----------|
| `delay_switch` | 到位后保持驱动 0/1 | `0` | `>1` → 0 |
| `delay_time` | 保持时间，ms | `0` | 钳制到 **0–5000**（`VDLY_DELAY_MS_MAX`） |

反馈码 get=19 / set=20；依据 `downlink.c:269-272,279,681-684`、`eeprom_config.h:290-295`。

#### C7 批量阈值查询 `threshold-get1`（扩展）

一次性回读三组阈值：**压力 → 温度 → 电压**，各为独立报文，最后回反馈码 **5**（`downlink.c:666-679`）。

#### C8 MQTT 心跳 `keepalive`（扩展，仅格式 A）

```
下发：{"id":"keepalive","value":"120"}
```

- `value >= 30` 才接受；写入 EEPROM 并下发 `AT+QMTCFG="keepalive",0,<值>`
- 无反馈码；需**重启或重连**后对新连接完全生效
- 依据 `downlink.c:828-842`

### 8.5 D 组 · 阀门与联动

#### D1 阀门控制 `valve-open` / `valve-close`

| 项目 | 内容 |
|------|------|
| 参数 | 无 |
| 应答 | `[{"id":"valve-control","value":"<结果>"},{"id":"valve-last-order","value":"<0/1>"}]` |
| 反馈码 | 23 |
| 依据 | `downlink.c:377-406`、`valve.c:11-87` |

`valve-control` 取值（`valve.c:37-99`）：

| 值 | 含义 |
|----|------|
| `valve-on` | 开到位（限位 1 PA11 低电平） |
| `valve-off` | 关到位（限位 2 PA12 低电平） |
| `valve-timeout` | 超时未到位，且对侧限位未触发 |
| `valve-err` | 两限位同时触发 / 超时且对侧限位有效（机械故障）/ 无电机硬件 |

`valve-last-order`：`0` = 关，`1` = 开（EEPROM 持久化，`eeprom_config.h:451`）。

**手动控制的附带效果**（`downlink.c:383-396`）：

- 清除 `g_valve_alarm_closed`（报警关阀闭锁）并记录关阀前状态；
- 清除 `g_ch4_alarm_closed`（甲烷关阀闭锁）；
- 复位「报警恢复已上报」标志 `g_alarm_recover_reported`。

> 即：**平台下发 `valve-open` 是解除报警闭锁、恢复供气的唯一远程手段**。

**硬件门控**：本机型 `MOTOR_ENABLED = 0`（`app_config.h:114`），阀门代码未编译，`valve_execute()` 恒返回 `valve-err`，阀门指令返回反馈码 23 但不动阀。带电机机型需将 `MOTOR_ENABLED` 置 1。

#### D2 阀门状态 `valve-get`（扩展）

只读，无副作用（`valve.c:90-99`）；仅回 `valve-control` 字段；反馈码 25。依据 `downlink.c:1176-1186`。

> ⚠ `指令集.xlsx` 第 13 行把本功能的 `commandStr` 写成了 `get-pressure2`，与「出气端压力读取」重码。**正确指令为 `valve-get`**，详见第 14 章。

#### D3 阀门最后动作 `valve-last-get`（扩展）

应答 `[{"id":"valve-last-order","value":"0|1"}]`，无反馈码。依据 `downlink.c:820-826`。

#### D4 阀门定时开关 `closeoropen-get` / `closeoropen-set`

| 参数 | 取值 | 说明 |
|------|------|------|
| `timing_onswitch` | `0`/`1` | 定时开阀使能；`>1` → 0 |
| `timing_offswitch` | `0`/`1` | 定时关阀使能；`>1` → 0 |
| `timing_open` | `YYMMDDHHMM` 10 位 | 开阀时刻 |
| `timing_close` | `YYMMDDHHMM` 10 位 | 关阀时刻 |

**时间格式语义**（`valve_timing.c:10-35`）：

| 写法 | 含义 |
|------|------|
| `0000001230` | 每天 12:30 |
| `0000231230` | 每月 23 日 12:30 |
| `0003231230` | 每年 3 月 23 日 12:30 |
| `2603231230` | 一次性：2026-03-23 12:30 |

- 年/月/日 允许 `00` 通配；**时 00–23、分 00–59 必须合法**；
- 匹配容差 **±30 s**（`main.c:1225,1233`）；
- 每天最多触发一次（`timing_open_done_today` / `timing_close_done_today`，跨日复位）；
- 非法时间串**被拒绝**并保留原值（`downlink.c:1207-1226`）——这是与 `window_start`/`window_stop` 的重要差别；
- 甲烷关阀或报警关阀闭锁期间，**定时开阀被跳过**（`main.c:1243-1248`）；
- 配置变更会复位当日已执行标志（`downlink.c:1235-1236`）。

应答 `[{"id":"timing_onswitch",...},{"id":"timing_offswitch",...},{"id":"timing_open",...},{"id":"timing_close",...}]`；反馈码 get=21 / set=22；依据 `downlink.c:1188-1255`。

#### D5/D6 进气端 / 出气端异常自动关阀

| 指令 | 参数 | 作用域 |
|------|------|--------|
| `abnormal-get` / `abnormal-set` | `abnormal_close` | 进气端（第 1 路压力） |
| `abnormal2-get` / `abnormal2-set` | `abnormal2_close` | 出气端（第 2 路压力） |

**策略取值**（`config_policy.c:207-254`）：

| 值 | 关阀触发条件 |
|----|--------------|
| `none` | 关闭（默认） |
| `pvhigh` | 压力**超高**（> `ppmax`） |
| `pvlow` | 压力**超低**（< `ppmin`） |
| `pvmutation` | 压力**骤变**（\|Δp\| > `mutation`） |
| `pvhighorlow` | 超高 **或** 超低 |
| `pvhighormutation` | 超高 **或** 骤变 |
| `pvlowormutation` | 超低 **或** 骤变 |
| `all` | 超高 / 超低 / 骤变 |

- 仅**极值档与突变档**参与关阀；普通档（`pmax`/`pmin`）与温度档**不关阀**，只上报；
- 电压类报警（VPROTECT/VOLT_HIGH/VOLT_LOW）**只上报，不关阀**；
- 未知/旧策略值一律按 `none` 处理。

应答 `[{"id":"abnormal_close","value":"<策略>",...}]`（出气端为 `abnormal2_close`）；反馈码 get=28 / set=29；依据 `downlink.c:719-745`。

```
下发：{"commandParms":[{"id":"abnormal_close","value":"pvhighorlow"}],"commandStr":"abnormal-set","value":"0"}
```

#### D7 激光甲烷异常自动关阀 `abnormal3-get` / `abnormal3-set`（硬件选配）

参数 `abnormal3_close`：`0` = 关闭，`1` = 开启（`>1` → 0）；报警即关阀并**保持闭锁**，直至平台下发 `valve-open`。反馈码 get=28 / set=29；依据 `downlink.c:747-764`、`ch4_alarm.c:76-83`。

### 8.6 E 组 · 数据查询

| 指令 | 参数 | 应答字段 | 反馈码 | 依据 |
|------|------|----------|--------|------|
| `LY06-get` | — | `LY06`（-1/0/1）、`voltage`（V） | — | `downlink.c:964-981` |
| `temp-get1` | — | `temp-status`、`temp` | 31 | `downlink.c:946-962` |
| `temp-get2` | — | `temp2-status`、`temp2` | 31 | `downlink.c:1068-1084` |
| `get-pressure1` | — | `rtu-have,rtu-status` → `temp,pressure` → `pressure-status`（3 条报文） | 30 | `downlink.c:408-464` |
| `get-pressure2` | — | `pressure2-status`、`pressure2`、`temp2` | 30 | `downlink.c:1086-1103` |
| `sensor-status` | — | `rtu-have,rtu-status`(+2) | — | `downlink.c:933-944` |
| `get-sim` | — | `csq,rsrp,snr,cereg,soft-version,ICCID,IMEI` | — | `downlink.c:844-867` |
| `get-ip` | — | `first-ip` | 1 | `downlink.c:869-872` |

> `get-pressure1` 会**实际采集一次传感器**并同时做阈值检查；若判定异常，还会触发关阀与报警上报（`downlink.c:440-463`）。该指令不是纯粹的「读当前值」。

### 8.7 F 组 · 激光甲烷（硬件选配 `LASER_CH4_ENABLED`）

> 本机型 `LASER_CH4_ENABLED = 0`（`app_config.h:108`），以下三条指令**未编译**，下发时只打印调试日志、无任何应答。

#### F1 激光甲烷状态与读数 `gas-get`

置位采集请求，状态机转入 `STATE_CH4` 执行：上电 → 暖机（`warmup_sec`，默认 20 s）→ 采集 → 上报 → 断电（`ch4_alarm.c:35-128`）。
应答 `[{"id":"gas",...},{"id":"mstate",...},{"id":"mtemp",...},{"id":"methane",...}]`；报警时 `gas=1` 并关阀；反馈码 **32**。

#### F2 激光采集时间点 `laser-get` / `laser-set`

| 参数 | 取值 | 默认 |
|------|------|------|
| `laser_switch` | `0` 关 / `1` 开（`>1` → 0） | `1` |
| `laser_time` | 逗号分隔整点 0–23，如 `08,20` | `08,20` |

应答 `[{"id":"laser_switch",...},{"id":"laser_time",...}]`；反馈码 get=33 / set=34；依据 `downlink.c:552-610`。

#### F3 甲烷门限值 `msh-get` / `msh-set`

参数 `msh_threshold`，float，`%VOL`，有效范围 **0–999**；非法（NaN/越界）回落默认 **0.50**（`downlink.c:634-653`）。
应答 `[{"id":"msh_threshold","value":"0.50"}]`；反馈码 get=35 / set=36。

### 8.8 G 组 · 系统维护

#### G1 系统重启 `restart-off`（`restart` 同义）

- 应答 `[{"id":"restart","value":"0"}]`
- 应答后延时 50 ms 执行 `NVIC_SystemReset()`；**无反馈码**
- 依据 `downlink.c:992-1000`

#### G2 状态强制转换 `install-status-set`

| 项目 | 内容 |
|------|------|
| 参数 | `install-status`；`0` = 未安装，`1` = 已安装（其他值忽略） |
| `=1` 效果 | `calib_force_install()` → 上报一条传感器记录 + `product-status=1` → 反馈 37 |
| `=0` 效果 | `calib_force_uninstall()` → 作废未安装期残留记录 → 上报 `product-status=0` → 反馈 37 |
| 反馈码 | 37 |
| 依据 | `downlink.c:769-818`、`calib_mode.c` |

```
下发：{"commandParms":[{"id":"install-status","value":"1"}],"commandStr":"install-status-set","value":"0"}
```

#### G3 LCD 开关 `lcd-switch`

参数 `lcd_switch`：`0` = 关（立即息屏），`1` = 开（`>1` → 1）；EEPROM 持久化。
应答 `[{"id":"lcd_switch","value":"0|1"}]`；无反馈码。依据 `downlink.c:1039-1056`。

---

## 9. 数据字典

### 9.1 测量类

| 字段 | 含义 | 单位 | 精度/格式 | 来源 |
|------|------|------|-----------|------|
| `temp` | 进气端温度 | ℃ | `%.2f` | PT304D #2 |
| `temp2` | 出气端温度 | ℃ | `%.2f` | PT304D #1（仅双路） |
| `pressure` | 进气端压力 | **Pa** | `%.2f` | PT304D #2 |
| `pressure2` | 出气端压力 | **Pa** | `%.2f` | PT304D #1（仅双路） |
| `voltage` | 电池电压 | V | `%.2f` | ADC（`adc_bat.c`） |
| `mtemp` | 甲烷传感器温度 | ℃ | `%.2f` | CH4（选配） |
| `methane` | 甲烷浓度 | %VOL | `%.2f` | CH4（选配） |

**量程**（`PT_304_35.h:33-40`）：出气端 S1 满量程 40 kPa；进气端 S2 满量程 600 kPa（双路机型）/ 35 kPa（单路机型）。
**用户平台 LY 格式中压力单位为 kPa**（`ec800e.c:1530-1531` 注释）。

### 9.2 状态类

| 字段 | 取值 | 说明 |
|------|------|------|
| `temp-status` / `temp2-status` | `temp-normal` / `temp-high` / `temp-low` / `temp-very-high` / `temp-very-low` / `temp-err` | `threshold.c:251-261`；`temp-err` = 传感器无有效数据 |
| `pressure-status` / `pressure2-status` | `pressure-normal` / `pressure-low` / `pressure-high` / `pressure-verylow` / `pressure-veryhigh` / `pressure-mutation` / `pressure-err` | `threshold.c:220-231` |
| `LY06` | `-1` 未知（ADC 无效或检测关闭）/ `0` 正常 / `1` 报警 | `threshold.h:53-55` |
| `rtu-have` / `rtu2-have` | `0` I2C 通信失败 / `1` 有响应 | `report.c:88` |
| `rtu-status` / `rtu2-status` | `0` 数据无效 / `1` 数据有效 | `report.c:89` |
| `valve-control` | `valve-on` / `valve-off` / `valve-timeout` / `valve-err` | 见 D1 |
| `valve-last-order` | `0` 关 / `1` 开 | EEPROM 持久化 |
| `product-status` | `0` 未安装（校零中）/ `1` 已安装 | `calib_is_installed()` |
| `gas` | `0` 正常 / `1` 报警 | CH4 选配 |
| `mstate` | `%02d` 两位传感器状态字节 | CH4 选配 |
| `restart` | `1` = 本次为设备重启后首报 | `main.c:3466-3476` |
| `feedback` | 见第 10 章 | 指令处理结果 |
| `upgrade` | `0`–`9`，见 11.4 | OTA 过程状态 |

**报警类型字符串**（`threshold_alarm_type_str`，`threshold.c:161-179`，用于调试日志）：
`voltage_protect` / `voltage_high` / `voltage_low` / `pressure_verylow` / `pressure_veryhigh` / `pressure_high` / `pressure_low` / `pressure_mutation` / `temperature_high` / `temperature_low` / `temperature_veryhigh` / `temperature_verylow` / `unknown`

### 9.3 配置回读类

| 字段组 | 字段 |
|--------|------|
| 身份 | `table`、`MQTT_username`、`MQTT_password`、`MQTT_client_id`、`MQTT_subject` |
| 服务器 | `first-ip`、`scend-ip`、`user-ip`（值格式 `IP.端口`） |
| 窗口 | `window_pattern`、`window_end_result`、`window_start`、`window_stop`、`window_dottime` |
| 周期 | `collect_once`、`collect_type`、`report_once`、`report_type` |
| 压力阈值 | `vpthreshold_switch/ppmax/pmax/ppmin/pmin/mutation/shock`、`vpthreshold2_*` |
| 温度阈值 | `Tthreshold_switch/high/low/vhigh/vlow`、`Tthreshold2_*` |
| 电压保护 | `spupower_switch/high/low/protect` |
| 阀门延时 | `delay_switch`、`delay_time` |
| 实时采样 | `real_enabled`、`real_frequency` |
| 定时开关阀 | `timing_onswitch`、`timing_offswitch`、`timing_open`、`timing_close` |
| 关阀策略 | `abnormal_close`、`abnormal2_close`、`abnormal3_close` |
| 甲烷 | `msh_threshold`、`laser_switch`、`laser_time` |
| 显示 | `lcd_switch` |

### 9.4 设备信息类

| 字段 | 含义 | 示例 |
|------|------|------|
| `csq` | 信号强度 0–31，99 = 未知 | `22` |
| `rsrp` | 参考信号接收功率（dBm） | `-85` |
| `snr` | 信噪比 | `12` |
| `cereg` | 网络注册状态（1 = 本地，5 = 漫游） | `1` |
| `soft-version` | 固件版本字符串 | `1` |
| `ICCID` | SIM 卡 ICCID | `8986...` |
| `IMEI` | 模组 IMEI | `86...` |

---

## 10. 反馈码字典

指令处理结果统一以 `[{"id":"feedback","value":"<码>","ts":"...","remark":""}]` 上报（`report.c:39-45`）。
**完整清单（依 `downlink.c` 全部调用点整理，无缺口）**：

| 码 | 含义 | 相关指令 | 依据 |
|----|------|----------|------|
| 1 | **服务器地址读取成功** | `first-ip-get`、`scend-ip-get`、`user-ip-get`、`get-ip` | `report.c:48-66`（`fb_code=1`） |
| 2 | **服务器地址配置成功** | `first-ip-set`、`scend-ip-set`、`user-ip-set` | `downlink.c:898,923,1128` |
| 3 | 窗口参数读取成功 | `window-get` | `downlink.c:715` |
| 4 | 窗口参数配置成功 | `window-set` | 同上 |
| 5 | 温度阈值读取成功 / 批量阈值查询成功 | `Tthreshold-get`、`Tthreshold-get2`、`threshold-get1` | `downlink.c:277,677` |
| 6 | 温度阈值配置成功 | `Tthreshold-set`、`Tthreshold-set2` | `downlink.c:277` |
| 7 | 压力阈值读取成功 | `vpthreshold-get1`、`vpthreshold-get2` | `downlink.c:276` |
| 8 | 压力阈值配置成功 | `vpthreshold-set1`、`vpthreshold-set2` | 同上 |
| 9 | 上报周期读取成功 | `report-get` | `downlink.c:522` |
| 10 | 上报周期配置成功 | `report-set` | 同上 |
| 11 | 采集周期读取成功 | `collectcycle-get` | `downlink.c:492` |
| 12 | 采集周期配置成功 | `collectspeed-set` | 同上 |
| 13 | 实时采样参数读取成功 | `real-get` | `downlink.c:1035` |
| 14 | 实时采样参数配置成功 | `real-set` | 同上 |
| 15 | 电压监测读取成功 | `spupower-get` | `downlink.c:278` |
| 16 | 电压监测配置成功 | `spupower-set` | 同上 |
| 17 | 用户端 MQTT 读取成功 | `MQTT-get` | `downlink.c:1172` |
| 18 | 用户端 MQTT 配置成功 | `MQTT-set` | 同上 |
| 19 | 阀门延时读取成功 | `delay-get` | `downlink.c:279` |
| 20 | 阀门延时配置成功 | `delay-set` | 同上 |
| 21 | 定时开关阀读取成功 | `closeoropen-get` | `downlink.c:1253` |
| 22 | 定时开关阀配置成功 | `closeoropen-set` | 同上 |
| 23 | **阀门控制执行完成** | `valve-open`、`valve-close` | `downlink.c:402` |
| 24 | **服务器地址格式错误** | `first-ip-set`、`scend-ip-set`、`user-ip-set` | `downlink.c:904,929,1134` |
| 25 | 阀门状态读取成功 | `valve-get` | `downlink.c:1184` |
| 26 | 表号读取成功 | `table-get` | `downlink.c:1301` |
| 27 | 表号配置成功 | `table-set` | 同上 |
| 28 | 异常关阀策略读取成功 | `abnormal-get`、`abnormal2-get`、`abnormal3-get` | `downlink.c:730,744,763` |
| 29 | 异常关阀策略配置成功 | `abnormal-set`、`abnormal2-set`、`abnormal3-set` | 同上 |
| 30 | **压力状态获取成功** | `get-pressure1`、`get-pressure2`、`sensor_read` | `downlink.c:437,1101` |
| 31 | **温度状态获取成功** | `temp-get1`、`temp-get2` | `downlink.c:960,1082` |
| 32 | 激光甲烷状态获取成功 | `gas-get` | `ch4_alarm.c:96` |
| 33 | 激光采集时间点读取成功 | `laser-get` | `downlink.c:576` |
| 34 | 激光采集时间点配置成功 | `laser-set` | `downlink.c:597` |
| 35 | 甲烷门限值获取成功 | `msh-get` | `downlink.c:630` |
| 36 | 甲烷门限值配置成功 | `msh-set` | `downlink.c:651` |
| 37 | **状态强制转换成功** | `install-status-set` | `downlink.c:795,805` |

**未定义/保留**：`0`、`38` 及以上固件未使用。

---

## 11. OTA 升级协议

### 11.1 主题与下行字段

| 项目 | 内容 |
|------|------|
| 下发主题 | `/<产品ID>/<设备ID>/upgrade/set`（设备订阅，msgid=2） |
| 回执主题 | `/<产品ID>/<设备ID>/upgrade/reply` |
| 过程状态主题 | 数据主题 `.../property/post`（`id = "upgrade"`） |
| 下行字段 | `downloadUrl`（必填，字符串，HTTP/HTTPS URL）、`version`（必填，整数） |
| 依据 | `ec800e.c:1097-1144`、`ota_app.c:237-238`、`downlink.c:1517-1530` |

```
{"version":2,"downloadUrl":"http://your-host/firmware_v2.bin"}
```

判定：主题含 `/upgrade/`，**或**报文任意位置含 `downloadUrl`（双保险，`downlink.c:1517-1530`）。

### 11.2 升级流程

`ota_app.c:227-385`：

```
1. 解析 downloadUrl / version
2. 前置条件检查
   · 电压：voltage_low_power 或 V < 2.6 V  → 拒绝（状态 4 / 回执 4）
   · 信号：CSQ < 8 或 CSQ == 99            → 拒绝（状态 3 / 回执 4）
3. 立即回执 {"mqttUpgradeReply":2}          ← 表示"已接受、升级中"
4. 版本检查：version 必须 > 当前版本且非 0   → 否则状态 9 / 回执 4
5. 状态 0（升级中），启用独立看门狗（约 26.2 s）
6. 擦除下载缓存区 0x08022000（120 KB）
7. HTTP 下载（AT+QHTTPCFG/QIACT/QHTTPURL/QHTTPGET/QHTTPREAD）边收边写 Flash
8. 校验：尺寸为 0 或 > 116 KB(OTA_APP_SIZE) → 状态 6 / 回执 4；否则状态 5
9. 写 InfoBlock（magic 0xAABB1122，status=PENDING，new_fw_size，new_fw_version）
10. 状态 8（准备重启）→ 延时 500 ms → NVIC_SystemReset()
11. Bootloader：校验缓存向量表 → 擦除 App 区 → 搬运 → 读回比对
    → status=SUCCESS → 跳转 App
12. App 启动：上报回执 3 或 4（依 InfoBlock），并清 InfoBlock
```

**Flash 分区**（`ota_info.h:26-42`）：

| 区域 | 地址 | 大小 |
|------|------|------|
| Bootloader | `0x08000000` | 16 KB |
| InfoBlock（升级标志） | `0x08004000` | 4 KB |
| App | `0x08005000` | 116 KB |
| 下载缓存 | `0x08022000` | 120 KB |

**校验**：4G 通道**仅校验文件尺寸范围**（无 MD5/CRC）；完整性最终依赖 Bootloader 的向量表校验 + 搬运后读回比对，失败重试上限 3 次（`boot_main.c:295-385`）。
**HTTP 要求**：响应码 200（或 -1），`Content-Length > 0` 且 ≤ 缓存区大小；30 s 无数据即中止。

### 11.3 回执码 `{"mqttUpgradeReply":<码>}`

| 码 | 含义 | 依据 |
|----|------|------|
| 0 | AWAIT（保留） | `ota_info.h:57-65` |
| 1 | SEND（保留） | 同上 |
| 2 | **REPLY / 接受升级中** | `ota_app.c:279` |
| 3 | **SUCCESS / 升级成功** | `ota_app.c:388-420` |
| 4 | **FAILED / 升级失败或前置条件不满足** | 多处 |
| 5 | STOP（保留，`ota_app_report_stop()` 无调用点） | `ota_app.c:423-426` |
| 404 | UNKNOWN（保留） | `ota_info.h:65` |

### 11.4 过程状态 `{"id":"upgrade","value":"<n>"}`

| 值 | 含义 |
|----|------|
| 0 | 升级中 |
| 1 | 成功 |
| 2 | 失败 |
| 3 | 拒绝：信号不足 |
| 4 | 拒绝：电压不足 |
| 5 | 校验通过 |
| 6 | 校验失败 |
| 7 | 下载中 |
| 8 | 准备重启 |
| 9 | 拒绝：版本不高于当前版本 |

依据 `ota_app.c:22-45`。

---

## 12. 报警与自动关阀

### 12.1 报警确认流程

1. 采集/实时检测判定异常 → **3 次重采**（间隔 500 ms，`APP_ALARM_RECHECK_COUNT`/`APP_ALARM_RECHECK_DELAY_MS`，`app_config.h:165-166`）；
2. 任一拍恢复正常 → 判为偶发，不报警；
3. 确认异常 → 写报警记录（`SENSOR_FLAG_ALARM = 0x01`）→ 按策略关阀 → 上报。

**报警上报序列**（`main.c:2556-2578`）：

| 序 | 报文 | 条件 |
|----|------|------|
| 1 | `temp,pressure,temp-status,pressure-status`(+2)（`report_publish_alarm_batch`） | 总是 |
| 2 | `LY06,voltage`（`report_publish_ly06(1, V)`） | 报警类型为 VPROTECT / VOLT_HIGH / VOLT_LOW |
| 3 | `valve-control,valve-last-order` | 发生自动关阀时 |

**恢复上报**（一次性，`g_alarm_recover_reported` 去重，`main.c:1388-1404,2425-2457`）：

| 序 | 报文 |
|----|------|
| 1 | `valve-control,valve-last-order`（仅关阀恢复路径） |
| 2 | `LY06,voltage`（`LY06=0`） |
| 3 | `temp,pressure,temp-status,pressure-status`(+2) |

### 12.2 报警与关阀的对应关系

| 报警类型 | 是否关阀 | 说明 |
|----------|----------|------|
| 压力超高 / 超低 / 骤变 | **取决于策略** | 仅当 `abnormal_close`(进气端) / `abnormal2_close`(出气端) 包含对应项 |
| 压力普通档（pmax/pmin） | ❌ | 只上报 |
| 温度各档 | ❌ | 只上报 |
| 电压各档（含 VPROTECT） | ❌ | 只上报；VPROTECT 另外触发 VLP 省电 |
| 甲烷超门限 | **取决于 `abnormal3_close`** | 硬件选配 |

**关阀闭锁**：自动关阀后置 `g_valve_alarm_closed` / `g_ch4_alarm_closed` 并写 EEPROM，**重启/升级后仍保持关闭**，直至平台下发 `valve-open`（`downlink.c:383-395`、`eeprom_config.h:452-454`）。

### 12.3 低电压保护（VLP）

| 项目 | 内容 |
|------|------|
| 进入 | `spupower.enabled=1` 且 `protect>0` 且 `V < protect - 0.1` |
| 退出 | 检测关闭，或 `V >= protect + 0.15` |
| 上报频率 | **每天 08:00 与 18:00 各一次**（`main.c:2135-2161`） |
| 4G | 强制断电（休眠期） |
| 关阀 | **不关阀** |
| OTA | 拒绝升级 |
| 状态跨重启 | `voltage_low_power` 写 EEPROM 持久化 |

---

## 13. 设备运行行为

### 13.1 状态机（9 状态）

| 状态 | 职责 | 后继 |
|------|------|------|
| `STATE_INIT` | 上电初始化 → 加载 EEPROM → 首次采集 → 连 MQTT → 首报（记录 / `restart=1` / 设备信息 / 汇总） | `STATE_SLEEP` |
| `STATE_SLEEP` | 配置低功耗 GPIO → 设 RTC 闹钟 → 深休眠；实时模式内嵌秒级采集循环 | 依唤醒标志 |
| `STATE_WAKEUP` | 恢复外设、判定唤醒源并路由 | `COLLECT`/`UPLOAD`/`DOWNLINK`/`SLEEP` |
| `STATE_COLLECT` | 采集 → 阈值检查 → 写历史；含定时阀检查 | `ALARM`/`UPLOAD`/`SLEEP` |
| `STATE_UPLOAD` | 窗口判定 → 连 4G → 逐条上报历史 → 汇总上报 → 网络对时 | `SLEEP` |
| `STATE_DOWNLINK` | 排空并处理所有下行指令 | `CH4`/`SLEEP` |
| `STATE_ALARM` | 3 次重采确认 → 报警上报 → 自动关阀 | `UPLOAD`/`SLEEP` |
| `STATE_CH4` | 甲烷采集状态机（硬件选配） | `SLEEP` |
| `STATE_BLE_OTA` | 蓝牙 OTA（`BLE_ENABLED=0` 不编译） | `SLEEP` |

依据 `main.h:12-22`、`main.c:1535-2108,2217-2897`。

### 13.2 唤醒源（4 类）

| 唤醒源 | 中断 | 路由 |
|--------|------|------|
| RTC 闹钟 | `RTC_Alarm_IRQHandler` | 采集到期 → `COLLECT`；上报到期 → `UPLOAD`；定时阀 → `COLLECT`；实时模式 → 秒级采集 |
| LPUART 接收（4G 下行/URC） | `LPUART_WKUP_IRQHandler` | 完整初始化 → `DOWNLINK` |
| 按键（PD0） | `EXTI0_IRQHandler` | 点亮 LCD / 翻页 → 回 `SLEEP` |
| 4G RI（PA1） | `EXTI1_IRQHandler` | 完整初始化 → `DOWNLINK`（与 LPUART 互为冗余） |

依据 `gd32l23x_it.c:129-196`、`wakeup.c:41`、`main.c:1928-2108`。

### 13.3 上报调度与防重

- **网格对齐**：`day`/`week` 周期以 1999-12-27（周一）为第 0 天的绝对分钟轴计算，保证「每 N 天 00:00」「每周一 00:00」（`config_policy.c:151-204`）；
- **跨重启防重**：成功上报后把「上报周期序号」写入 EEPROM（`EE_ADDR_UPL_DONE_IDX`，magic 0xCD），重启后沿用（`eeprom_config.h:246-253`）；
- **周期变更**：`collectspeed-set` / `report-set` 会重置网格锁存，严格等到下一个目标时刻；
- **上报后延**：`g_report_delay_min`（0–60 min，支持小数），仅可通过调试串口 `{id:delay_report,value:1.5}` 配置，**平台无对应指令**；
- **弱信号保护**：CSQ < 8 或 = 99 时 `long` 模式主动断 4G（`main.c:876-955`）。

### 13.4 安装（校零）流程

`CALIB_MODE_ENABLED = 1`（`app_config.h:120`）时启用：

- 无「已安装」标志 → 开机进入校零模式，采样周期固定 1 分钟（`CALIB_SAMPLE_MIN`）；
- 零压窗 ±900 Pa 内持续更新零点；`|raw| ≥ 1000 Pa` 连续 5 次 → **自动锁定为已安装**，并触发一次性安装上报（传感器记录 + `product-status=1`）；
- 校零期间：禁用实时模式、不写历史记录、每天 10:00 一次占位上报；
- `product-status` 由 `install-status-set`（反馈 37）或自动判定变更。

依据 `calib_mode.h:15-44`、`calib_mode.c:247-323`、`main.c:475-559`。

### 13.5 定时开关阀

- 判定周期：主循环每次迭代检查（无固定 tick），由 RTC 闹钟在最近事件时刻唤醒（`main.c:1163-1197,3571`）；
- 匹配容差 ±30 s；每天每方向最多执行一次；
- 甲烷关阀 / 报警关阀闭锁期间，**定时开阀被跳过**（`main.c:1243-1248`）；
- 执行后 4G 可用则上报 `valve-control,valve-last-order`（`main.c:1240-1260`）。

---

## 14. 与《指令集.xlsx》的差异说明

规范依据「固件实测行为」编写。以下为 `指令集.xlsx` 与固件的差异，**建议按「固件实际」修订表格**。
（下表「表内位置」的行号指 xlsx 的**物理行号**：第 3 行为表头，第 4–34 行为 31 条指令。）

| # | 表内位置 | 表内写法 | 固件实际 | 依据 |
|---|----------|----------|----------|------|
| 1 | 第 13 行「阀门状态获取」 | `commandStr = get-pressure2` | **应为 `valve-get`**；`get-pressure2` 是「出气端压力读取」（第 12 行），两者重码 | `downlink.c:116,158` |
| 2 | 第 14 行备注 | 「`timing_onswitchd`」「`timing_offswitchd`」 | 字段名为 `timing_onswitch` / `timing_offswitch`（无尾字母 d） | `downlink.c:1199-1202` |
| 3 | 第 13 行备注 | 参数示例包含大量缩进换行 | 参数提取要求 `"id","value"` **紧邻无空白**；美化排版会导致参数丢失 | `downlink.c:65-87`（实测见 5.3） |
| 4 | 第 3 行表头 | 表头为「功能 / 指令 / 备注」三项 | 与固件一致；但工作表 A、B 两列为空列，**有效数据列仅 C/D/E**（建议删除空列，避免下游解析歧义） | `指令集.xlsx` sheet1 原始 XML |
| 5 | 全表 | 未收录 `valve-get`、`threshold-get1`、`sensor-status`、`get-sim`、`valve-last-get`、`lcd-switch`、`keepalive`、`sensor_read` | 固件共支持 **62 条 `commandStr`**（+格式 A 专用 id），见 8.1 | `downlink.c:97-164` |
| 6 | 第 24 行备注 | 上报间隔模式仅列 `minute、hour、day、week` | 固件 `sec` 也接受（`cycle_type_from_str` 支持 5 种单位） | `config_policy.c:78-86` |
| 7 | 第 25 行备注 | 采集间隔模式列 `sec、minute、hour、day` | 固件 `week` 也接受，但采集周期用 `week` 无实际意义，建议平台限制为表列 4 种 | `config_policy.c:78-86` |
| 8 | 第 28 行 | 电压保护参数无默认值说明 | 出厂默认 `switch=1, high=0.00, low=2.80, protect=0.00` | `eeprom_config.h:302-306` |
| 9 | 第 20/21/22/23 行 | 未说明阈值「不校验范围」 | 固件 float 阈值用 `atof` 直写、**无范围校验**；平台必须自行保证物理合理值 | `downlink.c:341-343` |
| 10 | 第 4 行 | `table-set` 示例值 `D94C86Z7RFBIS` | 与默认 `client_id` 的「设备ID」段长度一致，可直接使用 | `downlink.c:1263-1284` |
| 11 | 第 19 行备注 | 窗口模式表格用 Markdown 语法混排 | 三种模式行为描述与固件一致，仅格式需调整为正文 | `main.c:2165-2190`、`config_policy.c:256-290` |
| 12 | 第 30 行 | `restart-off` | 固件同时接受 `restart`；两者行为相同（先回 `restart=0` 再复位） | `downlink.c:992-1000,1336-1337` |

---

## 15. 附录

### 15.1 调试串口命令（USART0，115200，仅工程调试用）

`eeprom_config.c:254-470`、`config_store.c`：

| 命令 | 说明 |
|------|------|
| `reset` | 恢复出厂：清除所有 EEPROM Magic + 校零状态，重启 |
| `{id:mqtt,server:IP,port:1883,client:xxx,user:xxx,pass:xxx}` | 配置主通道 |
| `{id:umqtt,...}` | 配置用户通道 |
| `{id:collect_cycle,once:22,type:minute}` | 采集周期 |
| `{id:report_cycle,once:12,type:minute}` | 上报周期 |
| `{id:window_pattern,value:short,start:080000,stop:200000,end_result:1,dottime:3}` | 窗口 |
| `{id:vpthreshold,en:1,ppmax:..,pmax:..,ppmin:..,pmin:..,mut:..,shock:..}` | 压力阈值 |
| `{id:Tthreshold,...}` / `{id:spupower,...}` / `{id:vdelay,...}` | 温度 / 电压 / 延时 |
| `{id:keepalive,value:300}` | 心跳 |
| `{id:delay_report,value:1.5}` | **周期上报后延（0–60 min，平台无对应指令）** |
| `{id:valve_timeout,value:40000}` | **阀门到位超时（1000–120000 ms，平台无对应指令）** |
| `{id:abnormal,value:pvhigh}` | 异常关阀策略（进气端） |
| `config` | 打印当前全部配置 |
| `vpthreshold_get` / `Tthreshold_get` / `spupower_get` / `delay_get` | 分组查询 |
| `ip` / `umqtt_get` / `valve_status` | 单项查询 |
| `lcd_switch=0/1` | LCD 开关 |

> `delay_report` 与 `valve_timeout` **仅调试串口可改**；若需平台远程配置，固件需新增指令。

### 15.2 EEPROM 配置布局（AT24C64）

| 区块 | 地址 | Magic | 内容 |
|------|------|-------|------|
| 1 间隔 | 0x000 | 0xA5 | collect/upload_interval_hours |
| 2 MQTT | 0x020 | 0x5A | client_id / user / pass / port / server / topic_up |
| 3 压力阈值 | 0x1B0 | 0xC0 | vpthreshold_* + keepalive_sec |
| 4 温度阈值 | 0x1D0 | 0xC1 | Tthreshold_* |
| 5 电压检测 | 0x1F0 | 0xC2 | spupower_* |
| 6 扩展 | 0x200 | 0xB7 | window / cycle / abnormal_close / valve_last_order / server2 / real_* / lcd / sensor_count / vlp / report_delay |
| 7 阀门延时 | 0x290 | 0xC3 | delay_switch / delay_ms / valve_timeout_ms |
| 8 出气压力阈值 | 0x2A0 | 0xC4 | vpthreshold2_* |
| 9 出气温度阈值 | 0x2C0 | 0xC5 | Tthreshold2_* |
| 10 用户端 MQTT | 0x300 | 0xC6 | server / port / user / pass / client_id / topic_up |
| 11 定时开关阀 | 0x490 | 0xC8 | on_switch / off_switch / open_time / close_time |
| 12 CH4 门限 | 0x4B0 | 0xC9 | warmup_sec / threshold |
| 13 激光定时 | 0x4C0 | 0xCA | laser_switch / laser_time 位图 |
| 14 出气/激光关阀 | 0x4D0 | 0xCB | abnormal2_close / abnormal3_close |
| 16 上报防重锁 | 0x500 | 0xCD | last_upload_idx |
| 历史记录区 | 0x800–0x1FFF | — | 191 条 × 32 B，环满覆盖最旧 |

依据 `eeprom_config.h:7-253`、`eeprom_history.h:29-34`。

### 15.3 关键常量

| 常量 | 值 | 说明 |
|------|-----|------|
| `APP_MQTT_KEEPALIVE` | 300 s | 主通道心跳默认 |
| `MQTT_FIELD_MAX` / `MQTT_TOPIC_MAX` | 64 B / 128 B | 字段 / 主题长度 |
| `APP_ALARM_RECHECK_COUNT` | 3 | 报警重采次数 |
| `APP_ALARM_RECHECK_DELAY_MS` | 500 ms | 重采间隔 |
| `VDLY_DELAY_MS_MAX` | 5000 ms | 阀门到位保持上限 |
| `DEF_VALVE_TIMEOUT_MS` | 40000 ms | 阀门到位等待超时 |
| `VALVE_TIMEOUT_MS_MIN/MAX` | 1000 / 120000 ms | 超时配置范围 |
| `FOURG_SUPERVISE_INTERVAL_MIN` | 30 min | `long` 模式 4G 巡检间隔 |
| `CSQ_WEAK_THRESHOLD` | 8 | 弱信号判定 |
| `OTA_vol_protection` | 2.6 V | OTA 最低电压 |
| `OTA_CSQ_MIN` | 8 | OTA 最低信号 |
| `OTA_APP_SIZE` / `OTA_CACHE_SIZE` | 116 KB / 120 KB | OTA 分区 |
| `DEF_CH4_THRESHOLD` | 0.50 %VOL | 甲烷门限默认 |

### 15.4 典型交互示例（紧凑报文，可直接复用）

**1) 平台读取窗口配置**

```
→ {"commandStr":"window-get","value":"0"}
← [{"id":"window_pattern","value":"short","ts":"2026-10-15 08:30:00","remark":""},
   {"id":"window_end_result","value":"1","ts":"...","remark":""},
   {"id":"window_start","value":"000000","ts":"...","remark":""},
   {"id":"window_stop","value":"000000","ts":"...","remark":""},
   {"id":"window_dottime","value":"","ts":"...","remark":""}]
← [{"id":"feedback","value":"3","ts":"...","remark":""}]
```

**2) 平台配置进气端压力阈值（部分参数）**

```
→ {"commandParms":[{"id":"vpthreshold_switch","value":"1"},{"id":"vpthreshold_pmax","value":"18000.00"},{"id":"vpthreshold_ppmax","value":"25000.00"},{"id":"vpthreshold_shock","value":"200.00"}],"commandStr":"vpthreshold-set1","value":"0"}
← [{"id":"vpthreshold_switch","value":"1",...},{"id":"vpthreshold_ppmax","value":"25000.00",...},
   {"id":"vpthreshold_pmax","value":"18000.00",...},{"id":"vpthreshold_ppmin","value":"0.00",...},
   {"id":"vpthreshold_pmin","value":"0.00",...},{"id":"vpthreshold_mutation","value":"0.00",...},
   {"id":"vpthreshold_shock","value":"200.00",...}]
← [{"id":"feedback","value":"8",...}]
```

**3) 开启「压力超高即关阀」并查询确认**

```
→ {"commandParms":[{"id":"abnormal_close","value":"pvhigh"}],"commandStr":"abnormal-set","value":"0"}
← [{"id":"abnormal_close","value":"pvhigh","ts":"...","remark":""}]
← [{"id":"feedback","value":"29","ts":"...","remark":""}]
```

**4) 报警后远程恢复供气**

```
→ {"commandStr":"valve-open","value":"0"}
← [{"id":"valve-control","value":"valve-on","ts":"...","remark":""},
   {"id":"valve-last-order","value":"1","ts":"...","remark":""}]
← [{"id":"feedback","value":"23","ts":"...","remark":""}]
```

**5) OTA 升级下发**

```
→（主题 .../upgrade/set）{"version":2,"downloadUrl":"http://host/fw_v2.bin"}
←（主题 .../upgrade/reply）{"mqttUpgradeReply":2}      设备已接受，开始下载
←（主题 .../property/post）[{"id":"upgrade","value":"0",...}]   升级中
←（主题 .../property/post）[{"id":"upgrade","value":"5",...}]   校验通过
←（设备重启，Bootloader 搬运完成）
←（主题 .../upgrade/reply）{"mqttUpgradeReply":3}      升级成功
```

**6) 强制标记为已安装**

```
→ {"commandParms":[{"id":"install-status","value":"1"}],"commandStr":"install-status-set","value":"0"}
← [{"id":"temp","value":"25.60",...},{"id":"pressure","value":"1024.00",...}]   安装事件记录
← [{"id":"product-status","value":"1",...}]
← [{"id":"feedback","value":"37",...}]
```

### 15.5 版本历史

| 版本 | 日期 | 说明 |
|------|------|------|
| V1.0 | 2026-10-15 | 首次发布。覆盖 `指令集.xlsx` 全部 31 条指令 + 固件扩展指令共 62 条 `commandStr`；新增传输层、报文编码硬约束、数据字典、反馈码全表（1–37）、OTA 协议、运行行为及差异勘误。 |

---

*本文档由固件源码逐条核对生成，全部规范条目均附 `文件:行号` 出处，可直接用于平台侧开发与联调验收。*

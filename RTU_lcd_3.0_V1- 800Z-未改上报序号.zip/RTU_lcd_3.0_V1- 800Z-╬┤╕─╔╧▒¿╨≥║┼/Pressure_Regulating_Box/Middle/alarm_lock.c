/**
 * @file alarm_lock.c
 * @brief 告警等级锁 + 恢复去抖 (周期/实时/查询三条路径共用)
 *
 * 与旧实现(整块状态向量 memcmp)的区别:
 *  - 每个通道分别记录压力等级与温度等级, 不因另一通道/另一物理量变化而重报;
 *  - 恢复必须连续 N 拍正常才解锁, 单次正常不清锁;
 *  - 查询路径只读锁 + 锁新等级, 不推进恢复计数;
 *  - 锁跨重启持久化(5 分钟节流写), 持续中的告警不重报。
 */

#include "alarm_lock.h"
#include "config_store.h"
#include "config_policy.h"
#include "eeprom_config.h"
#include "usart.h"
#include <string.h>

/* ==================== 内部状态 ==================== */
static uint8_t  s_last_r[ALARM_LOCK_CH_COUNT];   /* 最后已上报的压力/突变等级 */
static uint8_t  s_last_t[ALARM_LOCK_CH_COUNT];   /* 最后已上报的温度等级 */
static uint8_t  s_streak[ALARM_LOCK_CH_COUNT];   /* 连续正常拍数 */
static uint8_t  s_volt_latched;                  /* 电压锁 0/1 */
static uint8_t  s_volt_streak;                   /* 电压连续正常拍数 */
static uint8_t  s_dirty;                         /* 有未落盘变更 */
static uint32_t s_last_save_min = 0xFFFFFFFFu;   /* 上次落盘绝对分钟 (0xFFFFFFFF=从未) */

/* ==================== 内部工具 ==================== */
static uint8_t alk_crc8(const uint8_t *data, uint16_t len)
{
    uint8_t crc = 0x00;
    uint16_t i;
    uint8_t bit;

    for(i = 0; i < len; i++)
    {
        crc ^= data[i];
        for(bit = 0; bit < 8; bit++)
        {
            if(crc & 0x80)
                crc = (uint8_t)((crc << 1) ^ 0x07u);
            else
                crc = (uint8_t)(crc << 1);
        }
    }
    return crc;
}

/* 电压类报警码: 不进入通道锁 */
static uint8_t alk_is_volt_code(ThresholdResult_t r)
{
    return (r == THRESHOLD_VPROTECT ||
            r == THRESHOLD_VOLT_HIGH ||
            r == THRESHOLD_VOLT_LOW) ? 1u : 0u;
}

/* 通道压力等级码合法性: 0~THRESHOLD_VOLT_LOW 且非电压码 */
static uint8_t alk_valid_r(uint8_t r)
{
    if(r > (uint8_t)THRESHOLD_VOLT_LOW)
        return 0u;
    return alk_is_volt_code((ThresholdResult_t)r) ? 0u : 1u;
}

static uint8_t alk_valid_t(uint8_t t)
{
    return (t <= (uint8_t)TEMP_VERY_LOW) ? 1u : 0u;
}

/* 单路机型强制清通道1 */
static void alk_force_clear_disabled(void)
{
    uint8_t ch;
    for(ch = 0; ch < ALARM_LOCK_CH_COUNT; ch++)
    {
        if(alarm_lock_ch_enabled(ch))
            continue;
        if(s_last_r[ch] != 0u || s_last_t[ch] != 0u || s_streak[ch] != 0u)
        {
            s_last_r[ch] = 0u;
            s_last_t[ch] = 0u;
            s_streak[ch] = 0u;
            s_dirty = 1u;
        }
    }
}

/* ==================== 对外接口 ==================== */
void alarm_lock_init(void)
{
    uint8_t buf[6];          /* data(5) + crc(1) */
    uint8_t magic = 0u;
    uint8_t ok = 0u;

    memset(s_last_r, 0, sizeof(s_last_r));
    memset(s_last_t, 0, sizeof(s_last_t));
    memset(s_streak, 0, sizeof(s_streak));
    s_volt_latched = 0u;
    s_volt_streak  = 0u;
    s_dirty        = 0u;
    s_last_save_min = 0xFFFFFFFFu;

    EE_READ(EE_ADDR_ALK_MAGIC, &magic, 1);
    if(magic == EE_MAGIC_ALK)
    {
        EE_READ(EE_ADDR_ALK_DATA, buf, sizeof(buf));
        if(buf[5] == alk_crc8(buf, 5u) &&
           alk_valid_r(buf[0]) && alk_valid_r(buf[1]) &&
           alk_valid_t(buf[2]) && alk_valid_t(buf[3]) &&
           buf[4] <= 1u)
        {
            s_last_r[0]   = buf[0];
            s_last_r[1]   = buf[1];
            s_last_t[0]   = buf[2];
            s_last_t[1]   = buf[3];
            s_volt_latched = buf[4];
            ok = 1u;
        }
    }

    alk_force_clear_disabled();

    if(!ok || s_dirty)
        alarm_lock_save(1);   /* 首次上电/数据损坏/单路清位: 立即落盘 */

    printf_debug("[ALK] init: ch0 r=%u t=%u | ch1 r=%u t=%u | volt=%u%s\r\n",
                 s_last_r[0], s_last_t[0], s_last_r[1], s_last_t[1],
                 s_volt_latched, ok ? "" : " (reset)");
}

void alarm_lock_clear_all(void)
{
    memset(s_last_r, 0, sizeof(s_last_r));
    memset(s_last_t, 0, sizeof(s_last_t));
    memset(s_streak, 0, sizeof(s_streak));
    s_volt_latched = 0u;
    s_volt_streak  = 0u;
    s_dirty        = 1u;

    alarm_lock_save(1);   /* 手动开阀: 立即落盘 */
    printf_debug("[ALK] clear all (manual valve open)\r\n");
}

uint8_t alarm_lock_ch_enabled(uint8_t ch)
{
    if(ch == 0u)
        return 1u;
    if(ch == 1u)
        return (g_sensor_count >= 2u) ? 1u : 0u;
    return 0u;
}

uint8_t alarm_lock_has_new(uint8_t ch, ThresholdResult_t r, TempStatus_t ts)
{
    if(ch >= ALARM_LOCK_CH_COUNT || !alarm_lock_ch_enabled(ch))
        return 0u;

    /* 压力/突变等级变化 (电压码不参与通道锁) */
    if(r != THRESHOLD_OK && !alk_is_volt_code(r) &&
       (uint8_t)r != s_last_r[ch])
        return 1u;

    /* 温度等级变化 */
    if(ts != TEMP_NORMAL && (uint8_t)ts != s_last_t[ch])
        return 1u;

    return 0u;
}

void alarm_lock_latch(uint8_t ch, ThresholdResult_t r, TempStatus_t ts)
{
    uint8_t changed = 0u;

    if(ch >= ALARM_LOCK_CH_COUNT)
        return;

    if(!alarm_lock_ch_enabled(ch))
    {
        if(s_last_r[ch] != 0u || s_last_t[ch] != 0u)
        {
            s_last_r[ch] = 0u;
            s_last_t[ch] = 0u;
            s_streak[ch] = 0u;
            s_dirty = 1u;
            alarm_lock_save(0);
        }
        return;
    }

    if(r != THRESHOLD_OK && !alk_is_volt_code(r) &&
       (uint8_t)r != s_last_r[ch])
    {
        s_last_r[ch] = (uint8_t)r;
        changed = 1u;
    }

    /* last_t 总是跟随当前温度等级 */
    if((uint8_t)ts != s_last_t[ch])
    {
        s_last_t[ch] = (uint8_t)ts;
        changed = 1u;
    }

    if(changed)
    {
        s_streak[ch] = 0u;   /* 新等级: 恢复计数重新起算 */
        s_dirty = 1u;
        printf_debug("[ALK] ch%u latch r=%u t=%u\r\n",
                     ch, s_last_r[ch], s_last_t[ch]);
        alarm_lock_save(0);
    }
}

uint8_t alarm_lock_feed_normal(uint8_t ch, uint8_t online,
                               ThresholdResult_t r, TempStatus_t ts)
{
    if(ch >= ALARM_LOCK_CH_COUNT)
        return 0u;

    if(!alarm_lock_ch_enabled(ch))
    {
        /* 未启用通道: 锁位与计数强制清零, 不产生恢复上报 */
        s_streak[ch] = 0u;
        if(s_last_r[ch] != 0u || s_last_t[ch] != 0u)
        {
            s_last_r[ch] = 0u;
            s_last_t[ch] = 0u;
            s_dirty = 1u;
        }
        return 0u;
    }

    /* 离线 / 任一异常: 计数归零, 保留最后等级 */
    if(!online || r != THRESHOLD_OK || ts != TEMP_NORMAL)
    {
        s_streak[ch] = 0u;
        return 0u;
    }

    if(s_streak[ch] < ALARM_LOCK_CLEAR_COUNT)
        s_streak[ch]++;

    if(s_streak[ch] >= ALARM_LOCK_CLEAR_COUNT &&
       (s_last_r[ch] != 0u || s_last_t[ch] != 0u))
    {
        s_last_r[ch] = 0u;
        s_last_t[ch] = 0u;
        s_streak[ch] = 0u;
        s_dirty = 1u;
        printf_debug("[ALK] unlocked ch%u\r\n", ch);
        alarm_lock_save(0);
        return 1u;
    }

    return 0u;
}

uint8_t alarm_lock_volt_has_new(ThresholdResult_t r)
{
    return (alk_is_volt_code(r) && !s_volt_latched) ? 1u : 0u;
}

void alarm_lock_volt_latch(void)
{
    if(s_volt_latched)
        return;

    s_volt_latched = 1u;
    s_volt_streak  = 0u;
    s_dirty        = 1u;
    printf_debug("[ALK] voltage latch\r\n");
    alarm_lock_save(0);
}

uint8_t alarm_lock_volt_feed_normal(ThresholdResult_t r, uint8_t voltage_checked)
{
    /* 未做电压判定的路径不得触碰电压锁 */
    if(!voltage_checked)
        return 0u;

    if(alk_is_volt_code(r))
    {
        s_volt_streak = 0u;
        return 0u;
    }

    if(s_volt_streak < ALARM_LOCK_CLEAR_COUNT)
        s_volt_streak++;

    if(s_volt_streak >= ALARM_LOCK_CLEAR_COUNT && s_volt_latched)
    {
        s_volt_latched = 0u;
        s_volt_streak  = 0u;
        s_dirty        = 1u;
        printf_debug("[ALK] voltage unlocked\r\n");
        alarm_lock_save(0);
        return 1u;
    }

    return 0u;
}

uint8_t alarm_lock_ch_latched(uint8_t ch)
{
    if(ch >= ALARM_LOCK_CH_COUNT)
        return 0u;
    return (s_last_r[ch] != 0u || s_last_t[ch] != 0u) ? 1u : 0u;
}

uint8_t alarm_lock_any(void)
{
    return (alarm_lock_ch_latched(0u) ||
            alarm_lock_ch_latched(1u) ||
            s_volt_latched) ? 1u : 0u;
}

void alarm_lock_save(uint8_t force)
{
    uint8_t buf[6];
    uint32_t now;

    if(!force && !s_dirty)
        return;

    now = sched_abs_min();
    if(!force && s_last_save_min != 0xFFFFFFFFu &&
       (uint32_t)(now - s_last_save_min) < ALARM_LOCK_SAVE_MIN)
        return;   /* 5 分钟节流: 变更保留在 dirty 里, 下次 flush 再写 */

    buf[0] = s_last_r[0];
    buf[1] = s_last_r[1];
    buf[2] = s_last_t[0];
    buf[3] = s_last_t[1];
    buf[4] = s_volt_latched;
    buf[5] = alk_crc8(buf, 5u);

    /* 数据+CRC 先写, magic 最后写: 半写失效 → magic/CRC 不匹配 → 按空锁处理 */
    EE_WRITE(EE_ADDR_ALK_DATA, buf, sizeof(buf));
    EE_WRITE_BYTE(EE_ADDR_ALK_MAGIC, EE_MAGIC_ALK);

    s_dirty = 0u;
    s_last_save_min = now;
}

#ifndef ALARM_LOCK_H
#define ALARM_LOCK_H

/**
 * @file alarm_lock.h
 * @brief 告警等级锁 + 恢复去抖 (周期/实时/查询三条路径共用)
 *
 * 设计目标
 * ---------
 * 1. 每个通道独立记录"最后一次已上报的等级"(压力/突变等级 r, 温度等级 t);
 *    只有等级发生变化才允许再次上报 —— 同一等级持续期间不重复上报。
 * 2. 恢复正常必须连续 ALARM_LOCK_CLEAR_COUNT 拍才解锁, 防止阈值附近抖动
 *    造成"告警→恢复→告警"的报文风暴。
 * 3. 电压报警(VPROTECT/VOLT_HIGH/VOLT_LOW)单独 1 bit 锁 + 独立恢复计数,
 *    不进入通道锁; 只有真正做了电压判定(check_voltage=1)的路径才能置位/清除。
 * 4. 锁状态持久化到 EEPROM, 重启后持续中的告警不重报。
 *
 * 调用约定
 * ---------
 * - 周期采集/实时采集: 每拍对每个启用通道调用 alarm_lock_feed_normal()
 *   (推进恢复计数), 新等级用 alarm_lock_latch() 锁定。
 * - 查询路径(6.6~6.9): 只调用 alarm_lock_has_new()/alarm_lock_latch(),
 *   **不**调用 feed_normal —— 平台一轮轮询不能把恢复计数凑满。
 * - 离线通道: online=0 → 计数归零、保留最后等级; 不得用陈旧值判定。
 * - 单路机型: 通道 1 强制禁用, 锁位与计数由本模块自动清零。
 *
 * EEPROM 布局 (AT24C64, 配置区 0x000~0x7FF)
 * -----------------------------------------
 *   0x540: magic 0xCE
 *   0x541: last_r[0]   通道0 压力/突变等级 (ThresholdResult_t, 不含电压码)
 *   0x542: last_r[1]   通道1 压力/突变等级
 *   0x543: last_t[0]   通道0 温度等级 (TempStatus_t)
 *   0x544: last_t[1]   通道1 温度等级
 *   0x545: volt_flag   电压锁 0/1
 *   0x546: CRC8        覆盖 0x540~0x545 (6 字节)
 *   注: 0x500~0x504 为上报周期防重锁, 0x560/0x580 为校零双槽(各32B),
 *       0x540~0x546 为本告警锁; 历史区从 0x800 起。
 *       0x540 为 32 字节页首, 7 字节落在同一物理页。
 */

#include <stdint.h>
#include "threshold.h"

#define ALARM_LOCK_CH_COUNT       2u   /* 通道数: 0=进气端, 1=出气端 */
#define ALARM_LOCK_CLEAR_COUNT    3u   /* 连续正常拍数达到即解锁 */
#define ALARM_LOCK_SAVE_MIN       5u   /* EEPROM 写入最小间隔(分钟) */

/* 开机加载锁状态 (必须在 config_load_all + rtc_init_all 之后调用) */
void alarm_lock_init(void);

/* 清空全部锁并立即持久化 (用户手动开阀时调用) */
void alarm_lock_clear_all(void);

/* 通道是否启用 (单路机型通道1恒为0) */
uint8_t alarm_lock_ch_enabled(uint8_t ch);

/* 本次等级相对"最后已上报等级"是否有变化 (电压码不参与) */
uint8_t alarm_lock_has_new(uint8_t ch, ThresholdResult_t r, TempStatus_t ts);

/* 锁定本次已上报等级 (r 为电压码时不更新 last_r, last_t 总是更新) */
void alarm_lock_latch(uint8_t ch, ThresholdResult_t r, TempStatus_t ts);

/* 恢复去抖: 离线/异常 → 计数归零; 在线且全正常 → 计数递增;
 * 达到 ALARM_LOCK_CLEAR_COUNT 且该通道有等级 → 清零并返回 1 (应上报一次恢复) */
uint8_t alarm_lock_feed_normal(uint8_t ch, uint8_t online,
                               ThresholdResult_t r, TempStatus_t ts);

/* 电压锁: 是否出现新的电压报警 */
uint8_t alarm_lock_volt_has_new(ThresholdResult_t r);

/* 锁定电压报警 */
void alarm_lock_volt_latch(void);

/* 电压恢复去抖: voltage_checked=0 时完全不触碰电压锁;
 * 达到 ALARM_LOCK_CLEAR_COUNT 且已锁定 → 清零并返回 1 */
uint8_t alarm_lock_volt_feed_normal(ThresholdResult_t r, uint8_t voltage_checked);

/* 是否存在任何锁 (通道或电压) */
uint8_t alarm_lock_any(void);

/* 指定通道是否处于锁定状态 */
uint8_t alarm_lock_ch_latched(uint8_t ch);

/* 持久化: force=1 立即写; force=0 受 dirty + 5 分钟节流 */
void alarm_lock_save(uint8_t force);

#endif /* ALARM_LOCK_H */

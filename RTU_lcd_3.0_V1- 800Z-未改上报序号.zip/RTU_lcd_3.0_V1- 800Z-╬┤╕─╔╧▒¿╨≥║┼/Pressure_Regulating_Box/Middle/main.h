#ifndef MAIN_H
#define MAIN_H

#include "stdint.h"
#include "PT_304_35.h"
#include "ota_info.h"
#include "threshold.h"

#define APP_FW_VERSION_NUM     1

/* ==================== State Machine ==================== */
typedef enum {
    STATE_INIT = 0,
    STATE_SLEEP,
    STATE_WAKEUP,
    STATE_COLLECT,
    STATE_UPLOAD,
    STATE_DOWNLINK,
    STATE_ALARM,
    STATE_BLE_OTA,
    STATE_CH4
} AppState_t;

extern AppState_t app_state;

/* CH4 request flag (set by downlink gas_get, checked by do_downlink) */
extern volatile uint8_t g_ch4_request;
extern uint8_t g_alarm_recover_reported; /* 报警关阀恢复"已上报一次"标志 (RAM) */
typedef struct {
    PT304D_Data raw;
    PT304D_Data raw2;
    float       voltage;
    float       last_pressure_collect;
    float       last_pressure_realtime;
    float       last_pressure_collect2;
    float       last_pressure_realtime2;
    float       last_normal_voltage;
    uint8_t     prev_online;
    uint8_t     offline_cnt;
    uint8_t     online_cnt;
    uint8_t     prev_online2;
    uint8_t     offline_cnt2;
    uint8_t     online_cnt2;
} SensorContext_t;

extern SensorContext_t g_sensor;
extern uint8_t g_lcd_active;   // LCD当前是否显示 (运行状态, 区别于配置项; main.c 维护)

// 供其他模块使用 (main.c 实现, downlink.c 等模块调用)
void lcd_shutdown(void);
/* 安装事件一次性上报: 传感器记录 + product_status=1 (未安装→已安装瞬间调用) */
void install_event_report(void);
/* 未安装期"最新记录"缓存作废 (强制未安装后调用, 防安装前残留的旧记录被下一次上报带出) */
void calib_latest_invalidate(void);

const char* alarm_try_close_valve_all(const char *policy_str, ThresholdResult_t result);

const char* alarm_try_close_valve(ThresholdResult_t result);
const char* alarm_try_close_valve2(ThresholdResult_t result);   /* 出气端 (abnormal2_close) */
const char* ch4_alarm_try_close_valve(void);

/* ==================== 告警确认与上报 (三条路径共用) ====================
 * 等级锁在 Middle/alarm_lock.c: 通道内等级变化才上报, 恢复需连续 3 拍。
 * mask: bit0=通道0, bit1=通道1, bit2=电压
 * 语义: 调用方已用首检结果算出 mask 且已完成 3 次重采确认;
 *       本函数用当前最新采样重算等级 → 锁存 → 按策略关阀 → 上报
 *       (报警批量 + 电压类 LY06 + 阀门状态)。
 * ctx: COLLECT/REALTIME 自行建立/恢复 4G; DOWNLINK 复用现有连接。
 * 返回: 阀门动作结果字符串 (未关阀为 NULL)。
 */
typedef enum {
    ALARM_CTX_COLLECT = 0,
    ALARM_CTX_REALTIME,
    ALARM_CTX_DOWNLINK
} AlarmCtx_t;

uint8_t alarm_new_mask(ThresholdResult_t r1, ThresholdResult_t r2, uint8_t check_voltage);
const char* alarm_confirm_and_report(AlarmCtx_t ctx, uint8_t mask,
                                     float last_p1, float last_p2);
/* 3 次重采确认: 返回 1=确认异常(需调用 alarm_confirm_and_report), 0=偶发恢复
 * 重采期间基线固定为传入的上拍值; check_voltage=1 时每拍采样电压 */
uint8_t alarm_recheck_confirm(uint8_t check_voltage, float last_p1, float last_p2);

void upload_schedule_reset(void);   /* 上报周期/后延配置变更后调用, 重置延迟上报锁存 */

#endif

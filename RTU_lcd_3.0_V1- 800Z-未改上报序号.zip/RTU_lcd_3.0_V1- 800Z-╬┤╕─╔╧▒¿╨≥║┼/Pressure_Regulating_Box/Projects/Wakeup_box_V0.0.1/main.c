/**
 * @file main.c
 * @brief 调压箱物联网控制器 + 状态机驱动低功耗主程序
 *
 * 架构: MQTT持久连接 + MCU深休眠 + LPUART唤醒接收下发
 *
 * 状态机 (9个状态):
 *   STATE_INIT     → 上电初始化 → MQTT连接+订阅+首次上报 → STATE_SLEEP
 *   STATE_SLEEP    → 设闹钟 → 深休眠 → 模块QSCLK保持MQTT) → STATE_WAKEUP
 *   STATE_WAKEUP   → 恢复外设+判断唤醒源
 *                     RTC闹钟 → STATE_COLLECT
 *                     LPUART  → STATE_DOWNLINK
 *   STATE_COLLECT  → 采集+阈值检查 → 存入缓冲区 → STATE_UPLOAD/ALARM/SLEEP
 *   STATE_UPLOAD   → 批量逐条上报+清空缓冲区 → STATE_SLEEP
 *   STATE_DOWNLINK → 读取+处理MQTT下发指令+立即上报结果 → STATE_SLEEP
 *   STATE_ALARM    → 5次重采确认 → 报警上报 → STATE_SLEEP
 *   STATE_BLE_OTA  → BLE蓝牙固件升级(等待连接→接收数据→写Flash→提交)
 *                    (BLE_ENABLED=0 时不编译: 本机型无蓝牙)
 *   STATE_CH4  	→ 激光甲烷传感器采集: 上电→预热(20s)→采集→阈值判断→上报→断电。
 */

#include "gd32l23x.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "systick.h"
#include "usart.h"
#include "delay.h"
#include "ec800e.h"
#include "mygpio.h"
#include "power.h"
#include "wakeup.h"
#include "tim.h"
#include "valve_timing.h"
#include "PT_304_35.h"
#include "valve.h"
#include "downlink.h"
#include "report.h"
#include "app_config.h"
#include "eeprom_config.h"
#include "config_policy.h"
#include "calib_mode.h"
#include "m24m01.h"
#include "main.h"
#include "adc_bat.h"
#include "soft_i2c.h"
#include "motor.h"
#include "sensor_record.h"
#include "threshold.h"
#include "alarm_lock.h"
#include "ota_app.h"
#include "slcd_seg.h"
#include "lcd_ui.h"
#include "led.h"
#include "buzzer.h"
#if BLE_ENABLED
#include "ble_ota.h"
#endif
#include "json_builder.h"
#include "eeprom_history.h"
#include "ch4_alarm.h"

// ==================== 状态机 ====================
/* AppState_t moved to main.h */

// ==================== 全局变量 ====================
SensorContext_t g_sensor = { .last_pressure_collect = -1.0f, .last_pressure_realtime = -1.0f, .last_pressure_collect2 = -1.0f, .last_pressure_realtime2 = -1.0f, .prev_online = 1, .offline_cnt = 0, .online_cnt = 0, .prev_online2 = 1, .offline_cnt2 = 0, .online_cnt2 = 0, .last_normal_voltage = 3.6f };

#if CALIB_MODE_ENABLED
/* 未安装校零期: 不写历史, 只保留最新一条实时记录供周期上报 */
static SensorRecord_t s_calib_latest;
static uint8_t s_calib_latest_valid = 0;
#endif

#define SENSOR_OFFLINE_DEBOUNCE  3   // 连续N次离线才确认状态变化
#define SENSOR_ONLINE_DEBOUNCE   2   // 连续N次在线才确认状态变化(比离线快)
#define	one_by_one_delay		 900	// 逐条上报间隔延时

static volatile uint16_t wakeup_count = 0;
AppState_t app_state = STATE_INIT;
volatile uint8_t g_ch4_request = 0;
uint8_t g_alarm_recover_reported = 0;   // 报警关阀恢复"已上报一次"标志 (RAM, 防重复上报)
static uint8_t dot_uploaded_mask[3] = {0};
static uint16_t dot_uploaded_day = 0xFFFF;  // RTC day of uploaded bitmap (cross-day reset)  // dot pattern: uploaded-hour bitmap

/* ==================== 周期上报: 整点网格 + 标志位式调度 ====================
 * 上报点 = 绝对分钟轴上"上报周期"的整数倍(00:00 起算) → 固定整点,
 *          与上电/重启/上次上报时刻无关。
 *   s_upload_pending      : 1 = 有数据待上报; 只有"上报成功(缓冲清空)"才清零
 *   s_last_upload_idx     : 上次成功上报的"上报周期序号" (EEPROM持久化, 防重)
 *   s_pending_due_abs_min : 到期时刻(绝对分钟) = 本周期起点 + 后延, 只在 pending 时比较
 * 命中容差 = 整个上报周期: 判定拍被长流程推迟/被抢占/重启补报都能命中, 跨周期才等下一点 */
static uint8_t  s_upload_pending      = 0;
static uint32_t s_last_upload_idx     = 0xFFFFFFFFu;
static uint32_t s_pending_due_abs_min = 0;

static uint8_t  upload_due_now(void);   /* 前置声明: 实时循环里已使用 */
// valve_alarm_closed / valve_pre_alarm_order / ch4_alarm_closed 定义为 g_* 全局 (EEPROM 持久化, OTA 升级后自动恢复), 见 eeprom_config.h
uint8_t voltage_low_power = 0;              // 低电压省电模式; 8:00/18:00上报
uint8_t fourG_user_off = 0;                 // 用户手动关闭4G标志(防止do_wakeup盲目恢复PD9)
static uint8_t fourG_init_failed = 0;       // 4G注册失败标志(防止do_sleep保持4G在线, 下次上报重新尝试)
static uint8_t fourG_weak_signal = 0;       // 弱信号断电标志(long模式按CSQ判断, 平时保持断电)
#define CSQ_WEAK_THRESHOLD  8               // CSQ<该值则断电省电(8约-97dBm)
static uint8_t vlp_uploaded_this_hour = 0;  // 低电压模式: 防止同一小时重复上报
/* 告警等级/恢复去抖状态已移至 Middle/alarm_lock.c:
 *   - 每个通道独立记录最后已上报等级 (压力/突变 + 温度), 等级变化才重报
 *   - 恢复需连续 ALARM_LOCK_CLEAR_COUNT 拍正常, 单次正常不清锁
 *   - 电压报警单独 1 bit 锁, 独立恢复计数
 *   - 锁跨重启持久化 (5 分钟节流), 持续中的告警不重报 */
#if BLE_ENABLED
static uint32_t g_ble_on_hhmmss = 0;                          // BLE开启时的RTC时间 (HHMMSS), 超过60s未连接超时自动关闭
#endif
static uint8_t g_is_minimal_wakeup = 0;            // 标志是否为最小唤醒(纯RTC采集或按键快检状态)
uint8_t g_need_adc_sampling = 1;                   // 标志当前唤醒是否需要执行电池电压采样
static uint32_t last_grid_collect_abs_min = 0xFFFFFFFF;  // 最后一次网格采集的"绝对分钟"(跨天不误判/不重复)
#if LASER_CH4_ENABLED
static uint8_t s_laser_done_hour = 0xFF;           // 激光定时采集: 本小时已触发标志(跨小时自动恢复)
#endif

// ==================== 定时开关阀 当日执行标志 ====================
uint8_t timing_open_done_today  = 0;   // 当日已执行开阀
uint8_t timing_close_done_today = 0;   // 当日已执行关阀
static uint8_t timing_last_reset_hour  = 0xFF;// 上次重置标志的小时(防止重复)
volatile uint8_t g_timing_pending = 0;   /* timing valve pending (set by RTC ISR) */
volatile uint8_t g_timing_alarm_set = 0; /* current RTC alarm is a timing-valve alarm */

// ==================== LCD 超时关闭 ====================
uint8_t  g_lcd_active     = 0;      // LCD当前是否正在显示(运行状态, 区别于产品配置g_lcd_enabled)
static uint32_t g_lcd_on_hhmmss = 0; // LCD开启时的RTC时间 (HHMMSS格式)
#define LCD_DISPLAY_TIMEOUT_SEC  60  // LCD无操作显示超时(LCD_LOCK_ENABLED 模式)
/* 统一的"无操作息屏"时间: 按键点亮模式用 LCD_KEY_BLANK_SEC, 其余沿用 60s */
#if LCD_KEY_TRIGGER_ENABLED
#define LCD_BLANK_TIMEOUT_SEC    LCD_KEY_BLANK_SEC
#else
#define LCD_BLANK_TIMEOUT_SEC    LCD_DISPLAY_TIMEOUT_SEC
#endif

/* 休眠配置里的"蓝牙是否供电": BLE 关闭时恒为 0 (深休眠把 PD2/PB3/PB4 转 Analog 省电) */
#if BLE_ENABLED
#define PM_BT_FLAG()             ((uint8_t)g_bt_on)
#define PM_BLE_EXTI_ARM()        do { if(g_bt_on) ble_exti_init(); } while(0)
#else
#define PM_BT_FLAG()             (0u)
#define PM_BLE_EXTI_ARM()        ((void)0)
#endif

static uint32_t hhmmss_to_seconds(uint32_t hhmmss)
{
    uint8_t h = (uint8_t)(hhmmss / 10000);
    uint8_t m = (uint8_t)((hhmmss / 100) % 100);
    uint8_t s = (uint8_t)(hhmmss % 100);
    return (uint32_t)h * 3600 + (uint32_t)m * 60 + s;
}

/* 有效采集间隔(分钟): 未安装校零期使用 CALIB_SAMPLE_MIN, 其它情况用配置值 */
static uint16_t sched_collect_min(void)
{
#if CALIB_MODE_ENABLED
    return calib_is_active() ? CALIB_SAMPLE_MIN : g_interval.collect_interval_min;
#else
    return g_interval.collect_interval_min;
#endif
}

/* ==================== 跨天周期调度 (绝对时间轴) ====================
 * 到期点 = 绝对分钟轴上的 collect_min 整数倍; 支持 2 天/1 周等 >1 天的周期。 */

/* 当前时刻是否为采集到期点 */
static uint8_t sched_collect_due_now(void)
{
    uint16_t cm = sched_collect_min();
    uint32_t abs_min = sched_abs_min();

    if(cm == 0u) return 1u;
    if(abs_min == last_grid_collect_abs_min) return 0u;   /* 本分钟已采集过, 防重复 */
    return ((abs_min % (uint32_t)cm) == 0u) ? 1u : 0u;
}

/* 下一个采集到期点(绝对分钟) */
static uint32_t sched_next_collect_abs_min(void)
{
    uint16_t cm = sched_collect_min();
    uint32_t now_abs = sched_abs_min();

    if(cm == 0u) cm = 1u;
    return ((now_abs / (uint32_t)cm) + 1u) * (uint32_t)cm;
}

/* 设定下一个采集闹钟: 锚定"到期时刻", 但最多睡 24h —— 跨天周期在到期日之前每天醒一次判定 */
static void sched_set_next_collect_alarm(void)
{
    uint32_t now_abs  = sched_abs_min();
    uint32_t due      = sched_next_collect_abs_min();
    uint32_t wait_min;
    uint32_t tod;

    /* 待上报且到期点更早: 把唤醒提前到该点, 保证后延精度 */
    if(s_upload_pending && s_pending_due_abs_min > now_abs && s_pending_due_abs_min < due)
        due = s_pending_due_abs_min;

    wait_min = due - now_abs;
    if(wait_min > 1440u) wait_min = 1440u;
    tod = (now_abs + wait_min) % 1440u;
    rtc_set_alarm_at_hhmmss((tod / 60u) * 10000u + (tod % 60u) * 100u);
    printf_debug("[SM] RTC collect alarm: in %lumin (abs_due=%lu)\r\n",
                 (unsigned long)wait_min, (unsigned long)due);
}

/* 有效实时模式: 未安装校零期禁止秒级实时采集, 只用分钟节拍 */
static uint8_t real_mode_active(void)
{
#if CALIB_MODE_ENABLED
    return (g_real_enabled && !calib_is_active()) ? 1 : 0;
#else
    return g_real_enabled;
#endif
}

#if CALIB_MODE_ENABLED
/* 未安装校零诊断日志: 每个节拍样本打印一条 */
static void calib_log_sample(float p_raw, float p_cal)
{
    CalibStatus_t st;
    char ts[24];

    calib_get_status(&st);
    rtc_get_time_str(ts, sizeof(ts));
    printf_debug("[CALIB] sample %s P_raw=%.0fPa P_cal=%.0fPa zero=%ldPa(%d) "
                 "warm=%u hi=%u med=%u/%u cnt=%lu\r\n",
                 ts, p_raw, p_cal, (long)st.zero_pa, st.zero_valid,
                 st.warm, st.hi, st.med_n, (unsigned)CALIB_MEDIAN_CNT,
                 (unsigned long)st.samples);
}
#endif

#if CALIB_MODE_ENABLED
/* ==================== 未安装期LCD: 非阻塞短亮 ====================
 * 单路: 压力页亮5s → 息屏; 双路: 进口压力2s → 出口压力3s → 息屏.
 * (RTC闹钟秒级分辨, 双路2.5s近似为2s+3s, 合计5s)
 * 按键/下行事件优先: 按键点亮并允许翻页, 5s无操作再息屏. */
#define CALIB_LCD_PAGE_SEC       5u

/* 前向声明: LCD开关函数定义在本块之后 */
static void lcd_activate(void);
void lcd_shutdown(void);

static uint8_t  s_cal_lcd_wait = 0;       /* 1=有待处理LCD定时事件 */
static uint8_t  s_cal_lcd_state = 0;      /* 1=AUTO, 3=MANUAL */
static uint8_t  s_cal_lcd_step = 0;       /* 自动序列当前页序号 */
static uint32_t s_cal_lcd_deadline = 0;   /* 当日秒 */
static uint32_t s_cal_lcd_deadline_day = 0; /* 截止时间所属日期键(y*10000+m*100+d) */

static uint32_t calib_lcd_now(void)
{
    return hhmmss_to_seconds(rtc_get_hhmmss());
}

static uint32_t calib_lcd_day_key(void)
{
    RtcDateTime_t dt;
    rtc_get_datetime(&dt);
    return 10000u * dt.year + 100u * dt.month + dt.day;
}

static void calib_lcd_deadline_set(uint16_t sec)
{
    s_cal_lcd_deadline = (calib_lcd_now() + sec) % 86400u;
    s_cal_lcd_deadline_day = calib_lcd_day_key();
    s_cal_lcd_wait = 1;
}

/* 剩余秒数: 日期不一致(跨天/RTC对时跳变)一律视为已过期, 返回0 */
static int32_t calib_lcd_left(void)
{
    int32_t d;

    if(calib_lcd_day_key() != s_cal_lcd_deadline_day)
        return 0;                       /* 日期不同: 旧截止时间, 视为过期 */

    d = (int32_t)s_cal_lcd_deadline - (int32_t)calib_lcd_now();
    return (d > 0) ? d : 0;
}

static void calib_lcd_alarm_set(void)
{
    uint32_t t = s_cal_lcd_deadline;
    rtc_set_alarm_at_hhmmss((t / 3600u) * 10000u + ((t / 60u) % 60u) * 100u + (t % 60u));
}

static void calib_lcd_refresh(void)
{
    lcd_ui_update_data(&g_sensor.raw, &g_sensor.raw2, g_sensor.voltage);
}

/* 自动序列长度: 单路 压力→温度; 双路 S2压力→S2温度→S1压力→S1温度 */
static uint8_t calib_lcd_seq_len(void)
{
#if LCD_SINGLE_SENSOR
    return 2u;
#else
    return 4u;
#endif
}

static void calib_lcd_show_step(uint8_t step)
{
#if LCD_SINGLE_SENSOR
    switch(step)
    {
        case 0: lcd_ui_set_page(LCD_PAGE_OUTLET_PRESSURE); break;
        case 1: lcd_ui_set_page(LCD_PAGE_OUTLET_TEMP);     break;
        default: break;
    }
#else
    switch(step)
    {
        case 0: lcd_ui_set_page(LCD_PAGE_INLET_PRESSURE);  break;
        case 1: lcd_ui_set_page(LCD_PAGE_INLET_TEMP);      break;
        case 2: lcd_ui_set_page(LCD_PAGE_OUTLET_PRESSURE); break;
        case 3: lcd_ui_set_page(LCD_PAGE_OUTLET_TEMP);     break;
        default: break;
    }
#endif
}

#if !LCD_KEY_TRIGGER_ENABLED
/* 默认页(退出未安装/恢复正常显示时使用); 按键点亮模式下不主动点亮, 故不编译 */
static void calib_lcd_page_a(void)
{
#if LCD_SINGLE_SENSOR
    lcd_ui_set_page(LCD_PAGE_OUTLET_PRESSURE);
#else
    lcd_ui_set_page(LCD_PAGE_INLET_PRESSURE);
#endif
}
#endif /* !LCD_KEY_TRIGGER_ENABLED */

static void calib_lcd_off(void)
{
    if(g_lcd_active) lcd_shutdown();
    s_cal_lcd_wait = 0;
    s_cal_lcd_state = 0;
    printf_debug("[CALIB] LCD off (blank)\r\n");
}

/* 节拍点亮: 自动序列开始 (每页5s; 压力页显示0, 温度页真实值) */
static void calib_lcd_auto_begin(void)
{
    if(!calib_is_active() || !g_lcd_enabled) return;
#if LCD_KEY_TRIGGER_ENABLED
    /* 按键点亮模式: 不做"节拍自动点亮", LCD 只由按键触发
     * (否则每个采集节拍都会自动亮起, 与"默认灭屏"矛盾) */
    return;
#endif
    lcd_activate();
    s_cal_lcd_step = 0;
    calib_lcd_show_step(0);
    calib_lcd_refresh();
    s_cal_lcd_state = 1;
    calib_lcd_deadline_set(CALIB_LCD_PAGE_SEC);
    printf_debug("[CALIB] LCD seq start: %u page(s), %us each\r\n",
                 calib_lcd_seq_len(), CALIB_LCD_PAGE_SEC);
}

/* LCD定时到期: 自动序列切下一页或息屏; 手动模式到期直接息屏 */
static void calib_lcd_next_step(void)
{
    if(s_cal_lcd_state == 3)                 /* 手动模式: 5s无操作 → 息屏 */
    {
        calib_lcd_off();
        return;
    }

    s_cal_lcd_step++;
    if(s_cal_lcd_step >= calib_lcd_seq_len())
    {
        calib_lcd_off();
        return;
    }
    calib_lcd_show_step(s_cal_lcd_step);
    calib_lcd_refresh();
    calib_lcd_deadline_set(CALIB_LCD_PAGE_SEC);
    printf_debug("[CALIB] LCD page %u/%u, next in %us\r\n",
                 s_cal_lcd_step + 1, calib_lcd_seq_len(), CALIB_LCD_PAGE_SEC);
}

/* 按键等人工事件: 点亮并重置5秒无操作计时 */
static void calib_lcd_activity(void)
{
    if(!calib_is_active() || !g_lcd_enabled) return;
    lcd_activate();
    s_cal_lcd_state = 3;                 /* 手动模式: 不再自动切页 */
    calib_lcd_deadline_set(5u);
}

/* 锁定/退出未安装: 取消短亮逻辑, 恢复默认页与正常LCD策略 */
static void calib_lcd_exit_to_normal(void)
{
    if(!s_cal_lcd_wait && s_cal_lcd_state == 0) return;
    s_cal_lcd_wait = 0;
    s_cal_lcd_state = 0;
#if LCD_KEY_TRIGGER_ENABLED
    /* 按键点亮模式: 只清除校零短亮状态, 不主动点亮 (保持灭屏, 由按键点亮) */
    (void)0;
#else
    if(g_lcd_enabled)
    {
        lcd_activate();
        calib_lcd_page_a();
        calib_lcd_refresh();
    }
#endif
}

#define CALIB_LCD_BLOCKED()   (calib_is_active())
#else
#define CALIB_LCD_BLOCKED()   (0)
#endif /* CALIB_MODE_ENABLED */

/* ==================== 断电前补读下行 ====================
 * 功能主题按 QoS0 订阅(broker 不补发), 而模块的 QMTRECV 缓冲(5 槽)存在模块 RAM 里,
 * V4G_EN 一断电就随模块一起消失 → 凡是"临时连一次 4G 后要断电"的路径,
 * 必须在断电前把缓冲读走, 否则本次连接期间平台下发的指令会永久丢失。
 * 只挂在"即将断电"的分支上: 常态(保持在线)不增加 AT 与延时。 */
static void fourG_drain_before_power_off(void)
{
    uint8_t n;

    if(!power_4g_is_on())
        return;                       /* 已断电: 模块缓冲已不存在, 无需查询 */

    n = drain_pending_downlink();
    printf_debug("[SM] PWR-OFF drain: %d msg(s)\r\n", n);
}

#if CALIB_MODE_ENABLED
/* ==================== 安装事件上报 (未安装→已安装 一次性) ====================
 * 立即尝试一次4G(必要时冷启动), 上报:
 *   1) 单条传感器记录(双路自动带 temp/temp2/pressure/pressure2)
 *   2) product_status=1
 * 失败不重试; 引脚的初始化按 调试串口→GPIO→LPUART→4G→传感器→ADC 顺序处理 */
void install_event_report(void)
{
    PT304D_Data d1, d2;
    SensorRecord_t rec;
    float v;
    uint8_t was_online;
    uint8_t ok;

    /* 1. 恢复调试串口(休眠后PC4/PC5为Analog) */
    trea_uart_init();
    /* 2. 恢复电源/控制引脚(PC0/PC1/PA0/PC3等) */
    gpio_init();
    /* 3. 恢复4G LPUART (PD8/PD9) */
    com_lpuart_init();
    trea_delay_ms(50);

    /* 4. 4G: 在线则唤醒确认, 断电则冷启动一次; 失败不重试 */
    was_online = power_4g_is_on();
    if(was_online)
    {
        EC801E_Wakeup();
        ok = (EC801E_EnsureConnected() == EC_OK);
    }
    else
    {
        ok = (EC801E_InitAndConnect() == EC_OK);
    }
    if(!ok)
    {
        if(!was_online) EC801E_PowerOff();
        printf_debug("[CALIB] install event report: 4G unavailable, skip\r\n");
        calib_lcd_exit_to_normal();
        return;
    }

    /* 5. 现场采集压力/温度 (双路一起采) 与电压 */
    memset(&d1, 0, sizeof(d1));
    memset(&d2, 0, sizeof(d2));
    PT304D_CollectAll((g_sensor_count >= 2) ? &d2 : NULL, &d1);
    v = adc_bat_read_voltage();
    if(v < 0.0f) v = g_sensor.last_normal_voltage;

    memset(&rec, 0, sizeof(rec));
	if(g_sensor_count >= 2)
	{
		rec.pressure     = d1.pressure;
		rec.temperature  = d1.temperature;
		rec.pressure2    = d2.pressure;
		rec.temperature2 = d2.temperature;
//		if(d1.pressure<=0) d1.pressure = 0;
//		if(d2.pressure<=0) d2.pressure = 0;
	}
	else
	{
		rec.pressure     = d1.pressure;
		rec.temperature  = d1.temperature;
//		if(d1.pressure<=0) d1.pressure = 0;
	}
	rec.voltage      = v;
    rtc_get_time_str(rec.timestamp, sizeof(rec.timestamp));

    /* 6. 上报: 传感器记录 + 安装状态 */
    EC801E_PublishSingleRecord(&rec);
    trea_delay_ms(300);
    report_publish_field("product-status", "1");
    printf_debug("[CALIB] install event reported: P=%.2f T=%.2f V=%.2f status=1\r\n",
                 rec.pressure, rec.temperature, rec.voltage);

    /* 7. 收尾: 长连接保持在线 / 短连接断电 */
    if(was_online) EC801E_SetPSM(1);
    else
    {
        fourG_drain_before_power_off();   /* 断电前读走缓冲, 防止平台指令随断电丢失 */
        EC801E_PowerOff();
    }

    /* 8. LCD: 退出未安装短亮状态, 恢复正常显示策略 */
#if LCD_KEY_TRIGGER_ENABLED
    /* 按键点亮模式: 不主动点亮 (保持灭屏, 由按键点亮) */
#else
	// SLCD初始化(必须在rtc_init_all之后, LXTAL已启动)
    if(g_lcd_enabled) { slcd_seg_configuration(); lcd_ui_init(); g_lcd_active = 1; g_lcd_on_hhmmss = rtc_get_hhmmss(); }
#endif
    calib_lcd_exit_to_normal();
}

/* ==================== 未安装期"最新记录"缓存作废 ====================
 * s_calib_latest 只在未安装态采集时刷新, 安装后残留旧记录;
 * 强制未安装后必须作废, 否则下一次上报会把安装前的旧记录当作"最新值"发出 */
void calib_latest_invalidate(void)
{
    s_calib_latest_valid = 0;
}
#else
void install_event_report(void) { }
void calib_latest_invalidate(void) { }
#endif /* CALIB_MODE_ENABLED */

// ==================== 周期上报: 整点网格 + 标志位式调度 ====================
/* 上报周期序号 = 绝对分钟 / 上报周期分钟 (00:00 起算): 整个上报周期内取值不变
 *   → 命中容差 = 整个上报周期(周期内任意一拍判定都命中), 抗阀动作等长流程推迟/
 *     被抢占/重启补报; 跨出周期才等下一个上报点。
 *   注: 判定与采集节拍解耦(不用采集点序号), 校零期(CALIB_SAMPLE_MIN=1min)同样正确 */
static uint32_t upload_grid_index(void)
{
    uint32_t um = (uint32_t)g_interval.upload_interval_min;
    if(um == 0u) return 0xFFFFFFFFu;
    return sched_abs_min() / um;
}

/* 上报周期起点(绝对分钟): 后延的基准 */
static uint32_t upload_period_start(void)
{
    uint32_t um = (uint32_t)g_interval.upload_interval_min;
    if(um == 0u) return sched_abs_min();
    return (sched_abs_min() / um) * um;
}

/* 采集完成后调用: 进入新的上报周期且该周期未上报 → 置"待上报"(并算出到期时刻) */
static void upload_pending_update(void)
{
    uint32_t idx;

    if(g_interval.upload_interval_min == 0u)
        return;

    idx = upload_grid_index();
    if(s_last_upload_idx == 0xFFFFFFFFu)   /* 首次上电: 以当前周期为基准, 严格等一个完整周期 */
    {
        s_last_upload_idx = idx;
        return;
    }
    if(idx == s_last_upload_idx)           /* 本周期已成功上报过(防重, 跨重启保持) */
        return;

    if(!s_upload_pending)
    {
        /* 到期 = 本周期起点 + 后延:
         *   1) 单位是"绝对分钟", 不能乘 60;
         *   2) 以周期起点为基准: 判定拍被推迟时上报时刻不漂, 已过期则下一拍立即上报;
         *   3) 闹钟按分钟设 → 后延分辨率 1 分钟 (1.5min 四舍五入为 2min) */
        s_upload_pending      = 1;
        s_pending_due_abs_min = upload_period_start()
                              + (uint32_t)(g_report_delay_min + 0.5f);
        printf_debug("[SM] UPLOAD pending set (period=%lu um=%umin delay=%.1fmin due=%lu)\r\n",
                     (unsigned long)idx, (unsigned)g_interval.upload_interval_min,
                     g_report_delay_min, (unsigned long)s_pending_due_abs_min);
    }
}

/* 是否该执行上报: 只看"待上报标志 + 到期时刻" */
static uint8_t upload_due_now(void)
{
    if(!s_upload_pending) return 0;
    if(sched_abs_min() < s_pending_due_abs_min) return 0;   /* 后延未到 */
    return 1;
}

/* 上报成功(历史缓冲清空 / 校零期最新值已发)后提交: 清标志 + 记录本周期序号(持久化) */
static void upload_commit(void)
{
    if(!s_upload_pending) return;          /* 幂等: 未置位直接返回 */
    s_upload_pending  = 0;
    s_last_upload_idx = upload_grid_index();
    config_save_upload_idx(s_last_upload_idx);
    printf_debug("[SM] UPLOAD committed (period=%lu)\r\n", (unsigned long)s_last_upload_idx);
}

static void lcd_activate(void)
{
    if(!g_lcd_enabled) return;
    if(!g_lcd_active)
    {
        slcd_seg_configuration();
        lcd_ui_init();
    }
    g_lcd_active = 1;
    g_lcd_on_hhmmss = rtc_get_hhmmss();
}

void lcd_shutdown(void)
{
    if(!g_lcd_active) return;
    slcd_shutdown();   /* 关闭SLCD并释放引脚 (硬件关屏由BSP实现) */
    g_lcd_active = 0;
}

static void lcd_check_timeout(void)
{
#if CALIB_MODE_ENABLED
    if(calib_is_active()) return;       /* 未安装期用5s短亮逻辑, 不走正常超时 */
#endif
#if (LCD_LOCK_ENABLED || LCD_KEY_TRIGGER_ENABLED)
    /* 无操作息屏: 取消"常亮", 超时后 lcd_shutdown() 关屏
     * (按键点亮模式 = LCD_KEY_BLANK_SEC 秒; 锁定模式 = 60s) */
    if(!g_lcd_active) return;
    uint32_t now_sec = hhmmss_to_seconds(rtc_get_hhmmss());
    uint32_t on_sec  = hhmmss_to_seconds(g_lcd_on_hhmmss);
    uint32_t elapsed;
    if(now_sec >= on_sec)
        elapsed = now_sec - on_sec;
    else
        elapsed = (86400 - on_sec) + now_sec;  // 跨过午夜
    if(elapsed >= LCD_BLANK_TIMEOUT_SEC)
        lcd_shutdown();
#else
    /* LCD常亮模式: 不做超时, 保持常开 */
    (void)0;
#endif
}

// 传感器在线/离线消抖状态机 (进气端raw + 出气端raw2 共用; do_collect/do_realtime_check 复用)
// 更新 offline_cnt/offline_cnt2; 消抖通过后更新 prev_online/prev_online2.
// 返回: 1 = 发生经消抖确认的状态变化 0 = 无变化
static uint8_t sensor_debounce_update(uint8_t cur_online, uint8_t cur_online2)
{
    uint8_t state_changed = 0;

    // --- 进气端(raw, PT304D #2) ---
    if(cur_online && !g_sensor.prev_online)
    {
        g_sensor.offline_cnt = 0;
        g_sensor.online_cnt++;
        if(g_sensor.online_cnt >= SENSOR_ONLINE_DEBOUNCE)
            state_changed = 1;
    }
    else if(!cur_online && g_sensor.prev_online)
    {
        g_sensor.online_cnt = 0;
        g_sensor.offline_cnt++;
        if(g_sensor.offline_cnt >= SENSOR_OFFLINE_DEBOUNCE)
            state_changed = 1;
    }
    else
    {
        g_sensor.offline_cnt = cur_online ? 0 : g_sensor.offline_cnt;
        g_sensor.online_cnt  = cur_online ? g_sensor.online_cnt : 0;
    }

    // --- 出气端(raw2, PT304D #1) --- // 双传感器时才参与消抖
    if(g_sensor_count >= 2)
    {
        if(cur_online2 && !g_sensor.prev_online2)
        {
            g_sensor.offline_cnt2 = 0;
            g_sensor.online_cnt2++;
            if(g_sensor.online_cnt2 >= SENSOR_ONLINE_DEBOUNCE)
                state_changed = 1;
        }
        else if(!cur_online2 && g_sensor.prev_online2)
        {
            g_sensor.online_cnt2 = 0;
            g_sensor.offline_cnt2++;
            if(g_sensor.offline_cnt2 >= SENSOR_OFFLINE_DEBOUNCE)
                state_changed = 1;
        }
        else
        {
            g_sensor.offline_cnt2 = cur_online2 ? 0 : g_sensor.offline_cnt2;
            g_sensor.online_cnt2  = cur_online2 ? g_sensor.online_cnt2 : 0;
        }
    }

    if(state_changed)
    {
        // 同时更新两个通道的 prev 状态
        if(cur_online != g_sensor.prev_online &&
           (cur_online  ? (g_sensor.online_cnt  >= SENSOR_ONLINE_DEBOUNCE)
                        : (g_sensor.offline_cnt >= SENSOR_OFFLINE_DEBOUNCE)))
        {
            g_sensor.prev_online = cur_online;
            g_sensor.offline_cnt = 0;
            g_sensor.online_cnt  = 0;
        }
        if(g_sensor_count >= 2 &&
           cur_online2 != g_sensor.prev_online2 &&
           (cur_online2 ? (g_sensor.online_cnt2  >= SENSOR_ONLINE_DEBOUNCE)
                        : (g_sensor.offline_cnt2 >= SENSOR_OFFLINE_DEBOUNCE)))
        {
            g_sensor.prev_online2 = cur_online2;
            g_sensor.offline_cnt2 = 0;
            g_sensor.online_cnt2  = 0;
        }
    }
    return state_changed;
}

// ==================== 硬件恢复 ====================
static void sys_init(void)
{
    /* 重定位中断向量表到 App 运行地址 (Bootloader 跳转后必须设置, Cortex-M23 支持 VTOR) */
    SCB->VTOR = OTA_APP_ADDR;


    systick_config();
    my_systick_config();
    timer1_delay_init();
    trea_uart_init();

    gpio_init();

    // PC0(V4G_EN 4G电源) 默认低电平: power_gpio_init 后 ODR=0 即 PC0=LOW
    // 若4G 需保持在线(long模式+活动窗口), 则在此处补一次上电, 避免 1s+ 的延时导致4G 复位
    // 弱信号模式: 4G已断电, 无需恢复PC0
    if(!voltage_low_power && !fourG_user_off && !fourG_init_failed && !fourG_weak_signal &&
       strcmp(g_window.pattern, "long") == 0 &&
       (config_is_active_window() || g_window.end_result == 1))
        power_4g_set(1);

    motor_init(MOTOR_ENABLED);
    soft_i2c_sensors_init();
    adc_bat_init();
    // PC0 (V4G_EN 4G电源) 状态由上层业务逻辑控制，此处不再重复操作
    // PA5 (M_SLP 电机使能) 由 valve_execute() 内部控制，此处不做提前处理
    // PD4 (I2C 传感器接口) 默认保持 LOW; 由采集点按需 set/reset

    debug_rx_init();   // USART0 RX中断缓冲初始化
}

// ==================== 前向声明 ====================
static void ensure_full_init(void);

// ==================== LCD信号强度更新 (仅在线时调用, 同时上报给平台) ====================
static void lcd_update_csq(void)
{
    char csq_buf[8] = {0};
	EC801E_Wakeup();
	trea_delay_ms(120);
    if(EC801E_QueryCSQ(csq_buf, sizeof(csq_buf)) == EC_OK)
    {
        uint8_t csq_val = (uint8_t)atoi(csq_buf);
        /* 不加 g_lcd_active 守卫: 灭屏期间也要更新缓存, 点屏后第一屏即显示本次读到的值;
         * 绘制由 lcd_ui_update_signal 内部按 SLCD 运行状态决定 */
        lcd_ui_update_signal(csq_val);

        // 上报CSQ信号给平台
        report_publish_field("csq", csq_buf);
    }

    // 附加信息: LTE信号质量 + 网络注册状态
    {
        int rsrp = 0, sinr = 0;
        uint8_t cereg = 0;
        EC801E_QueryQCSQ(&rsrp, &sinr);
        EC801E_QueryCEREG(&cereg);
        printf_debug("[SM] Signal: CSQ=%s RSRP=%d SINR=%d CEREG=%d\r\n",
                     csq_buf, rsrp, sinr, cereg);
    }
}

// ==================== 4G 电源管理模块: 上电/唤醒 + 恢复 ====================
// 确保4G模块通道可用: 已通电则直接唤醒, 未通电则开机并初始化
// 返回: 1=连接成功, 0=失败; *p_was_online: 之前4G是否在线(供fourG_restore)
static int fourG_ensure_ready(int *p_was_online)
{
    int was_online = power_4g_is_on();
    *p_was_online = was_online;

    com_lpuart_init();
    trea_delay_ms(100);
    gpio_init();

    if(was_online)
    {
        EC801E_Wakeup();
        return (EC801E_EnsureConnected() == EC_OK);
    }
    else
    {
        fourG_user_off = 0;
        /* InitAndConnect 内含完整冷启动时序 (V4G_EN+PWRKEY), 不再单独 PowerOn */
        int ok = (EC801E_InitAndConnect() == EC_OK);
        if(ok)
        {
            fourG_init_failed = 0;
            EC801E_SetPSM(0);
            /* 冷启动路径补布防 RI EXTI: do_wakeup 只在"唤醒时 4G 已带电"时才布防,
             * 冷启动这一路此前 RI 是关的 → 本次连接期间到达的下行脉冲没人接收,
             * 也就没有 ri_wakeup_flag 给 do_sleep 收口补读。这里补上后脉冲可锁存。 */
            ri_exti_init();
//            trea_delay_ms(300);
//            report_4g_power_state(1);
        }
        return ok;
    }
}

// 恢复4G到休眠状态:
//   success=0 (连接失败): 无论之前是否在线, 统一断电 (不再尝试PowerOn)
//   success=1 且之前在线: SetPSM(1) 恢复轻休眠保持在线
//   success=1 且之前断电: 上报下线后断电 (临时连接用完即关)
static void fourG_restore(int was_online, int success)
{
    if(!success)
    {
        EC801E_PowerOff();
        return;
    }
    if(was_online)
    {
        // long模式: 根据信号强度决定是否保持在线
        if(strcmp(g_window.pattern, "long") == 0)
        {
            char csq_buf[8] = {0};
            if(EC801E_QueryCSQ(csq_buf, sizeof(csq_buf)) == EC_OK)
            {
                uint8_t csq_val = (uint8_t)atoi(csq_buf);
                if(csq_val < CSQ_WEAK_THRESHOLD || csq_val == 99)
                {
                    printf_debug("[SM] CSQ=%d weak, power off 4G\r\n", csq_val);
                    fourG_weak_signal = 1;
//                    report_4g_power_state(0);
                    fourG_drain_before_power_off();
                    EC801E_PowerOff();
                    return;
                }
                else if(fourG_weak_signal)
                {
                    printf_debug("[SM] CSQ=%d recovered, restoring long mode\r\n", csq_val);
                    fourG_weak_signal = 0;
                }
            }
        }
        EC801E_SetPSM(1);
    }
    else
    {
        // 之前断电(冷启动): 判断是否为弱信号恢复路径
        if(fourG_weak_signal && strcmp(g_window.pattern, "long") == 0)
        {
            // 弱信号断电后重新检查信号是否恢复
            char csq_buf[8] = {0};
            if(EC801E_QueryCSQ(csq_buf, sizeof(csq_buf)) == EC_OK)
            {
                uint8_t csq_val = (uint8_t)atoi(csq_buf);
                if(csq_val >= CSQ_WEAK_THRESHOLD && csq_val != 99)
                {
                    printf_debug("[SM] CSQ=%d recovered (was weak), keep 4G online\r\n", csq_val);
                    fourG_weak_signal = 0;
                    EC801E_SetPSM(1);
                    return;
                }
            }
            // 否则: 断电
            printf_debug("[SM] Still weak signal, power off\r\n");
        }
//        report_4g_power_state(0);
        fourG_drain_before_power_off();
        EC801E_PowerOff();
    }
}

// ==================== 弱信号检测+决策 (do_upload/do_downlink 收尾专用) ====================
// 上报/下行处理完后调用, 决定是否让4G去休眠
// 返回: 1=信号OK(调用方应SetPSM), 0=信号弱(内部已断电)
static int fourG_signal_check_and_decide(void)
{
    if(strcmp(g_window.pattern, "long") != 0)
        return 1;  // 非long模式不适用该逻辑

    char csq_buf[8] = {0};
    if(EC801E_QueryCSQ(csq_buf, sizeof(csq_buf)) != EC_OK)
    {
        // 查询失败按弱信号处理
        printf_debug("[SM] CSQ query failed, power off 4G\r\n");
        fourG_weak_signal = 1;
//        report_4g_power_state(0);
        EC801E_PowerOff();
        return 0;
    }

    uint8_t csq_val = (uint8_t)atoi(csq_buf);
    if(csq_val < CSQ_WEAK_THRESHOLD || csq_val == 99)
    {
        printf_debug("[SM] CSQ=%d < %d, 4G power off (weak signal)\r\n", csq_val, CSQ_WEAK_THRESHOLD);

        fourG_weak_signal = 1;
//        report_4g_power_state(0);
        fourG_drain_before_power_off();
        EC801E_PowerOff();
        return 0;
    }

    // 信号恢复
    if(fourG_weak_signal)
    {
        printf_debug("[SM] CSQ=%d, signal recovered\r\n", csq_val);
        fourG_weak_signal = 0;
    }
    return 1;
}

// ==================== 电压采样模块 ====================

// 统一ADC电压采样: 读取→有效性判断→写入g_sensor.voltage
// update_baseline: 1=同时更新last_normal_voltage(正常采集), 0=仅更新voltage(报警重采等)
// fallback: ADC无效时的回退值 (通常为g_sensor.last_normal_voltage, 首次启动用3.6f)
static void sensor_sample_voltage(uint8_t update_baseline, float fallback)
{
    float v_now = adc_bat_read_voltage();
    if(v_now >= 0.0f)
    {
        g_sensor.voltage = v_now;
        if(update_baseline)
            g_sensor.last_normal_voltage = v_now;
    }
    else
        g_sensor.voltage = fallback;
}

/**
 * 异常自动关阀（通用）
 * @param policy_str  策略字符串（g_abnormal_close 或 g_abnormal2_close）
 * @param result      阈值判断结果
 * @return            动作执行结果字符串（已关阀），NULL（未关阀）
 *
 * 安全说明: 此函数内部初始化 IIC/电机，确保任何调用点均可安全执行
 */
const char* alarm_try_close_valve_all(const char *policy_str, ThresholdResult_t result)
{
    if (policy_str == NULL) {
        return NULL;
    }

    AbnormalClose_t policy = abnormal_from_str(policy_str);

    /* 仅按异常关阀策略判定; 电压类报警(VPROTECT/VOLT_HIGH/VOLT_LOW)只上报不动阀 */
    if (abnormal_should_close_valve(policy, result) && !g_valve_alarm_closed)
    {
        g_valve_pre_alarm_order = g_valve_last_order;

        printf_debug("[SM] Auto-close valve (policy=%s, result=%d, pre=%d)\r\n",
                     policy_str, result, g_valve_pre_alarm_order);

        soft_i2c_sensors_init();
        motor_init(MOTOR_ENABLED);

        swdt_feed();   /* 关阀忙等最长 g_valve_timeout_ms (默认 40s), 前后喂狗 */
        const char *vr = valve_execute("close", 0);
        swdt_feed();

        g_valve_alarm_closed     = 1;
        g_alarm_recover_reported = 0;   // 新一轮报警: 恢复上报标志复位
        config_save_ext();

        return vr;
    }

    return NULL;
}

const char* alarm_try_close_valve(ThresholdResult_t result)
{
    return alarm_try_close_valve_all(g_abnormal_close, result);
}

const char* alarm_try_close_valve2(ThresholdResult_t result)
{
    return alarm_try_close_valve_all(g_abnormal2_close, result);
}

//// 异常自动关阀 (进气端 abnormal_close pv* 策略): 根据策略判断是否关阀, 不依赖4G通信状态
//// 返回: 动作执行结果字符串(已关阀), NULL(未关阀)
//// 安全说明: 此函数内部初始化IIC/电机, 确保任何调用点的均可安全执行
//const char* alarm_try_close_valve(ThresholdResult_t result)
//{
//    AbnormalClose_t policy = abnormal_from_str(g_abnormal_close);
//    /* 仅按异常关阀策略判定; 电压类报警(VPROTECT/VOLT_HIGH/VOLT_LOW)只上报不动阀 */
//    if(abnormal_should_close_valve(policy, result) && !g_valve_alarm_closed)
//    {
//        g_valve_pre_alarm_order = g_valve_last_order;
//        printf_debug("[SM] Auto-close valve (policy=%s, result=%d, pre=%d)\r\n",
//                     g_abnormal_close, result, g_valve_pre_alarm_order);
//    soft_i2c_sensors_init();
//        motor_init(MOTOR_ENABLED);
//        const char *vr = valve_execute("close", 0);
//        g_valve_alarm_closed = 1;
//        g_alarm_recover_reported = 0;   // 新一轮报警: 恢复上报标志复位
//        config_save_ext();
//        return vr;
//    }
//    return NULL;
//}

//// 异常自动关阀 (出气端 abnormal2_close pv* 策略): 逻辑同进气端, 判定用 g_abnormal2_close
//// 返回: 动作执行结果字符串(已关阀), NULL(未关阀)
//const char* alarm_try_close_valve2(ThresholdResult_t result)
//{
//    AbnormalClose_t policy = abnormal_from_str(g_abnormal2_close);
//    if(abnormal_should_close_valve(policy, result) && !g_valve_alarm_closed)
//    {
//        g_valve_pre_alarm_order = g_valve_last_order;
//        printf_debug("[SM] Auto-close valve (outlet policy=%s, result=%d, pre=%d)\r\n",
//                     g_abnormal2_close, result, g_valve_pre_alarm_order);
//        soft_i2c_sensors_init();
//        motor_init(MOTOR_ENABLED);
//        const char *vr = valve_execute("close", 0);
//        g_valve_alarm_closed = 1;
//        g_alarm_recover_reported = 0;   // 新一轮报警: 恢复上报标志复位
//        config_save_ext();
//        return vr;
//    }
//    return NULL;
//}

// 激光甲烷异常自动关阀 (abnormal3_close: 1=开启): 报警即关阀, 关闭后保持
// 直到平台 valve_open 手动打开 (不参与压力/温度报警的自动恢复链)
// 关阀标志 EEPROM 持久化: 掉电/重启后保持关闭状态, 不会被下一次采集误判为"未关阀"
// 返回: 动作执行结果字符串(已关阀), NULL(策略未启用/已关闭)
const char* ch4_alarm_try_close_valve(void)
{
    if(g_abnormal3_close != 1)
        return NULL;
    if(g_ch4_alarm_closed)
        return NULL;

    g_ch4_alarm_closed = 1;
    g_alarm_recover_reported = 0;   // 新一轮报警: 恢复上报标志复位
    printf_debug("[SM] CH4 auto-close valve (abnormal3=1)\r\n");
    soft_i2c_sensors_init();
    motor_init(MOTOR_ENABLED);
    swdt_feed();   /* 关阀忙等最长 g_valve_timeout_ms (默认 40s), 前后喂狗 */
    const char *vr = valve_execute("close", 0);
    swdt_feed();
    config_save_ext();   // 关阀动作结束后再持久化标志: 中途掉电则重启后重新关阀, 避免半开状态被当作已关
    return vr;
}

// 用户端MQTT上报 (id=1, LY格式双通道): 连接、发送、断开 (约1分钟耗时)
static void user_mqtt_try_publish(void)
{
    if(!EC801E_UserMqtt_IsConfigured())
        return;

    trea_delay_ms(500);
    if(EC801E_UserMqtt_Connect() != EC_OK)
    {
        printf_debug("[SM] UserMqtt: connect failed, retry once...\r\n");
        trea_delay_ms(1000);
        if(EC801E_UserMqtt_Connect() != EC_OK)
        {
            printf_debug("[SM] UserMqtt: retry failed, skip publish\r\n");
            return;
        }
    }

    trea_delay_ms(300);
    if(EC801E_UserMqtt_PublishSensorData(&g_sensor.raw, &g_sensor.raw2, g_sensor.voltage) != EC_OK)
        printf_debug("[SM] UserMqtt: publish sensor data failed\r\n");
    else
        printf_debug("[SM] UserMqtt: publish OK\r\n");

    trea_delay_ms(500);
    EC801E_UserMqtt_Disconnect();
}

// ==================== 告警判定 + 确认上报 (周期/实时/查询共用) ====================
/* 双通道阈值评估: 离线通道不参与 (err != PT304D_OK 时保留读数为上次成功值,
 * 直接判定会把陈旧值当现场值)。单路机型通道1不评估。 */
typedef struct {
    ThresholdResult_t r1, r2;
    TempStatus_t      t1, t2;
    uint8_t           online1, online2;
} AlarmEval_t;

static void alarm_eval(AlarmEval_t *ev, uint8_t check_voltage,
                       float last_p1, float last_p2)
{
    ev->online1 = (g_sensor.raw.err == PT304D_OK) ? 1u : 0u;
    ev->online2 = (alarm_lock_ch_enabled(1) &&
                   g_sensor.raw2.err == PT304D_OK) ? 1u : 0u;
    ev->r1 = THRESHOLD_OK;
    ev->r2 = THRESHOLD_OK;
    ev->t1 = TEMP_NORMAL;
    ev->t2 = TEMP_NORMAL;

    if(ev->online1)
    {
        ev->r1 = threshold_check(g_sensor.raw.pressure, g_sensor.raw.temperature,
                                 g_sensor.voltage, last_p1, check_voltage, 0);
        ev->t1 = threshold_get_temp_status(g_sensor.raw.temperature);
    }
    if(ev->online2)
    {
        ev->r2 = threshold_check2(g_sensor.raw2.pressure, g_sensor.raw2.temperature,
                                  last_p2, 0);
        ev->t2 = threshold_get_temp_status2(g_sensor.raw2.temperature);
    }
}

/* 新等级掩码: bit0=通道0, bit1=通道1, bit2=电压 */
uint8_t alarm_new_mask(ThresholdResult_t r1, ThresholdResult_t r2, uint8_t check_voltage)
{
    TempStatus_t t1 = TEMP_NORMAL;
    TempStatus_t t2 = TEMP_NORMAL;
    uint8_t mask = 0;

    if(g_sensor.raw.err == PT304D_OK)
        t1 = threshold_get_temp_status(g_sensor.raw.temperature);
    if(alarm_lock_ch_enabled(1) && g_sensor.raw2.err == PT304D_OK)
        t2 = threshold_get_temp_status2(g_sensor.raw2.temperature);

    if(g_sensor.raw.err == PT304D_OK && alarm_lock_has_new(0, r1, t1))
        mask |= 0x01;
    if(alarm_lock_ch_enabled(1) && g_sensor.raw2.err == PT304D_OK &&
       alarm_lock_has_new(1, r2, t2))
        mask |= 0x02;
    if(check_voltage && alarm_lock_volt_has_new(r1))
        mask |= 0x04;

    return mask;
}

/* 确认告警: 用最新采样重算等级 → 锁存 → 按策略关阀 → 上报。
 * 调用方已完成 3 次重采确认; last_p1/last_p2 为进入告警前的上拍值
 * (重采期间固定不变, 用于突变判定与状态报文)。 */
const char* alarm_confirm_and_report(AlarmCtx_t ctx, uint8_t mask,
                                     float last_p1, float last_p2)
{
    AlarmEval_t ev;
    uint8_t check_voltage = (ctx == ALARM_CTX_COLLECT) ? 1u : 0u;
    uint8_t lat;
    const char *vr1;
    const char *vr2;
    const char *vr;
    uint8_t sensor_err;

    alarm_eval(&ev, check_voltage, last_p1, last_p2);

    /* 首检 mask ∪ 重采后 mask: 覆盖重采期间新出现的等级 */
    lat = (uint8_t)(mask | alarm_new_mask(ev.r1, ev.r2, check_voltage));

    if(lat & 0x01u) alarm_lock_latch(0, ev.r1, ev.t1);
    if(lat & 0x02u) alarm_lock_latch(1, ev.r2, ev.t2);
    if(lat & 0x04u) alarm_lock_volt_latch();
    alarm_lock_save(0);

    /* 关阀是安全动作, 不依赖 4G; 关阀忙等最长 g_valve_timeout_ms, 前后喂狗 */
    swdt_feed();
    vr1 = alarm_try_close_valve(ev.r1);
    vr2 = alarm_try_close_valve2(ev.r2);
    swdt_feed();
    vr = vr1 ? vr1 : vr2;

    printf_debug("[ALK] confirm ctx=%d mask=0x%02X lat=0x%02X r1=%d r2=%d%s\r\n",
                 (int)ctx, mask, lat, (int)ev.r1, (int)ev.r2,
                 vr ? " valve-closed" : "");

    sensor_err = (g_sensor.raw.err != PT304D_OK) ? 1u : 0u;

    if(ctx == ALARM_CTX_DOWNLINK)
    {
        /* 查询路径: 复用当前 MQTT 连接, 不额外拉起 4G */
        if(EC801E_EnsureConnected() == EC_OK)
        {
            report_publish_alarm_batch(last_p1, last_p2);
            if(lat & 0x04u)
            {
                trea_delay_ms(300);
                report_publish_ly06(1, g_sensor.voltage);
            }
            if(vr != NULL)
            {
                trea_delay_ms(300);
                EC801E_PublishValveStatus(vr, g_valve_last_order);
            }
        }
    }
    else
    {
        int was_online;
        int ec_ok = fourG_ensure_ready(&was_online);
        if(ec_ok)
        {
            report_publish_alarm_batch(last_p1, last_p2);
            if(lat & 0x04u)
                report_publish_ly06(1, g_sensor.voltage);
            if(sensor_err)
                report_publish_sensor_status();
            if(vr != NULL)
                EC801E_PublishValveStatus(vr, g_valve_last_order);

            /* 用户端 MQTT 同步上报传感器数据 */
            user_mqtt_try_publish();
        }
        fourG_restore(was_online, ec_ok);
    }

    return vr;
}

/* 3 次重采确认 (三条路径共用): 返回 1=确认异常, 0=偶发恢复。
 * 重采期间基线固定为传入的上拍值, 不得中途更新。 */
uint8_t alarm_recheck_confirm(uint8_t check_voltage, float last_p1, float last_p2)
{
    AlarmEval_t ev;
    uint8_t i;

    for(i = 0; i < APP_ALARM_RECHECK_COUNT; i++)
    {
        trea_delay_ms(APP_ALARM_RECHECK_DELAY_MS);
        swdt_feed();

        PT304D_CollectAll((g_sensor_count >= 2) ? &g_sensor.raw2 : NULL, &g_sensor.raw);
        if(check_voltage)
            sensor_sample_voltage(0, g_sensor.last_normal_voltage);

        alarm_eval(&ev, check_voltage, last_p1, last_p2);

        /* 只有真正做了电压判定的路径才推进电压恢复计数 (查询/实时不触碰) */
        if(check_voltage)
            (void)alarm_lock_volt_feed_normal(ev.r1, 1u);

        printf_debug("[ALK] recheck %d/%d: P1=%.2f T1=%.2f P2=%.2f T2=%.2f r1=%d r2=%d\r\n",
                     i + 1, APP_ALARM_RECHECK_COUNT,
                     g_sensor.raw.pressure, g_sensor.raw.temperature,
                     g_sensor.raw2.pressure, g_sensor.raw2.temperature,
                     (int)ev.r1, (int)ev.r2);

        if(alarm_new_mask(ev.r1, ev.r2, check_voltage) == 0)
        {
            printf_debug("[ALK] recheck %d: recovered, false alarm\r\n", i + 1);
            return 0;
        }
    }
    return 1;
}

// ==================== 状态上报汇总模块 ====================
// 上报实测值+状态 (temp/pressure/temp_status/pressure_status [+第二路])
// last_p1/last_p2: 上次压力值(用于突变判断)
static void publish_all_status(float last_p1, float last_p2)
{
    report_publish_status_all(last_p1, last_p2);
}

// ==================== 定时阀: 执行+上报(最高优先级) ====================
// action: "open" 或 "close"
// 执行阀门动作, 通过4G上报 valve_control + valve_last_order, 恢复PSM
static void vtiming_execute_and_report(const char *action);   /* forward */
/* timing valve immediate check: run during upload/blocking as fallback;
 * executes when within +-30s window and not yet done today */
/* 日期+1 (2000-2099, 4年一闰) */
static void vtiming_next_day(RtcDateTime_t *dt)
{
    static const uint8_t mdays[12] = {31,28,31,30,31,30,31,31,30,31,30,31};
    uint8_t maxd = mdays[dt->month - 1];

    if(dt->month == 2 && (dt->year % 4) == 0) maxd = 29;

    dt->day++;
    if(dt->day > maxd)
    {
        dt->day = 1;
        dt->month++;
        if(dt->month > 12)
        {
            dt->month = 1;
            dt->year++;
            if(dt->year > 99) dt->year = 0;   /* 2000年后回卷 */
        }
    }
}

/* 计算距离下一个匹配事件的时间 (YYMMDDHHMM, 支持通配); 无匹配返回 0xFFFFFFFF */
static uint32_t vtiming_next_wait(const char *t, const RtcDateTime_t *now)
{
    RtcDateTime_t cand;
    uint16_t days;
    uint32_t tgt_sec, now_sec;
    uint8_t y, mo, d, h, mi;

    if(!valve_timing_time_valid(t)) return 0xFFFFFFFF;

    y  = (uint8_t)((t[0] - '0') * 10 + (t[1] - '0'));
    mo = (uint8_t)((t[2] - '0') * 10 + (t[3] - '0'));
    d  = (uint8_t)((t[4] - '0') * 10 + (t[5] - '0'));
    h  = (uint8_t)((t[6] - '0') * 10 + (t[7] - '0'));
    mi = (uint8_t)((t[8] - '0') * 10 + (t[9] - '0'));

    tgt_sec = ((uint32_t)h * 60 + mi) * 60;
    now_sec = ((uint32_t)now->hour * 60 + now->minute) * 60 + now->second;

    cand = *now;
    for(days = 0; days <= 366; days++)
    {
        if((y == 0 || y == cand.year) &&
           (mo == 0 || mo == cand.month) &&
           (d == 0 || d == cand.day))
        {
            /* 目标已过 则从明天开始算 */
            if(days == 0 && tgt_sec <= now_sec) { }
            else
                return (uint32_t)days * 86400 + tgt_sec - now_sec;
        }
        vtiming_next_day(&cand);
    }
    return 0xFFFFFFFF;
}

/* timing valve immediate check: run during upload/blocking as fallback;
 * executes when date matches (wildcard) and within tolerance */
static void vtiming_check_now(void)
{
    RtcDateTime_t dt;

    /* 消费定时阀挂起事件: RTC ISR 置位的 g_timing_pending 必须在此清零,
     * 否则 EC_SendCmd 永久返回 EC_PREEMPT (4G 通信失效, do_upload 死循环) */
    g_timing_pending = 0;

    if(!g_valve_timing.on_switch && !g_valve_timing.off_switch) return;

    rtc_get_datetime(&dt);

    /* 跨天重置当日执行标志 */
    if(dt.hour == 0 && timing_last_reset_hour != 0)
    {
        timing_open_done_today  = 0;
        timing_close_done_today = 0;
        timing_last_reset_hour  = 0;
    }
    else if(dt.hour != 0)
        timing_last_reset_hour = dt.hour;

    /* 开阀: 定时开 + 当日未执行 + 时间匹配(±30s) */
    if(!timing_open_done_today && g_valve_timing.on_switch &&
       valve_timing_time_match(g_valve_timing.open_time, &dt, 30))
    {
        vtiming_execute_and_report("open");
        timing_open_done_today = 1;
    }

    /* 关阀 */
    if(!timing_close_done_today && g_valve_timing.off_switch &&
       valve_timing_time_match(g_valve_timing.close_time, &dt, 30))
    {
        vtiming_execute_and_report("close");
        timing_close_done_today = 1;
    }
}

static void vtiming_execute_and_report(const char *action)
{
    g_timing_pending = 0;   /* 执行前消费挂起事件, 确保 4G 上报不被 EC_PREEMPT 拦截 */
    /* 报警自动关阀/激光甲烷关阀未恢复前禁止自动开阀 (工业安全) */
    if(strcmp(action, "open") == 0 && (g_ch4_alarm_closed || g_valve_alarm_closed))
    {
        printf_debug("[SM] VTIMING: open skipped (alarm latch active)\r\n");
        return;
    }
    ensure_full_init();
    soft_i2c_sensors_init();
    motor_init(MOTOR_ENABLED);
    const char *vr = valve_execute(action, 1);
    printf_debug("[SM] VTIMING: %s result=%s\r\n", action, vr);

    int was_online;
    int ec_ok = fourG_ensure_ready(&was_online);
    if(ec_ok)
        EC801E_PublishValveStatus(vr, g_valve_last_order);
    fourG_restore(was_online, ec_ok);
}

// ==================== 实时路径: 按用户选择进入休眠 ====================
static void realtime_enter_sleep(void)
{
    uint8_t lpuart_enabled = 0;

    sensor_pwr_off();   /* 常供电板型空实现 (PC3 归 ADC 基准) */
    rtc_alarm_wakeup_init();
    rtc_set_next_alarm_sec_quiet(g_real_frequency);   /* 实时重布防: 不刷 RTC 日志 */
    g_timing_alarm_set = 0;   /* realtime alarm, timing handled per-cycle */

    // 4G在线时启用LPUART唤醒 + RI中断 (可接收平台下发, 弱信号断电时禁用)
    if(!voltage_low_power && !fourG_user_off && !fourG_init_failed && !fourG_weak_signal &&
       strcmp(g_window.pattern, "long") == 0 &&
       (config_is_active_window() || g_window.end_result == 1))
    {
        power_4g_set(1);   /* 深睡期间由 MCU 保持 V4G_EN(PC0) HIGH */
        com_lpuart_init();
        lpuart_wakeup_init();
        ri_exti_init();
        lpuart_enabled = 1;
    }

    button_exti_init();
    PM_BLE_EXTI_ARM();
    lpuart_dma_rx_disable();
    {
        PmSleepCfg_t sc = { lpuart_enabled, g_lcd_active, PM_BT_FLAG() };
        enter_deepsleep_mode(&sc);
    }
}

// ==================== 实时采集最小唤醒路径 ====================
// 最小化初始化 SysTick + I2C + PD4, 采集判断异常
// 异常时重采确认, 确认后通过4G上报; 正常时直接回睡
// ==================== ==================== ====================
static void do_realtime_check(void)
{
    AlarmEval_t ev;
    float prev_p1, prev_p2;
    uint8_t mask;
    uint8_t unlocked;

    // === 最小初始化 (时钟恢复) ===
    system_wakeup_reinit();

    // 软件看门狗: 实时采集路径由 do_sleep 循环直接调用(非主循环入口), 需自行使能
    // SysTick 由 system_wakeup_reinit 重新启动; 休眠时 enter_deepsleep_mode 会关闭
    swdt_enable(SWDT_TIMEOUT_MS);

    // === 采集 (双通道, 不采ADC; PD4/IIC 由 CollectAll 内部处理) ===
    PT304D_CollectAll((g_sensor_count >= 2) ? &g_sensor.raw2 : NULL, &g_sensor.raw);

    // === LCD超时检查 + 采集后刷新显示 ===
    lcd_check_timeout();
#if (LCD_LOCK_ENABLED || LCD_KEY_TRIGGER_ENABLED)
    /* 按键点亮模式/锁定模式: 只刷新, 不自动翻页 (翻页只由按键触发) */
    if(g_lcd_active) lcd_ui_refresh(&g_sensor.raw, &g_sensor.raw2, g_sensor.voltage);
#else
    /* LCD常亮模式: 每个采集周期自动翻一页 */
    if(g_lcd_active) { lcd_ui_refresh(&g_sensor.raw, &g_sensor.raw2, g_sensor.voltage); lcd_ui_next_page(); }
#endif

    // === 传感器在线/离线状态变化检测(带消抖, 双路在线/离线) ===
    {
        uint8_t cur_online  = (g_sensor.raw.err  == PT304D_OK) ? 1 : 0;
        uint8_t cur_online2 = (g_sensor.raw2.err == PT304D_OK) ? 1 : 0;
        uint8_t state_changed = sensor_debounce_update(cur_online, cur_online2);

        if(state_changed)
        {
            ensure_full_init();
            trea_uart_init();
            {
                char rt_ts[32];
                rtc_get_time_str(rt_ts, sizeof(rt_ts));
                printf_debug("[RT] %s SENSOR STATE CHANGED: S2=%s(err=%d) S1=%s(err=%d) freq=%ds\r\n",
                             rt_ts,
                             cur_online  ? "ON" : "OFF", g_sensor.raw.err,
                             cur_online2 ? "ON" : "OFF", g_sensor.raw2.err,
                             g_real_frequency);
            }

            // 启动4G上报
            {
                int was_online;
                int ec_ok = fourG_ensure_ready(&was_online);
                if(ec_ok)
                {
                    report_publish_sensor_status();
                    printf_debug("[RT] Sensor state reported\r\n");
                }
                fourG_restore(was_online, ec_ok);
            }

            // 传感器离线时不参与阈值检查, 直接回睡
            // 告警锁: 离线通道不计正常、保留最后等级; 基线置 -1 跳过恢复首拍突变
            if(!cur_online)
            {
                alarm_lock_feed_normal(0, 0, THRESHOLD_OK, TEMP_NORMAL);
                alarm_lock_feed_normal(1, 0, THRESHOLD_OK, TEMP_NORMAL);
                g_sensor.last_pressure_realtime  = -1.0f;
                g_sensor.last_pressure_realtime2 = -1.0f;
                alarm_lock_save(0);
                realtime_enter_sleep();
                return;
            }
        }
        else if(!cur_online)
        {
            // 传感器在线(异常期间), 不重复上报, 直接回睡
            alarm_lock_feed_normal(0, 0, THRESHOLD_OK, TEMP_NORMAL);
            alarm_lock_feed_normal(1, 0, THRESHOLD_OK, TEMP_NORMAL);
            g_sensor.last_pressure_realtime  = -1.0f;
            g_sensor.last_pressure_realtime2 = -1.0f;
            alarm_lock_save(0);
            realtime_enter_sleep();
            return;
        }
    }

    // === 阈值评估 + 告警锁 (恢复去抖: 每拍推进) ===
    // 实时路径不采 ADC: check_voltage=0, 不触碰电压锁
    prev_p1 = g_sensor.last_pressure_realtime;
    prev_p2 = g_sensor.last_pressure_realtime2;

    alarm_eval(&ev, 0, prev_p1, prev_p2);

    unlocked  = alarm_lock_feed_normal(0, ev.online1, ev.r1, ev.t1);
    unlocked |= alarm_lock_feed_normal(1, ev.online2, ev.r2, ev.t2);

    // === 恢复正常 (连续 3 拍): 上报一次恢复; VLP 模式不额外开 4G ===
    if(unlocked)
    {
        ensure_full_init();
        if(voltage_low_power)
        {
            printf_debug("[RT] ALK recovered (VLP, skip 4G report)\r\n");
        }
        else
        {
            int was_online;
            int ec_ok = fourG_ensure_ready(&was_online);
            if(ec_ok)
            {
                if(g_valve_alarm_closed && !g_ch4_alarm_closed)
                {
                    g_alarm_recover_reported = 1;
                    motor_limit_init();   /* 深休眠后 PA11/PA12 为 Analog, 读限位前恢复输入 */
                    EC801E_PublishValveStatus(valve_get_status(), g_valve_last_order);
                }
                report_publish_ly06(0, g_sensor.last_normal_voltage);
                publish_all_status(prev_p1, prev_p2);
            }
            fourG_restore(was_online, ec_ok);
        }
    }

    // === 新等级判定 (等级变化才上报; 电压码不进通道锁) ===
    mask = alarm_new_mask(ev.r1, ev.r2, 0);

    // 基线必须晚于阈值检查更新; 离线通道置 -1, 恢复后首拍跳过突变
    g_sensor.last_pressure_realtime  = ev.online1 ? g_sensor.raw.pressure  : -1.0f;
    g_sensor.last_pressure_realtime2 = ev.online2 ? g_sensor.raw2.pressure : -1.0f;

    if(mask == 0)
    {
        alarm_lock_save(0);   /* 正常采样定期 flush */
        realtime_enter_sleep();
        return;
    }

    // === 3 次重采确认 (共用函数; 基线固定为进入前的上拍值) ===
    printf_debug("[RT] ALK new mask=0x%02X, rechecking...\r\n", mask);
    if(!alarm_recheck_confirm(0, prev_p1, prev_p2))
    {
        g_sensor.last_pressure_realtime  = (g_sensor.raw.err == PT304D_OK)
                                         ? g_sensor.raw.pressure : -1.0f;
        g_sensor.last_pressure_realtime2 = (alarm_lock_ch_enabled(1) &&
                                            g_sensor.raw2.err == PT304D_OK)
                                         ? g_sensor.raw2.pressure : -1.0f;
        alarm_lock_save(0);
        realtime_enter_sleep();
        return;
    }

    // === 确认异常 → 锁存 + 按策略关阀 + 上报 ===
    ensure_full_init();
    trea_uart_init();
    printf_debug("[RT] ALK ALARM CONFIRMED mask=0x%02X P1=%.2f T1=%.2f\r\n",
                 mask, g_sensor.raw.pressure, g_sensor.raw.temperature);

    (void)alarm_confirm_and_report(ALARM_CTX_REALTIME, mask, prev_p1, prev_p2);

    g_sensor.last_pressure_realtime  = (g_sensor.raw.err == PT304D_OK)
                                     ? g_sensor.raw.pressure : -1.0f;
    g_sensor.last_pressure_realtime2 = (alarm_lock_ch_enabled(1) &&
                                        g_sensor.raw2.err == PT304D_OK)
                                     ? g_sensor.raw2.pressure : -1.0f;
    alarm_lock_save(0);
    realtime_enter_sleep();
}

// ==================== 休眠流程 ====================
static void do_sleep(void)
{
    int fourG_keep_on = 0;

#if CALIB_MODE_ENABLED
    if(!calib_is_active())
        calib_lcd_exit_to_normal();     /* 已锁定: 取消未安装期LCD短亮状态 */
#endif

    motor_sleep_disable();   /* M_SLP(PA5) 拉低: 电机禁用 */
    sensor_pwr_off();   /* 常供电板型空实现 (PC3 归 ADC 基准) */

    gpio_bit_reset(GPIOA, GPIO_PIN_2);
    gpio_bit_reset(GPIOA, GPIO_PIN_3);
    gpio_bit_reset(GPIOC, GPIO_PIN_4);
    gpio_bit_reset(GPIOC, GPIO_PIN_5);
    gpio_bit_reset(GPIOB, GPIO_PIN_8);
    // PB9 = SLCD COM3, 保持关闭
    // PB6/PB7(I2C0 SCL/SDA): 常供电总线, 由 gpio_enter_low_power 转 Analog
    // 避免休眠期间总线上残留异常 I2C 信号导致功耗异常

#if MOTOR_DRV_MODE == 0
    gpio_bit_reset(GPIOA, GPIO_PIN_6);
    gpio_bit_reset(GPIOA, GPIO_PIN_7);
#endif

    /* ==================== 大睡收口: 补读长流程期间到达的下行指令 ====================
     * RI 只在"平台新下发"时产生下降沿脉冲, 读历史缓存不会再脉冲,
     * 所以长流程(暖机/逐条上报/阀动作/OTA)期间到达的指令若不在睡前读走就不会自愈。
     * 放在 4G 电源决策之前: 补读可能改变 fourG_init_failed / fourG_weak_signal。
     * 常态下 ri_wakeup_flag=0 → 一次 AT 都不发, 不影响功耗。 */
    if(ri_wakeup_flag)
    {
        ri_wakeup_flag = 0;      /* 先消费: 后面 ri_exti_init()/enter_deepsleep_mode() 都会清标志 */
        if(power_4g_is_on())
        {
            uint8_t drained;

            printf_debug("[SM] SLEEP: RI pending, drain before sleep\r\n");
            ensure_full_init();  /* 最小唤醒 → 完整初始化(处理指令需 EEPROM 配置/4G参数) */
            com_lpuart_init();
            trea_delay_ms(100);
            gpio_init();         /* 深休眠后 DTR/RI/LPUART 引脚为 Analog, 恢复后才能读下发 */

            drained = drain_pending_downlink();
            if(ri_wakeup_flag)   /* 补读期间又来了新指令(RI 再次脉冲) → 再补一轮 */
            {
                ri_wakeup_flag = 0;
                drained += drain_pending_downlink();
            }
            printf_debug("[SM] SLEEP: drained %d msg(s)\r\n", drained);

            /* 补读把 DTR 拉低了: 必须恢复 QSCLK(允许休眠), 否则模块整个休眠期不睡 */
            EC801E_SetPSM(1);
        }
        else
        {
            printf_debug("[SM] SLEEP: RI pending but 4G off, skip\r\n");
        }
    }

    // 4G电源控制: 根据window pattern决定PC0(V4G_EN)状态
    // 低电压省电模式: 强制4G断电
    if(voltage_low_power)
    {
        power_4g_set(0);
    }
    else if(strcmp(g_window.pattern, "long") == 0)
    {
        // long模式: 活动窗口或end_result=1时保持4G (用户手动关闭/弱信号除外)
        if(!fourG_user_off && !fourG_init_failed && !fourG_weak_signal && (config_is_active_window() || g_window.end_result == 1))
        {
            fourG_keep_on = 1;
            power_4g_set(1);   /* 显式保持 V4G_EN(PC0) HIGH: 深睡期间由 MCU 维持模块供电 */
            power_4g_dtr_set(1);   /* DTR HIGH: 允许模块进入轻休眠 (深睡时 PA0 保持输出) */
        }
        else
            power_4g_set(0);  // long+er=0+非窗口: user_off/weak_signal: 4G断电
    }
    else
    {
        // short/dot: 4G始终断电(由do_upload上报时临时PowerOn后PowerOff)
        power_4g_set(0);
    }

#if (LCD_LOCK_ENABLED || LCD_KEY_TRIGGER_ENABLED)
    // === LCD 无操作息屏: LCD处于显示时, 先短睡, 到点后再关闭 ===
    //     按键点亮模式: LCD_KEY_BLANK_SEC 秒 (每次按键都会刷新 g_lcd_on_hhmmss)
    // 实时模式(1-10s频率): do_realtime_check + lcd_check_timeout() 会处理, 此处跳过
    if(g_lcd_active && !real_mode_active() && !CALIB_LCD_BLOCKED())
    {
        uint32_t now_sec = hhmmss_to_seconds(rtc_get_hhmmss());
        uint32_t on_sec  = hhmmss_to_seconds(g_lcd_on_hhmmss);
        uint32_t elapsed = (now_sec >= on_sec) ? (now_sec - on_sec) : (86400 - on_sec + now_sec);

		
        if(elapsed < LCD_BLANK_TIMEOUT_SEC)
        {
			
            uint32_t remain = LCD_BLANK_TIMEOUT_SEC - elapsed;
            if(remain < 1) remain = 1;

            rtc_alarm_wakeup_init();
            rtc_set_next_alarm_sec((uint8_t)remain);
            g_timing_alarm_set = 0;   /* LCD timeout sleep: normal alarm */
            button_exti_init();
            PM_BLE_EXTI_ARM();
            if(fourG_keep_on) { com_lpuart_init(); lpuart_wakeup_init(); ri_exti_init(); }
            lpuart_dma_rx_disable();

            printf_debug("[SM] LCD timeout sleep %ds\r\n", (int)remain);
            trea_delay_ms(20);
            {
                PmSleepCfg_t sc = { (uint8_t)fourG_keep_on, g_lcd_active, PM_BT_FLAG() };
                enter_deepsleep_mode(&sc);
            }

            // 唤醒: 按键/LPUART/RI(可选BLE)事件 → 直接进入 STATE_WAKEUP
            if(button_wakeup_flag || counter0 || ri_wakeup_flag || ble_connect_wakeup_flag)
            {
                app_state = STATE_WAKEUP;
                return;
            }

            /* RTC 到点唤醒(非人工事件): 必须先恢复系统 —— 深休眠后 APB1 停摆,
             * TIMER1 计数器不再走动, 而 trea_delay_ms()/delay_us() 依赖它,
             * 且此时看门狗已被 enter_deepsleep_mode() 关闭, 不恢复会死等无复位。
             * 同时重新初始化调试串口(深休眠把 PC4/PC5 转 Analog), 保证后续日志可见 */
            system_wakeup_reinit();
            trea_uart_init();
        }
        // RTC 超时唤醒后继续: 关闭 LCD
        lcd_shutdown();
        printf_debug("[SM] LCD off after timeout\r\n");
    }
#endif /* LCD_LOCK_ENABLED || LCD_KEY_TRIGGER_ENABLED */

    // 重设RTC闹钟: 计算好下次采集时刻, 防止超时唤醒错过窗口
    rtc_alarm_wakeup_init();

    // 定时阀门: 计算最近一个未执行的阀门事件距当前的时间
    // 定时阀门: 计算最近一个未执行的阀门事件距当前的时间
    {
        uint8_t use_valve_alarm = 0;
        uint32_t valve_wait_sec = 0xFFFFFFFF;

        if((g_valve_timing.on_switch || g_valve_timing.off_switch) && !real_mode_active())
        {
            RtcDateTime_t dt;
            rtc_get_datetime(&dt);

            if(!timing_open_done_today && g_valve_timing.on_switch)
            {
                uint32_t w = vtiming_next_wait(g_valve_timing.open_time, &dt);
                if(w < valve_wait_sec) valve_wait_sec = w;
            }
            if(!timing_close_done_today && g_valve_timing.off_switch)
            {
                uint32_t w = vtiming_next_wait(g_valve_timing.close_time, &dt);
                if(w < valve_wait_sec) valve_wait_sec = w;
            }

            // 阀门事件更早: 可等待到目标时间, 直接设定秒级闹钟
            uint32_t collect_sec = (uint32_t)sched_collect_min() * 60;
            if(valve_wait_sec < collect_sec && valve_wait_sec < 0xFFFFFFFF)
            {
                // 计算目标绝对时间(可能跨天), 换算为HHMMSS
                uint32_t t_abs = ((uint32_t)dt.hour * 60 + dt.minute) * 60 + dt.second + valve_wait_sec;
                uint32_t target_hhmmss;
                t_abs %= 86400;
                target_hhmmss = (t_abs / 3600) * 10000 + ((t_abs / 60) % 60) * 100 + (t_abs % 60);

                rtc_set_alarm_at_hhmmss(target_hhmmss);
                g_timing_alarm_set = 1;   /* timing valve alarm */
                use_valve_alarm = 1;
            }
        }

        if(!use_valve_alarm)
        {
            if(real_mode_active())
                rtc_set_next_alarm_sec(g_real_frequency);
            else
                sched_set_next_collect_alarm();   /* 绝对轴: 跨天周期锚定到期时刻(最多提前1天判定) */
            g_timing_alarm_set = 0;   /* normal collect alarm */
        }

#if CALIB_MODE_ENABLED
        /* 未安装期LCD截止事件: 若比阀门/后延闹钟更近, 用秒级闹钟覆盖 */
        if(calib_is_active() && s_cal_lcd_wait)
        {
            int32_t left = calib_lcd_left();
            if(left <= 0)
                calib_lcd_next_step();          /* 已过期: 立即切页/息屏 */
            if(s_cal_lcd_wait)
            {
                left = calib_lcd_left();
                if(!use_valve_alarm ||
                   (valve_wait_sec != 0xFFFFFFFFu && (uint32_t)left < valve_wait_sec))
                {
                    calib_lcd_alarm_set();
                    g_timing_alarm_set = 0;
                    use_valve_alarm = 1;        /* 防止被后续collect闹钟覆盖 */
                }
            }
        }
#endif
    }

    // LPUART唤醒 + RI中断: 4G在线时允许接收(可接收下行URC)
    if(fourG_keep_on)
    {
        com_lpuart_init();
        lpuart_wakeup_init();
        ri_exti_init();
    }

    // PA12按键唤醒: 始终使能(可手动唤醒4G)
    button_exti_init();

#if BLE_ENABLED
    // BLE连接事件未触发(与按键同时到达), 回到WAKEUP处理
    if(ble_connect_wakeup_flag)
    {
        app_state = STATE_WAKEUP;
        return;
    }

    // BLE超时: 超过60s未连接超时, 未超时则使用PD2 EXTI等待
    if(g_bt_on)
    {
        uint32_t now_sec = hhmmss_to_seconds(rtc_get_hhmmss());
        uint32_t on_sec  = hhmmss_to_seconds(g_ble_on_hhmmss);
        uint32_t elapsed = (now_sec >= on_sec) ? (now_sec - on_sec) : (86400 - on_sec + now_sec);
        if(elapsed >= 60)
        {
            printf_debug("[SM] BLE timeout (%ds), auto power off\r\n", (int)elapsed);
            g_bt_on = 0;
            power_ble_set(0);
            if(g_lcd_active) slcd_seg_icon_display(SLCD_ICON_LY, RESET);
        }
        else
        {
            ble_exti_init();
        }
    }
#endif /* BLE_ENABLED */

    // 关闭接收DMA(休眠期间DMA时钟被关闭, 唤醒后重新配置)
    lpuart_dma_rx_disable();

    if(real_mode_active())
        printf_debug("[SM] SLEEP %ds-RT (buf=%d 4G=%s BLE=%d)\r\n",
                     g_real_frequency, ee_hist_count(),
                     fourG_keep_on ? "ON" : "OFF", PM_BT_FLAG());
    else
        printf_debug("[SM] SLEEP %dmin (buf=%d 4G=%s BLE=%d)\r\n",
                     sched_collect_min(), ee_hist_count(),
                     fourG_keep_on ? "ON" : "OFF", PM_BT_FLAG());
    trea_delay_ms(20);

    {
        PmSleepCfg_t sc = { (uint8_t)fourG_keep_on, g_lcd_active, PM_BT_FLAG() };
        enter_deepsleep_mode(&sc);
    }

#if CALIB_MODE_ENABLED
    /* 未安装期LCD定时事件(非阻塞): 到期唤醒切页/息屏, 不采样 */
    while(calib_is_active() && s_cal_lcd_wait &&
          rtc_alarm_flag && !counter0 && !ri_wakeup_flag && !button_wakeup_flag && !ble_connect_wakeup_flag)
    {
        if(calib_lcd_left() > 0)
            break;                              /* 非LCD事件(阀门/后延等): 交回正常流程 */

        system_wakeup_reinit();
        trea_uart_init();
        calib_lcd_next_step();
        rtc_alarm_flag = 0;                     /* 消费LCD定时唤醒 */

        if(!calib_is_active() || !s_cal_lcd_wait)
            break;                              /* 息屏完成 */

        calib_lcd_alarm_set();
        if(fourG_keep_on)
        {
            /* system_wakeup_reinit 关闭了 LPUART/RI 唤醒, 重新布防保持随时可收下行 */
            com_lpuart_init();
            lpuart_wakeup_init();
            ri_exti_init();
            power_4g_set(1);
            power_4g_dtr_set(1);
        }
        {
            PmSleepCfg_t sc2 = { (uint8_t)fourG_keep_on, g_lcd_active, PM_BT_FLAG() };
            enter_deepsleep_mode(&sc2);
        }
    }
    if(calib_is_active() && !s_cal_lcd_wait &&
       !rtc_alarm_flag && !counter0 && !ri_wakeup_flag && !button_wakeup_flag && !ble_connect_wakeup_flag)
    {
        app_state = STATE_SLEEP;                /* 息屏完成: 直接回睡, 避免误入采集 */
        return;
    }
#endif

    // 实时采集循环: RTC秒级唤醒 → 判断是否到采集分钟 → 否则最小实时采集→睡
    while(real_mode_active() && rtc_alarm_flag && !counter0 && !ri_wakeup_flag && !button_wakeup_flag && !ble_connect_wakeup_flag)
    {
        // 最小时钟恢复 → 查RTC中断是否到达网格采集时刻
        system_wakeup_reinit();
        /* 深睡前 gpio_enter_low_power() 会把 PC4/PC5 转 Analog,
         * 不重新初始化则本拍所有日志(告警/重采/关阀/上报)都打印不出来 */
        trea_uart_init();
        rtc_register_sync_wait();

        {
            uint32_t now_hhmmss = rtc_get_hhmmss();
            uint8_t cur_sec = (uint8_t)(now_hhmmss % 100);
            uint32_t abs_min = sched_abs_min();

            // 网格采集时刻到 (分钟+5s容差, 且当前分钟未执行过采集 → 退出循环, 转入STATE_WAKEUP
            if(sched_collect_min() > 0 &&
               (abs_min % (uint32_t)sched_collect_min()) == 0 &&
               cur_sec < 6 &&
               abs_min != last_grid_collect_abs_min)
                break;

            // 待上报(到期) → 退出实时循环直接转上报, 不采集
            if(upload_due_now())
            {
                printf_debug("[SM] RT upload due, break to upload\r\n");
                ensure_full_init();
                app_state = STATE_UPLOAD;
                return;              /* 必须 return: break 会走到函数末尾把 app_state 覆写为 WAKEUP */
            }

            // ---- 实时模式下的定时阀门检查 ----
            // ---- 实时模式下的定时阀门检查 ----
            if(g_valve_timing.on_switch || g_valve_timing.off_switch)
            {
                RtcDateTime_t dt;
                rtc_get_datetime(&dt);

                // 跨天重置当日执行标志
                if(dt.hour == 0 && timing_last_reset_hour != 0)
                {
                    timing_open_done_today  = 0;
                    timing_close_done_today = 0;
                    timing_last_reset_hour  = 0;
                }
                else if(dt.hour != 0)
                    timing_last_reset_hour = dt.hour;

                // 检查开阀 (容差5秒, 实时模式频率高于30s)
                if(!timing_open_done_today && g_valve_timing.on_switch &&
                   valve_timing_time_match(g_valve_timing.open_time, &dt, 5))
                {
                    printf_debug("[SM] VTIMING-RT: OPEN at %02u:%02u\r\n", dt.hour, dt.minute);
                    vtiming_execute_and_report("open");
                    timing_open_done_today = 1;
                }
                // 检查关阀 (容差5秒)
                if(!timing_close_done_today && g_valve_timing.off_switch &&
                   valve_timing_time_match(g_valve_timing.close_time, &dt, 5))
                {
                    printf_debug("[SM] VTIMING-RT: CLOSE at %02u:%02u\r\n", dt.hour, dt.minute);
                    vtiming_execute_and_report("close");
                    timing_close_done_today = 1;
                }
            }

#if LASER_CH4_ENABLED
            // ---- 实时模式下的激光甲烷定时采集检查 ----
            // 命中时间点 → 置 g_ch4_request 并退出实时循环;
            // 由主循环在网格采集/整点上传完成后执行 STATE_CH4 (不抢占采集)
            if(g_laser_switch &&
               ((uint8_t)(now_hhmmss / 10000)) != s_laser_done_hour &&
               window_dottime_hit(g_laser_time_mask, (uint8_t)(now_hhmmss / 10000)))
            {
                printf_debug("[SM] LASER schedule trigger at %02u:00\r\n", (uint8_t)(now_hhmmss / 10000));
                g_ch4_request = 1;
                break;
            }
#endif
        }

        // 非采集分钟 → 最小实时采集 (内部: 采集→判断→[异常上报]→上电→进入睡眠→唤醒后返回)
        do_realtime_check();
        // do_realtime_check 返回后, 新的唤醒标志已被复位, while再次判断
    }

    // 唤醒后统一转入 WAKEUP 状态
    app_state = STATE_WAKEUP;
}

// ==================== 唤醒恢复 ====================
static void do_wakeup(void)
{
    // 判断是否为纯RTC网格采集唤醒 (非按键且非LPUART且非RI且非BLE唤醒)
    if(button_wakeup_flag == 0 && counter0 == 0 && ri_wakeup_flag == 0 && ble_connect_wakeup_flag == 0)
    {
        g_is_minimal_wakeup = 1;
        g_need_adc_sampling = 0;
        
        system_wakeup_reinit();
        
        // 最小采集初始化: Systick和Debug 串口未启动, 仅初始化 I2C; PC3 基准由 adc_bat 内部保证
        systick_config();
//        my_systick_config();
        trea_uart_init();
        
        if(g_need_adc_sampling)
        {
            adc_bat_init();
        }
        
        button_exti_disable();
        
        rtc_show_time();
        printf_debug("[SM] PURE RTC WAKEUP: minimal init (ADC=%d)\r\n", g_need_adc_sampling);
    }
    else if(button_wakeup_flag && counter0 == 0 && ri_wakeup_flag == 0)
    {
        // === 按键唤醒 (快速检测路径: 最小初始化, 不执行 sys_init() 约1s 延时 ===
        // GPIO 状态在休眠期间保持不变, PD0 作为按键输入, button_is_pressed() 可直接使用
        // 需要完整功能时由 ensure_full_init() 升级处理
        g_is_minimal_wakeup = 1;
        g_need_adc_sampling = 1;
        
        system_wakeup_reinit();
        trea_uart_init();
		buzzer_init();
        button_exti_disable();
        
        rtc_show_time();
        printf_debug("[SM] WAKEUP: BUTTON (fast detect)\r\n");
    }
    else
    {
        // === LPUART/RI 唤醒或恢复会话: 完整初始化 ===
        g_is_minimal_wakeup = 0;
        g_need_adc_sampling = 1;
        
        system_wakeup_reinit();
        sys_init();
        
        // 禁用按键EXTI(唤醒后立即禁用防止抖动重复触发)
        button_exti_disable();
        
        // PC0(V4G_EN 4G电源)恢复: gpio_init默认PC0=LOW
        // 低电压省电模式: 不恢复4G
        // 用户手动关闭: 不恢复4G(等待用户再次打开)
        // 弱信号模式: 不恢复4G(下次上报时再尝试)
        // long模式: 活动窗口或end_result=1时恢复4G供电
        if(!voltage_low_power && !fourG_user_off && !fourG_init_failed && !fourG_weak_signal &&
           strcmp(g_window.pattern, "long") == 0 &&
           (config_is_active_window() || g_window.end_result == 1))
            power_4g_set(1);
        // 其他情况(VLP/user_off/weak_signal/short/dot/long+er=0+非窗口): PC0保持LOW
        
        rtc_show_time();
        printf_debug("\r\n");
    }

    // === 按键唤醒: 只做 LCD 点亮与翻页 (按下即响应) ===
    //   灭屏 → 首次按下: 只点亮默认页, 不翻页
    //   亮屏 → 再次按下: 翻下一页 (不判连击/长按, 长按无功能)
    //   点亮后 LCD_BLANK_TIMEOUT_SEC 秒无操作: 由 do_sleep 短睡闹钟自动息屏
    if(button_wakeup_flag)
    {
        printf_debug("[SM] WAKEUP: BUTTON\r\n");

        uint8_t lcd_was_off = !g_lcd_active;
        lcd_activate();                 /* 点亮: 内部完成 SLCD 初始化, 页复位到默认页 */
#if CALIB_MODE_ENABLED
        if(calib_is_active())
            calib_lcd_activity();       /* 未安装期: 点亮并重置无操作计时 */
#endif

        button_wakeup_flag = 0;
        if(g_lcd_active)
            buzzer_beep(1, 200);        /* 按键有效提示音(有屏时) */

        if(lcd_was_off)
        {
            if(g_lcd_active)
                lcd_ui_refresh(&g_sensor.raw, &g_sensor.raw2, g_sensor.voltage);
            printf_debug("[SM] BUTTON: LCD on (default page)\r\n");
        }
        else if(g_lcd_active)
        {
            lcd_ui_next_page();
            printf_debug("[SM] BUTTON: LCD page -> %d\r\n", g_lcd_page);
        }

        app_state = STATE_SLEEP;
        return;
    }

    // debug串口命令由主循环统一处理

#if BLE_ENABLED
    // === BLE连接唤醒: PD2 EXTI下降沿 (手机连接BLE模块) ===
    if(ble_connect_wakeup_flag)
    {
        ble_connect_wakeup_flag = 0;
        ble_exti_disable();

        if(g_bt_on && ble_link_is_connected())
        {
            printf_debug("[SM] WAKEUP: BLE connected (PD2=LOW), entering OTA mode\r\n");
            ensure_full_init();
            ble_uart_init();
            ble_uart_rx_flush();
            ble_ota_init();
            g_ble_ota.state = BLE_OTA_IDLE;
            g_ble_ota.last_rx_ms = trea_millis();
            app_state = STATE_BLE_OTA;
            return;
        }
        else
        {
            printf_debug("[SM] WAKEUP: BLE EXTI but not connected (glitch?)\r\n");
        }
    }
#endif /* BLE_ENABLED */

    if(counter0 || ri_wakeup_flag)
    {
        printf_debug("[SM] WAKEUP: %s (downlink)\r\n", counter0 ? "LPUART" : "RI");
        app_state = STATE_DOWNLINK;
    }
    else if(rtc_alarm_flag)
    {
        printf_debug("[SM] WAKEUP: RTC\r\n");
        /* 阀定时闹钟 / 校零 LCD 等待 / 实时模式: 保持原行为(交由 do_collect 处理) */
        if(g_timing_alarm_set == 0
#if CALIB_MODE_ENABLED
                && !s_cal_lcd_wait
#endif
                && !real_mode_active())
        {
            /* 采集到期点优先: 后延到期点与采集点重合时先采集(否则该采集点会被整拍跳过, 历史缺一格);
             * 未到采集点但"待上报+后延已到"(后延点唤醒) → 直接上报, 不采集
             * (否则会多出一条网格外历史记录); 两者都不是 → 回睡 */
            if(sched_collect_due_now())
                app_state = STATE_COLLECT;
            else if(upload_due_now())
            {
                printf_debug("[SM] WAKEUP: upload pending due, direct upload\r\n");
                ensure_full_init();      /* 最小唤醒时升级(上报需 EEPROM/4G) */
                app_state = STATE_UPLOAD;
            }
            else
            {
                /* 跨天周期(>1天): 到期日之前每天只醒一次做判定, 非到期点直接回睡 */
                printf_debug("[SM] WAKEUP: not collect due, back to sleep\r\n");
                app_state = STATE_SLEEP;
            }
        }
        else
            app_state = STATE_COLLECT;
    }
    else
    {
        printf_debug("[SM] WAKEUP: unknown\r\n");
        app_state = STATE_COLLECT;
    }

    /* RI EXTI 是一次性闭锁(EXTI1_IRQHandler 内 exti_interrupt_disable): 唤醒后必须重新布防,
     * 否则本次周期内的长流程(CH4 暖机/上报/阀动作/OTA)期间到达的指令,
     * 其下降沿脉冲没人接收, 会一直留在模块缓冲里直到平台再发新指令。
     * 重新布防后脉冲会锁存到 ri_wakeup_flag, 由 do_sleep 大睡收口做补读。
     * 注: ri_exti_init() 会清 ri_wakeup_flag, 故必须放在上面唤醒源判断之后。 */
    if(power_4g_is_on())
        ri_exti_init();
}

// ==================== 确认完整初始化 ====================
static void ensure_full_init(void)
{
    if(g_is_minimal_wakeup)
    {
        printf_debug("[SM] Escalating to FULL INIT (need 4G/Motor/EEPROM)\r\n");
        sys_init();
        g_is_minimal_wakeup = 0;
        g_need_adc_sampling = 1;
    }
}

// ==================== 上报调度判断 (do_collect / do_alarm 共用) ====================
// 上报周期/后延配置变更后调用: 重置延迟上报锁存, 避免换周期后漏一次或重一次
void upload_schedule_reset(void)
{
    s_upload_pending      = 0;
    s_pending_due_abs_min = 0;
    s_last_upload_idx     = 0xFFFFFFFFu;   /* 换周期/改后延: 下一个上报周期重新起算 */
    config_save_upload_idx(0xFFFFFFFFu);
}

// 根据当前模式和时间判断是否需要批量上报历史数据, 设置 app_state
static void check_upload_schedule(void)
{
    // === 低电压省电模式: 不执行常规上报, 8:00/18:00上报 ===
    if(voltage_low_power)
    {
        uint32_t now_hhmmss = rtc_get_hhmmss();
        uint8_t current_hour = (uint8_t)(now_hhmmss / 10000);
        if((current_hour == 8 || current_hour == 18) && !vlp_uploaded_this_hour)
        {
            vlp_uploaded_this_hour = 1;
            if(ee_hist_count() > 0)
            {
                printf_debug("[SM] VLP trigger: hour=%d, uploading %d records\r\n", current_hour, ee_hist_count());
                ensure_full_init();
                app_state = STATE_UPLOAD;
            }
            else
            {
                printf_debug("[SM] VLP trigger: hour=%d, buf empty, skip 4G\r\n", current_hour);
                app_state = STATE_SLEEP;
            }
        }
        else
        {
            if(current_hour != 8 && current_hour != 18)
                vlp_uploaded_this_hour = 0;
            app_state = STATE_SLEEP;
        }
        return;
    }

    // 判断是否需要上报(网格模式, 对齐时间网格)
    if(strcmp(g_window.pattern, "dot") == 0)
    {
        // dot pattern: any configured hour in 24h bitmap triggers upload once per day
        uint32_t now_hhmmss = rtc_get_hhmmss();
        uint8_t current_hour = (uint8_t)(now_hhmmss / 10000);
        rtc_parameter_struct tp;
        rtc_current_time_get(&tp);
        uint16_t day_key = (uint16_t)(((tp.year & 0xFF) << 8) | ((tp.month & 0xFF) << 4) | (tp.date & 0xFF));
        if(day_key != dot_uploaded_day)
        {
            memset(dot_uploaded_mask, 0, sizeof(dot_uploaded_mask));
            dot_uploaded_day = day_key;
        }
        if(window_dottime_hit(g_window.dottime_mask, current_hour) &&
           !window_dottime_hit(dot_uploaded_mask, current_hour))
        {
            printf_debug("[SM] DOT trigger: hour=%d (mask hit)\r\n", current_hour);
            window_dottime_set(dot_uploaded_mask, current_hour);
            ensure_full_init();
            app_state = STATE_UPLOAD;
        }
        else
        {
            app_state = STATE_SLEEP;
        }
    }
    else
    {
        // long/short: 整点网格 + 标志位式调度
        //   进入新的上报周期 → 置"待上报"; 置位后一路上报直到成功(缓冲清空)
        //   不依赖时间窗口/目标点 → 长流程推迟、被抢占、RTC 校时跳变都不会永久漏报
        uint32_t now_hhmmss = rtc_get_hhmmss();

        upload_pending_update();

        if(upload_due_now())
        {
            printf_debug("[SM] UPLOAD trigger: %02u:%02u:%02u (um=%umin every_n=%u)\r\n",
                         (unsigned)(now_hhmmss / 10000),
                         (unsigned)((now_hhmmss / 100) % 100),
                         (unsigned)(now_hhmmss % 100),
                         (unsigned)g_interval.upload_interval_min,
                         (unsigned)g_interval.upload_every_n);
            ensure_full_init();
            app_state = STATE_UPLOAD;
        }
        else
            app_state = STATE_SLEEP;
    }
}

// ==================== 采集传感器 + 阈值检查 ====================
static void do_collect(void)
{
    SensorRecord_t record;
    AlarmEval_t ev;
    float prev_p1, prev_p2;
    uint8_t mask;
    uint8_t unlocked;
    uint8_t vlp_just_exited = 0;

    // ========== 定时开关阀检查 ==========
    // ========== 定时开关阀检查 ==========
    if(g_valve_timing.on_switch || g_valve_timing.off_switch)
    {
        RtcDateTime_t dt;
        rtc_get_datetime(&dt);
        uint8_t cur_hour = dt.hour;

        // 跨天重置当日执行标志 (00:00~00:59, 若未重置过)
        if(cur_hour == 0 && timing_last_reset_hour != 0)
        {
            timing_open_done_today  = 0;
            timing_close_done_today = 0;
            timing_last_reset_hour  = 0;
            printf_debug("[SM] VTIMING: daily flags reset\r\n");
        }
        else if(cur_hour != 0)
            timing_last_reset_hour = cur_hour;

        // 检查开阀时间 (容差30秒)
        if(!timing_open_done_today && g_valve_timing.on_switch &&
           valve_timing_time_match(g_valve_timing.open_time, &dt, 30))
        {
            printf_debug("[SM] VTIMING: OPEN triggered at %02u:%02u\r\n", dt.hour, dt.minute);
            vtiming_execute_and_report("open");
            timing_open_done_today = 1;
        }

        // 检查关阀时间 (容差30秒)
        if(!timing_close_done_today && g_valve_timing.off_switch &&
           valve_timing_time_match(g_valve_timing.close_time, &dt, 30))
        {
            printf_debug("[SM] VTIMING: CLOSE triggered at %02u:%02u\r\n", dt.hour, dt.minute);
            vtiming_execute_and_report("close");
            timing_close_done_today = 1;
        }
    }

    // 记录本次网格采集的分钟序号, 防止与秒级频率实时唤醒循环在同一分钟重复巡检
    {
        last_grid_collect_abs_min = sched_abs_min();
    }

    PT304D_CollectAll((g_sensor_count >= 2) ? &g_sensor.raw2 : NULL, &g_sensor.raw);
#if CALIB_MODE_ENABLED
    {
        /* 未安装自动校零: 喂样本; 零点成熟时同拍修正当前读数
         * 注意: 必须喂"未扣除当前零点"的原始读数。g_sensor.raw.pressure 已由驱动
         * 减去 s_pt304d_zero_offset (y = P - O), 直接喂入会让算法把 y 当成新绝对
         * 零点 → 下一拍输出变成 O, 零点在 ±O 之间来回翻转, 永不收敛。 */
        uint8_t was_calib = calib_is_active();
        float p_raw = g_sensor.raw.pressure + PT304D_GetZeroOffset(PT304D_SENSOR_2);
        float corr = calib_feed_sample(p_raw);
        if(corr != 0.0f)
            g_sensor.raw.pressure -= corr;
        if(was_calib)
        {
            calib_log_sample(p_raw, g_sensor.raw.pressure);
            if(!calib_is_active())
                install_event_report();         /* 自动锁定: 一次性安装事件上报 */
        }
    }
#endif
    g_sensor.voltage = g_sensor.last_normal_voltage;

    printf_debug("[SM] COLLECT (buf=%d) V=%.2f S2:P=%.2f T=%.2f err=%d S1:P=%.2f T=%.2f err=%d (ADC=%d)\r\n",
                 ee_hist_count() + 1, g_sensor.voltage,
                 g_sensor.raw.pressure, g_sensor.raw.temperature, g_sensor.raw.err,
                 g_sensor.raw2.pressure, g_sensor.raw2.temperature, g_sensor.raw2.err,
                 g_need_adc_sampling);

    // 实时模式关闭时, 采集周期结束后 LCD 刷新 (实时模式由 do_realtime_check 刷新)
#if CALIB_MODE_ENABLED
    if(calib_is_active())
    {
        calib_lcd_auto_begin();         /* 未安装期: 压力页短亮 + 定时息屏
                                         * (LCD_KEY_TRIGGER_ENABLED 时该函数内部直接返回:
                                         *  不做节拍自动点亮, 只由按键点亮) */
    }
    else
    {
        calib_lcd_exit_to_normal();     /* 锁定后: 取消短亮, 恢复正常LCD策略 */
    }
#endif
#if (LCD_LOCK_ENABLED || LCD_KEY_TRIGGER_ENABLED)
    /* 按键点亮模式/锁定模式: 只刷新, 不自动翻页 (翻页只由按键触发) */
    if(g_lcd_active && !real_mode_active() && !CALIB_LCD_BLOCKED())
        lcd_ui_refresh(&g_sensor.raw, &g_sensor.raw2, g_sensor.voltage);
#else
    /* LCD常亮模式: 每个采集周期自动翻一页 */
    if(g_lcd_active && !real_mode_active() && !CALIB_LCD_BLOCKED())
    { lcd_ui_refresh(&g_sensor.raw, &g_sensor.raw2, g_sensor.voltage); lcd_ui_next_page(); }
#endif

    // ========== 传感器在线/离线状态变化检测(带消抖, 双路在线/离线) ==========
    {
        uint8_t cur_online  = (g_sensor.raw.err  == PT304D_OK) ? 1 : 0;
        uint8_t cur_online2 = (g_sensor.raw2.err == PT304D_OK) ? 1 : 0;
        uint8_t state_changed = sensor_debounce_update(cur_online, cur_online2);

        if(state_changed)
        {
            ensure_full_init();

            printf_debug("[SM] SENSOR STATE CHANGED: S2=%s(err=%d) S1=%s(err=%d) debounce=%d\r\n",
                         cur_online  ? "ON" : "OFF", g_sensor.raw.err,
                         cur_online2 ? "ON" : "OFF", g_sensor.raw2.err,
                         SENSOR_OFFLINE_DEBOUNCE);

            // 启动4G上报
            {
                int was_online;
                int ec_ok = fourG_ensure_ready(&was_online);
                if(ec_ok)
                {
                    report_publish_sensor_status();
                    printf_debug("[SM] Sensor state reported\r\n");
                }
                fourG_restore(was_online, ec_ok);
            }

            // 传感器离线时不参与阈值检查, 直接回睡
            // 告警锁: 离线通道不计正常、保留最后等级; 基线置 -1 跳过恢复首拍突变
            if(!cur_online)
            {
                alarm_lock_feed_normal(0, 0, THRESHOLD_OK, TEMP_NORMAL);
                alarm_lock_feed_normal(1, 0, THRESHOLD_OK, TEMP_NORMAL);
                g_sensor.last_pressure_collect  = -1.0f;
                g_sensor.last_pressure_collect2 = -1.0f;
                alarm_lock_save(0);
                app_state = STATE_SLEEP;
                return;
            }
        }
        else if(!cur_online)
        {
            // 传感器在线(异常期间), 不重复上报, 直接回睡
            printf_debug("[SM] SENSOR still OFFLINE (cnt=%d/%d cnt2=%d/%d), skip\r\n",
                         g_sensor.offline_cnt, SENSOR_OFFLINE_DEBOUNCE,
                         g_sensor.offline_cnt2, SENSOR_OFFLINE_DEBOUNCE);
            alarm_lock_feed_normal(0, 0, THRESHOLD_OK, TEMP_NORMAL);
            alarm_lock_feed_normal(1, 0, THRESHOLD_OK, TEMP_NORMAL);
            g_sensor.last_pressure_collect  = -1.0f;
            g_sensor.last_pressure_collect2 = -1.0f;
            alarm_lock_save(0);
            app_state = STATE_SLEEP;
            return;
        }
    }

    // === 阈值评估 + 告警锁 ===
    prev_p1 = g_sensor.last_pressure_collect;
    prev_p2 = g_sensor.last_pressure_collect2;

    /* 周期采集不做电压判定 (与改造前一致): check_voltage=0, 不触碰电压锁 */
    alarm_eval(&ev, 0, prev_p1, prev_p2);

    /* 恢复去抖: 每拍推进; 查询路径不推进 */
    unlocked  = alarm_lock_feed_normal(0, ev.online1, ev.r1, ev.t1);
    unlocked |= alarm_lock_feed_normal(1, ev.online2, ev.r2, ev.t2);

    /* 低电压恢复: 电压恢复到正常时退出VLP
     *   (a) 电压回到 vprotect 以上 (正常恢复)
     *   (b) spupower.switch 被用户关闭(不再执行电压检查, 不能残留 VLP 状态锁定) */
    if(voltage_low_power && (!g_spupower.enabled ||
       g_sensor.voltage >= g_spupower.protect + 0.15f))
    {
        voltage_low_power = 0;
        config_save_ext();
        vlp_uploaded_this_hour = 0;
        vlp_just_exited = 1;     /* 标记: 本次 collect 时 VLP 刚退出, 走 normal 上报 */
        if(!g_spupower.enabled)
            printf_debug("[SM] VLP: spupower disabled by user, exiting low power mode\r\n");
        else
            printf_debug("[SM] VLP: voltage recovered (%.2fV >= %.2fV), exiting low power mode\r\n",
                         g_sensor.voltage, g_spupower.protect);
    }

    /* 恢复报文: 必须在进入 STATE_ALARM 之前发送, 避免被提前 return 吞掉。
     * (a) 报警锁解锁 → 上报一次"正常+阀门保持关闭";
     * (b) VLP 刚退出 → 通知平台低电压恢复 (即使未发生关阀)。 */
    if(!voltage_low_power && (unlocked || vlp_just_exited))
    {
        ensure_full_init();
        const char *vr = NULL;

        if(g_valve_alarm_closed && !g_ch4_alarm_closed)
        {
            g_alarm_recover_reported = 1;
            motor_limit_init();        /* 深休眠后 PA11/PA12 为 Analog, 读限位前恢复输入 */
            vr = valve_get_status();   /* 上报真实阀门状态(保持关闭) */
            printf_debug("[SM] ALK recovered, valve stays closed (report only)\r\n");
        }
        else if(vlp_just_exited)
        {
            printf_debug("[SM] VLP recovered, publishing normal status\r\n");
        }

        {
            int was_online;
            int ec_ok = fourG_ensure_ready(&was_online);
            if(ec_ok)
            {
                if(vr != NULL)
                    EC801E_PublishValveStatus(vr, g_valve_last_order);
                report_publish_ly06(0, g_sensor.voltage);
                publish_all_status(prev_p1, prev_p2);
            }
            fourG_restore(was_online, ec_ok);
        }
    }

    /* 新等级判定: 只有等级变化才进入 ALARM/上报 */
    mask = alarm_new_mask(ev.r1, ev.r2, 0);

    if(mask != 0)
    {
        printf_debug("[SM] ALK new mask=0x%02X r1=%d r2=%d -> STATE_ALARM\r\n",
                     mask, (int)ev.r1, (int)ev.r2);
        ensure_full_init();
        app_state = STATE_ALARM;
        return;   /* 基线保持旧值: do_alarm 重采使用进入告警前的上拍值 */
    }

    alarm_lock_save(0);   /* 正常采样定期 flush */

    // 记录: 存入缓冲区
    record.pressure = g_sensor.raw.pressure;
    record.temperature = g_sensor.raw.temperature;
    record.pressure2 = g_sensor.raw2.pressure;
    record.temperature2 = g_sensor.raw2.temperature;
    record.voltage = g_sensor.voltage;
    rtc_get_time_str(record.timestamp, sizeof(record.timestamp));
    record.flags = 0;
    memset(record.reserved, 0, sizeof(record.reserved));

#if CALIB_MODE_ENABLED
    if(calib_is_active())
    {
        /* 未安装校零期: 不写历史, 只保留最新一条供周期上报 */
        s_calib_latest = record;
        s_calib_latest_valid = 1;
    }
    else
#endif
    {
        ee_hist_push(record.pressure, record.temperature,
                     record.pressure2, record.temperature2,
                     record.voltage, record.flags);
    }
    g_sensor.last_pressure_collect  = ev.online1 ? g_sensor.raw.pressure  : -1.0f;
    g_sensor.last_pressure_collect2 = ev.online2 ? g_sensor.raw2.pressure : -1.0f;
    wakeup_count++;

    // 报警确认
    check_upload_schedule();
}

// ==================== 报警确认 ====================
static void do_alarm(void)
{
    uint8_t confirmed = 0;
    SensorRecord_t record;
    AlarmEval_t ev;
    ThresholdResult_t result = THRESHOLD_OK;
    float prev_p1, prev_p2;
    uint8_t mask;

    ensure_full_init();

    /* 进入告警前的上拍值: 首次检查与 3 次重采全程固定, 不得中途更新 */
    prev_p1 = g_sensor.last_pressure_collect;
    prev_p2 = g_sensor.last_pressure_collect2;

    /* 与 do_collect 同口径重算 (check_voltage=0) */
    alarm_eval(&ev, 0, prev_p1, prev_p2);
    mask = alarm_new_mask(ev.r1, ev.r2, 0);

    /* 3 次重采确认 (共用函数; 重采做完整电压判定, 可发现首检漏掉的电压报警) */
    if(mask != 0)
    {
        printf_debug("[SM] ALARM: mask=0x%02X, rechecking...\r\n", mask);
        confirmed = alarm_recheck_confirm(1, prev_p1, prev_p2);
    }
    else
    {
        printf_debug("[SM] ALARM: no new level (mask=0), skip recheck\r\n");
    }

    // 报警记录
    record.pressure = g_sensor.raw.pressure;
    record.temperature = g_sensor.raw.temperature;
    record.pressure2 = g_sensor.raw2.pressure;
    record.temperature2 = g_sensor.raw2.temperature;
    record.voltage = g_sensor.voltage;
    rtc_get_time_str(record.timestamp, sizeof(record.timestamp));
    memset(record.reserved, 0, sizeof(record.reserved));
    record.flags = confirmed ? SENSOR_FLAG_ALARM : 0;

    if(confirmed)
    {
        alarm_eval(&ev, 1, prev_p1, prev_p2);
        result = (ev.r1 != THRESHOLD_OK) ? ev.r1 : ev.r2;

        printf_debug("[SM] *** ALARM CONFIRMED: %s ***\r\n", threshold_alarm_type_str(result));
        printf_debug("[SM] ALARM: P=%.2f T=%.2f V=%.2f @%s\r\n",
                     g_sensor.raw.pressure, g_sensor.raw.temperature, g_sensor.voltage, record.timestamp);

        /* 锁存新等级 → 按策略关阀 → 报警批量/电压/阀门状态上报 */
        (void)alarm_confirm_and_report(ALARM_CTX_COLLECT, mask, prev_p1, prev_p2);
    }

    // 存入EEPROM历史记录
#if CALIB_MODE_ENABLED
    if(calib_is_active())
    {
        s_calib_latest = record;
        s_calib_latest_valid = 1;
    }
    else
#endif
    {
        ee_hist_push(record.pressure, record.temperature,
                     record.pressure2, record.temperature2,
                     record.voltage, record.flags);
    }
    g_sensor.last_pressure_collect  = (g_sensor.raw.err == PT304D_OK)
                                    ? g_sensor.raw.pressure : -1.0f;
    g_sensor.last_pressure_collect2 = (alarm_lock_ch_enabled(1) &&
                                       g_sensor.raw2.err == PT304D_OK)
                                    ? g_sensor.raw2.pressure : -1.0f;
    wakeup_count++;
    alarm_lock_save(0);

    // 上报调度判断 (若报警上报后仍到上报时刻, 历史数据再补上报)
    check_upload_schedule();
}

// ==================== 批量上报 (历史数据, 各模式) ====================
static void do_upload(void)
{
    uint16_t n, i;
    int is_coldstart = 0;

    // === 窗口检查(dot/VLP模式由do_collect已确认时间点, 直接通过) ===
    // 后延只推迟上报时刻, 数据仍属于"窗口内网格点": 以(当前时刻-后延)的网格时刻判断窗口,
    // 窗口外网格点(如夜间)不上报, 数据累积到次日窗口内网格点补报
    if(!voltage_low_power && strcmp(g_window.pattern, "dot") != 0)
    {
        uint32_t now_hhmmss = rtc_get_hhmmss();
        uint32_t now_sec = hhmmss_to_seconds(now_hhmmss);
        uint32_t delay_sec = (uint32_t)(g_report_delay_min * 60.0f);
        uint32_t grid_sec = (now_sec >= delay_sec) ? (now_sec - delay_sec)
                                                   : (now_sec + 86400u - delay_sec);
        uint32_t grid_hhmmss = (grid_sec / 3600) * 10000
                             + ((grid_sec / 60) % 60) * 100 + (grid_sec % 60);
        if(!config_is_active_window_at(grid_hhmmss))
        {
            printf_debug("[SM] UPLOAD: outside window (grid %02u:%02u:%02u), skip\r\n",
                         grid_sec / 3600, (grid_sec / 60) % 60, grid_sec % 60);
            app_state = STATE_SLEEP;
            return;
        }
    }

    printf_debug("[SM] UPLOAD: %d records (pattern=%s%s)\r\n",
                 ee_hist_count(), g_window.pattern,
                 voltage_low_power ? " VLP" : "");

    // === 确保4G模块连接 ===
    com_lpuart_init();
    trea_delay_ms(100);
    gpio_init();   /* 最小唤醒后 PA0(DTR) 被深休眠配置为 Analog, 必须恢复输出才能唤醒4G */

    // 低电压省电模式 / 弱信号模式: 强制走冷启动路径
    if(voltage_low_power || strcmp(g_window.pattern, "long") != 0 ||
       fourG_weak_signal || fourG_init_failed)
    {
        // short/dot/VLP/weak_signal: 4G断电状态, InitAndConnect 冷启动 (V4G_EN+PWRKEY 完整时序)
        is_coldstart = 1;
        if(EC801E_InitAndConnect() != EC_OK)
        {
            printf_debug("[SM] UPLOAD: cold start failed, power off\r\n");
            EC801E_PowerOff();
            fourG_init_failed = 1;   /* 下次上报冷启动重试 (do_upload 冷启动分支已含此标志) */
            app_state = STATE_SLEEP;
            return;
        }
        fourG_init_failed = 0;  // 连接成功, 清除失败标志
        fourG_weak_signal = 0;  // 冷启动成功: 同时清除弱信号标志, 防止下个do_sleep再次断电
        EC801E_SetPSM(0);
//        trea_delay_ms(300);
//        report_4g_power_state(1);
    }
    else
    {
        // long模式(无VLP, 无弱信号): 4G应保持在线(QSCLK), 直接确认
        if(EC801E_EnsureConnected() != EC_OK)
        {
            printf_debug("[SM] UPLOAD: connect failed, power off\r\n");
            EC801E_PowerOff();
            fourG_init_failed = 1;   /* 挂死模块: 断电并标记, 下次上报走冷启动真复位 */
            app_state = STATE_SLEEP;
            return;
        }
        fourG_init_failed = 0;  // EnsureConnected 成功, 清除失败标志
    }

    // 4G连接成功后才更新LCD信号强度
    lcd_update_csq();
#if CALIB_MODE_ENABLED
    report_publish_field("product-status", calib_is_active() ? "0" : "1");  /* 每次周期上传带状态 */
#else
    report_publish_field("product-status", "1");
#endif

    // === 用户端MQTT: 预连接 (历史记录同步上报, 约1分钟耗时) ===
    uint8_t user_mqtt_on = 0;
    if(EC801E_UserMqtt_IsConfigured())
    {
        trea_delay_ms(500);
        if(EC801E_UserMqtt_Connect() == EC_OK)
        {
            user_mqtt_on = 1;
        }
        else
        {
            printf_debug("[SM] UserMqtt: 1st connect failed, retry...\r\n");
            trea_delay_ms(1000);
            user_mqtt_on = (EC801E_UserMqtt_Connect() == EC_OK);
            if(!user_mqtt_on)
                printf_debug("[SM] UserMqtt: 2nd connect failed, skip user mqtt\r\n");
        }
    }

    // === 批量上传 (双通道: 平台id=0 + 用户端id=1, 从EEPROM读取) ===
#if CALIB_MODE_ENABLED
    if(calib_is_active())
    {
        /* 未安装校零期: 只上报最新值, 不读历史批量 */
        if(s_calib_latest_valid)
        {
            if(EC801E_PublishSingleRecord(&s_calib_latest) == EC_OK)
            {
                /* 未安装期不弹历史, 需在此提交防重锁: 保证一个上报周期只发一次最新值 */
                upload_commit();
            }
            trea_delay_ms(300);
        }
    }
    else
#endif
    while(ee_hist_count() > 0)
    {
        vtiming_check_now();   /* timing valve preempts upload */
        EeHistRecord_t ee_rec;
        SensorRecord_t rec;
        uint8_t rd_ret;

        swdt_feed();
        rd_ret = ee_hist_read(0, &ee_rec);
        if(rd_ret == 0)
        {
            ee_hist_to_sensor_record(&ee_rec, &rec);

            EC_Status_t pub_ret = EC801E_PublishSingleRecord(&rec);
            if(pub_ret == EC_PREEMPT)
            {
                vtiming_check_now();   /* run timing valve, then resend current record */
                continue;
            }
            if(pub_ret == EC_OK)
            {
                if(user_mqtt_on)
                {
                    trea_delay_ms(300);
                    if(EC801E_UserMqtt_PublishRecord(&rec) != EC_OK)
                    {
                        printf_debug("[SM] UserMqtt: publish failed, try reconnect\r\n");
                        EC801E_UserMqtt_Disconnect();
                        trea_delay_ms(500);
                        if(EC801E_UserMqtt_Connect() == EC_OK)
                        {
                            trea_delay_ms(300);
                            EC801E_UserMqtt_PublishRecord(&rec);
                        }
                        else
                        {
                            printf_debug("[SM] UserMqtt: reconnect failed, disable\r\n");
                            user_mqtt_on = 0;
                        }
                    }
                }
                ee_hist_pop();

                if(ee_hist_count() > 0)
                    trea_delay_ms(one_by_one_delay);
            }
            else
            {
                printf_debug("[SM] UPLOAD: Publish record failed, stop remaining uploads\r\n");
                break;
            }
        }
        else
        {
            // CRC校验失败或读取异常, 跳过损坏记录
            printf_debug("[SM] UPLOAD: EEPROM read error (ret=%d), skip record\r\n", rd_ret);
            ee_hist_pop();
        }
    }

    // === 用户端MQTT: 断开 ===
    if(user_mqtt_on)
    {
        trea_delay_ms(500);
        EC801E_UserMqtt_Disconnect();
    }

    // 上报汇总状态 (含传感器状态+信号+压力温度状态+阀门+IP+电压)
    trea_delay_ms(200);
    report_publish_upload_summary();
    printf_debug("[SM] upload summary published\r\n");

    // 上次上传过程结束点位清零重新开始统计计数
    wakeup_count = 0;
    /* 上报成功(历史缓冲清空)才提交: 清待上报标志 + 记录周期序号(持久化);
     * 失败/部分失败保留标志, 下个采集点自动重试 */
    if(ee_hist_count() == 0)
        upload_commit();
    printf_debug("[SM] UPLOAD finished, remaining records in buffer: %d\r\n", ee_hist_count());

    // === RTC校准: 通过4G网络时间同步本地时钟 ===
    {
        trea_delay_ms(200);
        EC_Status_t sync_ret = EC801E_SyncTime();
        if(sync_ret == EC_OK)
            printf_debug("[SM] RTC calibrated from network\r\n");
        else
            printf_debug("[SM] RTC calibration failed (non-critical)\r\n");
    }

    // === 模式化收尾 ===
    if(is_coldstart)
    {
        // 冷启动模式(VLP/short/dot/weak_signal): 等待20s接收平台下发指令
        printf_debug("[SM] Waiting 20s for downlink...\r\n");
        trea_delay_ms(20000);
        {
            uint8_t dl_count = drain_pending_downlink();
            if(dl_count > 0)
                printf_debug("[SM] Processed %d downlink msg(s)\r\n", dl_count);
        }

        // long模式弱信号恢复路径: 检查信号是否恢复, 决定是否保持在线
        if(fourG_weak_signal && strcmp(g_window.pattern, "long") == 0)
        {
            if(fourG_signal_check_and_decide())
            {
                // 信号恢复, 保持4G在线(long模式正常行为)
                EC801E_SetPSM(1);
                printf_debug("[SM] UPLOAD: signal OK, keep 4G online\r\n");
            }
            // else: 内部已断电
        }
        else
        {
//            report_4g_power_state(0);
            EC801E_PowerOff();
        }
    }
    else
    {
        // long(无弱信号): 按信号强弱决定去留
        trea_delay_ms(500);
        if(fourG_signal_check_and_decide())
            EC801E_SetPSM(1);
        // else: 信号弱, 内部已断电
    }

    app_state = STATE_SLEEP;
}



// ==================== 处理MQTT下行指令 (下行最高优先级) ====================
static void do_downlink(void)
{
    uint8_t msg_count;

    printf_debug("[SM] DOWNLINK\r\n");
    com_lpuart_init();
    trea_delay_ms(100);

    msg_count = drain_pending_downlink();

    if(msg_count == 0)
    {
        printf_debug("[SM] No downlink, check MQTT...\r\n");
        if(EC801E_EnsureConnected() == EC_OK)
            printf_debug("[SM] MQTT OK\r\n");
    }
    else
    {
        printf_debug("[SM] Processed %d msg(s)\r\n", msg_count);
    }

    /* gas_get 指令: 优先进入 CH4 采集状态机。
     * 放在 SetPSM/弱信号判断之前: 此时 4G 刚被 QMTRECV 唤醒且 MQTT 在线,
     * 直接进入 CH4 可保证采集完成后的上报通道可用; 若先 SetPSM(1), 暖机
     * 30s 后模块已 QSCLK 休眠, 上报首条 AT 会丢失。 */
    if(g_ch4_request) {
        g_ch4_request = 0;
        app_state = STATE_CH4;
        return;
    }

    // 如果信号OK则保持在线 (弱信号断电时已内部处理)
    trea_delay_ms(500);
    if(fourG_signal_check_and_decide())
        EC801E_SetPSM(1);
    // else: 信号弱, 内部已断电

    app_state = STATE_SLEEP;
}

#if BLE_ENABLED
// ==================== BLE OTA 状态处理 ====================
static void do_ble_ota(void)
{
    /* 第一阶段: 等待手机连接BLE (PD2=LOW) */
    if(g_ble_ota.state == BLE_OTA_WAIT_CONNECT)
    {
        if(ble_link_is_connected())
        {
            /* 手机已连接BLE模块 -> 初始化UART开始处理OTA指令 */
            printf_debug("[SM] BLE connected (PD2=LOW), init UART4\r\n");
            ble_uart_init();
            ble_uart_rx_flush();
            g_ble_ota.state = BLE_OTA_IDLE;
            g_ble_ota.last_rx_ms = trea_millis();  /* 重置超时计时 */
            trea_delay_ms(500);
            printf_debug("[SM] BLE connected (PD2=LOW), init UART4---OK\r\n");
        }
        else
        {
            /* 尚未连接, 检查超时 (ble_ota_process内部处理) */
            ble_ota_process();
        }
    }
    else
    {
        /* 第二阶段: 数据接收, 处理OTA指令 */
        ble_ota_process();

        if(g_ble_ota.state == BLE_OTA_DOWNLOADING)
        {
            ota_wdt_feed();
        }
    }
	
#if BUTTON_ENABLED
    /* 按键退出: 3次按键关闭蓝牙 (需3次按键不松手) */
    if(button_is_pressed())
    {
        uint8_t ble_press_count = 1;
        uint16_t ble_wait;

        while(button_is_pressed()) trea_delay_ms(20);
        trea_delay_ms(30);

        while(ble_press_count < 3)
        {
            uint8_t ble_got = 0;
            for(ble_wait = 0; ble_wait < 500; ble_wait += 20)
            {
                trea_delay_ms(20);
                if(button_is_pressed()) { ble_got = 1; break; }
            }
            if(!ble_got) break;
            ble_press_count++;
            while(button_is_pressed()) trea_delay_ms(20);
            trea_delay_ms(30);
        }

        if(ble_press_count >= 3)
        {
            printf_debug("[SM] BLE_OTA: 3-press detected, turning off BLE\r\n");
            g_bt_on = 0;
            power_ble_set(0);
            if(g_lcd_active) slcd_seg_icon_display(SLCD_ICON_LY, RESET);
        }
    }
#endif

    /* 退出条件: OTA完成/超时, 关闭蓝牙并返回 */
    if(g_ble_ota.state == BLE_OTA_ERROR || !g_bt_on)
    {
        printf_debug("[SM] BLE_OTA exit: state=%d, bt=%d\r\n", g_ble_ota.state, g_bt_on);
        ble_uart_deinit();
        if(g_bt_on)
        {
            lcd_ui_toggle_bluetooth();
        }
        app_state = STATE_SLEEP;
    }
    /* 注: OTA_COMPLETE不会走到这里, handle_end()已调用NVIC_SystemReset() */
}
#endif /* BLE_ENABLED */

// ==================== Debug串口命令处理(需要硬件上下文) ====================
static void debug_check_cmd(void)
{
    static char line_buf[512];
    uint16_t len;

    while((len = debug_rx_read_line(line_buf, sizeof(line_buf), 0)) > 0)
    {
        printf_debug("[DBG] %s\r\n", line_buf);

        // ---- commands requiring main.c hardware context ----
        if(strcmp(line_buf, "status") == 0)
        {
            const char *state_names[] = {"INIT","SLEEP","WAKEUP","COLLECT","UPLOAD","DOWNLINK","ALARM","BLE_OTA"};
            printf_debug("  state=%s wakeup=%d buf=%d\r\n",
                         (app_state <= STATE_BLE_OTA) ? state_names[app_state] : "?",
                         wakeup_count, ee_hist_count());
            printf_debug("  P=%.2f T=%.2f V=%.2f last_Pc=%.2f last_Pr=%.2f\r\n",
                         g_sensor.raw.pressure, g_sensor.raw.temperature, g_sensor.voltage, g_sensor.last_pressure_collect, g_sensor.last_pressure_realtime);
            printf_debug("  valve=%d abnormal=%s\r\n", g_valve_last_order, g_abnormal_close);
            printf_debug("  4G: user_off=%d init_fail=%d weak_sig=%d\r\n", fourG_user_off, fourG_init_failed, fourG_weak_signal);
#if BLE_ENABLED
            printf_debug("  BLE: on=%d\r\n", g_bt_on);
#else
            printf_debug("  BLE: disabled\r\n");
#endif
            printf_debug("  PT304D err=%d stat=0x%02X\r\n", g_sensor.raw.err, g_sensor.raw.stat_raw);
            continue;
        }
        if(strcmp(line_buf, "sensor") == 0)
        {
            PT304D_CollectAll((g_sensor_count >= 2) ? &g_sensor.raw2 : NULL, &g_sensor.raw);
            g_sensor.voltage = adc_bat_read_voltage();
            printf_debug("  err=%d stat=0x%02X P=%.2f T=%.2f V=%.2f\r\n",
                         g_sensor.raw.err, g_sensor.raw.stat_raw, g_sensor.raw.pressure, g_sensor.raw.temperature, g_sensor.voltage);
            if(g_sensor.raw.err != PT304D_OK)
                printf_debug("  press_raw=0x%06X temp_raw=0x%06X\r\n", g_sensor.raw.press_raw, g_sensor.raw.temp_raw);
            continue;
        }
        if(strcmp(line_buf, "sensor_status") == 0)
        {
            PT304D_CollectAll((g_sensor_count >= 2) ? &g_sensor.raw2 : NULL, &g_sensor.raw);
            const char *have   = (g_sensor.raw.err != PT304D_ERR_I2C) ? "1" : "0";
            const char *status = (g_sensor.raw.err == PT304D_OK)       ? "1" : "0";
            printf_debug("  have=%s status=%s err=%d stat=0x%02X\r\n",
                         have, status, g_sensor.raw.err, g_sensor.raw.stat_raw);
            continue;
        }
        if(strcmp(line_buf, "temp_status") == 0)
        {
            PT304D_CollectAll((g_sensor_count >= 2) ? &g_sensor.raw2 : NULL, &g_sensor.raw);
            TempStatus_t ts = threshold_get_temp_status(g_sensor.raw.temperature);
            printf_debug("  T=%.2f -> %s\r\n", g_sensor.raw.temperature, threshold_temp_status_str(ts));
            continue;
        }
        if(strcmp(line_buf, "pressure_status") == 0)
        {
            PT304D_CollectAll((g_sensor_count >= 2) ? &g_sensor.raw2 : NULL, &g_sensor.raw);
            PressureStatus_t ps = threshold_get_pressure_status(g_sensor.raw.pressure, g_sensor.last_pressure_collect);
            printf_debug("  P=%.2f -> %s\r\n", g_sensor.raw.pressure, threshold_pressure_status_str(ps));
            continue;
        }
        if(strcmp(line_buf, "sim") == 0)
        {
            char csq[8] = {0}, iccid[32] = {0}, imei[24] = {0};
            int rsrp = 0, sinr = 0;
            uint8_t cereg = 0;
            EC801E_Wakeup();
            EC801E_QueryCSQ(csq, sizeof(csq));
            EC801E_QueryQCSQ(&rsrp, &sinr);
            EC801E_QueryCEREG(&cereg);
            EC801E_QueryICCID(iccid, sizeof(iccid));
            EC801E_QueryIMEI(imei, sizeof(imei));
            printf_debug("  CSQ=%s RSRP=%d SINR=%d CEREG=%d\r\n", csq, rsrp, sinr, cereg);
            printf_debug("  ICCID=%s IMEI=%s\r\n", iccid, imei);
            continue;
        }
        if(strcmp(line_buf, "restart") == 0)
        {
            printf_debug("[DBG] Restarting...\r\n");
            trea_delay_ms(50);
            NVIC_SystemReset();
        }
        if(strncmp(line_buf, "valve:", 6) == 0)
        {
            const char *action = line_buf + 6;  // "open" or "close"
            const char *result = valve_execute(action, 1);
            if(g_valve_alarm_closed)
            {
                g_valve_alarm_closed = 0;
                g_valve_pre_alarm_order = g_valve_last_order;
                config_save_ext();
                printf_debug("  cleared alarm_closed flag (user override)\r\n");
            }
            g_ch4_alarm_closed = 0;
            g_alarm_recover_reported = 0;
            /* 用户手动开阀: 清告警锁并立即持久化 (手动关阀不清锁) */
            if(strcmp(action, "open") == 0 || strcmp(action, "1") == 0)
                alarm_lock_clear_all();
            printf_debug("  valve(%s) -> %s  last_order=%d\r\n", action, result, g_valve_last_order);
            continue;
        }
        if(strncmp(line_buf, "first_ip:", 9) == 0)
        {
            char ip_buf[MQTT_FIELD_MAX];
            strncpy(ip_buf, line_buf + 9, sizeof(ip_buf) - 1);
            ip_buf[sizeof(ip_buf) - 1] = '\0';
            char *last_dot = strrchr(ip_buf, '.');
            if(last_dot)
            {
                *last_dot = '\0';
                g_mqtt.port = (uint16_t)atoi(last_dot + 1);
                strncpy(g_mqtt.server, ip_buf, MQTT_FIELD_MAX - 1);
                config_save_mqtt();
                printf_debug("  Primary IP set: %s:%d, reconnecting...\r\n", g_mqtt.server, g_mqtt.port);
                EC801E_DisconnectMQTT();
                trea_delay_ms(500);
                EC801E_ConnectMQTT();
                EC801E_SubscribeTopic();
            }
            else
                printf_debug("  Invalid format, use: first_ip:IP.port\r\n");
            continue;
        }
        if(strncmp(line_buf, "scend_ip:", 9) == 0)
        {
            char ip_buf[MQTT_FIELD_MAX];
            strncpy(ip_buf, line_buf + 9, sizeof(ip_buf) - 1);
            ip_buf[sizeof(ip_buf) - 1] = '\0';
            char *last_dot = strrchr(ip_buf, '.');
            if(last_dot)
            {
                *last_dot = '\0';
                g_mqtt.port2 = (uint16_t)atoi(last_dot + 1);
                strncpy(g_mqtt.server2, ip_buf, MQTT_FIELD_MAX - 1);
                config_save_mqtt();
                printf_debug("  Secondary IP set: %s:%d\r\n", g_mqtt.server2, g_mqtt.port2);
            }
            else
                printf_debug("  Invalid format, use: scend_ip:IP.port\r\n");
            continue;
        }
        if(strcmp(line_buf, "4Gpower_off") == 0)
        {
            printf_debug("  4G power off\r\n");
//            report_4g_power_state(0);
//            trea_delay_ms(200);
            EC801E_PowerOff();
            fourG_user_off = 1;
            continue;
        }
        if(strcmp(line_buf, "4Gpower_on") == 0)
        {
            printf_debug("  4G power on\r\n");
            fourG_user_off = 0;
            fourG_weak_signal = 0;
            com_lpuart_init();
            trea_delay_ms(100);
            /* InitAndConnect 内含完整冷启动时序 (V4G_EN+PWRKEY) */
            EC801E_InitAndConnect();
            if(EC801E_EnsureConnected() == EC_OK)
            {
//                report_4g_power_state(1);
                printf_debug("  4G power on OK, reported\r\n");
            }
            else
                printf_debug("  4G power on FAILED\r\n");
            EC801E_SetPSM(1);
            continue;
        }
        if(strcmp(line_buf, "mqtt_reconnect") == 0)
        {
            printf_debug("  MQTT reconnecting...\r\n");
            EC801E_Wakeup();
            EC801E_DisconnectMQTT();
            trea_delay_ms(500);
            if(EC801E_ConnectMQTT() == EC_OK)
            {
                EC801E_SubscribeTopic();
                printf_debug("  MQTT reconnected OK\r\n");
            }
            else
                printf_debug("  MQTT reconnect FAILED\r\n");
            continue;
        }
        if(strcmp(line_buf, "vlp") == 0)
        {
            printf_debug("  voltage_low_power=%d vlp_uploaded=%d valve_alarm_closed=%d pre=%d\r\n",
                         voltage_low_power, vlp_uploaded_this_hour,
                         g_valve_alarm_closed, g_valve_pre_alarm_order);
            printf_debug("  fourG: user_off=%d init_failed=%d weak_signal=%d\r\n",
                         fourG_user_off, fourG_init_failed, fourG_weak_signal);
            printf_debug("  spupower en=%d vprotect=%.2f\r\n",
                         g_spupower.enabled, g_spupower.protect);
            continue;
        }
        if(strcmp(line_buf, "buf") == 0)
        {
            printf_debug("  ee_hist: %d records\r\n", ee_hist_count());
            continue;
        }
        if(strcmp(line_buf, "time") == 0)
        {
            rtc_show_time();
            continue;
        }

        // ---- commands without hardware context, delegated to eeprom_config.c ----
        if(config_parse_and_apply(line_buf) == 0)
            printf_debug("[DBG] Unknown: %s\r\n", line_buf);
    }
}

#if LASER_CH4_ENABLED
// ==================== 激光甲烷定时采集调度 ====================
// laser_switch 仅管理读取时间点: 当前小时命中 laser_time 位图且本小时未执行过则触发 STATE_CH4
static void laser_schedule_check(void)
{
    RtcDateTime_t dt;

    if(!g_laser_switch) return;

    rtc_get_datetime(&dt);
    if(dt.hour != s_laser_done_hour && window_dottime_hit(g_laser_time_mask, dt.hour))
    {
        s_laser_done_hour = dt.hour;
        printf_debug("[SM] LASER schedule trigger at %02u:00\r\n", dt.hour);
        /* 仅置请求标志, 由主循环在 app_state==SLEEP 时转入 STATE_CH4,
         * 确保网格采集/整点上传先完成, 不再抢占 STATE_COLLECT */
        g_ch4_request = 1;
    }
}
#endif /* LASER_CH4_ENABLED */

#if 1  /* 30分钟巡检临时屏蔽 (待现场验证后恢复) */
// ==================== 4G连接主动巡检 (一直在线模式, 每30分钟) ====================
// long模式且(活动窗口或end_result=1)时4G应保持在线; 每30分钟主动确认与平台MQTT连接,
// 掉线自动重连; 重连失败断电并置失败标志, 等下次上报冷启动 (do_upload 冷启动分支已含 init_failed)
// 注意: 最小唤醒上下文 4G 的 LPUART/引脚未初始化, 巡检前必须 com_lpuart_init + gpio_init
static void check_4g_connection_supervision(void)
{
    static uint16_t s_last_supervise_min = 0xFFFF;
    uint32_t now_hhmmss;
    uint16_t now_min;

    /* 非"一直在线"模式: 不巡检, 保持现状 */
    if(voltage_low_power || fourG_user_off || fourG_init_failed || fourG_weak_signal ||
       strcmp(g_window.pattern, "long") != 0 ||
       !(config_is_active_window() || g_window.end_result == 1))
        return;

    now_hhmmss = rtc_get_hhmmss();
    now_min = (uint16_t)((now_hhmmss / 10000) * 60 + (now_hhmmss / 100) % 100);

    if(s_last_supervise_min == 0xFFFF)
    {
        s_last_supervise_min = now_min;   /* 上电后满30分钟再首次巡检 */
        return;
    }
    if((uint16_t)(now_min - s_last_supervise_min) < FOURG_SUPERVISE_INTERVAL_MIN)
        return;

    s_last_supervise_min = now_min;
    printf_debug("[SM] 4G supervision: checking MQTT connection...\r\n");

    /* 恢复 4G LPUART 与引脚 (否则 AT 全部 rx(0), 与 CH4 上报路径同一根因) */
    com_lpuart_init();
    gpio_init();

    if(EC801E_EnsureConnected() != EC_OK)
    {
        printf_debug("[SM] 4G supervision: reconnect failed, power off (next upload cold start)\r\n");
        EC801E_PowerOff();
        fourG_init_failed = 1;
        return;
    }

    fourG_init_failed = 0;
    EC801E_SetPSM(1);   /* 恢复QSCLK轻休眠, 保持在线 */
}
#endif /* 30分钟巡检屏蔽 */


// ==================== 主函数 ====================
int main(void)
{
    SensorRecord_t init_record;		//首次采集记录

    // ==================== STATE_INIT ====================
    sys_init();
	// ==================== 首次采集上报 ====================
#if APP_DEFAULT_SENSOR_COUNT == 2
    PT304D_Init(PT304D_SENSOR_1);   /* S1(IIC2/PC0/PC1) 仅双传感器旧板存在 */
#endif
    PT304D_Init(PT304D_SENSOR_2);
    // 软件看门狗: SysTick 由 sys_init 启动, 可保护后续的 4G 连接/上报等耗时操作
    swdt_enable(SWDT_TIMEOUT_MS);
    com_lpuart_init();
    lpuart_wakeup_init();
	printf_debug("\r\n[OTA] yes%s \r\n", APP_FIRMWARE_VERSION);
	
    config_load_all();
    /* 上报防重锁: 读回上次成功上报的周期序号(跨重启保持, 防重复上报) */
    s_last_upload_idx     = config_load_upload_idx();
    s_upload_pending      = 0;
    s_pending_due_abs_min = 0;
    config_enter_setup_mode(0);
    config_print_current();

    rtc_init_all();
    rtc_alarm_wakeup_init();

    /* 告警等级锁: 必须在 config_load_all + rtc_init_all 之后、首次阈值判定之前加载
     * (依赖 sched_abs_min 做 5 分钟节流, 持久化地址见 eeprom_config.h 区块17) */
    alarm_lock_init();
	
	
	
    ee_hist_init();
    /* 重启补报: 若开机时刻所在的上报周期还没报过 → 立即置待上报,
     * 防止"上报被打断(掉电/复位/OTA)后数据被推迟一整个周期" */
    upload_pending_update();

#if CALIB_MODE_ENABLED
    /* ============ 未安装自动校零: 提前置状态(显示/首次采集/上报都要用) ============ */
    calib_load_state();
    if(!calib_is_installed())
    {
        calib_set_active(1);
        printf_debug("[CALIB] uninstalled: auto-calibration active (sample=%umin)\r\n",
                     CALIB_SAMPLE_MIN);
    }
    calib_apply_zero_offsets();         /* 未安装: 有冻结零点先应用, 否则0偏移 */
#endif

	// SLCD初始化(必须在rtc_init_all之后, LXTAL已启动)
#if LCD_KEY_TRIGGER_ENABLED
    /* 按键点亮模式: 开机默认灭屏, 由按键点亮 (lcd_activate 内部完成 SLCD 初始化) */
#else
    if(g_lcd_enabled) { slcd_seg_configuration(); lcd_ui_init(); g_lcd_active = 1; g_lcd_on_hhmmss = rtc_get_hhmmss(); }
#endif
	
	// 首次采集+存入缓冲区+上报
    PT304D_CollectAll((g_sensor_count >= 2) ? &g_sensor.raw2 : NULL, &g_sensor.raw);
#if CALIB_MODE_ENABLED
    {
        uint8_t was_calib = calib_is_active();
        /* 校零: 必须用未扣当前零点的原始读数 (见 do_collect 同处说明) */
        float p_raw = g_sensor.raw.pressure + PT304D_GetZeroOffset(PT304D_SENSOR_2);
        float corr = calib_feed_sample(p_raw);   /* 校零: 零点成熟同拍修正 */
        if(corr != 0.0f)
            g_sensor.raw.pressure -= corr;
        if(was_calib)
        {
            calib_log_sample(p_raw, g_sensor.raw.pressure);
            if(!calib_is_active())
                install_event_report();         /* 自动锁定(首次采集): 一次性上报 */
        }
    }
#endif
	// 首次采集后刷新LCD显示
    sensor_sample_voltage(1, g_sensor.last_normal_voltage);
#if CALIB_MODE_ENABLED
    if(calib_is_active())
        calib_lcd_auto_begin();         /* 未安装期首次采集: 短亮压力页 */
    else if(g_lcd_active)
        lcd_ui_refresh(&g_sensor.raw, &g_sensor.raw2, g_sensor.voltage);
#else
    if(g_lcd_active) lcd_ui_refresh(&g_sensor.raw, &g_sensor.raw2, g_sensor.voltage);
#endif

    
	
    printf_debug("\r\n[OTA] yes%s \r\n", APP_FIRMWARE_VERSION);
	
    printf_debug("\r\n========================================\r\n");
    printf_debug("  Household Valve Controller v%s\r\n", APP_FIRMWARE_VERSION);
    printf_debug("  Collect: %dmin  Upload: %dmin (grid-aligned)\r\n",
                 g_interval.collect_interval_min,
                 g_interval.upload_interval_min);
    char dot_str5[64]; window_dottime_to_str(g_window.dottime_mask, dot_str5, sizeof(dot_str5));
    printf_debug("  Window: pattern=%s start=%s stop=%s er=%d dot=%s\r\n",
                 g_window.pattern, g_window.start, g_window.stop,
                 g_window.end_result, dot_str5);
//    printf_debug("  VPTH en=%d ppmax=%.1f pmax=%.1f ppmin=%.1f pmin=%.1f mut=%.1f shock=%.1f\r\n",
//                 g_pthreshold.enabled, g_pthreshold.ppmax, g_pthreshold.pmax,
//                 g_pthreshold.ppmin, g_pthreshold.pmin,
//                 g_pthreshold.mutation, g_pthreshold.shock);
//    printf_debug("  TTH  en=%d high=%.1f low=%.1f vhigh=%.1f vlow=%.1f\r\n",
//                 g_tthreshold.enabled, g_tthreshold.high, g_tthreshold.low,
//                 g_tthreshold.vhigh, g_tthreshold.vlow);
    printf_debug("  SPUP en=%d high=%.2f low=%.2f protect=%.2f\r\n",
                 g_spupower.enabled, g_spupower.high, g_spupower.low, g_spupower.protect);
    printf_debug("  VDLY en=%d delay_ms=%d\r\n", g_vdelay.enabled, g_vdelay.delay_ms);
    printf_debug("  Keepalive: %d s\r\n", config_get_keepalive());
    printf_debug("========================================\r\n");

    // 检查debug串口是否有待处理命令
    if(debug_rx_line_ready())
            debug_check_cmd();

	// === 公共首次联网: 配置下发 + RTC网络时间同步 (非业务上报) ===
    uint8_t init_4g_ok = (EC801E_InitAndConnect() == EC_OK);
    if(init_4g_ok)
    {
        EC801E_SyncTime();
        /* 开机冷启动同样属于"唤醒时 4G 未带电"的路径(RI 此前未布防):
         * 补布防后, 开机上报期间到达的下行可锁存到 ri_wakeup_flag,
         * 由 do_sleep 大睡收口补读, 不会随后的 4G 断电丢失。 */
        ri_exti_init();
    }
	
    if(init_4g_ok)
    {

        // 4G连接成功后, 再检查debug串口命令
        if(debug_rx_line_ready())
            debug_check_cmd();

        // 用户端MQTT连接 (id=1, 与本地服务器同一阶段建立)
        if(EC801E_UserMqtt_IsConfigured())
            EC801E_UserMqtt_Connect();
//        report_4g_power_state(1);

        // 4G连接后更新LCD信号强度图标
        lcd_update_csq();

        // 连接成功提示音
        buzzer_beep(1, 200);
    }
    else
    {
        printf_debug("[SM] INIT: 4G connect failed, skip MQTT reports\r\n");
        fourG_init_failed = 1;
    }

    // OTA启动前debug串口命令
    config_check_cmd();

    // === OTA 启动回执: 按 InfoBlock 显示上次升级 SUCCESS/FAILED, 上报 mqttUpgradeReply ===
    ota_app_report_boot_status();

    
    trea_delay_ms(50);

    init_record.pressure = g_sensor.raw.pressure;
    init_record.temperature = g_sensor.raw.temperature;
    init_record.pressure2 = g_sensor.raw2.pressure;
    init_record.temperature2 = g_sensor.raw2.temperature;
    init_record.voltage = g_sensor.voltage;
    rtc_get_time_str(init_record.timestamp, sizeof(init_record.timestamp));
    init_record.flags = 0;
    memset(init_record.reserved, 0, sizeof(init_record.reserved));
#if CALIB_MODE_ENABLED
    if(calib_is_active())
    {
        s_calib_latest = init_record;
        s_calib_latest_valid = 1;
    }
    else
#endif
    {
        ee_hist_push(init_record.pressure, init_record.temperature,
                     init_record.pressure2, init_record.temperature2,
                     init_record.voltage, init_record.flags);
    }
    g_sensor.last_pressure_collect  = g_sensor.raw.pressure;
    g_sensor.last_pressure_realtime = g_sensor.raw.pressure;
    g_sensor.last_pressure_collect2  = g_sensor.raw2.pressure;
    g_sensor.last_pressure_realtime2 = g_sensor.raw2.pressure;

    printf_debug("[SM] INIT V=%.2f S2:P=%.2f T=%.2f err=%d S1:P=%.2f T=%.2f err=%d\r\n",
                 g_sensor.voltage,
                 g_sensor.raw.pressure, g_sensor.raw.temperature, g_sensor.raw.err,
                 g_sensor.raw2.pressure, g_sensor.raw2.temperature, g_sensor.raw2.err);

    

    // 将首次采集结果更新 prev_online (不论4G是否成功, 防止实时模式误判状态变化)
    g_sensor.prev_online  = (g_sensor.raw.err  == PT304D_OK) ? 1 : 0;
    g_sensor.prev_online2 = (g_sensor.raw2.err == PT304D_OK) ? 1 : 0;

    // ==================== 首次批量上报 (当4G连接成功时) ====================
    if(!init_4g_ok) goto init_skip_report;

    EC801E_PublishSensorData(&g_sensor.raw, g_sensor.voltage);
    trea_delay_ms(500);

    // 第1: restart=1 + valve_last_order
    {
        char v_order[4];
        snprintf(v_order, sizeof(v_order), "%d", g_valve_last_order);
        static char boot_json[100];
        static char boot_ts[32];
        rtc_get_time_str(boot_ts, sizeof(boot_ts));
        snprintf(boot_json, sizeof(boot_json),
            "[{\"id\":\"restart\",\"value\":\"1\",\"ts\":\"%s\",\"remark\":\"\"}]",
            boot_ts);
        EC801E_PublishRawJson(boot_json);
    }
    trea_delay_ms(300);

    // 第2: 设备信息 (csq + rsrp + sinr + cereg + soft-version + ICCID + IMEI)
    {
        static char info_json[530];
        char csq[8] = {0}, iccid[32] = {0}, imei[24] = {0};
        char rsrp_str[8] = {0}, sinr_str[8] = {0}, cereg_str[4] = {0};
        int rsrp = 0, sinr = 0;
        uint8_t cereg = 0;
        EC801E_Wakeup();
        EC801E_QueryCSQ(csq, sizeof(csq));
        if(EC801E_QueryQCSQ(&rsrp, &sinr) == EC_OK)
        {
            snprintf(rsrp_str, sizeof(rsrp_str), "%d", rsrp);
            snprintf(sinr_str, sizeof(sinr_str), "%d", sinr);
        }
        EC801E_QueryCEREG(&cereg);
        snprintf(cereg_str, sizeof(cereg_str), "%d", cereg);
        trea_delay_ms(200);
        EC801E_QueryICCID(iccid, sizeof(iccid));
        trea_delay_ms(200);
        EC801E_QueryIMEI(imei, sizeof(imei));
        static char info_ts[32];
        rtc_get_time_str(info_ts, sizeof(info_ts));
        snprintf(info_json, sizeof(info_json),
            "[{\"id\":\"csq\",\"value\":\"%s\",\"ts\":\"%s\",\"remark\":\"\"},"
            "{\"id\":\"rsrp\",\"value\":\"%s\",\"ts\":\"%s\",\"remark\":\"\"},"
            "{\"id\":\"snr\",\"value\":\"%s\",\"ts\":\"%s\",\"remark\":\"\"},"
            "{\"id\":\"soft-version\",\"value\":\"%s\",\"ts\":\"%s\",\"remark\":\"\"},"
            "{\"id\":\"ICCID\",\"value\":\"%s\",\"ts\":\"%s\",\"remark\":\"\"},"
            "{\"id\":\"IMEI\",\"value\":\"%s\",\"ts\":\"%s\",\"remark\":\"\"}]",
            csq, info_ts, rsrp_str, info_ts, sinr_str, info_ts, 
            APP_FIRMWARE_VERSION, info_ts, iccid, info_ts, imei, info_ts);
        EC801E_PublishRawJson(info_json);
        printf_debug("[SM] Device info:\r\n CSQ=%s RSRP=%s SINR=%s CEREG=%s\r\n ICCID=%s\r\n IMEI=%s\r\n",
                     csq, rsrp_str, sinr_str, cereg_str, iccid, imei);
    }

    // 第3: 传感器状态(在线+离线)字段
    {
//        report_publish_sensor_status();   // rtu_have/status 各 2 (传感器状态字段上报)
		report_publish_upload_summary();
        g_sensor.prev_online  = (g_sensor.raw.err  == PT304D_OK) ? 1 : 0;
        g_sensor.prev_online2 = (g_sensor.raw2.err == PT304D_OK) ? 1 : 0;
    }


    // === 用户端MQTT上报 (id=1, 与传感器数据同一阶段建立) ===
    if(EC801E_UserMqtt_IsConfigured())
    {
        trea_delay_ms(300);
        EC801E_UserMqtt_PublishSensorData(&g_sensor.raw, &g_sensor.raw2, g_sensor.voltage);
        trea_delay_ms(500);
        EC801E_UserMqtt_Disconnect();
    }

	// 连接成功提示音
    buzzer_beep(2, 200);
init_skip_report:
    if(init_4g_ok)
    {
        // 首次上报后也检查信号: 弱信号直接断电, 不再无效重试
        if(!fourG_signal_check_and_decide())
            printf_debug("[SM] INIT: weak signal, 4G powered off\r\n");
        else
            EC801E_SetPSM(1);
    }
    else
        EC801E_PowerOff();
    wakeup_count = 0;

    // INIT结束: 若 spupower 关闭或电压已恢复, 则清除退出时的 VLP 状态
    if(voltage_low_power && (!g_spupower.enabled || g_sensor.voltage >= g_spupower.protect + 0.15f))
    {
        voltage_low_power = 0;
        config_save_ext();
        printf_debug("[SM] VLP cleared on boot (spup_en=%d V=%.2f)\r\n", g_spupower.enabled, g_sensor.voltage);
    }
	// 检查debug串口是否有待处理命令
    if(debug_rx_line_ready())
            debug_check_cmd();

    // 初始化完成, 进入睡眠
    app_state = STATE_SLEEP;

    // ==================== 主状态机循环 ====================
    while(1)
    {
        // ISR置位标志后执行对应debug串口命令处理
        if(debug_rx_line_ready())
            debug_check_cmd();

        // 软件看门狗: 每个状态分支前重新使能并复位计时器(活跃阶段均被保护)
        // 注意: 进入 enter_deepsleep_mode() 内部会 swdt_disable() 关闭, 休眠期间不计时
        swdt_enable(SWDT_TIMEOUT_MS);

        vtiming_check_now();   /* timing valve highest priority */
#if LASER_CH4_ENABLED
        laser_schedule_check();  /* 激光甲烷定时采集: 置 g_ch4_request */
        if(g_ch4_request && app_state == STATE_SLEEP)
        {
            g_ch4_request = 0;
            app_state = STATE_CH4;
        }
#endif
        /* 30分钟巡检 (见 check_4g_connection_supervision #if 0) */
		check_4g_connection_supervision();
        switch(app_state)
        {
            case STATE_SLEEP:    do_sleep();    break;
            case STATE_WAKEUP:   do_wakeup();   break;
            case STATE_COLLECT:  do_collect();  break;
            case STATE_UPLOAD:   do_upload();   break;
            case STATE_DOWNLINK: do_downlink(); break;
            case STATE_ALARM:    do_alarm();    break;
#if BLE_ENABLED
            case STATE_BLE_OTA:  do_ble_ota();  break;
#endif
            case STATE_CH4:
#if LASER_CH4_ENABLED
                do_ch4();
#else
                app_state = STATE_SLEEP;
#endif
                break;
            default:             app_state = STATE_SLEEP; break;
        }
    }
}

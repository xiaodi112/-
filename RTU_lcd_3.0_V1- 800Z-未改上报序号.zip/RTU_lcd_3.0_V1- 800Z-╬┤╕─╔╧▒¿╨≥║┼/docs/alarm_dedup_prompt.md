# 任务提示词：取数指令统一 + 告警去重与恢复去抖（RTU_lcd_3.0_V1）

> 适用工程：`F:\GD32_library\t-y-x\RTU_lcd_3.0_V1`
> 两个目标：
> 1. 协议 6.6/6.7/6.8/6.9（进气/出气端 温度/压力状态）四条取数指令行为完全一致，都顺带做一次完整安全判定；
> 2. 同一告警不重复上报（物联网卡流量），等级变化（升级/降级）各报一次，恢复必须连续 3 次正常才解锁。

## 0. 角色与约束

你是资深嵌入式工程师，在 GD32L233 + Keil MDK 工程上工作。遵守现有分层：

- 应用层：`Projects/Wakeup_box_V0.0.1/main.c`
- 中间层：`Middle/`（协议、配置、上报、阈值、校零）
- 驱动层：`Drivers/`、`BSP/`

要求：先读代码再动手；跟随现有命名/风格；不使用动态内存；ISR 只置标志；不改协议字段名和反馈码（6.6/6.8 → 31，6.7/6.9 → 30）。

**必须保留的功能**：CH4（`ch4_alarm.c`）、校零模式（`calib_mode.c`）、OTA、LCD、历史上报、BLE。改完后确认它们不依赖旧的 `s_last_*_state`。

## 1. 现状问题（先确认）

### 1.1 四条取数指令行为不一致

- `h_sensor_read`（6.7）有一段内联检查：`threshold_check` + 直接上报/关阀，**没有去重、没有 3 次重采确认**；
- `h_temp_status`（6.6）、`h_temp_status2`（6.8）、`h_get_pressure2`（6.9）**完全没有安全判定**；
- `h_sensor_read` 在调用 `threshold_check` **之前**就把 `g_sensor.last_pressure_collect` 更新成当前值 → 突变项 `delta` 恒为 0，压力骤变永远不触发；
- `h_get_pressure2` 的 `threshold_get_pressure_status2(..., -1.0f)` 固定跳过突变判断；
- 通道 1 的阈值检查没有 `err == PT304D_OK` 离线守卫（通道 2 有）。

结果：平台查温度不会发现压力异常；查压力又可能重复报警；骤变检测失效。

### 1.2 三套独立的告警去重状态

1. `main.c` 的 `s_last_rt_state`（实时路径）
2. `main.c` 的 `s_last_collect_state`（周期采集路径）
3. 查询路径没有去重状态（只有 `h_sensor_read` 的内联检查）

共同缺陷：

- 去重键是"整个状态向量"，任一温度状态变化都会让压力告警重报；
- **一次正常采样就 `alarm_state_reset`** → 压力在阈值附近抖动时，"告警→恢复→告警"每轮发 3 条报文；
- 实时/采集两套状态互不感知，同一次告警至少报 2 遍。

现场表现：出气端低压在阈值附近抖动时，平台每分钟收到数条状态快照，流量快速消耗。

## 2. 目标行为（必须逐条实现）

### 2.1 四条取数指令统一流程

每条指令都执行：

```
采集一次传感器
  → 按 g_need_adc_sampling 采电压
  → 回读本条指令自身字段 + 反馈码（6.6/6.8 → 31，6.7/6.9 → 30）
  → 共用安全闸门：
      双通道完整阈值检查（压力/温度/压力骤变，离线通道跳过）
      → 查告警锁（只处理新等级）
      → 3 次重采确认
      → 确认异常按策略关阀
      → 报警批量报文（+ 电压报文 + 阀门状态）
  → 更新压力基线（必须晚于阈值检查）
```

顺序要求：**先回读+反馈码，再执行安全闸门**。关阀最长阻塞 `g_valve_timeout_ms`（默认 40s），不能让平台指令 ack 等这么久。

### 2.2 锁的语义

每个通道记录"**最后一次已上报的等级**"：

```c
s_last_r[ch]  // ThresholdResult_t：最后已上报的压力/温度结果码
s_last_t[ch]  // TempStatus_t：最后已上报的温度状态
```

判定规则：

| 本次等级 vs 最后已上报 | 动作 |
|---|---|
| 不同（升级） | 报一次，更新最后等级 |
| 不同（降级） | **报一次**，更新最后等级 |
| 相同 | 不报 |
| 回到正常（OK/NORMAL） | 不算新等级；由恢复流程处理 |

注意：是"等级变化就报"，不是"每个等级只报一次"。`很低 → 低压` 必须重报。

### 2.3 恢复去抖

- 条件：该通道**在线**且 `r == THRESHOLD_OK` 且 `temp == TEMP_NORMAL`；
- 连续 `ALARM_LOCK_CLEAR_COUNT = 3` 次满足 → 清空该通道最后等级，并**报一次恢复**（`LY06=0` + 状态批量）；
- 任意一次异常或离线 → 计数归零；
- 单次正常**不得**清锁。

### 2.4 三条路径职责

| 路径 | 检测/上报等级变化 | 推进 3 次恢复计数 | 报恢复 |
|---|---|---|---|
| 实时 `do_realtime_check`（`real_mode_active()` 时） | 是 | 是 | 是 |
| 采集 `do_collect` / `do_alarm`（默认 20 分钟） | 是 | 是 | 是 |
| 查询 4 条取数指令的安全闸门 | 是 | **否（只读锁）** | 否 |

查询路径仍可"锁上新等级"，否则平台每次轮询都会重复报；但它不推进恢复计数，避免一轮 6.6~6.9 轮询凑满 3 次。

### 2.5 离线与单路

- `err != PT304D_OK` 的通道：不参与阈值检查、不计正常、保留最后等级；
- `PT304D_CollectAll` 失败时只写 `err`，pressure/temperature 保留上次成功值 → 所有判定必须先判断 `err`；
- `g_sensor_count == 1`：只评估通道 0；通道 1 的锁位强制清零，不得用 raw2 的陈旧值参与判定；
- 单路时协议 6.8/6.9 的回读要加 `g_sensor_count` 守卫（返回不支持或明确错误），不能回报 raw2 的 0/陈旧值。

### 2.6 电压

- 电压码（`VPROTECT` / `VOLT_HIGH` / `VOLT_LOW`）**不进入通道锁**；
- 单独一个 1 bit 电压锁 + 独立 3 次恢复计数；
- 只有真正做了电压判定的路径（`check_voltage=1`）才能置位/清除电压锁；
- 实时/采集路径不采 ADC 时（`g_need_adc_sampling=0`）不得触碰电压锁。

### 2.7 持久化与手动操作

- 锁持久化到 EEPROM，重启后持续中的告警不重报；
- 写入节流：**至少间隔 5 分钟**；dirty 标志 + 正常采样时定期 flush；手动清锁立即写；
- 不要用 `config_save_ext()` 写锁（会重写整个 EXT 区块，增加磨损）；
- 用户手动开阀（下行 `h_valve` 的 open/1、调试串口 `valve:open`）→ 清锁并立即持久化；
- 手动关阀不清锁；定时开关阀等自动阀动作**不得**清锁。

### 2.8 报警确认与上报（保持现有安全语义）

- 3 次重采确认，每次间隔 `APP_ALARM_RECHECK_DELAY_MS`；
- 重采期间压力基线固定为"进入告警前的上拍值"，不得中途更新；
- 确认后：记录最后等级 → 按 `abnormal_close` / `abnormal2_close` 关阀 → 上报报警批量（+ 电压报警 + 阀门状态）；
- 关阀是安全动作，不依赖 4G；先关阀、后上报；
- 关阀忙等最长 `g_valve_timeout_ms`（默认 40s），前后调用 `swdt_feed()`；
- 报警批量、LY06、阀门状态的字段和顺序保持不变；
- 校零模式（`calib_is_active()`）下不写历史的行为保持不变。

## 3. 实现方案

### 3.1 新增 `Middle/alarm_lock.c/.h`

API：

```c
void    alarm_lock_init(void);
void    alarm_lock_clear_all(void);
uint8_t alarm_lock_ch_enabled(uint8_t ch);
uint8_t alarm_lock_has_new(uint8_t ch, ThresholdResult_t r, TempStatus_t ts);
void    alarm_lock_latch(uint8_t ch, ThresholdResult_t r, TempStatus_t ts);
uint8_t alarm_lock_feed_normal(uint8_t ch, uint8_t online,
                               ThresholdResult_t r, TempStatus_t ts);
uint8_t alarm_lock_volt_has_new(ThresholdResult_t r);
void    alarm_lock_volt_latch(void);
uint8_t alarm_lock_volt_feed_normal(ThresholdResult_t r, uint8_t voltage_checked);
uint8_t alarm_lock_any(void);
uint8_t alarm_lock_ch_latched(uint8_t ch);
void    alarm_lock_save(uint8_t force);
```

内部状态：

```c
static uint8_t  s_last_r[2];
static uint8_t  s_last_t[2];
static uint8_t  s_streak[2];
static uint8_t  s_volt_latched;
static uint8_t  s_volt_streak;
static uint8_t  s_dirty;
static uint32_t s_last_save_min;
```

关键语义：

- `has_new`：`r != OK && !电压码 && r != last_r` → 1；`ts != NORMAL && ts != last_t` → 1；
- `latch`：`r != OK && !电压码` 时更新 `last_r`；`last_t` 总是更新为当前 `ts`；
- `feed_normal`：离线/异常 → `streak=0`；在线全正常 → `streak++`；达到 3 且该通道有等级 → 清零并返回 1；
- 未启用通道：锁位与计数强制清零。

### 3.2 EEPROM 布局

本工程 `0x500-0x504` 已被"上报周期防重锁"占用，`0x505` 起空闲（AT24C64 配置区 0x000-0x7FF，历史区 0x800 起）。建议：

```
0x520: magic 0xCE (1B)
0x521-0x525: last_r[0], last_r[1], last_t[0], last_t[1], volt_flag (5B)
0x526: CRC8 (1B)
```

- `0x520` 是 32 字节页对齐，7 字节落在同一物理页；
- magic 最后写（半写失效）；
- 读回时校验 magic + CRC，并裁剪非法码（电压码不能作为通道等级）。

### 3.3 `main.c` 改造

- 删除 `ThresholdAlarmState_t`、`s_last_rt_state`、`s_last_collect_state`、`alarm_state_fill/is_dup/is_normal/reset`、`threshold_alarm_reset_rt`；
- 新增并导出 `alarm_new_mask(r1, r2, check_voltage)`（bit0=通道0，bit1=通道1，bit2=电压）；
- `do_realtime_check`：
  - 离线 → 打断该通道计数；
  - 每拍对每个启用通道调用 `alarm_lock_feed_normal`；
  - `mask = alarm_new_mask(r1,r2,0)`，为 0 去重返回；
  - 新告警 → 3 次重采确认 → 按通道 `alarm_lock_latch` → 关阀 → 上报；
  - 恢复计数达到 3 → 报一次恢复（VLP 低电压模式下不额外开 4G）；
  - 用 `real_mode_active()` 判断实时模式，不要绕过校零状态。
- `do_collect`：
  - 同样每拍 `feed_normal`；
  - 把"解锁恢复报文"放在进入 `STATE_ALARM` 之前，避免被提前 `return` 吞掉；
  - 去掉"一次正常就 reset"的逻辑；
  - 保持 `calib_is_active()` 时不写历史的行为。
- `do_alarm`：
  - 进入时用采集数据重算 `r1/r2` 和 `alarm_new_mask`（与 `do_collect` 同口径）；
  - 提取/复用统一的 `alarm_confirm_and_report(ctx, mask, last_p1, last_p2)`，供周期、实时、查询三条路径共用；
  - 重采期间使用传入的旧基线；
  - 保留 `motor_limit_init()`。
- 上电顺序：`config_load_all()` → `rtc_init_all()` → **`alarm_lock_init()`** → 首次阈值判定。
- `h_real_set`（切换实时模式）不再清告警锁。

### 3.4 `downlink.c` 改造（本次重点）

1. **新增共用辅助**：
   - `query_collect()`：`collect_all_sensors()` + 按 `g_need_adc_sampling` 采电压（ADC 无效回退 `last_normal_voltage`）；
   - `query_safety_gate()`：双通道阈值检查（离线守卫）→ `alarm_new_mask` → 新等级才调 `alarm_confirm_and_report(ALARM_CTX_DOWNLINK, mask, last_p1, last_p2)` → 电压锁恢复 → 更新基线（晚于检查，离线通道置 -1.0f）。
2. **4 个 handler 统一**：
   - `h_sensor_read` / `h_temp_status` / `h_temp_status2` / `h_get_pressure2` 都改为：
     `query_collect()` → 回读自身字段 + 反馈码 → `query_safety_gate()`；
   - 删除 `h_sensor_read` 里的内联阈值检查/关阀/上报；
   - 删除 `h_sensor_read` 中"先更新 `last_pressure_collect` 再检查"的顺序错误；
   - `h_get_pressure2` 的突变基线从 `-1.0f` 改为 `g_sensor.last_pressure_collect2`。
3. **删除旧的查询去重**（如果实现过程中引入了 `s_last_query_state`，不要保留；本工程目前没有，直接接入统一锁）。
4. **`h_valve`**：open/1 → `alarm_lock_clear_all()`；close 不清。
5. **删除 `threshold_alarm_reset_rt()` 调用**（如果有）。

### 3.5 工程文件

- `main.h`：声明新接口；删除旧去重接口；
- `MDK-ARM/GD32L233R_EVAL.uvprojx`：Middle 组加入 `alarm_lock.c/.h`。

## 4. 必须避开的坑（逐条检查）

1. **基线顺序**：先 `threshold_check`，后更新 `last_pressure_collect(2)` / `last_pressure_realtime(2)`；否则突变项恒为 0。`h_sensor_read` 现有的错误顺序必须修正。
2. **离线旧值**：`PT304D_CollectAll` 失败只写 `err`，压力/温度还是上次的值；所有检查加 `err == PT304D_OK` 守卫（通道 1 也要加）。
3. **轮询突发**：查询路径不得推进恢复计数，否则一轮 6.6~6.9 就凑满 3 次。
4. **恢复报文被吞**：`do_collect` 进入 `STATE_ALARM` 会提前返回，解锁恢复要在该分支之前发送，或保留 pending 标志。
5. **ADC 未初始化**：纯 RTC 最小唤醒路径可能未 `adc_bat_init()`；用 `g_need_adc_sampling` 门控电压采样与电压判定，无效值回退 `last_normal_voltage`。
6. **EEPROM 磨损**：5 分钟节流 + dirty + 正常采样 flush；单页写；magic 最后写；不要走 `config_save_ext()`。
7. **看门狗**：`SWDT_TIMEOUT_MS=180s`；`valve_execute` 忙等最长 `g_valve_timeout_ms`（默认 40s），关阀前后喂狗。
8. **电压优先级**：电压检查开启时会抢占压力/温度结果；电压码不进通道锁，避免非电压路径"清了又锁"。
9. **单路回读**：6.8/6.9 在 `g_sensor_count==1` 时不能回报 raw2 的 0/陈旧值。
10. **手动 vs 自动**：只清用户手动开阀；定时开关阀的自动动作不得清锁。
11. **校零**：`calib_mode.c` 的行为不得改变；告警锁只在阈值判定路径生效，不参与校零状态机。
12. **不要做**：不要新增"最小重报间隔"（本次未要求）；不要改协议字段/反馈码；不要用动态内存。

## 5. 验收测试

| # | 操作 | 期望 |
|---|---|---|
| 1 | 依次下发 6.6/6.7/6.8/6.9 | 四条都回读自身字段+反馈码；四条都会触发安全判定 |
| 2 | 制造出气端低压，保持 5 分钟 | 1 条报警批量 + 首次关阀的阀门状态；期间不再出现报警批量 |
| 3 | 低压 → 正常 1~2 拍 → 低压 | 0 条新增告警；不出现恢复报文 |
| 4 | 正态连续 3 拍（实时 5s → 约 15s） | 1 条 LY06(0) + 1 条状态批量；`[ALK] ... unlocked` 出现一次 |
| 5 | 低压 → 很低 | +1 条报警批量（升级） |
| 6 | 很低 → 低压 | +1 条报警批量（降级） |
| 7 | 同一等级持续 | 0 条新增 |
| 8 | 拔掉进气端传感器 | 不报警、不解锁；`rtu-status` 正常上报 |
| 9 | `APP_DEFAULT_SENSOR_COUNT=1` | 只评估通道 0；6.8/6.9 不产生假数据/假告警 |
| 10 | 告警中重启 | 不重报；恢复后仍能正常解锁 |
| 11 | 手动开阀后再异常 | 锁已清，能重新确认并关阀 |
| 12 | 压力骤变（在静态阈值内） | 6.7 能触发一次 `pressure-mutation`；不因基线提前更新而失效 |
| 13 | 平台连续下发 6.6/6.7/6.8/6.9 | 不得把恢复计数凑满 |
| 14 | 4G 断开时告警 | 关阀照常执行；恢复后周期状态报文能体现异常 |
| 15 | 校零流程 | 行为与改动前一致；不得被告警锁干扰 |

## 6. 构建

```bat
cd Pressure_Regulating_Box\Projects\Wakeup_box_V0.0.1\MDK-ARM
"D:\keil\core\UV4\UV4.exe" -b GD32L233R_EVAL.uvprojx -j0 -o build_alarm_lock.log
```

期望：`0 Error(s), 0 Warning(s)`。必须查看日志内容，不能只看退出码。

## 7. 交付

1. 修改后的源码 + 新增 `Middle/alarm_lock.c/.h`；
2. 一段说明：取数指令统一后的流程、锁的语义、EEPROM 地址、三条路径的职责、验证结果；
3. 明确列出未改动/未覆盖的风险点（例如 4G 发送失败时该次告警只靠后续周期状态报文体现）。

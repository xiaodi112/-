/**
 * @file alarm_lock.c
 * @brief 告警锁存模块 — 按"通道 + 当前等级"去重, 连续 N 次正常解锁
 * @details 记录每通道"最后一次已上报的等级"(压力结果码 + 温度状态码):
 *            - 等级变化(升级/降级) → 视为新告警, 报一次
 *            - 等级不变 → 不重报
 *            - 在线且全正常连续 N 次 → 解锁并报一次恢复
 *          锁状态持久化到 EEPROM config 区空闲段(0x500, 32 字节页对齐),
 *          写入按 ALARM_LOCK_SAVE_MIN 节流, 避免抖动场景把 EEPROM 写穿。
 */

#include "alarm_lock.h"
#include "config_store.h"
#include "config_policy.h"
#include "eeprom_config.h"
#include "usart.h"
#include <string.h>

/* ==================== EEPROM 布局 ====================
 * 0x500: magic (1B)
 * 0x501: data  (5B) = last_r[0](1) + last_r[1](1) + last_t[0](1) + last_t[1](1) + flags(1)
 * 0x506: crc8  (1B)
 * 共 7 字节, 位于 0x500~0x51F 同一物理页内
 */
#define ALK_EE_MAGIC_ADDR    0x500
#define ALK_EE_DATA_ADDR     0x501
#define ALK_EE_DATA_LEN      5
#define ALK_EE_CRC_ADDR      0x506
#define ALK_EE_MAGIC         0xA8   /* v2: 最后上报等级格式(与旧位图格式不兼容) */

#define ALK_FLAG_VOLT        0x01

/* 每通道: 最后一次已上报的等级 (THRESHOLD_OK / TEMP_NORMAL = 未锁) */
static uint8_t  s_last_r[ALARM_LOCK_CH_MAX];
static uint8_t  s_last_t[ALARM_LOCK_CH_MAX];
static uint8_t  s_streak[ALARM_LOCK_CH_MAX];   /* 每通道: 连续全正常次数 */

static uint8_t  s_volt_latched;                /* 电压告警锁 */
static uint8_t  s_volt_streak;                 /* 电压连续正常次数 */

static uint32_t s_last_save_min = 0xFFFFFFFFu;
static uint8_t  s_inited;
static uint8_t  s_dirty;                       /* RAM 状态与 EEPROM 不一致 */

/* ==================== 内部工具 ==================== */
static uint8_t crc8_calc(const uint8_t *data, uint8_t len)
{
    uint8_t crc = 0x00;
    uint8_t i, j;

    for(i = 0; i < len; i++)
    {
        crc ^= data[i];
        for(j = 0; j < 8; j++)
        {
            if(crc & 0x80) crc = (uint8_t)((crc << 1) ^ 0x07);
            else           crc = (uint8_t)(crc << 1);
        }
    }
    return crc;
}

static uint8_t is_voltage_code(ThresholdResult_t r)
{
    return (r == THRESHOLD_VPROTECT ||
            r == THRESHOLD_VOLT_HIGH ||
            r == THRESHOLD_VOLT_LOW) ? 1 : 0;
}

static void lock_ch_clear(uint8_t ch)
{
    s_last_r[ch] = (uint8_t)THRESHOLD_OK;
    s_last_t[ch] = (uint8_t)TEMP_NORMAL;
    s_streak[ch] = 0;
    s_dirty = 1;
}

static void lock_pack(uint8_t *b)
{
    b[0] = s_last_r[0];
    b[1] = s_last_r[1];
    b[2] = s_last_t[0];
    b[3] = s_last_t[1];
    b[4] = (uint8_t)(s_volt_latched ? ALK_FLAG_VOLT : 0);
}

static void lock_unpack(const uint8_t *b)
{
    uint8_t i;

    s_last_r[0] = b[0];
    s_last_r[1] = b[1];
    s_last_t[0] = b[2];
    s_last_t[1] = b[3];
    s_volt_latched = (b[4] & ALK_FLAG_VOLT) ? 1 : 0;

    /* 合理性裁剪: 非法码/电压码不能作为通道锁等级(防止坏数据导致永不清锁) */
    for(i = 0; i < ALARM_LOCK_CH_MAX; i++)
    {
        if(s_last_r[i] > (uint8_t)THRESHOLD_VOLT_LOW ||
           is_voltage_code((ThresholdResult_t)s_last_r[i]))
            s_last_r[i] = (uint8_t)THRESHOLD_OK;
        if(s_last_t[i] > (uint8_t)TEMP_VERY_LOW)
            s_last_t[i] = (uint8_t)TEMP_NORMAL;
    }
}

/* ==================== 初始化 / 清锁 ==================== */
void alarm_lock_init(void)
{
    uint8_t magic = 0;
    uint8_t i;

    for(i = 0; i < ALARM_LOCK_CH_MAX; i++)
        lock_ch_clear(i);
    s_volt_latched = 0;
    s_volt_streak  = 0;

    EE_READ(ALK_EE_MAGIC_ADDR, &magic, 1);
    if(magic == ALK_EE_MAGIC)
    {
        uint8_t buf[ALK_EE_DATA_LEN];
        uint8_t crc = 0;

        EE_READ(ALK_EE_DATA_ADDR, buf, ALK_EE_DATA_LEN);
        EE_READ(ALK_EE_CRC_ADDR, &crc, 1);
        if(crc == crc8_calc(buf, ALK_EE_DATA_LEN))
        {
            lock_unpack(buf);
            printf_debug("[ALK] restored: r0=%u r1=%u t0=%u t1=%u volt=%d\r\n",
                         s_last_r[0], s_last_r[1], s_last_t[0], s_last_t[1], s_volt_latched);
        }
        else
        {
            printf_debug("[ALK] stored lock CRC bad, reset\r\n");
        }
    }

    /* 未启用通道的锁位强制清零: 单路产品不能残留通道 2 的锁 */
    for(i = 0; i < ALARM_LOCK_CH_MAX; i++)
    {
        if(!alarm_lock_ch_enabled(i))
            lock_ch_clear(i);
    }

    s_last_save_min = sched_abs_min();
    s_dirty = 0;
    s_inited = 1;
}

void alarm_lock_clear_all(void)
{
    uint8_t i;

    for(i = 0; i < ALARM_LOCK_CH_MAX; i++)
        lock_ch_clear(i);
    s_volt_latched = 0;
    s_volt_streak  = 0;

    printf_debug("[ALK] cleared by user override\r\n");
    alarm_lock_save(1);
}

/* ==================== 通道锁 ==================== */
uint8_t alarm_lock_ch_enabled(uint8_t ch)
{
    uint8_t cnt = (g_sensor_count == 0) ? 1 : g_sensor_count;

    return (ch < ALARM_LOCK_CH_MAX && ch < cnt) ? 1 : 0;
}

uint8_t alarm_lock_has_new(uint8_t ch, ThresholdResult_t r, TempStatus_t ts)
{
    if(!alarm_lock_ch_enabled(ch))
        return 0;

    /* 压力/温度等级与"最后已上报等级"不同 → 新告警(升级或降级都报) */
    if(r != THRESHOLD_OK && !is_voltage_code(r) &&
       (uint8_t)r != s_last_r[ch])
        return 1;

    /* 温度: 只在"非正常"时算新等级; 回到正常属于恢复, 由连续正常解锁处理 */
    if(ts != TEMP_NORMAL && (uint8_t)ts != s_last_t[ch])
        return 1;

    return 0;
}

void alarm_lock_latch(uint8_t ch, ThresholdResult_t r, TempStatus_t ts)
{
    uint8_t old_r;
    uint8_t old_t;

    if(!alarm_lock_ch_enabled(ch))
        return;

    old_r = s_last_r[ch];
    old_t = s_last_t[ch];

    /* 电压类码由 alarm_lock_volt_latch 单独处理, 不写入通道等级 */
    if(r != THRESHOLD_OK && !is_voltage_code(r))
        s_last_r[ch] = (uint8_t)r;
    s_last_t[ch] = (uint8_t)ts;

    if(old_r != s_last_r[ch] || old_t != s_last_t[ch])
    {
        s_dirty = 1;
        printf_debug("[ALK] ch%u report level: r=%d ts=%d -> r=%u t=%u\r\n",
                     ch, (int)r, (int)ts, s_last_r[ch], s_last_t[ch]);
        alarm_lock_save(0);
    }
}

uint8_t alarm_lock_feed_normal(uint8_t ch, uint8_t online,
                               ThresholdResult_t r, TempStatus_t ts)
{
    if(!alarm_lock_ch_enabled(ch))
    {
        /* 通道被禁用: 锁位/计数不能残留 */
        if(s_last_r[ch] != (uint8_t)THRESHOLD_OK ||
           s_last_t[ch] != (uint8_t)TEMP_NORMAL ||
           s_streak[ch])
            lock_ch_clear(ch);
        return 0;
    }

    if(!online || r != THRESHOLD_OK || ts != TEMP_NORMAL)
    {
        s_streak[ch] = 0;            /* 异常/离线打断连续正常计数 */
        alarm_lock_save(0);          /* 节流写: 把之前延迟的等级落盘 */
        return 0;
    }

    if(s_streak[ch] < 0xFF)
        s_streak[ch]++;

    if(s_streak[ch] >= ALARM_LOCK_CLEAR_COUNT)
    {
        s_streak[ch] = 0;
        if(s_last_r[ch] != (uint8_t)THRESHOLD_OK ||
           s_last_t[ch] != (uint8_t)TEMP_NORMAL)
        {
            s_last_r[ch] = (uint8_t)THRESHOLD_OK;
            s_last_t[ch] = (uint8_t)TEMP_NORMAL;
            s_dirty = 1;
            printf_debug("[ALK] ch%u unlocked after %d normal samples\r\n",
                         ch, ALARM_LOCK_CLEAR_COUNT);
            alarm_lock_save(0);
            return 1;
        }
    }

    alarm_lock_save(0);              /* 正常情况下也定期尝试落盘(内部节流) */
    return 0;
}

/* ==================== 电压独立锁 ==================== */
uint8_t alarm_lock_volt_has_new(ThresholdResult_t r)
{
    return (is_voltage_code(r) && !s_volt_latched) ? 1 : 0;
}

void alarm_lock_volt_latch(void)
{
    if(!s_volt_latched)
    {
        s_volt_latched = 1;
        s_volt_streak  = 0;
        s_dirty = 1;
        printf_debug("[ALK] voltage alarm latched\r\n");
        alarm_lock_save(0);
    }
}

uint8_t alarm_lock_volt_feed_normal(ThresholdResult_t r, uint8_t voltage_checked)
{
    /* 本路径没做电压判定: 不参与电压锁的恢复, 也不打断(未知) */
    if(!voltage_checked)
        return 0;

    if(is_voltage_code(r))
    {
        s_volt_streak = 0;
        alarm_lock_save(0);
        return 0;
    }

    if(!s_volt_latched)
    {
        s_volt_streak = 0;
        return 0;
    }

    if(s_volt_streak < 0xFF)
        s_volt_streak++;

    if(s_volt_streak >= ALARM_LOCK_CLEAR_COUNT)
    {
        s_volt_streak  = 0;
        s_volt_latched = 0;
        s_dirty = 1;
        printf_debug("[ALK] voltage unlocked\r\n");
        alarm_lock_save(0);
        return 1;
    }

    alarm_lock_save(0);              /* 定期尝试落盘(内部节流) */
    return 0;
}

/* ==================== 查询 / 持久化 ==================== */
uint8_t alarm_lock_any(void)
{
    uint8_t i;

    for(i = 0; i < ALARM_LOCK_CH_MAX; i++)
    {
        if(alarm_lock_ch_enabled(i) &&
           (s_last_r[i] != (uint8_t)THRESHOLD_OK ||
            s_last_t[i] != (uint8_t)TEMP_NORMAL))
            return 1;
    }
    return s_volt_latched;
}

uint8_t alarm_lock_ch_latched(uint8_t ch)
{
    if(!alarm_lock_ch_enabled(ch))
        return 0;
    return (s_last_r[ch] != (uint8_t)THRESHOLD_OK ||
            s_last_t[ch] != (uint8_t)TEMP_NORMAL) ? 1 : 0;
}

void alarm_lock_save(uint8_t force)
{
    uint8_t buf[ALK_EE_DATA_LEN];
    uint8_t crc;
    uint32_t now;

    if(!s_inited)
        return;

    if(!force && !s_dirty)
        return;

    now = sched_abs_min();

    /* 节流: 抖动场景下等级会频繁翻转, 不能每次都写 EEPROM。
     * 漏写的最坏后果: 复位后锁状态最多滞后 ALARM_LOCK_SAVE_MIN 分钟。 */
    if(!force && s_last_save_min != 0xFFFFFFFFu &&
       now >= s_last_save_min &&
       (now - s_last_save_min) < ALARM_LOCK_SAVE_MIN)
        return;

    lock_pack(buf);
    crc = crc8_calc(buf, ALK_EE_DATA_LEN);
    EE_WRITE(ALK_EE_DATA_ADDR, buf, ALK_EE_DATA_LEN);
    EE_WRITE_BYTE(ALK_EE_CRC_ADDR, crc);
    EE_WRITE_BYTE(ALK_EE_MAGIC_ADDR, ALK_EE_MAGIC);   /* magic 最后写: 半写失效 */

    s_last_save_min = now;
    s_dirty = 0;
}

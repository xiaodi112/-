#ifndef ALARM_LOCK_H
#define ALARM_LOCK_H

#include <stdint.h>
#include "threshold.h"
#include "app_config.h"

/**
 * @file alarm_lock.h
 * @brief 告警锁存: 按"通道 + 当前等级"去重, 连续 N 次正常才解锁
 *
 * 设计规则:
 *   - 锁按通道独立: 单路产品只评估通道 0; 另一路掉线不阻塞本路解锁
 *   - 每通道记录"最后一次已上报的等级": 等级变化(升级/降级)报一次,
 *     同等级不重报; 温度恢复正常不算新告警(属于恢复过程)
 *   - 解锁条件: 该通道在线且全正常, 连续 ALARM_LOCK_CLEAR_COUNT 次
 *   - 查询路径只读锁(不推进计数), 实时/采集路径推进计数
 *   - 电压告警单独一把锁: 只有会做电压判定的路径(查询)参与
 *   - 锁持久化到 EEPROM, 写入节流 ALARM_LOCK_SAVE_MIN 分钟(防写穿)
 *
 * 分层: 只负责"判定状态", 不负责上报/关阀; 上报与阀门动作仍由 main/downlink 执行。
 */

#define ALARM_LOCK_CH_MAX          2
#define ALARM_LOCK_CLEAR_COUNT     3      /* 连续全正常多少次解锁 */
#define ALARM_LOCK_SAVE_MIN        5      /* 锁持久化最小间隔(分钟) */

/* 上电时调用一次(需在 config_load_all + rtc_init_all 之后) */
void alarm_lock_init(void);

/* 全部清零并立即持久化: 用户手动开阀 / 通道配置变更 */
void alarm_lock_clear_all(void);

/* 该通道是否启用 (与 g_sensor_count 同口径: ch < g_sensor_count) */
uint8_t alarm_lock_ch_enabled(uint8_t ch);

/* 本拍该通道的等级是否与"最后已上报等级"不同 (升级/降级都算新告警)
 * 电压类告警码不进入通道锁, 由 alarm_lock_volt_* 单独处理
 * 调用方需保证该通道在线 (离线时的旧值不参与判定) */
uint8_t alarm_lock_has_new(uint8_t ch, ThresholdResult_t r, TempStatus_t ts);

/* 确认报警后记录该通道"最后已上报的等级" (r/ts 为本拍该通道的等级) */
void alarm_lock_latch(uint8_t ch, ThresholdResult_t r, TempStatus_t ts);

/* 每拍对每个启用通道调用一次:
 *   online=0 或 r!=OK 或 ts!=NORMAL → 打断连续计数
 *   在线且全正常 → 计数; 连续达到阈值且该通道有锁 → 解锁, 返回 1
 * 返回 1 表示该通道刚刚解锁 (调用方据此发一次恢复报文)
 * 未启用通道: 锁位与计数强制清零, 返回 0 */
uint8_t alarm_lock_feed_normal(uint8_t ch, uint8_t online,
                               ThresholdResult_t r, TempStatus_t ts);

/* ==================== 电压告警独立锁 ==================== */
/* 本拍电压告警是否尚未锁存 */
uint8_t alarm_lock_volt_has_new(ThresholdResult_t r);
/* 确认电压报警后置位 */
void    alarm_lock_volt_latch(void);
/* 电压恢复去抖: 只有真正做了电压判定的路径传 voltage_checked=1
 * 返回 1 = 电压锁刚刚解锁 (调用方发一次 LY06 恢复) */
uint8_t alarm_lock_volt_feed_normal(ThresholdResult_t r, uint8_t voltage_checked);

/* 任一启用通道或电压处于锁定 */
uint8_t alarm_lock_any(void);
/* 指定通道是否锁定 */
uint8_t alarm_lock_ch_latched(uint8_t ch);

/* 持久化: force=1 立即写; force=0 受 ALARM_LOCK_SAVE_MIN 节流 */
void alarm_lock_save(uint8_t force);

#endif /* ALARM_LOCK_H */

#ifndef MAIN_H
#define MAIN_H

#include "stdint.h"
#include "PT_304_35.h"
#include "ota_info.h"
#include "threshold.h"

/* 优化key值、上报形式、4G数据获取 */
#define APP_FW_VERSION_NUM     2

/* ==================== State Machine ==================== */
typedef enum {
    STATE_INIT = 0,
    STATE_SLEEP,
    STATE_WAKEUP,
    STATE_COLLECT,
    STATE_UPLOAD,
    STATE_DOWNLINK,
    STATE_ALARM,
    STATE_BLE_OTA,
    STATE_CH4
} AppState_t;

extern AppState_t app_state;

/* CH4 request flag (set by downlink gas_get, checked by do_downlink) */
extern volatile uint8_t g_ch4_request;
extern uint8_t g_alarm_recover_reported; /* 报警关阀恢复"已上报一次"标志 (RAM) */
typedef struct {
    PT304D_Data raw;
    PT304D_Data raw2;
    float       voltage;
    float       last_pressure_collect;
    float       last_pressure_realtime;
    float       last_pressure_collect2;
    float       last_pressure_realtime2;
    float       last_normal_voltage;
    uint8_t     prev_online;
    uint8_t     offline_cnt;
    uint8_t     online_cnt;
    uint8_t     prev_online2;
    uint8_t     offline_cnt2;
    uint8_t     online_cnt2;
} SensorContext_t;

extern SensorContext_t g_sensor;
extern uint8_t g_lcd_active;   // LCD当前是否显示 (运行状态, 区别于配置项; main.c 维护)

// 供其他模块使用 (main.c 实现, downlink.c 等模块调用)
void lcd_shutdown(void);

const char* alarm_try_close_valve_all(const char *policy_str, ThresholdResult_t result);

const char* alarm_try_close_valve(ThresholdResult_t result);
const char* alarm_try_close_valve2(ThresholdResult_t result);   /* 出气端 (abnormal2_close) */
const char* ch4_alarm_try_close_valve(void);

/* ==================== 报警确认闸门 (周期采集 / 下行取数 共用) ====================
 * 告警去重状态由 Middle/alarm_lock.c 统一维护 (按通道+等级锁存, 三条路径共用);
 * 因此判定/重采/关阀/上报整段收在 main.c, 不各写一份。 */

/* 报警确认闸门的调用上下文 */
typedef enum {
    ALARM_CTX_PERIODIC = 0,   /* 周期采集: 内部管理4G, 采样电压, 附带用户端MQTT同步 */
    ALARM_CTX_REALTIME,       /* 实时采集: 内部管理4G, 不采样电压, 附带用户端MQTT同步 */
    ALARM_CTX_DOWNLINK        /* 下行取数: 4G已在线, 只用平台通道, 不占用用户端MQTT */
} AlarmCtx_t;

/* 报警确认闸门: 3次重采确认 → 按通道加锁 → 按策略关阀 → 报警批量/电压/阀门状态上报
 * alarm_mask: bit0=通道1(进气端)有新告警, bit1=通道2(出气端)有新告警
 * last_p1/last_p2: 本次判定使用的"上次压力"基线(供突变判断/上报, 重采期间保持不变)
 * 返回: 1=确认报警并完成上报; 0=重采排除(偶发异常, 未关阀未上报)
 * 注: 内部重采会刷新 g_sensor.raw/raw2, 调用方需在返回后再更新压力基线 */
uint8_t alarm_confirm_and_report(AlarmCtx_t ctx, uint8_t alarm_mask,
                                 float last_p1, float last_p2);

/* 计算"尚未锁存"的告警掩码: bit0=通道1, bit1=通道2, bit2=电压
 * 离线通道不参与; check_voltage=0 时电压项恒为 0。三条判定路径共用。 */
uint8_t alarm_new_mask(ThresholdResult_t r1, ThresholdResult_t r2, uint8_t check_voltage);

/* 压力突变基线更新: 在线通道取当前值, 离线通道置 -1.0f (未知, 不判突变)
 * 采集/报警路径用 collect 版, 实时路径用 realtime 版; 必须在阈值检查之后调用 */
void sensor_baseline_update_collect(void);
void sensor_baseline_update_realtime(void);

void upload_schedule_reset(void);   /* 上报周期/后延配置变更后调用, 重置延迟上报锁存 */

#endif

# 任务提示词：不影响现有功能的前提下，保证 30 分钟一次掉线巡检

> 适用工程：`Vertical_pipe_valve - 261021-老-调压箱9+7`（GD32L233RCT6 + Keil MDK）
> 源码根：`Pressure_Regulating_Box`；参考行号为当前工作区实测，以函数名为准。

---

## 0. 角色与约束

你是资深嵌入式工程师，在本工程上工作。分层：

- 应用层：`Projects/Wakeup_box_V0.0.1/main.c`
- 中间层：`Middle/`（`downlink.c`、`report.c`、`eeprom_config.c`…）
- 驱动/外设：`Drivers/`（EC801E）、`BSP/`、`App/`（valve、buzzer、lcd_ui、led）

硬性要求：

- 先读代码再动手；跟随现有命名/风格；**不使用动态内存**；**ISR 只置标志**；
- **不改协议字段名与反馈码**；
- 改完全量编译 0 Error / 0 Warning（第 6 节）；
- 本任务只做"巡检节奏保证"，**不重构睡眠状态机**。

---

## 1. 现状（巡检函数已有，问题只在"什么时候被调用"）

| 位置 | 现状 |
|---|---|
| `Middle/app_config.h:57` | `FOURG_SUPERVISE_INTERVAL_MIN 30` 已定义 |
| `main.c:3051` | `#if 1  /* 30分钟巡检临时屏蔽 (待现场验证后恢复) */` —— **值是 1，函数体参与编译**，注释文字是历史遗留 |
| `main.c:3056` | `check_4g_connection_supervision()` 已实现（3056-3096，`#endif` 在 3097） |
| `main.c:3058` | 函数内 `static uint16_t s_last_supervise_min = 0xFFFF;` |
| `main.c:3063-3066` | 适用条件：`voltage_low_power / fourG_user_off / fourG_init_failed / fourG_weak_signal` 任一为真、或 `g_window.pattern != "long"`、或 `!(config_is_active_window() || g_window.end_result == 1)` → 直接 return |
| `main.c:3068-3069` | `now_min = (hh*60 + mm)`，分钟制，来自 `rtc_get_hhmmss()` |
| `main.c:3071-3075` | `s_last_supervise_min == 0xFFFF` 时只记时间并 return（**上电后满 30 分钟才首次巡检**） |
| `main.c:3076-3079` | `< 30 min` 则 return；否则**先**更新 `s_last_supervise_min` 再执行检查 |
| `main.c:3083-3084` | 检查前 `com_lpuart_init(); gpio_init();`（最小唤醒上下文恢复 AT 通道） |
| `main.c:3086-3095` | `EC801E_EnsureConnected()` 失败 → `EC801E_PowerOff(); fourG_init_failed = 1;`；成功 → `fourG_init_failed = 0; EC801E_SetPSM(1);` |
| `main.c:3364-3365` | 主循环里**唯一调用点**（`while(1)` 内、`switch(app_state)` 之前）。3364 行注释文字里带 "`#if 0`"，但那是注释，不是预处理指令 |
| `main.c:153-172` | `sched_set_next_collect_alarm()`：算 `wait_min`，`if(wait_min > 1440u) wait_min = 1440u;`，`tod = (now_abs + wait_min) % 1440`，最后 **`rtc_set_alarm_at_hhmmss(...)`（169 行）** |
| `main.c:1045` | `do_sleep()` 入口；`fourG_keep_on`（1047） |
| `main.c:1104-1121` | 4G 电源决策：低压/短窗/关 4G/初始化失败/弱信号 → `power_4g_set(0)`；long+窗口或 `end_result=1` → `fourG_keep_on = 1` |
| `main.c:1172-1217` | 阀门定时动作分支：`valve_wait_sec < collect_sec`（1194）时用**秒级**闹钟（1202），否则 `g_real_enabled ? rtc_set_next_alarm_sec(1211) : sched_set_next_collect_alarm(1213)` |
| `main.c:1220-1225` | `fourG_keep_on` 时 `com_lpuart_init + lpuart_wakeup_init + ri_exti_init` |
| `main.c:836-863` | `realtime_enter_sleep()`：`rtc_set_next_alarm_sec(g_real_frequency)`（842），范围 1-10 s |
| `main.c:1275-1350` | 实时循环；非采集分钟调用 `do_realtime_check()`（1348） |
| `main.c:869-882` | `do_realtime_check()`：`system_wakeup_reinit()`（875）→ `swdt_enable()`（879）→ `PT304D_CollectAll()`（882） |
| `main.c:94-97` | `voltage_low_power`、`fourG_user_off`、`fourG_init_failed`、`fourG_weak_signal` |

### 1.1 实际缺口（为什么要改）

1. `check_4g_connection_supervision()` **只在 `main()` 主循环调用**。而：
   - 进入 `do_sleep()` 后，设备在 `enter_deepsleep_mode()` 里长期不返回 → 巡检停；
   - 实时模式（`g_real_enabled`）下主循环被 `do_sleep()` 内部的 RT 循环长期占住，主循环那行巡检要等实时模式结束才执行；
   - `sched_set_next_collect_alarm()` 可能把下一次唤醒算到 8 h/24 h 后，**中间根本没有唤醒点**去执行巡检。
2. 结果：配 12h 上报 + 8h 采集这类稀疏计划时，实际巡检间隔可能是**数小时到十几小时**，不是 30 分钟。

### 1.2 本工程特有约束

- `LASER_CH4_ENABLED = 1`：CH4 采集/报警/关阀（`ch4_alarm_*`、`g_ch4_alarm_closed`、`laser_schedule_check()`）**不得受影响**。
- 本工程**没有**测漏任务（无 `STATE_LEAK`）、**没有** LED 提示闹钟；不要新增。
- **本工程 4G 有真实电源轨**（`BSP/power.c`：PB5=V4G_EN，HIGH=供电；`power_4g_set()`）。不要在巡检里新增常供电；`power_gpio_init()` 只配置模式、不写输出电平，所以 `gpio_init()` 不会改变 PB5 当前电平。
- `LCD_LOCK_ENABLED = 0`：LCD 超时短睡分支不参与编译，无需考虑。
- 唤醒源（不要改）：RTC 闹钟、LPUART 起始位唤醒、RI(PA1) 下降沿（一次性、自禁用）、PB11 按键、BLE PD2。

---

## 2. 目标

在**保持现有巡检判定逻辑、现有省电策略、现有报警/阀门优先级**不变的前提下：

1. 只要 `check_4g_connection_supervision()` 的适用条件成立，**相邻两次巡检间隔 ≤ 30 分钟**；
2. 不因巡检而延长睡眠、不因巡检而让 4G 常供电、不抢占报警/阀门动作；
3. 不适用的场景（用户关 4G、初始化失败、弱信号、低压省电等）**行为与现在完全一致**。

> 精度说明：RTC 闹钟是分钟/秒粒度，`wait_min` 是整分钟，30 分钟是"≤30 分钟 + 1 分钟调度粒度"。

---

## 3. 实现方案（两处改动 + 一处清理）

### 3.1 把巡检时间基准提升到文件作用域，并新增到期计算

在 `sched_set_next_collect_alarm()`（153 行）**之前**加入（这样 153 行能直接用）：

```c
/* ---- 30 分钟网络巡检: 时间基准与到期计算 ---- */
static uint16_t s_last_supervise_min = 0xFFFF;

/* 与 check_4g_connection_supervision() 内原判定完全一致 */
static uint8_t supervise_is_applicable(void)
{
    if(voltage_low_power || fourG_user_off || fourG_init_failed || fourG_weak_signal)
        return 0;
    if(strcmp(g_window.pattern, "long") != 0)
        return 0;
    if(!(config_is_active_window() || g_window.end_result == 1))
        return 0;
    return 1;
}

static uint16_t supervise_now_min(void)
{
    uint32_t h = rtc_get_hhmmss();
    return (uint16_t)((h / 10000u) * 60u + (h / 100u) % 100u);
}

/* 距巡检到期还有多少分钟: 0=已到期, 0xFFFFFFFF=不适用
 * last==0xFFFF 表示还没记录过基准 → 首次巡检安排在 30 分钟后 */
static uint32_t supervise_wait_min(void)
{
    uint16_t now, elapsed;

    if(!supervise_is_applicable())
        return 0xFFFFFFFFu;
    if(s_last_supervise_min == 0xFFFFu)
        return FOURG_SUPERVISE_INTERVAL_MIN;

    now = supervise_now_min();
    /* 跨午夜修正: 直接相减在 now<last 时会得到巨大正数, 变成午夜后立刻巡检 */
    elapsed = (now >= s_last_supervise_min)
            ? (uint16_t)(now - s_last_supervise_min)
            : (uint16_t)(now + 1440u - s_last_supervise_min);

    if(elapsed >= FOURG_SUPERVISE_INTERVAL_MIN)
        return 0u;
    return (uint32_t)(FOURG_SUPERVISE_INTERVAL_MIN - elapsed);
}
```

### 3.2 调度器加"巡检到期夹紧"（核心）

在 `sched_set_next_collect_alarm()`（153 行）算出 `wait_min`、做过 `>1440` 夹取之后，**在** `tod = ...` **之前**插入：

```c
/* ---- 30 分钟网络巡检: 把下一次唤醒夹到巡检到期点 ---- */
{
    uint32_t sv_wait = supervise_wait_min();   /* 0=已到期, 0xFFFFFFFF=不适用 */
    if(sv_wait < wait_min) wait_min = sv_wait;
    if(wait_min == 0u) wait_min = 1u;          /* 禁用 0 分钟闹钟, 避免立即重入 */
}
```

这样下一次 `rtc_set_alarm_at_hhmmss()` 最多 30 分钟后就唤醒一次主循环，主循环 3365 行的巡检调用得以执行。

### 3.3 阀门秒级闹钟分支也要让巡检"更早叫醒"

`do_sleep()` 的阀门分支（1172-1217）在 `!g_real_enabled` 且阀门事件更早时用秒级闹钟，**不经过** `sched_set_next_collect_alarm()`。若阀门事件在 45 分钟后、巡检只剩 5 分钟，不处理就会漏掉 30 分钟保证。把 1194 行的条件改为：

```c
uint32_t sv_wait_min = supervise_wait_min();
uint32_t sv_sec = (sv_wait_min == 0xFFFFFFFFu) ? 0xFFFFFFFFu : (sv_wait_min * 60u);

if(valve_wait_sec < collect_sec && valve_wait_sec < 0xFFFFFFFFu &&
   (sv_sec == 0xFFFFFFFFu || valve_wait_sec <= sv_sec))
```

- 巡检比阀门更早（或同时）→ 走 `else` 分支（1208-1216），由 `sched_set_next_collect_alarm()` 的夹紧生效；
- `sv_wait_min == 0` → `sv_sec == 0` → 阀门分支不成立 → 夹紧后 `wait_min=1`，1 分钟内醒来巡检；
- 阀门事件更早 → 仍走阀门秒级闹钟，**阀门最高优先级不变**。

### 3.4 实时窗口内也执行一次巡检

实时模式下主循环被 `do_sleep()` 的 RT 循环占住，且 842 行是 1-10 s 的秒级闹钟，不经过调度器。在 `do_realtime_check()` 的 `swdt_enable()`（879 行）之后、`PT304D_CollectAll()`（882 行）之前加一行：

```c
check_4g_connection_supervision();   /* 内部自带 30 分钟节流, 未到期立即返回 */
```

放在采集之前的原因：巡检内部会 `com_lpuart_init(); gpio_init();`，先恢复引脚再采集更符合现有"最小唤醒 → 完整初始化 → 采集"的顺序；`gpio_init()` 只配置模式、不写电源引脚的输出电平，不会切断 4G/传感器电源。若实测发现实时采集中断，再改到 `PT304D_CollectAll()` 之后（两者都不影响判定逻辑）。

### 3.5 巡检函数自身清理（只对齐，不改判定）

`check_4g_connection_supervision()`（3056-3096）：

1. 删除函数内 `static uint16_t s_last_supervise_min = 0xFFFF;`（已提升到文件作用域，3.1）；
2. `now_min` 计算改用 `supervise_now_min()`；节流判断改用跨午夜修正后的 `elapsed`（避免午夜后多巡检一次）：
   ```c
   uint16_t elapsed;
   now_min = supervise_now_min();
   if(s_last_supervise_min == 0xFFFFu) { s_last_supervise_min = now_min; return; }
   elapsed = (now_min >= s_last_supervise_min)
           ? (uint16_t)(now_min - s_last_supervise_min)
           : (uint16_t)(now_min + 1440u - s_last_supervise_min);
   if(elapsed < FOURG_SUPERVISE_INTERVAL_MIN) return;
   s_last_supervise_min = now_min;
   ```
   注意保持原语义：**先更新时间戳，再尝试连接**（失败也不形成连续重试）。
3. 适用条件可以改为 `if(!supervise_is_applicable()) return;`，与原来完全等价（不要改变条件本身）；
4. **失败路径保持原样**：`EC801E_PowerOff(); fourG_init_failed = 1; return;`
   → 此后 `supervise_is_applicable()` 为假、巡检暂停、`do_sleep()` 也不再给 4G 供电，等下一次上报冷启动恢复。这是**现有省电策略，不要为了"继续 30 分钟重试"去清标志**。
5. **成功路径保持原样**：`fourG_init_failed = 0; EC801E_SetPSM(1);`
6. 同时把 3051 行 `#if 1 /* 30分钟巡检临时屏蔽 */` 的过期注释改成准确描述（如 `#if 1 /* 4G 连接主动巡检 (long 模式 + 窗口/end_result) */`），3052-3055 的注释保留。

---

## 4. 必须避开的坑

1. **`wait_min` 夹到 0 会变成"立即重入"**：RTC 闹钟最小 1 分钟，必须 `if(wait_min==0u) wait_min=1u;`。
2. **只改 `sched_set_next_collect_alarm()` 不够**：阀门秒级闹钟分支（3.3）和实时模式（3.4）各是一条独立路径，三处都要覆盖。
3. **不要用 tick/uptime 计 30 分钟**：深睡丢计数；必须用 RTC 的"当日分钟"做差，并处理跨午夜。
4. **不要把 `s_last_supervise_min` 留在函数内**：调度器需要读它来夹紧；提升到文件作用域后只保留一份。
5. **不要为巡检打开 4G 常供电**：本工程 PB5 是真实电源轨；巡检只在到期那一刻使用已有供电，结束按原策略（`do_sleep` 1104-1121）断电。
6. **不要抢报警/阀门优先级**：阀门定时动作、真实报警、采集闹钟、`g_ch4_request` 的顺序保持原样；巡检只把"下一次唤醒"提前。
7. **弱信号/关 4G/初始化失败/低压省电时不巡检**：沿用 `supervise_is_applicable()`，不要"为了巡检"绕过省电判断。
8. **巡检失败后不要强行 30 分钟重试**：现有逻辑置 `fourG_init_failed=1` 并断电，这是有意设计；保持。
9. **CH4 路径零改动**：`laser_schedule_check()`、`do_ch4()`、`ch4_alarm_*`、`g_ch4_alarm_closed` 都不碰。
10. **LPUART 唤醒臂（1220-1225）与 RI 一次性臂不要动**；巡检里的 `com_lpuart_init()` 是原有代码，保持。
11. **不要在 ISR 里调用巡检**（现有 ISR 只置 `counter0`/`ri_wakeup_flag`，保持）。
12. **`#if 1` 不是屏蔽**：不要因为注释里写"临时屏蔽"就把它改成 `#if 0`。

---

## 5. 验收测试

| # | 配置/操作 | 期望 |
|---|---|---|
| 1 | 上报 12h、采集 8h、long + 活动窗口（或 `end_result=1`） | 串口日志中 `[SM] 4G supervision` 约每 30 分钟出现一次；两次上报之间不再出现数小时空档 |
| 2 | long 窗口内实时模式（1-10 s） | 主循环被 RT 循环占住时，仍约每 30 分钟出现一次巡检 |
| 3 | `FOURG_SUPERVISE_INTERVAL_MIN` 临时改 5 分钟 | 巡检间隔随之约 5 分钟；测试后改回 30 |
| 4 | 设置上报间隔使 `sched_set_next_collect_alarm()` 的 `wait_min = 45` | 实际唤醒/巡检发生在 30 分钟内，而不是 45 分钟 |
| 5 | 阀门定时动作在 45 分钟后、巡检 5 分钟后到期 | 30 分钟内先唤醒巡检；阀门事件时刻照常执行，不丢不错 |
| 6 | 巡检到期瞬间有报警/阀门动作 | 动作照常执行，不被巡检阻塞或跳过；巡检随后执行 |
| 7 | 用户关闭 4G（`fourG_user_off`）/ 低压省电 | 不做巡检，4G 断电策略与改前一致 |
| 8 | 巡检时模组离线 | 尝试重连；失败后 `EC801E_PowerOff()` + `fourG_init_failed=1`，**巡检暂停**直到下一次上报冷启动（现有行为） |
| 9 | 跨午夜运行 | 午夜后不会因为 `now<last` 立刻多巡检一次 |
| 10 | 睡眠电流 | 巡检后 4G 按原策略断电/入睡；平均电流与改前同一量级 |
| 11 | CH4 采集/报警/关阀 | 与改前完全一致（回归项） |
| 12 | 唤醒源回归 | RTC/LPUART/RI/按键/BLE 唤醒均正常；下行业务可用 |

---

## 6. 构建

```bat
cd /d "F:\GD32_library\t-y-x\Vertical_pipe_valve - 261021-老-调压箱9+7\Pressure_Regulating_Box\Projects\Wakeup_box_V0.0.1\MDK-ARM"
"D:\keil\core\UV4\UV4.exe" -r GD32L233R_EVAL.uvprojx -j0 -o build_supervise30.log
```

期望：`0 Error(s), 0 Warning(s)`。**必须查看日志内容**，不能只看退出码。

---

## 7. 交付

1. 修改后的源码（`main.c` 为主；`app_config.h` 仅在需要时改注释）；
2. 说明：
   - 巡检适用条件（原样保留的语义）；
   - 30 分钟保证的三条路径：调度器夹紧、阀门秒级闹钟比较、实时窗口入口；
   - 与阀门/报警/采集/上报闹钟的优先级关系；
   - 4G 电源轨在巡检前后的状态变化；
   - 失败后暂停巡检的既有设计；
3. 明确列出未覆盖/已知限制：
   - 30 分钟是"最坏唤醒间隔"，实际巡检可能因适用条件不满足而不发生；
   - 深睡期间无法主动唤醒，只能靠上述闹钟夹紧保证唤醒点；
   - RTC 分钟粒度带来 ≤1 分钟的调度误差。

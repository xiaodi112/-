# 任务提示词：双路传感器"只插一路"时的存史/上报 + 离线通道只存哨兵、不参与判定

> 适用工程：`Vertical_pipe_valve - 261021-老-调压箱9+7`（GD32L233RCT6 + Keil MDK）
> 源码根：`Pressure_Regulating_Box`；参考行号为当前工作区实测，以函数名为准。

---

## 0. 角色与约束

你是资深嵌入式工程师，在本工程上工作。遵守现有分层：

- 应用层：`Pressure_Regulating_Box/Projects/Wakeup_box_V0.0.1/main.c`
- 中间层：`Pressure_Regulating_Box/Middle/`
- 驱动层：`Pressure_Regulating_Box/Drivers/`、`Pressure_Regulating_Box/BSP/`、`Pressure_Regulating_Box/App/`

硬性要求：

- 先读代码再动手；跟随现有命名/风格；**不使用动态内存**；**ISR 只置标志**；
- **不改协议字段名与反馈码**：6.6/6.8 → 31，6.7/6.9 → 30；
- 改完必须全量编译 0 Error / 0 Warning（命令见第 6 节）。

---

## 1. 现状（先确认：本工程已经做了很多，别重复改）

### 1.1 已经正确、**不要动**的部分

| 能力 | 位置 | 说明 |
|---|---|---|
| 阈值按在线守卫 | `do_realtime_check()`（~948-986）、`do_collect()`（~2078-2090） | `r1 = (raw.err==OK) ? threshold_check(...) : OK`，`raw2` 同理 |
| 温度状态按在线取 | 同上、`alarm_new_mask()`（main.c:108-131） | 离线取 `TEMP_NORMAL` |
| 告警锁 feed/latch | 同上（`alarm_lock_feed_normal(0/1, online, ...)`） | 已带 online 参数 |
| 查询安全闸门 | `Middle/downlink.c` 的 `query_safety_gate()`（~200-240） | 双通道守卫 + 只校验触发通道 + **离线基线置 -1.0f** |
| 统一报警确认 | `alarm_confirm_and_report(AlarmCtx_t ctx, uint8_t alarm_mask, last_p1, last_p2)`（main.c:2269） | 内部 3 次重采、按 `alarm_mask` 只校验触发通道、按策略关阀、上报；**caller 需在返回后更新压力基线** |
| 上报侧状态字段 | `Middle/report.c` | `publish_status_batch()` / `upload_summary()` 已有 err 守卫，离线回 `*-err` |

### 1.2 仍然缺失、本次要补的部分

1. **驱动不清值**：`Drivers/PT_304_35.c` 的 `pt304d_4b_read()`（117 行，当前唯一生效）与 `pt304d_7b_read()`（79 行）失败时只写 `p_data->err`，**不修改 `pressure/temperature`**；`PT304D_Collect()`（204 行）与 `PT304D_CollectAll()`（228 行）的 `SendMeasCmd` 失败分支也只置 `err`。
   → 开机以来从未读到 = `0.00`；读到过再掉线 = **最后一次成功的旧值一直被当真实值**。
2. **采集/实时门禁仍是"进气端离线即整拍早退"**：
   `do_realtime_check()` 926/935、`do_collect()` 2064/2071 都是 `if(!cur_online){ ...; return; }`（`cur_online` 只代表 `g_sensor.raw`）
   → **只插出气端（raw2）时，整个采集/入库/网格上报停摆**。
   另外 `cur_online2` 的计算（896 / 2039）缺少 `g_sensor_count >= 2` 条件。
3. **main.c 的突变基线仍是无条件赋值**：
   `last_pressure_*` 共 **8 对**：929/930、1011/1012、1023/1024、1039/1040（实时）、2241/2242（周期采集）、2457/2458（报警路径）、3228-3231（上电首采，含 collect + realtime 两对）
   → 离线时基线会变成旧值/0，恢复首拍**必然误报"压力突变"**。
   （`downlink.c` 的 `query_safety_gate()` 已经写对了：离线置 `-1.0f`，照它抄即可。）
4. **6.6~6.9 没有按通道门禁**：`h_sensor_read`(480)/`h_temp_status`(932)/`h_temp_status2`(1058)/`h_get_pressure2`(1080) 直接用 `g_sensor.raw/raw2` 的值算状态
   → 离线通道会用旧值/0 回一个"看起来正常"的状态。
5. **上电首采两路都离线时仍写历史**：`main()` 里 `ee_hist_push()`（3225）；且 3228-3231 的四个基线是无条件赋值。

### 1.3 本工程特有约束

- `LASER_CH4_ENABLED = 1`（激光甲烷）：改动**不得影响** CH4 采集/报警/关阀路径（`ch4_alarm_*`、`g_ch4_alarm_closed`）。
- 本工程**没有**测漏任务（无 `STATE_LEAK`）、**没有** LED 提示闹钟；LCD 由运行时 `g_lcd_enabled` 选择（`APP_DEFAULT_LCD_ENABLED=0`），别动。
- 双路配置：`APP_DEFAULT_SENSOR_COUNT = 2`。

---

## 2. 目标行为

### 2.1 哨兵值

| 无效读数 | 存史/上报数值 |
|---|---|
| 压力 | **-1000 Pa** |
| 温度 | **-50 ℃** |

常量只定义一次（`Drivers/PT_304_35.h`）：`PT304D_INVALID_PRESSURE_PA (-1000.0f)`、`PT304D_INVALID_TEMP_C (-50.0f)`。
哨兵只承担"可辨识"职责（历史记录报文没有状态字段），**绝不参与判定**。

### 2.2 分场景行为

| 场景 | 存历史 | 网格上报 | 阈值/报警/关阀 | 6.6~6.9 取数 |
|---|---|---|---|---|
| 两路都在线 | 正常 | 正常 | 双路判定 | 正常应答 |
| 仅进气端（raw）在线 | 正常，raw2 存哨兵 | 正常 | 仅 raw 判定 | 6.8/6.9 回"err+哨兵+反馈码" |
| 仅出气端（raw2）在线 | 正常，raw 存哨兵 | **正常（修复当前停摆）** | 仅 raw2 判定 | 6.6/6.7 回"err+哨兵+反馈码" |
| 两路都离线 | **不写** | **不上报** | 不判 | 四条全拦（err+哨兵+反馈码） |

- 通道对应关系（不要搞反）：`g_sensor.raw` = 进气端 S2（IIC1/PD4/PD5，满量程 600 kPa）；`g_sensor.raw2` = 出气端 S1（IIC2/PC0/PC1，满量程 40 kPa）。
- 离线通道"四不"：不判阈值、不报警/不关阀、不参与告警锁去重与恢复、不参与突变基线。
- 状态字段一律 `*-err`；数值字段用哨兵。
- 两路都离线时：**上电/复位的身份+汇总报文照常发**；周期采集、历史入库、网格上报跳过。
- 单路机型（`g_sensor_count < 2`）：`raw2`/出气端恒按无效处理。

---

## 3. 实现方案（只补 1.2 的五处）

### 3.1 驱动层 `Drivers/PT_304_35.c`

1. `PT_304_35.h` 增加两个哨兵宏（见 2.1）。
2. 新增文件内静态函数（**放在所有 `#ifdef PT304D_DRV_*` 分支之外**，三种协议共用：

   ```c
   static void pt304d_mark_invalid(PT304D_Data *p_data)
   {
       if(!p_data) return;
       p_data->stat_raw    = 0;
       p_data->press_raw   = 0;
       p_data->temp_raw    = 0;
       p_data->pressure    = PT304D_INVALID_PRESSURE_PA;
       p_data->temperature = PT304D_INVALID_TEMP_C;
   }
   ```

3. 在 `pt304d_4b_read()`（117 行，当前唯一生效）与 `pt304d_7b_read()`（79 行）的**入口**先调用它，成功时再覆盖；
   `PT304D_Collect()`（204 行，`SendMeasCmd` 失败分支）与 `PT304D_CollectAll()`（228 行，两个 `else` 分支）也要 `mark_invalid + err`。
   注意本工程没有 `pt304d_read_channels()` 这个函数，不要按别的工程的名字找。

### 3.2 采集/实时门禁改为"两路都离线才早退"

`do_realtime_check()`（~896-941）与 `do_collect()`（~2039-2075）：

```c
uint8_t cur_online  = (g_sensor.raw.err == PT304D_OK) ? 1 : 0;
uint8_t cur_online2 = (g_sensor_count >= 2 && g_sensor.raw2.err == PT304D_OK) ? 1 : 0;  /* 补 count 条件 */
...
/* 两路都离线才停止采集/上报 */
if(!cur_online && !cur_online2) { ...原早退逻辑...; return; }
```

- 状态变化上报（`report_publish_sensor_status()`）保持原样；
- 两处早退分支（`state_changed` 内 926/2064、`else if` 连离线 935/2071）都改成 `if(!cur_online && !cur_online2)`；
- 早退分支里的 `alarm_lock_feed_normal(0, 0, ...)` 之后补一行 `alarm_lock_feed_normal(1, 0, THRESHOLD_OK, TEMP_NORMAL);`（出气端也按离线 feed，打断其恢复计数）；
- 阈值/温度守卫本工程已正确，不需要再改（1.1）；
- ⚠️ 单路配置（`g_sensor_count < 2`）时 `PT304D_CollectAll()` 根本不写 `raw2`，而 `PT304D_Data` 的 `.err` 初值是 0（= `PT304D_OK`），会被误判为"出气端在线"。因此**所有 `raw2` 的在线判断都必须带 `g_sensor_count >= 2`**（896/2039 只是其中两处）。

### 3.3 main.c 的突变基线

新增两个助手（放在 `alarm_new_mask()` 之后、`Middle/main.h` 导出；命名可自定）：

```c
void sensor_baseline_update_collect(void)   /* last_pressure_collect / collect2 */
{
    g_sensor.last_pressure_collect  = (g_sensor.raw.err == PT304D_OK) ? g_sensor.raw.pressure : -1.0f;
    g_sensor.last_pressure_collect2 = (g_sensor_count >= 2 && g_sensor.raw2.err == PT304D_OK)
                                    ? g_sensor.raw2.pressure : -1.0f;
}
void sensor_baseline_update_realtime(void)  /* last_pressure_realtime / realtime2 */
{ /* 同上, 用 realtime 字段 */ }
```

替换 1.2 第 3 条列出的 **8 对**直接赋值（含上电 3228-3231）。
⚠️ 注意 `alarm_confirm_and_report()` 内部重采会刷新 `g_sensor.raw/raw2`，**基线更新必须在它返回之后**（现有调用顺序已经是这样，不要调整）。

### 3.4 取数指令按通道门禁（`Middle/downlink.c`，当前没有）

`process_downlink_cmd()` 里、进 handler 之前新增：

```c
typedef enum { SREQ_TEMP1, SREQ_PRESS1, SREQ_TEMP2, SREQ_PRESS2 } SensorReqKind_t;
typedef struct { const char *id; uint8_t ch; SensorReqKind_t kind; } SensorReqId_t;

static const SensorReqId_t s_sensor_req_ids[] = {
    { "sensor_read",   0, SREQ_PRESS1 },
    { "get_pressure",  0, SREQ_PRESS1 },
    { "temp_status",   0, SREQ_TEMP1  },
    { "get_pressure2", 1, SREQ_PRESS2 },
    { "temp_status2",  1, SREQ_TEMP2  },
};
```

- 判定：`ch==0` 看 `g_sensor.raw.err`；`ch==1` 看 `g_sensor_count<2 || g_sensor.raw2.err!=OK`；
- 离线应答保持"本指令原有字段集合"，追加数值哨兵 + 反馈码：

| 指令 | 应答 | 反馈码 |
|---|---|---|
| 6.6 `temp-get1` | `temp-status=temp-err` + `temp=-50.00` | 31 |
| 6.7 `get-pressure1`/`sensor_read` | `pressure-status=pressure-err` + `pressure=-1000.00` | 30 |
| 6.8 `temp-get2` | `temp2-status=temp-err` + `temp2=-50.00` | 31 |
| 6.9 `get-pressure2` | `pressure2-status=pressure-err` + `pressure2=-1000.00` + `temp2=-50.00` | 30 |

- 有效通道照常走原 handler；`query_safety_gate()`（已正确）调用顺序不变（先应答、后安全检查）。

### 3.5 上电首采（`main()`，3217-3231）

1. `init_record` 的两个通道字段用哨兵填充（离线通道）；
2. 两路都离线时**不 `ee_hist_push()`**；
3. 3228-3231 的四个基线改用两个助手（`sensor_baseline_update_collect()` / `sensor_baseline_update_realtime()`）；
4. 身份/汇总报文照发，`prev_online/prev_online2` 的既有初始化保持原样。

---

## 4. 必须避开的坑

1. **哨兵绝不能进 `threshold_check*` / `threshold_get_pressure_status*` / `threshold_get_temp_status*`**（后者内部有 `press_hyst_update()` 滞回副作用）。
2. **基线**：离线置 `-1.0f`（不是 0、不是哨兵）。
3. **不要改已经正确的部分**（1.1 表）：阈值守卫、`alarm_new_mask`、`query_safety_gate`、`alarm_confirm_and_report`、report.c 守卫。
4. **不要动 CH4 路径**：`LASER_CH4_ENABLED=1`，`ch4_alarm_try_close_valve()` / `g_ch4_alarm_closed` / `laser_schedule_check()` 保持原样。
5. **两路都离线时不写历史**（含上电首采），避免哨兵记录挤占环形区。
6. 不用 0 代替哨兵（历史记录报文无状态字段，0 与真实 0 Pa/0℃ 无法区分）。
7. `zero_cal`：已有 err 检查 + 大气窗口，安全，不用改。

---

## 5. 验收测试

| # | 操作 | 期望 |
|---|---|---|
| 1 | 双路都插，正常运行 | 与改前完全一致 |
| 2 | 只插进气端，拔掉出气端 | 采集/存史/网格上报照常；`pressure2/temp2=-1000.00/-50.00`、`pressure2-status/temp2-status=*-err`；6.8/6.9 回"err+哨兵+反馈码"；不产生通道 2 报警/关阀 |
| 3 | 只插出气端，拔掉进气端 | 采集/存史/上报照常（修复当前停摆）；通道 1 数值哨兵 + `*-err`；6.6/6.7 回"err+哨兵+反馈码" |
| 4 | 两路都拔 | 不采集、不写历史、不上报；rtu 状态反映离线；上电身份/汇总报文仍能发 |
| 5 | 通道掉线后再插回 | 第一拍**不得**报"压力突变"；恢复计数正常累积 |
| 6 | 单路在线时触发报警 | 报警批量中离线通道数值哨兵 + 状态 err；关阀只按在线通道策略判定（`alarm_mask` 机制不受影响） |
| 7 | `APP_DEFAULT_SENSOR_COUNT=1` 编译 | 只评估通道 1；通道 2 恒无效；6.8/6.9 回 err+哨兵+反馈码 |
| 8 | CH4 采集/报警流程 | 与改前一致（回归项） |

---

## 6. 构建

```bat
cd /d "F:\GD32_library\t-y-x\Vertical_pipe_valve - 261021-老-调压箱9+7\Pressure_Regulating_Box\Projects\Wakeup_box_V0.0.1\MDK-ARM"
"D:\keil\core\UV4\UV4.exe" -r GD32L233R_EVAL.uvprojx -j0 -o build_sensor_offline.log
```

期望：`0 Error(s), 0 Warning(s)`。**必须查看日志内容**，不能只看退出码。

---

## 7. 交付

1. 修改后的源码；
2. 说明：哨兵值定义位置、离线通道"四不"语义、各场景行为、查询应答格式；
3. 明确列出未覆盖/已知限制：
   - 历史记录报文没有状态字段，平台需按 `-1000/-50`（或 `<0`）过滤；
   - 平台按数值判断的报警规则应对 `*-status=*-err` 的通道忽略数值。

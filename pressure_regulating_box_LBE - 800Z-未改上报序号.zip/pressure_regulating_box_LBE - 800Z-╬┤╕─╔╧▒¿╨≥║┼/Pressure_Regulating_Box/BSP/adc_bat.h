#ifndef ADC_BAT_H
#define ADC_BAT_H

#include "gd32l23x.h"

/* ==================== 电池电压采集引脚 (板级) ====================
 *   AD_BAT : PC2  分压中点, ADC_CHANNEL_12
 *   AD_EN  : PD1  分压使能 (低=使能, 高=关闭; 默认/深睡输出高)
 *   分压   : V-BAT --R3(300K)-- AD_BAT --R5(300K)-- AD_EN(PD1)
 * 注: PC3 是压变传感器电源(SENSOR_PWR), 本模块不得操作。 */
#define ADC_BAT_PORT           GPIOC
#define ADC_BAT_PIN            GPIO_PIN_2
#define ADC_BAT_CHANNEL        ADC_CHANNEL_12

#define ADC_EN_PORT            GPIOD
#define ADC_EN_PIN             GPIO_PIN_1

// 初始化电池电压检测: PD1 输出高(关闭分压) + PC2 模拟输入 + ADC 校准
void adc_bat_init(void);

// 读取电池电压 (单位: V)
// 采样时 PD1 拉低使能分压(约6uA), 读完立即恢复输出高(约0.5uA); 失败返回 -1.0f
// V_BAT = ADC_BAT / ADC_VREFINT × 1.20 × (R3+R5)/R5
float adc_bat_read_voltage(void);

#endif /* ADC_BAT_H */

#include "power.h"

void power_gpio_init(void)
{
    rcu_periph_clock_enable(RCU_GPIOA);
    rcu_periph_clock_enable(RCU_GPIOB);
    rcu_periph_clock_enable(RCU_GPIOC);

    /* PA0 (4G_DTR): 输出, 默认 HIGH (允许 EC800E 轻睡; 唤醒时由 EC801E_Wakeup 拉低) */
    gpio_bit_set(PWR_4G_DTR_PORT, PWR_4G_DTR_PIN);
    gpio_mode_set(PWR_4G_DTR_PORT, GPIO_MODE_OUTPUT, GPIO_PUPD_NONE, PWR_4G_DTR_PIN);
    gpio_output_options_set(PWR_4G_DTR_PORT, GPIO_OTYPE_PP, GPIO_OSPEED_2MHZ, PWR_4G_DTR_PIN);

    /* PB5 (V4G_EN): 输出, 常高 — 4G 模块常供电, 运行期间不再拉低
     * 注: 先写 ODR 再切输出模式, 避免 MCU 复位瞬间 EN 短暂为低导致模块掉电重启 */
    gpio_bit_set(PWR_4G_PORT, PWR_4G_PIN);
    gpio_mode_set(PWR_4G_PORT, GPIO_MODE_OUTPUT, GPIO_PUPD_NONE, PWR_4G_PIN);
    gpio_output_options_set(PWR_4G_PORT, GPIO_OTYPE_PP, GPIO_OSPEED_2MHZ, PWR_4G_PIN);

    /* PA4 (4G PWRKEY): 输出, 默认 LOW = 释放 (HIGH=按下, NPN 导通拉低 PWRKEY) */
    gpio_bit_reset(PWR_4G_KEY_PORT, PWR_4G_KEY_PIN);
    gpio_mode_set(PWR_4G_KEY_PORT, GPIO_MODE_OUTPUT, GPIO_PUPD_NONE, PWR_4G_KEY_PIN);
    gpio_output_options_set(PWR_4G_KEY_PORT, GPIO_OTYPE_PP, GPIO_OSPEED_2MHZ, PWR_4G_KEY_PIN);

    /* PC12 (SW_BT): 默认 LOW (蓝牙默认断电) */
    gpio_mode_set(PWR_BLE_PORT, GPIO_MODE_OUTPUT, GPIO_PUPD_NONE, PWR_BLE_PIN);
    gpio_output_options_set(PWR_BLE_PORT, GPIO_OTYPE_PP, GPIO_OSPEED_2MHZ, PWR_BLE_PIN);

    /* PC3 (SENSOR_PWR): 默认 LOW */
    gpio_mode_set(PWR_SENSOR_PORT, GPIO_MODE_OUTPUT, GPIO_PUPD_NONE, PWR_SENSOR_PIN);
    gpio_output_options_set(PWR_SENSOR_PORT, GPIO_OTYPE_PP, GPIO_OSPEED_2MHZ, PWR_SENSOR_PIN);

    /* PC13 (SW_Sensor/CH4_PWR): 默认 LOW */
    gpio_mode_set(PWR_CH4_PORT, GPIO_MODE_OUTPUT, GPIO_PUPD_NONE, PWR_CH4_PIN);
    gpio_output_options_set(PWR_CH4_PORT, GPIO_OTYPE_PP, GPIO_OSPEED_2MHZ, PWR_CH4_PIN);
}

void power_ble_set(uint8_t on)
{
    if(on) gpio_bit_set(PWR_BLE_PORT, PWR_BLE_PIN);
    else   gpio_bit_reset(PWR_BLE_PORT, PWR_BLE_PIN);
}

void power_sensor_set(uint8_t on)
{
    if(on) gpio_bit_set(PWR_SENSOR_PORT, PWR_SENSOR_PIN);
    else   gpio_bit_reset(PWR_SENSOR_PORT, PWR_SENSOR_PIN);
}

void power_4g_dtr_set(uint8_t level)
{
    /* 深睡后 PA0 会被转成 Analog, 每次调用重新配置为推挽输出再置电平 */
    gpio_mode_set(PWR_4G_DTR_PORT, GPIO_MODE_OUTPUT, GPIO_PUPD_NONE, PWR_4G_DTR_PIN);
    gpio_output_options_set(PWR_4G_DTR_PORT, GPIO_OTYPE_PP, GPIO_OSPEED_2MHZ, PWR_4G_DTR_PIN);

    if(level) gpio_bit_set(PWR_4G_DTR_PORT, PWR_4G_DTR_PIN);
    else      gpio_bit_reset(PWR_4G_DTR_PORT, PWR_4G_DTR_PIN);
}

void power_ch4_set(uint8_t on)
{
    if(on) gpio_bit_set(PWR_CH4_PORT, PWR_CH4_PIN);
    else  gpio_bit_reset(PWR_CH4_PORT, PWR_CH4_PIN);
}

uint8_t power_ch4_is_on(void)
{
    return (gpio_input_bit_get(PWR_CH4_PORT, PWR_CH4_PIN) == SET) ? 1 : 0;
}

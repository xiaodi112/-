#ifndef POWER_H
#define POWER_H

#include "gd32l23x.h"

/* ==================== 板级电源引脚映射 ==================== */
#define PWR_4G_PORT       GPIOB      /* V4G_EN (TPS61023 EN): 4G 模块电源, 常高/常供电 */
#define PWR_4G_PIN        GPIO_PIN_5
#define PWR_4G_KEY_PORT   GPIOA      /* 4G PWRKEY (Q21 基极): HIGH=按下, LOW=释放 */
#define PWR_4G_KEY_PIN    GPIO_PIN_4
#define PWR_BLE_PORT      GPIOC      /* SW_BT: 蓝牙模块电源 (HIGH=供电) */
#define PWR_BLE_PIN       GPIO_PIN_12
#define PWR_SENSOR_PORT   GPIOC      /* SENSOR_PWR: 传感器模块电源/上拉 (HIGH=供电) */
#define PWR_SENSOR_PIN    GPIO_PIN_3
#define PWR_CH4_PORT      GPIOC      /* SW_Sensor: CH4 (HIGH=ON) */
#define PWR_CH4_PIN       GPIO_PIN_13
#define PWR_4G_DTR_PORT   GPIOA      /* 4G_DTR: 模块休眠控制 (HIGH=允许休眠) */
#define PWR_4G_DTR_PIN    GPIO_PIN_0

/* 传感器电源开关: 1=PC3 供电+上拉(当前默认, 传感器上电); 0=传感器常供电板型 */
#define SENSOR_PWR_ENABLED         1
/* PC3 上电稳定延时(毫秒) */
#define SENSOR_PWRUP_DELAY_MS      100

/* 初始化全部电源控制引脚:
 *   PB5(V4G_EN)=输出高(4G 模块常供电, 运行期间不再拉低)
 *   PA4(PWRKEY)=输出低(释放, 板上 Rg2 47K 基极下拉)
 *   PA0(DTR)=输出高(允许模块轻睡); 其余电源脚默认 LOW */
void power_gpio_init(void);

/* 蓝牙模块电源: 1=供电, 0=断电 */
void power_ble_set(uint8_t on);

/* 传感器模块电源: 1=供电, 0=断电 */
void power_sensor_set(uint8_t on);

/* 4G DTR: 1=HIGH(允许模块轻睡), 0=LOW(强制唤醒);
 * 每次调用重新配置 PA0 为推挽输出(深睡后该脚会变 Analog) */
void power_4g_dtr_set(uint8_t level);

/* CH4: 1=, 0= */
void power_ch4_set(uint8_t on);
uint8_t power_ch4_is_on(void);

#endif /* POWER_H */

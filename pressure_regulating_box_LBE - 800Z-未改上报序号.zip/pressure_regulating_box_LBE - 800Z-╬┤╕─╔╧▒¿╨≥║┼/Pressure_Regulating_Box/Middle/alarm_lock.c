/**
 * @file alarm_lock.c
 * @brief 告警锁: 等级变化上报 + 恢复去抖 + EEPROM 持久化 (三路径共用)
 *
 * 锁语义:
 *   每个通道记录"最后一次已上报的等级"(结果码 last_r + 温度状态 last_t)。
 *     本次等级 != 最后已上报  → 报一次并锁存
 *     本次等级 == 最后已上报  → 不报
 *     回到正常(OK/NORMAL)     → 不算新等级, 由恢复流程处理
 *   电压码(VPROTECT/VOLT_HIGH/VOLT_LOW)不进入通道锁, 由独立 1 bit 电压锁管理。
 *
 * 恢复去抖:
 *   该通道在线 且 r==OK 且 ts==NORMAL 连续 ALARM_LOCK_CLEAR_COUNT 次
 *   → 清空该通道最后等级并返回 1 (调用方发恢复报文: LY06=0 + 状态批量)。
 *   任意一次异常/离线 → 计数归零; 单次正常不清锁。
 *
 * 持久化 (AT24C64, 配置区 0x000-0x7FF; 0x500 起空闲且 32B 页对齐):
 *   0x500       : magic 0xA8
 *   0x501-0x505 : last_r[0], last_r[1], last_t[0], last_t[1], volt_flag
 *   0x506       : CRC8 (覆盖 0x501-0x505)
 *   magic 最后写(半写失效); 写节流 >= ALARM_LOCK_SAVE_MIN_INTERVAL 分钟;
 *   用户手动开阀清锁时立即写; 不使用 config_save_ext() 以免重写整个 EXT 区块。
 */

#include "alarm_lock.h"
#include "config_store.h"      /* EE_READ / EE_WRITE / EE_WRITE_BYTE */
#include "eeprom_config.h"     /* g_sensor_count */
#include "tim.h"               /* rtc_get_hhmmss */
#include "usart.h"             /* printf_debug */
#include <string.h>

/* ==================== EEPROM 布局 ==================== */
#define ALK_EE_MAGIC        0x500
#define ALK_EE_DATA         0x501   /* 5B: last_r[0], last_r[1], last_t[0], last_t[1], volt */
#define ALK_EE_CRC          0x506   /* 1B: CRC8 over 0x501-0x505 */
#define ALK_EE_MAGIC_VAL    0xA8
#define ALK_EE_DATA_LEN     5

/* ==================== 锁状态 (RAM) ==================== */
static uint8_t  s_last_r[ALARM_LOCK_CH_COUNT];    /* 最后已上报结果码 */
static uint8_t  s_last_t[ALARM_LOCK_CH_COUNT];    /* 最后已上报温度状态 */
static uint8_t  s_streak[ALARM_LOCK_CH_COUNT];    /* 连续全正常次数 */
static uint8_t  s_volt_latched;                   /* 电压锁 */
static uint8_t  s_volt_streak;                    /* 电压恢复计数 */
static uint8_t  s_dirty;                          /* 有未落盘修改 */
static uint8_t  s_save_valid;                     /* s_last_save_min 是否有效 */
static uint32_t s_last_save_min;                  /* 上次落盘时刻(当天分钟) */
static uint8_t  s_inited;                         /* 本次上电已从 EEPROM 初始化 */

/* ==================== 内部工具 ==================== */
static uint8_t alk_is_voltage_code(uint8_t r)
{
    return (r == (uint8_t)THRESHOLD_VPROTECT ||
            r == (uint8_t)THRESHOLD_VOLT_HIGH ||
            r == (uint8_t)THRESHOLD_VOLT_LOW) ? 1 : 0;
}

static uint8_t alk_result_valid(uint8_t r)
{
    return (r <= (uint8_t)THRESHOLD_VOLT_LOW && !alk_is_voltage_code(r)) ? 1 : 0;
}

static uint8_t alk_temp_valid(uint8_t t)
{
    return (t <= (uint8_t)TEMP_VERY_LOW) ? 1 : 0;
}

/* 当天分钟数 (0..1439); RTC 未配置时返回 0, 仅影响保存节流精度 */
static uint32_t alk_now_min(void)
{
    uint32_t t = rtc_get_hhmmss();
    return ((t / 10000u) * 60u) + ((t / 100u) % 100u);
}

static uint8_t alk_crc8(const uint8_t *data, uint8_t len)
{
    uint8_t crc = 0x00;
    uint8_t i, b;

    for(i = 0; i < len; i++)
    {
        crc ^= data[i];
        for(b = 0; b < 8; b++)
            crc = (crc & 0x80u) ? (uint8_t)((crc << 1) ^ 0x07u) : (uint8_t)(crc << 1);
    }
    return crc;
}

static void alk_store(void)
{
    uint8_t buf[ALK_EE_DATA_LEN];

    buf[0] = s_last_r[0];
    buf[1] = s_last_r[1];
    buf[2] = s_last_t[0];
    buf[3] = s_last_t[1];
    buf[4] = s_volt_latched;

    EE_WRITE(ALK_EE_DATA, buf, ALK_EE_DATA_LEN);
    EE_WRITE_BYTE(ALK_EE_CRC, alk_crc8(buf, ALK_EE_DATA_LEN));
    EE_WRITE_BYTE(ALK_EE_MAGIC, ALK_EE_MAGIC_VAL);   /* magic 最后写: 半写失效 */
}

static void alk_load(void)
{
    uint8_t magic = 0;
    uint8_t buf[ALK_EE_DATA_LEN];
    uint8_t crc = 0;

    EE_READ(ALK_EE_MAGIC, &magic, 1);
    if(magic != ALK_EE_MAGIC_VAL)
        return;                                       /* 无有效锁: 保持全 0 */

    EE_READ(ALK_EE_DATA, buf, ALK_EE_DATA_LEN);
    EE_READ(ALK_EE_CRC, &crc, 1);
    if(crc != alk_crc8(buf, ALK_EE_DATA_LEN))
    {
        printf_debug("[ALK] EEPROM CRC bad, locks ignored\r\n");
        return;
    }

    s_last_r[0] = alk_result_valid(buf[0]) ? buf[0] : (uint8_t)THRESHOLD_OK;
    s_last_r[1] = alk_result_valid(buf[1]) ? buf[1] : (uint8_t)THRESHOLD_OK;
    s_last_t[0] = alk_temp_valid(buf[2]) ? buf[2] : (uint8_t)TEMP_NORMAL;
    s_last_t[1] = alk_temp_valid(buf[3]) ? buf[3] : (uint8_t)TEMP_NORMAL;
    s_volt_latched = (buf[4] != 0) ? 1 : 0;
}

/* ==================== 对外接口 ==================== */
void alarm_lock_init(void)
{
    if(s_inited)
    {
        /* 最小唤醒升级时 ensure_full_init()→sys_init() 会再次调用:
         * 此时 RAM 中的锁比 EEPROM 新, 不能重读覆盖; 顺手尝试落盘 */
        alarm_lock_save(0);
        return;
    }

    memset(s_last_r, 0, sizeof(s_last_r));
    memset(s_last_t, 0, sizeof(s_last_t));
    memset(s_streak, 0, sizeof(s_streak));
    s_volt_latched   = 0;
    s_volt_streak    = 0;
    s_dirty          = 0;
    s_save_valid     = 0;
    s_last_save_min  = 0;

    alk_load();

    /* 单路机型: 通道1不参与, 锁位/计数强制清零 */
    if(!alarm_lock_ch_enabled(1))
    {
        s_last_r[1] = (uint8_t)THRESHOLD_OK;
        s_last_t[1] = (uint8_t)TEMP_NORMAL;
        s_streak[1] = 0;
    }

    s_inited = 1;

    printf_debug("[ALK] init: ch0(r=%u t=%u) ch1(r=%u t=%u) volt=%u\r\n",
                 s_last_r[0], s_last_t[0], s_last_r[1], s_last_t[1], s_volt_latched);
}

void alarm_lock_clear_all(void)
{
    s_last_r[0] = (uint8_t)THRESHOLD_OK;
    s_last_t[0] = (uint8_t)TEMP_NORMAL;
    s_last_r[1] = (uint8_t)THRESHOLD_OK;
    s_last_t[1] = (uint8_t)TEMP_NORMAL;
    s_streak[0] = 0;
    s_streak[1] = 0;
    s_volt_latched = 0;
    s_volt_streak  = 0;
    s_dirty        = 1;

    alarm_lock_save(1);                               /* 手动清锁: 立即持久化 */
    printf_debug("[ALK] cleared by user (valve open)\r\n");
}

uint8_t alarm_lock_ch_enabled(uint8_t ch)
{
    if(ch >= ALARM_LOCK_CH_COUNT) return 0;
    if(ch == 1) return (g_sensor_count >= 2) ? 1 : 0;
    return 1;
}

uint8_t alarm_lock_has_new(uint8_t ch, ThresholdResult_t r, TempStatus_t ts)
{
    if(!alarm_lock_ch_enabled(ch)) return 0;

    if(r != THRESHOLD_OK && !alk_is_voltage_code((uint8_t)r) &&
       (uint8_t)r != s_last_r[ch])
        return 1;                                     /* 压力/温度/突变等级变化(升/降级都算) */

    if(ts != TEMP_NORMAL && (uint8_t)ts != s_last_t[ch])
        return 1;                                     /* 温度状态单独比较(不叠加压力等级) */

    return 0;
}

void alarm_lock_latch(uint8_t ch, ThresholdResult_t r, TempStatus_t ts)
{
    if(ch >= ALARM_LOCK_CH_COUNT) return;

    if(r != THRESHOLD_OK && !alk_is_voltage_code((uint8_t)r))
        s_last_r[ch] = (uint8_t)r;
    s_last_t[ch] = (uint8_t)ts;                       /* last_t 总是更新 */
    s_streak[ch] = 0;                                 /* 新等级: 恢复计数从零开始 */
    s_dirty = 1;
}

uint8_t alarm_lock_feed_normal(uint8_t ch, uint8_t online,
                               ThresholdResult_t r, TempStatus_t ts)
{
    if(ch >= ALARM_LOCK_CH_COUNT) return 0;

    if(!alarm_lock_ch_enabled(ch))
    {
        s_last_r[ch] = (uint8_t)THRESHOLD_OK;
        s_last_t[ch] = (uint8_t)TEMP_NORMAL;
        s_streak[ch] = 0;
        return 0;
    }

    if(!online || r != THRESHOLD_OK || ts != TEMP_NORMAL)
    {
        s_streak[ch] = 0;                             /* 异常/离线: 计数归零, 保留最后等级 */
        return 0;
    }

    if(!alarm_lock_ch_latched(ch))
    {
        s_streak[ch] = 0;                             /* 无锁: 不计数 */
        return 0;
    }

    if(s_streak[ch] < ALARM_LOCK_CLEAR_COUNT)
        s_streak[ch]++;

    if(s_streak[ch] >= ALARM_LOCK_CLEAR_COUNT)
    {
        s_last_r[ch] = (uint8_t)THRESHOLD_OK;
        s_last_t[ch] = (uint8_t)TEMP_NORMAL;
        s_streak[ch] = 0;
        s_dirty = 1;
        return 1;                                     /* 解锁: 调用方报恢复 */
    }
    return 0;
}

uint8_t alarm_lock_volt_has_new(ThresholdResult_t r)
{
    return (alk_is_voltage_code((uint8_t)r) && !s_volt_latched) ? 1 : 0;
}

void alarm_lock_volt_latch(void)
{
    s_volt_streak = 0;
    if(!s_volt_latched)
    {
        s_volt_latched = 1;
        s_dirty = 1;
    }
}

uint8_t alarm_lock_volt_feed_normal(ThresholdResult_t r, uint8_t voltage_checked)
{
    if(!voltage_checked)
        return 0;                                     /* 未做电压判定/采样: 不触碰电压锁 */

    if(alk_is_voltage_code((uint8_t)r))
    {
        s_volt_streak = 0;                            /* 电压仍异常 */
        return 0;
    }

    if(!s_volt_latched)
    {
        s_volt_streak = 0;
        return 0;
    }

    if(s_volt_streak < ALARM_LOCK_CLEAR_COUNT)
        s_volt_streak++;

    if(s_volt_streak >= ALARM_LOCK_CLEAR_COUNT)
    {
        s_volt_latched = 0;
        s_volt_streak  = 0;
        s_dirty = 1;
        return 1;
    }
    return 0;
}

uint8_t alarm_lock_any(void)
{
    return (alarm_lock_ch_latched(0) || alarm_lock_ch_latched(1) ||
            s_volt_latched) ? 1 : 0;
}

uint8_t alarm_lock_ch_latched(uint8_t ch)
{
    if(ch >= ALARM_LOCK_CH_COUNT) return 0;
    return (s_last_r[ch] != (uint8_t)THRESHOLD_OK ||
            s_last_t[ch] != (uint8_t)TEMP_NORMAL) ? 1 : 0;
}

void alarm_lock_save(uint8_t force)
{
    uint32_t now_min, elapsed;

    if(!force && !s_dirty)
        return;

    now_min = alk_now_min();

    if(!force && s_save_valid)
    {
        /* 跨天回卷: 当天分钟比较, 5min 远小于 24h */
        elapsed = (now_min >= s_last_save_min)
                ? (now_min - s_last_save_min)
                : (now_min + 1440u - s_last_save_min);
        if(elapsed < ALARM_LOCK_SAVE_MIN_INTERVAL)
            return;                                   /* 节流: 保持 dirty, 下次再写 */
    }

    alk_store();
    s_dirty         = 0;
    s_save_valid    = 1;
    s_last_save_min = now_min;
    printf_debug("[ALK] saved: ch0(r=%u t=%u) ch1(r=%u t=%u) volt=%u\r\n",
                 s_last_r[0], s_last_t[0], s_last_r[1], s_last_t[1], s_volt_latched);
}

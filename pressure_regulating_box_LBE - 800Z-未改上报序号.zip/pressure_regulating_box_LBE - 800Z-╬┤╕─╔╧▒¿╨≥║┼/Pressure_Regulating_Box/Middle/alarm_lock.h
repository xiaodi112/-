/**
 * @file alarm_lock.h
 * @brief 告警锁: 按通道记录"最后已上报等级" + 恢复去抖(3次) + EEPROM 持久化
 * @details 供实时/周期采集/查询三条路径共用; 锁的语义见 alarm_lock.c
 */
#ifndef ALARM_LOCK_H
#define ALARM_LOCK_H

#include <stdint.h>
#include "threshold.h"

#define ALARM_LOCK_CH_COUNT           2   /* 0=进气端(S1), 1=出气端(S2) */
#define ALARM_LOCK_CLEAR_COUNT        3   /* 连续 N 次"在线且全正常"才解锁并报恢复 */
#define ALARM_LOCK_SAVE_MIN_INTERVAL  5   /* 持久化最小间隔(分钟) */

/* 上电: 从 EEPROM 读回锁状态 (config_load_all/rtc_init_all 之后调用) */
void    alarm_lock_init(void);

/* 用户手动开阀: 清全部锁并立即持久化 */
void    alarm_lock_clear_all(void);

/* 通道是否参与 (单路机型只有通道0; 未启用通道的锁位强制清零) */
uint8_t alarm_lock_ch_enabled(uint8_t ch);

/* 本次等级是否为新等级 (r != 最后已上报; 电压码不参与通道锁; 温度单独比较) */
uint8_t alarm_lock_has_new(uint8_t ch, ThresholdResult_t r, TempStatus_t ts);

/* 记录最后已上报等级 (r 为电压码时不更新 last_r; last_t 总是更新) */
void    alarm_lock_latch(uint8_t ch, ThresholdResult_t r, TempStatus_t ts);

/* 恢复去抖: 离线/异常 → 计数归零; 在线全正常 → 计数;
 * 连续 ALARM_LOCK_CLEAR_COUNT 次且该通道有锁 → 清锁并返回 1 (调用方报恢复) */
uint8_t alarm_lock_feed_normal(uint8_t ch, uint8_t online,
                               ThresholdResult_t r, TempStatus_t ts);

/* 电压锁: 独立 1 bit + 独立 3 次恢复计数; 仅真正做电压判定的路径更新 */
uint8_t alarm_lock_volt_has_new(ThresholdResult_t r);
void    alarm_lock_volt_latch(void);
uint8_t alarm_lock_volt_feed_normal(ThresholdResult_t r, uint8_t voltage_checked);

/* 查询: 是否有任何锁 / 某通道是否锁存 */
uint8_t alarm_lock_any(void);
uint8_t alarm_lock_ch_latched(uint8_t ch);

/* 持久化: force=1 立即写; force=0 受 5 分钟节流 (dirty 保留到下次) */
void    alarm_lock_save(uint8_t force);

#endif /* ALARM_LOCK_H */

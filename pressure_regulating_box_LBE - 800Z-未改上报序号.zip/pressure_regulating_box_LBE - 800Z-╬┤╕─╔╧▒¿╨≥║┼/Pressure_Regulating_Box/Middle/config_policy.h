#ifndef CONFIG_POLICY_H
#define CONFIG_POLICY_H

#include <stdint.h>
#include "eeprom_config.h"

/* ==================== 配置策略/纯逻辑 (无EEPROM/串口依赖) ==================== */

/* dot pattern (24-hour bitmap) */
void window_dottime_clear(uint8_t *mask);
void window_dottime_set(uint8_t *mask, uint8_t hour);
uint8_t window_dottime_hit(const uint8_t *mask, uint8_t hour);
uint8_t window_dottime_first(const uint8_t *mask);
void window_dottime_from_str(const char *str, uint8_t *mask);
void window_dottime_to_str(const uint8_t *mask, char *buf, uint16_t buf_size);

/* 周期类型 */
CycleType_t cycle_type_from_str(const char *str);
const char* cycle_type_to_str(CycleType_t type);
uint32_t cycle_to_seconds(const CycleConfig_t *cfg);

/* 周期值钳制: 保证 once*单位 <= 65535 分钟 (g_interval.*_min 为 uint16, 超限会回绕)
 * cycle_max_once 返回该单位允许的最大 once; cycle_clamp 就地修正并返回 1=发生过修正 */
uint32_t cycle_max_once(CycleType_t type);
uint8_t  cycle_clamp(CycleConfig_t *cfg);

/* ==================== 绝对时间轴 (跨天周期调度) ====================
 * 以 1999-12-27(周一) 为第 0 天:
 *   1 day  → 每天 00:00      N day → 每 N 天 00:00      1 week → 每周一 00:00
 * 用于采集/上报这类可能 >=1 天的周期 (旧实现按"当天秒数"取模, >=24h 的周期会退化) */
uint32_t sched_day_index(uint8_t year, uint8_t month, uint8_t day);
uint32_t sched_abs_min_of(uint8_t year, uint8_t month, uint8_t day,
                          uint8_t hour, uint8_t minute);
uint32_t sched_abs_min(void);      /* 当前绝对分钟 */
uint32_t sched_abs_sec(void);      /* 当前绝对秒 */

/* 异常关阀策略 */
AbnormalClose_t abnormal_from_str(const char *str);
const char* abnormal_to_str(AbnormalClose_t ac);
int abnormal_should_close_valve(AbnormalClose_t policy, ThresholdResult_t result);

/* 窗口/采集决策 */
int config_is_active_window(void);
int config_is_active_window_at(uint32_t hhmmss);
uint8_t config_need_adc_sampling(void);

#endif /* CONFIG_POLICY_H */

#ifndef MAIN_H
#define MAIN_H

#include "stdint.h"
#include "PT_304_35.h"
#include "ota_info.h"
#include "threshold.h"
#include "alarm_lock.h"

/* 优化key值、上报形式、4G数据获取 */
#define APP_FW_VERSION_NUM     2

/* ==================== State Machine ==================== */
typedef enum {
    STATE_INIT = 0,
    STATE_SLEEP,
    STATE_WAKEUP,
    STATE_COLLECT,
    STATE_UPLOAD,
    STATE_DOWNLINK,
    STATE_ALARM,
    STATE_BLE_OTA,
    STATE_CH4
} AppState_t;

extern AppState_t app_state;

/* CH4 request flag (set by downlink gas_get, checked by do_downlink) */
extern volatile uint8_t g_ch4_request;
extern uint8_t g_alarm_recover_reported; /* 报警关阀恢复"已上报一次"标志 (RAM) */
typedef struct {
    PT304D_Data raw;
    PT304D_Data raw2;
    float       voltage;
    float       last_pressure_collect;
    float       last_pressure_realtime;
    float       last_pressure_collect2;
    float       last_pressure_realtime2;
    float       last_normal_voltage;
    uint8_t     prev_online;
    uint8_t     offline_cnt;
    uint8_t     online_cnt;
    uint8_t     prev_online2;
    uint8_t     offline_cnt2;
    uint8_t     online_cnt2;
} SensorContext_t;

extern SensorContext_t g_sensor;
extern uint8_t g_lcd_active;   // LCD当前是否显示 (运行状态, 区别于配置项; main.c 维护)

// 供其他模块使用 (main.c 实现, downlink.c 等模块调用)
void lcd_shutdown(void);

const char* alarm_try_close_valve_all(const char *policy_str, ThresholdResult_t result);

const char* alarm_try_close_valve(ThresholdResult_t result);
const char* alarm_try_close_valve2(ThresholdResult_t result);   /* 出气端 (abnormal2_close) */
const char* ch4_alarm_try_close_valve(void);
void upload_schedule_reset(void);   /* 上报周期/后延配置变更后调用, 重置延迟上报锁存 */

/* ==================== 告警锁: 三条路径共用接口 (main.c 实现) ==================== */
/* 新等级掩码 bit 定义 */
#define ALARM_NEW_CH0   0x01   /* 通道0(进气端) 等级变化 */
#define ALARM_NEW_CH1   0x02   /* 通道1(出气端) 等级变化 */
#define ALARM_NEW_VOLT  0x04   /* 电压锁新告警 */

/* 确认/上报上下文 */
typedef struct {
    ThresholdResult_t r1;
    ThresholdResult_t r2;
    uint8_t online1;         /* 通道0 在线 */
    uint8_t online2;         /* 通道1 在线 */
    uint8_t conn_mode;       /* 0=仅 EnsureConnected(查询路径, 4G已在线); 1=fourG_ensure_ready/restore(主路径) */
    uint8_t sync_user_mqtt;  /* 1=报警后同步用户端MQTT(实时/采集既有行为) */
} AlarmReportCtx_t;

/* 新等级掩码 (bit0/1=通道, bit2=电压; 与 alarm_lock 的锁状态比较; check_voltage 门控电压位) */
uint8_t alarm_new_mask(ThresholdResult_t r1, ThresholdResult_t r2, uint8_t check_voltage);

/* 突变基线更新: 在线通道写当前值, 离线通道写 -1.0f (跳过突变判定) */
void sensor_baseline_update_collect(void);    /* last_pressure_collect / collect2 */
void sensor_baseline_update_realtime(void);   /* last_pressure_realtime / realtime2 */

/* 确认异常后的统一动作: 锁存新等级 → 关阀(不依赖4G) → 上报(批量/电压/阀门);
 * 返回: 1=已上报, 0=无新等级跳过 */
uint8_t alarm_confirm_and_report(const AlarmReportCtx_t *ctx, uint8_t mask,
                                 float last_p1, float last_p2);

#endif

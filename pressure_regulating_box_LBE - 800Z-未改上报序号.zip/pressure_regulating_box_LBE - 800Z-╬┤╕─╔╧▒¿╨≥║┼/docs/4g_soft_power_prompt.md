# 任务提示词：4G 常供电 + PWRKEY 软开关机（pressure_regulating_box_LBE）

> 适用工程：`F:\GD32_library\t-y-x\pressure_regulating_box_LBE`
> 目标：PB5(V4G_EN) 常高、4G 模块常供电；用 PA4(PWRKEY) 实现软开关机，逻辑与 24V 工程一致。
> 约束：**不要改其他引脚**；保留 CH4、OTA、LCD、BLE、历史上报等现有功能；先读代码再动手。

## 0. 最终引脚/电平定义

| 信号 | 引脚 | 有效电平 | 深睡保持 | 备注 |
|---|---|---|---|---|
| V4G_EN（TPS61023 EN） | **PB5** | **HIGH=供电**，要求常高 | **推挽输出高** | 运行期间不再拉低 |
| 4G PWRKEY（Q21 基极） | **PA4** | **HIGH=按下**（NPN 导通拉低 PWRKEY）；**LOW=释放** | **推挽输出低** | 板上 Rg2 47K 基极下拉 |
| 4G_DTR | PA0 | HIGH=允许模块轻睡 | 4G 在线时输出高 | 深睡后需重新配置 |

PA4 在 LBE 里目前只出现在深睡 Analog 列表（`BSP/mygpio.c:90`），没有其他功能占用。

## 1. 现状与冲突（LBE 当前代码）

1. `Drivers/ec800e.h:20-21`：
   ```c
   #define EC_PWRKEY_PORT  GPIOB
   #define EC_PWRKEY_PIN   GPIO_PIN_5
   ```
   PWRKEY 与 V4G_EN 是同一个脚，必须改成 PA4。

2. `BSP/power.c:14-40`：
   - `power_gpio_init()` 只把 PB5 配成输出，ODR 复位为 0 → 默认断电；
   - `power_4g_set()` 直接置/清 PB5；
   - `power_4g_is_on()` 直接读 PB5。
   PB5 常高后 `power_4g_is_on()` **恒为 1**，所有基于它的判断都会失效。

3. `BSP/mygpio.c:90`：深睡时 PA4 被转成 Analog，PA0 也无条件转 Analog。PA4 必须保持输出低；PA0 只在 4G 未保持在线时转 Analog。

4. `Drivers/ec800e.c:176-186`：`EC801E_PowerOn/Off` 只是置/清 PB5，没有 PWRKEY 脉冲、没有状态探测。

5. `main.c` 的调用点：
   - `303` `sys_init`：按窗口条件拉高 PB5；
   - `322` `lcd_update_csq`：先 `PowerOn`；
   - `350` `fourG_ensure_ready`：`was_online = power_4g_is_on()`；
   - `365`：冷启动单独 `PowerOn`；
   - `408` `fourG_drain_before_power_off`：用 `power_4g_is_on()` 做守卫；
   - `1189` / `1968`：用 `power_4g_is_on()` 判断；
   - `1219/1227/1232` `do_sleep`：`power_4g_set(0)` 拉低 PB5；
   - `1685` `do_wakeup`：条件拉高 PB5；
   - `1823/1853/2586/3009/3150`：`InitAndConnect()` 之前多余的 `PowerOn()`。

## 2. 24V 工程的软开关机逻辑（需要照搬的部分）

| 项 | 规则 |
|---|---|
| 开机脉冲 | PWRKEY 按下 **≥500ms** → 释放 |
| 关机脉冲 | PWRKEY 按下 **≥650ms** → 释放 |
| 关机验证 | 等待 **2000ms** → DTR+AT 探测；失败重试 1 次 |
| 存活探测 | `com_lpuart_init()` → DTR 拉低 160ms → 最多 3 次 `AT`（单次 400ms 超时） |
| 探测缓存 | 3 秒内复用；**每次 PWRKEY 脉冲后清缓存** |
| `PowerOn` | 先探测：已运行则**不发脉冲**；否则发 500ms 脉冲 |
| `PowerOff` | 先探测：已关机则**不发脉冲**；否则发 650ms 脉冲并验证 |
| `InitAndConnect` | `PowerOff()` → 500ms → `PowerOn()` → 等启动横幅 `RDY`（最多 4s）→ `SetPSM(0)` |
| 休眠策略 | long 保持在线：`SetPSM(1)` + DTR 高；VLP/弱信号/short/dot：`PowerOff()` 软关机 |
| 深睡 | 不操作 PB5；PA4 保持输出低；PA0 按是否保持在线决定 |

**关键原因**：常供电下 MCU 复位后模块可能仍在运行；PWRKEY 脉冲的含义随模块状态而变（运行中 + ≥650ms = 关机；已关机 + ≥500ms = 开机），所以任何脉冲前必须先探测。

## 3. 实施步骤

### 3.1 BSP

**`BSP/power.h`**
- 保留 `PWR_4G_PORT/PIN = GPIOB/GPIO_PIN_5`（V4G_EN，注释改为"常高、模块常供电"）。
- 新增：
  ```c
  #define PWR_4G_KEY_PORT   GPIOA
  #define PWR_4G_KEY_PIN    GPIO_PIN_4
  ```
- 删除 `power_4g_set()` / `power_4g_is_on()` 声明。

**`BSP/power.c`**
- `power_gpio_init()`：
  - PA0 DTR 配输出并**置高**；
  - PB5 配输出并**置高**；
  - PA4 配输出并**置低**（PWRKEY 释放）。
- 删除 `power_4g_set()` / `power_4g_is_on()` 定义。
- `power_4g_dtr_set()` 每次调用重新配置 PA0 为推挽输出再置电平（深睡后该脚会变 Analog）。

**`BSP/mygpio.c` 的 `gpio_enter_low_power()`**
- 从 `gpioa_analog_pins` 移除 `GPIO_PIN_4`；
- 把 `GPIO_PIN_0` 从无条件 Analog 改为仅 `!lpuart_enabled` 时加入；
- 在函数末尾显式配置：
  ```c
  PB5 = 输出高;   /* V4G_EN 常供电 */
  PA4 = 输出低;   /* PWRKEY 释放, 不能悬空 */
  ```

### 3.2 Drivers

**`Drivers/ec800e.h`**
- 增加 `#include "power.h"`。
- `EC_PWRKEY_PORT/PIN` 改为 `PWR_4G_KEY_PORT/PIN`。
- 增加声明：
  ```c
  uint8_t EC801E_ProbeAlive(void);
  uint8_t EC801E_IsAlive(void);
  ```

**`Drivers/ec800e.c`**
- 增加常量：
  ```c
  #define EC_PWRKEY_ON_PULSE_MS      500u
  #define EC_PWRKEY_OFF_PULSE_MS     650u
  #define EC_POWEROFF_SETTLE_MS      2000u
  #define EC_PROBE_AT_TIMEOUT_MS     400u
  #define EC_PROBE_RETRY             3u
  #define EC_PROBE_FRESH_MS          3000u
  #define EC_BOOT_RDY_TIMEOUT_MS     4000u
  ```
- 增加状态缓存：`UNKNOWN / OFF / ON` + 时间戳。
- 实现 `ec_pwrkey_drive(on)`：PA4 推挽输出，高=按下。
- 实现 `EC801E_ProbeAlive()`：`com_lpuart_init()` → `power_4g_dtr_set(0)` → 160ms → 最多 3 次 `AT`。
- 实现 `ec_probe_fresh()`（3s 缓存）和 `EC801E_IsAlive()`。
- 实现 `ec_wait_boot_banner()`：`lpuart_wait_for("RDY", 4000)`。
- 重写 `EC801E_PowerOn()`：探测保护 → 500ms 脉冲 → 清缓存。
- 重写 `EC801E_PowerOff()`：探测保护 → 650ms 脉冲 → 2s → 探测验证，失败重试一次。
- `EC801E_InitAndConnect()`：
  - 保留 `PowerOff()` → 500ms → `PowerOn()`；
  - 开机后 `ec_wait_boot_banner(4000)`；
  - 再 `EC801E_SetPSM(0)`；
  - 删除固定 `trea_delay_ms(3000)`。

### 3.3 应用层 `main.c`

| 位置 | 改动 |
|---|---|
| `sys_init`（303 附近） | 删除条件 `power_4g_set(1)`；PB5 由 `power_gpio_init()` 常高 |
| `lcd_update_csq`（322） | 删除 `EC801E_PowerOn()`，只保留 `EC801E_Wakeup()` |
| `fourG_ensure_ready`（350/365） | `was_online = EC801E_IsAlive()`；冷启动删除单独 `PowerOn()` |
| `fourG_drain_before_power_off`（408） | 守卫改为 `if(!EC801E_IsAlive()) return;` |
| `fourG_restore`（423/443/473/499） | `PowerOff()` 保留（新语义自动生效）；注释"断电"改"软关机" |
| `do_sleep` RI 补读（1189） | `if(EC801E_IsAlive())` |
| `do_sleep` 电源策略（1219/1227/1232） | `power_4g_set(0)` → `EC801E_PowerOff()`；long 保持在线分支加 `power_4g_dtr_set(1)` |
| `do_wakeup`（1685） | 删除 PB5 恢复供电条件 |
| `do_wakeup` 末尾（1968） | `if(EC801E_IsAlive()) ri_exti_init();` |
| `realtime_enter_sleep` | 4G 保持在线时加 `power_4g_dtr_set(1)`，避免唤醒后 DTR 一直低 |
| 按钮 1823/1853、上传 2586、调试 3009、初始化 3150 | 删除 `InitAndConnect()` 之前多余的 `PowerOn()` |
| `ch4_alarm.c:111` | `PowerOff()` 保留（新语义） |

### 3.4 文档

更新 `docs/引脚使用情况说明.md`：
- PA4：4G PWRKEY，输出，默认 LOW（释放），深睡保持输出低；
- PB5：V4G_EN，输出，默认 HIGH（常供电），深睡保持输出高；
- 删除"PB5 默认 LOW / 4G 默认断电"的旧描述。

## 4. 必须避开的坑

1. `power_4g_is_on()` 在 PB5 常高后恒为 1，必须全部替换为 `EC801E_IsAlive()`；否则冷启动分支永远不执行。
2. 深睡不能把 PB5/PA4 转 Analog；PA4 必须输出低，PB5 必须输出高。
3. `PowerOff()` 现在是阻塞操作（最长约 3.5s），冷启动还会等 `RDY`（≤4s）；检查看门狗（180s）和调用路径时序。
4. 脉冲前必须探测；对运行中的模块发 500ms 脉冲会被当成关机，对关机模块发 650ms 会被当成开机。
5. 探测缓存 3s；每次脉冲后必须清缓存。
6. 模块挂死且 AT 无响应时，探测会判为"已关机"，无法用 PWRKEY 硬复位。这是常供电方案的固有风险；如需保底，可在 `InitAndConnect` 中无条件先发 650ms（关机）再发 500ms（开机）。
7. PB5 仍直接驱动 TPS61023 EN：MCU 复位瞬间 ODR=0 会短暂拉低 EN，模块可能重启。固件只能在 `power_gpio_init()` 里尽快拉高；要根治需硬件上拉/常高。
8. 深睡静态电流会上升（模块常供电 + 软关机漏电），需要实测。

## 5. 验收测试

| # | 操作 | 期望 |
|---|---|---|
| 1 | 模块关机时冷启动 | `PowerOn` 发 500ms 脉冲 → `RDY` → 连上 MQTT |
| 2 | 模块在线时调用 `PowerOn` | 不发脉冲，直接返回 |
| 3 | 模块在线时调用 `PowerOff` | 650ms 脉冲 → 2s → AT 无响应 |
| 4 | 模块已关机时调用 `PowerOff` | 不发脉冲，立即返回 |
| 5 | MCU 复位后模块仍在运行 | 首次 `IsAlive` 判在线，不误发开机脉冲 |
| 6 | 深睡 | PB5=高、PA4=低、DTR 按在线状态 |
| 7 | long 模式保持在线 | PB5 高、PA4 低、DTR 高、QSCLK 生效 |
| 8 | short/dot 上报 | 临时软开机 → 上报 → 软关机 |
| 9 | VLP / 弱信号 | 软关机，PB5 不拉低 |
| 10 | 按钮 4 次短按/长按、调试 `4Gpower_on/off` | 正常软开关机 |
| 11 | 看门狗 | 软关机/冷启动全流程不复位 |
| 12 | 实测 | 深睡电流、关机电流、开机耗时、关机耗时 |

## 6. 构建

```bat
cd Pressure_Regulating_Box\Projects\Wakeup_box_V0.0.1\MDK-ARM
"D:\keil\core\UV4\UV4.exe" -b GD32L233R_EVAL.uvprojx -j0 -o build_4g_softpower.log
```

期望：`0 Error(s), 0 Warning(s)`。必须查看日志内容，不能只看退出码。

## 7. 交付

1. 修改后的源码（BSP/power、BSP/mygpio、Drivers/ec800e、main.c）；
2. 一段说明：引脚定义、软开关机时序、探测/缓存策略、休眠策略；
3. 明确列出风险点（复位窗口、静态电流、挂死模块无法硬复位、软关机耗时）。

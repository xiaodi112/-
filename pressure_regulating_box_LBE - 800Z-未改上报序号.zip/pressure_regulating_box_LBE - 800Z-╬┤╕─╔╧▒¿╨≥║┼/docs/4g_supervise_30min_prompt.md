# 任务提示词：不影响现有功能的前提下，保证 30 分钟一次掉线巡检

> 适用工程：`pressure_regulating_box_LBE - 800Z`（GD32L233RCT6 + Keil MDK）
> 源码根：`Pressure_Regulating_Box`；参考行号为当前工作区实测，以函数名为准。
> 本工程特点：4G **软关机**（PB5 常高、模块常供电，`EC801E_PowerOff()` 走 AT 软关机）、`LCD_LOCK_ENABLED=1`、`LASER_CH4_ENABLED=0`、无测漏任务。

---

## 0. 角色与约束

你是资深嵌入式工程师，在本工程上工作。分层：

- 应用层：`Projects/Wakeup_box_V0.0.1/main.c`
- 中间层：`Middle/`（`downlink.c`、`report.c`、`eeprom_config.c`…）
- 驱动/外设：`Drivers/`（EC801E）、`BSP/`、`App/`（valve、buzzer、lcd_ui、led）

硬性要求：

- 先读代码再动手；跟随现有命名/风格；**不使用动态内存**；**ISR 只置标志**；
- **不改协议字段名与反馈码**；
- 改完全量编译 0 Error / 0 Warning（第 6 节）；
- 本任务只做"巡检节奏保证"，**不重构睡眠状态机**。

---

## 1. 现状（巡检函数已有，问题只在"什么时候被调用"）

| 位置 | 现状 |
|---|---|
| `Middle/app_config.h:59` | `FOURG_SUPERVISE_INTERVAL_MIN 30` 已定义 |
| `main.c:3069` | `#if 1  /* 30分钟巡检临时屏蔽 (待现场验证后恢复) */` —— **值是 1，函数体参与编译**，注释文字是历史遗留 |
| `main.c:3074-3114` | `check_4g_connection_supervision()` 已实现（`#endif` 在 3115） |
| `main.c:3076` | 函数内 `static uint16_t s_last_supervise_min = 0xFFFF;` |
| `main.c:3081-3084` | 适用条件：`voltage_low_power / fourG_user_off / fourG_init_failed / fourG_weak_signal` 任一为真、或 `g_window.pattern != "long"`、或 `!(config_is_active_window() || g_window.end_result == 1)` → 直接 return |
| `main.c:3086-3087` | `now_min = (hh*60 + mm)`，来自 `rtc_get_hhmmss()` |
| `main.c:3089-3093` | `s_last_supervise_min == 0xFFFF` 时只记时间并 return（**上电后满 30 分钟才首次巡检**） |
| `main.c:3094-3097` | `< 30 min` 则 return；否则**先**更新时间戳再检查 |
| `main.c:3101-3102` | 检查前 `com_lpuart_init(); gpio_init();`（最小唤醒上下文恢复 AT 通道） |
| `main.c:3104-3113` | `EC801E_EnsureConnected()` 失败 → `EC801E_PowerOff(); fourG_init_failed = 1;`；成功 → `fourG_init_failed = 0; EC801E_SetPSM(1);` |
| `main.c:3381-3382` | 主循环里**唯一调用点**（`while(1)` 内、`switch(app_state)` 之前）。3381 行注释文字里带 "`#if 0`"，但那是注释，不是预处理指令 |
| `main.c:125-144` | `sched_set_next_collect_alarm()`：算 `wait_min`，`if(wait_min > 1440u) wait_min = 1440u;`（139），`tod = ...`，最后 **`rtc_set_alarm_at_hhmmss(...)`（141 行）** |
| `main.c:95-98` | `voltage_low_power`、`fourG_user_off`、`fourG_init_failed`、`fourG_weak_signal` |
| `main.c:1151-1461` | `do_sleep()`：4G 电源决策 1210-1227（全部走 `EC801E_PowerOff()` 软关机）；LCD 短睡 1229-1271；阀门定时 1278-1323；LPUART 臂 1326-1332 |
| `main.c:1229-1271` | `LCD_LOCK_ENABLED=1`，LCD 显示时先 `rtc_set_next_alarm_sec(remain)`（1246，remain ≤ 60 s）短睡；RTC 唤醒后 `lcd_shutdown()` 并**继续往下**走到调度器 |
| `main.c:1300` | 阀门分支条件 `valve_wait_sec < collect_sec`；1308 设秒级闹钟；1314-1322 的 `else` 才调用 `sched_set_next_collect_alarm()`（1319）或实时秒闹钟（1317） |
| `main.c:918-946` | `realtime_enter_sleep()`：`rtc_set_next_alarm_sec(g_real_frequency)`（924），范围 1-10 s |
| `main.c:952-968` | `do_realtime_check()`：`system_wakeup_reinit()`（961）→ `swdt_enable()`（965）→ `PT304D_CollectAll()`（968） |

### 1.1 实际缺口（为什么要改）

1. `check_4g_connection_supervision()` **只在 `main()` 主循环调用**。而：
   - 进入 `do_sleep()` 后，设备在 `enter_deepsleep_mode()` 里长期不返回 → 巡检停；
   - 实时模式（`g_real_enabled`）下主循环被 `do_sleep()` 内部的 RT 循环长期占住，主循环那行巡检要等实时模式结束才执行；
   - `sched_set_next_collect_alarm()` 可能把下一次唤醒算到 8 h/24 h 后，**中间没有唤醒点**去执行巡检；
   - 阀门定时动作走秒级闹钟（1308），可能比巡检到期更晚。
2. 结果：配 12h 上报 + 8h 采集这类稀疏计划时，实际巡检间隔可能是**数小时到十几小时**，不是 30 分钟。

### 1.2 本工程特有约束

- **4G 是软关机**：`BSP/power.h` 明确 PB5(V4G_EN) 常高、模块常供电；`do_sleep()` 用 `EC801E_PowerOff()`（AT 软关机），不是拉电源轨。**不要新增硬开关/电源轨逻辑**。
- `LASER_CH4_ENABLED = 0`：CH4 相关代码未编译，**不要新增 CH4 分支**。
- `LCD_LOCK_ENABLED = 1`：LCD 短睡分支参与编译，但 `remain ≤ 60 s`，不会把 30 分钟拖长；**保持原样**。
- 本工程**没有**测漏任务（无 `STATE_LEAK`）、**没有** LED 提示闹钟；不要新增。
- 唤醒源（不要改）：RTC 闹钟、LPUART 起始位唤醒、RI(PA1) 下降沿（一次性、自禁用）、PB11 按键、BLE PD2。

---

## 2. 目标

在**保持现有巡检判定逻辑、现有省电策略、现有报警/阀门优先级**不变的前提下：

1. 只要 `check_4g_connection_supervision()` 的适用条件成立，**相邻两次巡检间隔 ≤ 30 分钟**；
2. 不因巡检而延长睡眠、不因巡检而让 4G 保持在线、不抢占报警/阀门动作；
3. 不适用的场景（用户关 4G、初始化失败、弱信号、低压省电等）**行为与现在完全一致**。

> 精度说明：RTC 闹钟是分钟/秒粒度，`wait_min` 是整分钟，30 分钟是"≤30 分钟 + 1 分钟调度粒度"。

---

## 3. 实现方案（两处改动 + 一处清理）

### 3.1 把巡检时间基准提升到文件作用域，并新增到期计算

在 `sched_set_next_collect_alarm()`（125 行）**之前**加入（这样 125 行能直接用）：

```c
/* ---- 30 分钟网络巡检: 时间基准与到期计算 ---- */
static uint16_t s_last_supervise_min = 0xFFFF;

/* 与 check_4g_connection_supervision() 内原判定完全一致 */
static uint8_t supervise_is_applicable(void)
{
    if(voltage_low_power || fourG_user_off || fourG_init_failed || fourG_weak_signal)
        return 0;
    if(strcmp(g_window.pattern, "long") != 0)
        return 0;
    if(!(config_is_active_window() || g_window.end_result == 1))
        return 0;
    return 1;
}

static uint16_t supervise_now_min(void)
{
    uint32_t h = rtc_get_hhmmss();
    return (uint16_t)((h / 10000u) * 60u + (h / 100u) % 100u);
}

/* 距巡检到期还有多少分钟: 0=已到期, 0xFFFFFFFF=不适用
 * last==0xFFFF 表示还没记录过基准 → 首次巡检安排在 30 分钟后 */
static uint32_t supervise_wait_min(void)
{
    uint16_t now, elapsed;

    if(!supervise_is_applicable())
        return 0xFFFFFFFFu;
    if(s_last_supervise_min == 0xFFFFu)
        return FOURG_SUPERVISE_INTERVAL_MIN;

    now = supervise_now_min();
    /* 跨午夜修正: 直接相减在 now<last 时会得到巨大正数, 变成午夜后立刻巡检 */
    elapsed = (now >= s_last_supervise_min)
            ? (uint16_t)(now - s_last_supervise_min)
            : (uint16_t)(now + 1440u - s_last_supervise_min);

    if(elapsed >= FOURG_SUPERVISE_INTERVAL_MIN)
        return 0u;
    return (uint32_t)(FOURG_SUPERVISE_INTERVAL_MIN - elapsed);
}
```

### 3.2 调度器加"巡检到期夹紧"（核心）

在 `sched_set_next_collect_alarm()`（125 行）算出 `wait_min`、做过 `>1440` 夹取之后，**在** `tod = ...` **之前**插入：

```c
/* ---- 30 分钟网络巡检: 把下一次唤醒夹到巡检到期点 ---- */
{
    uint32_t sv_wait = supervise_wait_min();   /* 0=已到期, 0xFFFFFFFF=不适用 */
    if(sv_wait < wait_min) wait_min = sv_wait;
    if(wait_min == 0u) wait_min = 1u;          /* 禁用 0 分钟闹钟, 避免立即重入 */
}
```

### 3.3 阀门秒级闹钟分支也要让巡检"更早叫醒"

`do_sleep()` 的阀门分支（1278-1323）在 `!g_real_enabled` 且阀门事件更早时用秒级闹钟，**不经过** `sched_set_next_collect_alarm()`。把 1300 行的条件改为：

```c
uint32_t sv_wait_min = supervise_wait_min();
uint32_t sv_sec = (sv_wait_min == 0xFFFFFFFFu) ? 0xFFFFFFFFu : (sv_wait_min * 60u);

if(valve_wait_sec < collect_sec && valve_wait_sec < 0xFFFFFFFFu &&
   (sv_sec == 0xFFFFFFFFu || valve_wait_sec <= sv_sec))
```

- 巡检比阀门更早（或同时）→ 走 `else` 分支（1314-1322），由调度夹紧生效；
- `sv_wait_min == 0` → `sv_sec == 0` → 阀门分支不成立 → 夹紧后 `wait_min=1`，1 分钟内醒来巡检；
- 阀门事件更早 → 仍走阀门秒级闹钟，**阀门最高优先级不变**。

### 3.4 实时窗口内也执行一次巡检

实时模式下主循环被 `do_sleep()` 的 RT 循环占住，且 924 行是 1-10 s 的秒级闹钟，不经过调度器。在 `do_realtime_check()` 的 `swdt_enable()`（965 行）之后、`PT304D_CollectAll()`（968 行）之前加一行：

```c
check_4g_connection_supervision();   /* 内部自带 30 分钟节流, 未到期立即返回 */
```

放在采集之前的原因：巡检内部会 `com_lpuart_init(); gpio_init();`，先恢复引脚再采集更符合现有"最小唤醒 → 完整初始化 → 采集"的顺序；`gpio_init()` 只配置模式、不写 4G 软关机状态。若实测发现实时采集中断，再改到 `PT304D_CollectAll()` 之后（两者都不影响判定逻辑）。

### 3.5 巡检函数自身清理（只对齐，不改判定）

`check_4g_connection_supervision()`（3074-3114）：

1. 删除函数内 `static uint16_t s_last_supervise_min = 0xFFFF;`（已提升到文件作用域，3.1）；
2. `now_min` 计算改用 `supervise_now_min()`；节流判断改用跨午夜修正后的 `elapsed`：
   ```c
   uint16_t elapsed;
   now_min = supervise_now_min();
   if(s_last_supervise_min == 0xFFFFu) { s_last_supervise_min = now_min; return; }
   elapsed = (now_min >= s_last_supervise_min)
           ? (uint16_t)(now_min - s_last_supervise_min)
           : (uint16_t)(now_min + 1440u - s_last_supervise_min);
   if(elapsed < FOURG_SUPERVISE_INTERVAL_MIN) return;
   s_last_supervise_min = now_min;
   ```
   注意保持原语义：**先更新时间戳，再尝试连接**（失败也不形成连续重试）。
3. 适用条件可以改为 `if(!supervise_is_applicable()) return;`，与原来完全等价（不要改变条件本身）；
4. **失败路径保持原样**：`EC801E_PowerOff(); fourG_init_failed = 1; return;`
   → 此后巡检暂停、`do_sleep()` 也不再保持 4G 在线，等下一次上报冷启动恢复。这是**现有省电策略，不要为了"继续 30 分钟重试"去清标志**。
5. **成功路径保持原样**：`fourG_init_failed = 0; EC801E_SetPSM(1);`
6. 把 3069 行 `#if 1 /* 30分钟巡检临时屏蔽 */` 的过期注释改成准确描述（如 `#if 1 /* 4G 连接主动巡检 (long 模式 + 窗口/end_result) */`）；3070-3073 的注释保留。

### 3.6 LCD 短睡分支（1229-1271）不要改

`remain` 最大 60 s，远小于 30 min；RTC 唤醒后会 `lcd_shutdown()` 并继续走到 1273 行之后的调度器。不需要在 LCD 分支里加巡检夹紧。

---

## 4. 必须避开的坑

1. **`wait_min` 夹到 0 会变成"立即重入"**：RTC 闹钟最小 1 分钟，必须 `if(wait_min==0u) wait_min=1u;`。
2. **只改 `sched_set_next_collect_alarm()` 不够**：阀门秒级闹钟（3.3）和实时模式（3.4）是两条独立路径，三处都要覆盖。
3. **不要用 tick/uptime 计 30 分钟**：深睡丢计数；必须用 RTC 的"当日分钟"做差，并处理跨午夜。
4. **不要把 `s_last_supervise_min` 留在函数内**：调度器需要读它来夹紧；提升到文件作用域后只保留一份。
5. **不要新增 4G 硬开关**：本工程 PB5 常高、模块常供电，关机是 `EC801E_PowerOff()` 软关机；巡检结束按原策略（`do_sleep` 1210-1227）处理。
6. **不要抢报警/阀门优先级**：阀门定时动作、真实报警、采集闹钟的顺序保持原样；巡检只把"下一次唤醒"提前。
7. **弱信号/关 4G/初始化失败/低压省电时不巡检**：沿用 `supervise_is_applicable()`，不要"为了巡检"绕过省电判断。
8. **巡检失败后不要强行 30 分钟重试**：现有逻辑置 `fourG_init_failed=1` 并软关机，这是有意设计；保持。
9. **不要动 LCD 短睡分支**（3.6）。
10. **不要新增 CH4 逻辑**：`LASER_CH4_ENABLED=0`。
11. **LPUART 唤醒臂（1326-1332）与 RI 一次性臂不要动**；巡检里的 `com_lpuart_init()` 是原有代码，保持。
12. **不要在 ISR 里调用巡检**（现有 ISR 只置 `counter0`/`ri_wakeup_flag`，保持）。
13. **`#if 1` 不是屏蔽**：不要因为注释里写"临时屏蔽"就把它改成 `#if 0`。

---

## 5. 验收测试

| # | 配置/操作 | 期望 |
|---|---|---|
| 1 | 上报 12h、采集 8h、long + 活动窗口（或 `end_result=1`） | 串口日志中 `[SM] 4G supervision` 约每 30 分钟出现一次；两次上报之间不再出现数小时空档 |
| 2 | long 窗口内实时模式（1-10 s） | 主循环被 RT 循环占住时，仍约每 30 分钟出现一次巡检 |
| 3 | `FOURG_SUPERVISE_INTERVAL_MIN` 临时改 5 分钟 | 巡检间隔随之约 5 分钟；测试后改回 30 |
| 4 | 设置上报间隔使 `sched_set_next_collect_alarm()` 的 `wait_min = 45` | 实际唤醒/巡检发生在 30 分钟内，而不是 45 分钟 |
| 5 | 阀门定时动作在 45 分钟后、巡检 5 分钟后到期 | 30 分钟内先唤醒巡检；阀门事件时刻照常执行，不丢不错 |
| 6 | LCD 正在显示、非实时模式（`LCD_LOCK_ENABLED=1`） | LCD 60 s 短睡不影响巡检时点；LCD 关闭后仍按调度唤醒巡检 |
| 7 | 用户关闭 4G（`fourG_user_off`）/ 低压省电 | 不做巡检，4G 软关机策略与改前一致 |
| 8 | 巡检时模组离线 | 尝试重连；失败后 `EC801E_PowerOff()` + `fourG_init_failed=1`，**巡检暂停**直到下一次上报冷启动（现有行为） |
| 9 | 跨午夜运行 | 午夜后不会因为 `now<last` 立刻多巡检一次 |
| 10 | 睡眠电流 | 巡检后 4G 按原策略软关机/入睡；平均电流与改前同一量级 |
| 11 | 定时阀门/报警回归 | 与改前完全一致（回归项） |
| 12 | 唤醒源回归 | RTC/LPUART/RI/按键/BLE 唤醒均正常；下行业务可用 |

---

## 6. 构建

```bat
cd /d "F:\GD32_library\t-y-x\pressure_regulating_box_LBE - 800Z\Pressure_Regulating_Box\Projects\Wakeup_box_V0.0.1\MDK-ARM"
"D:\keil\core\UV4\UV4.exe" -r GD32L233R_EVAL.uvprojx -j0 -o build_supervise30.log
```

期望：`0 Error(s), 0 Warning(s)`。**必须查看日志内容**，不能只看退出码。

---

## 7. 交付

1. 修改后的源码（`main.c` 为主；`app_config.h` 仅在需要时改注释）；
2. 说明：
   - 巡检适用条件（原样保留的语义）；
   - 30 分钟保证的三条路径：调度器夹紧、阀门秒级闹钟比较、实时窗口入口；
   - 与 LCD 短睡/阀门/报警/采集/上报闹钟的优先级关系；
   - 4G 软关机在巡检前后的状态变化；
   - 失败后暂停巡检的既有设计；
3. 明确列出未覆盖/已知限制：
   - 30 分钟是"最坏唤醒间隔"，实际巡检可能因适用条件不满足而不发生；
   - 深睡期间无法主动唤醒，只能靠上述闹钟夹紧保证唤醒点；
   - RTC 分钟粒度带来 ≤1 分钟的调度误差。

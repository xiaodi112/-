# 任务提示词：双路传感器"只插一路"时的存史/上报 + 离线通道只存哨兵、不参与判定

> 适用工程：`pressure_regulating_box_LBE - 800Z`（GD32L233RCT6 + Keil MDK）
> 源码根：`Pressure_Regulating_Box`；参考行号为当前工作区实测，以函数名为准。
> 本工程特点：`PT304D_DRV_4BYTE` 生效（7 字节驱动未编译）、`LASER_CH4_ENABLED=0`、`LCD_LOCK_ENABLED=1`、`APP_DEFAULT_SENSOR_COUNT=2`。

---

## 0. 角色与约束

你是资深嵌入式工程师，在本工程上工作。遵守现有分层：

- 应用层：`Pressure_Regulating_Box/Projects/Wakeup_box_V0.0.1/main.c`
- 中间层：`Pressure_Regulating_Box/Middle/`
- 驱动层：`Pressure_Regulating_Box/Drivers/`、`Pressure_Regulating_Box/BSP/`、`Pressure_Regulating_Box/App/`

硬性要求：

- 先读代码再动手；跟随现有命名/风格；**不使用动态内存**；**ISR 只置标志**；
- **不改协议字段名与反馈码**：6.6/6.8 → 31，6.7/6.9 → 30；
- 改完必须全量编译 0 Error / 0 Warning（命令见第 6 节）。

---

## 1. 现状（本工程已经有一部分守卫，别重复改，也别漏改）

### 1.1 已经正确、**不要动**的部分

| 能力 | 位置 | 说明 |
|---|---|---|
| 出气端阈值守卫 | `do_realtime_check()` 1036、1066、1099；`do_collect()` 2180；`do_alarm()` 2306；`downlink.c` 215/251 | `r2 = THRESHOLD_OK; if(g_sensor_count >= 2 && raw2.err == OK) ...`，这部分模式是对的 |
| 告警锁出气端守卫 | `alarm_new_mask()` 683-684；feed 调用 1044/2187 | 出气端温度状态已带 `g_sensor_count >= 2 && raw2.err == OK` |
| 统一报警动作 | `alarm_confirm_and_report(const AlarmReportCtx_t *ctx, mask, last_p1, last_p2)`（main.c:717-788） | 锁存新等级 → 按 `ctx.online1/online2` 关阀 → 上报；**注意 3 次重采在 caller 里**，不在该函数内 |
| 出气端关阀守卫 | 750-751 | `g_sensor_count >= 2 && ctx->online2` 才做 `alarm_try_close_valve2()` |
| 上报侧状态字段 | `Middle/report.c` 131-146、238-250 | 已按 `g_sensor_count >= 2` + `raw2.err` 输出 `pressure2-status/temp2-status=*-err` |
| 恢复报文 | `alarm_report_recovery()` 694-712 | 内部用 `publish_all_status()`，状态字段的 err 守卫由 report.c 完成 |

### 1.2 仍然缺失、本次要补的部分

1. **驱动不清值**：`Drivers/PT_304_35.c` 的 `pt304d_4b_read()`（117 行，当前唯一生效）与 `pt304d_7b_read()`（79 行，当前未编译）失败时只写 `p_data->err`，**不修改 `pressure/temperature`**；`PT304D_Collect()`（204 行）与 `PT304D_CollectAll()`（228 行）的 `SendMeasCmd` 失败分支也只置 `err`。
   → 开机以来从未读到 = `0.00`；读到过再掉线 = **最后一次成功的旧值一直被当真实值**。
2. **三处"进气端离线即整拍早退"**：
   - `do_realtime_check()` 1012/1022、`do_collect()` 2160/2166 都是 `if(!cur_online){ ...; return; }`（`cur_online` 只代表 `g_sensor.raw`）；
   - `downlink.c` `run_full_threshold_check()` 195-199 是 `if(g_sensor.raw.err != PT304D_OK) return 0;`。
   → **只插出气端（raw2）时，采集/入库/网格上报/查询安全检查全部停摆**。
3. **`cur_online2` 缺少机型守卫**：982 / 2135 是 `(g_sensor.raw2.err == PT304D_OK)`，单路配置下 `raw2` 从未被采集、`.err` 初值为 0，会被当成"在线"。
4. **进气端阈值没有守卫**：1034、1064、1097、2178、2304 以及 `downlink.c` 212/248 都是直接 `threshold_check(g_sensor.raw...)`。
   现在靠"raw 离线就早退"挡着；一旦改成双路，必须逐通道守卫，否则离线通道的旧值会参与阈值/突变判定。
5. **`alarm_new_mask()` 的 ts1 没守卫**（682）：`threshold_get_temp_status(g_sensor.raw.temperature)` 无条件算。raw 离线时旧温度可能让 `alarm_lock_has_new(0, ...)` 误判"有新等级"。
6. **突变基线大量无条件赋值**：
   - main.c：1014/1015、1070/1071、1085/1086、1114/1115、1145/1146（实时）、2275/2276（周期采集）、2372/2373（报警路径）、3245-3248（上电）
   - downlink.c `run_full_threshold_check()`：225/226（正常出口）、235/236（去重跳过）、288/289（统一出口）
   → 离线时基线被写成旧值，恢复首拍**必然误报"压力突变"**。
7. **6.6~6.9 没有按通道门禁**：
   `h_sensor_read`（530）、`h_temp_status`（986）、`h_temp_status2`（1111）、`h_get_pressure2`（1141）都直接用 `g_sensor.raw/raw2` 算状态；后两个只判 `g_sensor_count < 2`，**不判 `raw2.err`** → 离线通道会回一个"看起来正常"的状态和旧值。
8. **上电首采两路都离线时仍写历史**：`main()` 3242 的 `ee_hist_push()`；且 3245-3248 的四个基线无条件赋值。

### 1.3 本工程特有约束

- `LASER_CH4_ENABLED = 0`：CH4 相关代码未编译，**不要新增 CH4 分支**，也不要为了 CH4 改双路逻辑。
- 本工程**没有**测漏任务（无 `STATE_LEAK`）。
- `LCD_LOCK_ENABLED = 1`、`APP_DEFAULT_LCD_ENABLED = 1`：LCD 是受控显示，采集后刷新/翻页逻辑保持原样，不要动。
- 双路配置：`APP_DEFAULT_SENSOR_COUNT = 2`；单路机型仍需能编译、能正确回"通道 2 无效"。

---

## 2. 目标行为

### 2.1 哨兵值

| 无效读数 | 存史/上报数值 |
|---|---|
| 压力 | **-1000 Pa** |
| 温度 | **-50 ℃** |

常量只定义一次（`Drivers/PT_304_35.h`）：`PT304D_INVALID_PRESSURE_PA (-1000.0f)`、`PT304D_INVALID_TEMP_C (-50.0f)`。
哨兵只承担"可辨识"职责（历史记录报文没有状态字段），**绝不参与判定**。

### 2.2 分场景行为

| 场景 | 存历史 | 网格上报 | 阈值/报警/关阀 | 6.6~6.9 取数 |
|---|---|---|---|---|
| 两路都在线 | 正常 | 正常 | 双路判定 | 正常应答 |
| 仅进气端（raw）在线 | 正常，raw2 存哨兵 | 正常 | 仅 raw 判定 | 6.8/6.9 回"err+哨兵+反馈码" |
| 仅出气端（raw2）在线 | 正常，raw 存哨兵 | **正常（修复当前停摆）** | 仅 raw2 判定 | 6.6/6.7 回"err+哨兵+反馈码" |
| 两路都离线 | **不写** | **不上报** | 不判 | 四条全拦（err+哨兵+反馈码） |

- 通道对应关系（不要搞反）：`g_sensor.raw` = 进气端 S2（IIC1/PD4/PD5，满量程 600 kPa）；`g_sensor.raw2` = 出气端 S1（IIC2/PC0/PC1，满量程 40 kPa）。
- 离线通道"四不"：不判阈值、不报警/不关阀、不参与告警锁去重与恢复、不参与突变基线。
- 状态字段一律 `*-err`；数值字段用哨兵。
- 两路都离线时：**上电/复位的身份+汇总报文照常发**；周期采集、历史入库、网格上报跳过。
- 单路机型（`g_sensor_count < 2`）：`raw2`/出气端恒按无效处理。

---

## 3. 实现方案（只补 1.2 的八处）

### 3.1 驱动层 `Drivers/PT_304_35.c`

1. `PT_304_35.h` 增加两个哨兵宏（见 2.1）。
2. 新增文件内静态函数（**放在所有 `#ifdef PT304D_DRV_*` 分支之外**，两种协议共用）：

   ```c
   static void pt304d_mark_invalid(PT304D_Data *p_data)
   {
       if(!p_data) return;
       p_data->stat_raw    = 0;
       p_data->press_raw   = 0;
       p_data->temp_raw    = 0;
       p_data->pressure    = PT304D_INVALID_PRESSURE_PA;
       p_data->temperature = PT304D_INVALID_TEMP_C;
   }
   ```

3. 在 `pt304d_4b_read()`（117 行）与 `pt304d_7b_read()`（79 行）的**入口**先调用它，成功时再覆盖；
   `PT304D_Collect()`（204 行，`SendMeasCmd` 失败分支）与 `PT304D_CollectAll()`（228 行，两个 `else` 分支）也要 `mark_invalid + err`。
4. 本工程当前没有 `pt304d_read_channels()`；不要按别的工程的名字找。

### 3.2 三处早退改成"两路都离线才早退"

`do_realtime_check()`（980-1028）与 `do_collect()`（2133-2175）：

```c
uint8_t cur_online  = (g_sensor.raw.err == PT304D_OK) ? 1 : 0;
uint8_t cur_online2 = (g_sensor_count >= 2 && g_sensor.raw2.err == PT304D_OK) ? 1 : 0;  /* 补 count 条件 */
...
/* 两路都离线才停止采集/上报 */
if(!cur_online && !cur_online2) { ...原早退逻辑...; return; }
```

- 两处都要改：`state_changed` 内（1012/2160）与 `else if` 连离线（1022/2166）；
- 早退分支的恢复计数处理不同，注意别漏：
  - 实时路径（1017、1025）已有 `alarm_lock_feed_normal(0, 0, ...)`，后面补一行 `alarm_lock_feed_normal(1, 0, THRESHOLD_OK, TEMP_NORMAL);`
  - 周期采集路径（2160-2164）**没有** feed 调用（正常 feed 在 2192 之后），早退前要补 `alarm_lock_feed_normal(0, 0, ...)` 和 `alarm_lock_feed_normal(1, 0, ...)` 两行；
- 状态变化上报（`report_publish_sensor_status()`）保持原样。

`downlink.c` 的 `run_full_threshold_check()`（184）：

```c
uint8_t online1 = (g_sensor.raw.err == PT304D_OK);
uint8_t online2 = (g_sensor_count >= 2 && g_sensor.raw2.err == PT304D_OK);
if(!online1 && !online2)
{
    printf_debug("[SM] QUERY CHK: both sensors offline, skip threshold check\r\n");
    return 0;
}
```

### 3.3 逐通道阈值/温度守卫

1. 把所有 `threshold_check(g_sensor.raw...)` 改成：

   ```c
   r1 = (g_sensor.raw.err == PT304D_OK)
      ? threshold_check(g_sensor.raw.pressure, g_sensor.raw.temperature,
                        g_sensor.voltage, g_sensor.last_pressure_xxx, ...)
      : THRESHOLD_OK;
   ```

   位置：1034、1064、1097、2178、2304；`downlink.c` 212、248。
   ⚠️ 实时路径的电压占位 `-1.0f` / `check_voltage=0` / `skip_mutation` 参数**保持原样**，只加条件。

2. `alarm_new_mask()`（682）：

   ```c
   TempStatus_t ts1 = (g_sensor.raw.err == PT304D_OK)
                    ? threshold_get_temp_status(g_sensor.raw.temperature) : TEMP_NORMAL;
   ```

3. feed 处的 `ts1`（1045、2188）同样加 `online1` 守卫（不判离线通道温度）。

4. 重采循环（1092-1109、2297-2320、downlink 243-266）里的 `r1/r2` 逐拍按在线守卫。
   离线通道按 `THRESHOLD_OK` 处理，"是否恢复"只看 `result == THRESHOLD_OK`，**不要再用 `sensor_err`（只反映 raw）去阻止恢复判断**；`sensor_err` 若要保留，仅用于报警类型文本/上报字段，且语义改为"该通道离线"，不要让它把单路离线升级成整机报警。

### 3.4 main.c 的突变基线

新增两个助手（放在 `alarm_new_mask()` 之后、`Middle/main.h` 导出；命名可自定）：

```c
void sensor_baseline_update_collect(void)   /* last_pressure_collect / collect2 */
{
    g_sensor.last_pressure_collect  = (g_sensor.raw.err == PT304D_OK) ? g_sensor.raw.pressure : -1.0f;
    g_sensor.last_pressure_collect2 = (g_sensor_count >= 2 && g_sensor.raw2.err == PT304D_OK)
                                    ? g_sensor.raw2.pressure : -1.0f;
}
void sensor_baseline_update_realtime(void)  /* last_pressure_realtime / realtime2 */
{ /* 同上, 用 realtime 字段 */ }
```

替换 1.2 第 6 条列出的 main.c 各对直接赋值（含上电 3245-3248）。
⚠️ `alarm_confirm_and_report()` 内部会重采/刷新 `g_sensor.raw/raw2` 再上报，**基线更新必须在它返回之后**（现有调用顺序就是这样，不要调整）。

### 3.5 downlink.c 的基线（`run_full_threshold_check()`）

1. 入口快照（202-203）按通道取：

   ```c
   prev_p1 = (g_sensor.raw.err == PT304D_OK) ? g_sensor.last_pressure_collect : -1.0f;
   prev_p2 = (g_sensor_count >= 2 && g_sensor.raw2.err == PT304D_OK)
           ? g_sensor.last_pressure_collect2 : -1.0f;
   ```

2. 三个基线更新点（225/226、235/236、288/289）统一改成按通道写：在线 → 当前值；离线 → `-1.0f`。
3. 两路都离线时，早退前也要把两个基线置 `-1.0f`（否则恢复首拍仍会假突变）。

### 3.6 取数指令按通道门禁（`Middle/downlink.c`，当前没有）

在 `downlink.c` 增加两个小助手：

```c
static uint8_t sensor_ch_offline(uint8_t ch)
{
    if(ch == 0) return (g_sensor.raw.err != PT304D_OK);
    return (g_sensor_count < 2 || g_sensor.raw2.err != PT304D_OK);
}
```

并在 4 个 handler 的 `collect_all_sensors()` 之后、算状态之前分支。
**离线分支要保持该指令原有字段集合**，数值用哨兵、状态用 `*-err`、反馈码不变：

| 指令 / CmdMap | handler | 通道 | 离线应答 | 反馈码 |
|---|---|---|---|---|
| 6.6 `temp-get1` | `h_temp_status`(986) | raw | `temp-status=temp-err` + `temp=-50.00` | 31 |
| 6.7 `get-pressure`/`get-pressure1`/`sensor_read` | `h_sensor_read`(530) | raw | `pressure-status=pressure-err`（数值由 `EC801E_PublishSensorData` 携带哨兵） | 30 |
| 6.8 `temp-get2` | `h_temp_status2`(1111) | raw2 | `temp2-status=temp2-err` + `temp2=-50.00` | 31 |
| 6.9 `get-pressure2` | `h_get_pressure2`(1141) | raw2 | `pressure2-status=pressure2-err` + `pressure2=-1000.00` + `temp2=-50.00` | 30 |

- `h_sensor_read` 的离线分支仍要 `report_publish_sensor_status()`（把"离线"事实报出去）；
- 离线分支末尾仍调用 `run_full_threshold_check()`（内部会跳过离线通道、只判在线通道）；
- 有效通道照常走原逻辑；不要改 `CmdMap` / 分发表 / 反馈码。
- 单路机型（`g_sensor_count < 2`）对 6.8/6.9 也回哨兵而不是 0（现有代码回 `0.0f`，与"无效值不用 0"冲突）。

### 3.7 上电首采（`main()` 3234-3248）

1. `init_record` 的两个通道字段用哨兵填充（离线通道）；
2. 两路都离线时**不 `ee_hist_push()`**；
3. 3245-3248 的四个基线改用两个助手；
4. 身份/汇总报文照发，`prev_online/prev_online2` 的既有初始化保持原样。

---

## 4. 必须避开的坑

1. **哨兵绝不能进 `threshold_check*` / `threshold_get_pressure_status*` / `threshold_get_temp_status*`**（后者带滞回副作用）。
2. **基线**：离线置 `-1.0f`（不是 0、不是哨兵）；`threshold_check` 对 `last < 0` 跳过突变判定。
3. **不要改已经正确的部分**（1.1 表）：出气端 `r2` 守卫、`alarm_new_mask` 的 ch1 守卫、`alarm_confirm_and_report`、`report.c` 的 `*-err` 输出。
4. **不要动 LCD**：`LCD_LOCK_ENABLED=1`，`lcd_ui_refresh/next_page` 的调用位置与条件保持原样。
5. **不要新增 CH4 逻辑**：`LASER_CH4_ENABLED=0`。
6. **两路都离线时不写历史**（含上电首采），避免哨兵记录挤占环形区。
7. 不用 0 代替哨兵（4 字节协议里 `p_raw <= PT304D_4B_ZERO_ADC` 会产出真实 `0.0f`，与"无效"无法区分）。
8. **不要用 `sensor_err` 把单路离线当成整机报警**：告警锁/关阀都按 `ctx.online1/online2` 逐通道判断。
9. `zero_cal`：已有 err 检查 + 大气窗口，安全，不用改。

---

## 5. 验收测试

| # | 操作 | 期望 |
|---|---|---|
| 1 | 双路都插，正常运行 | 与改前完全一致 |
| 2 | 只插进气端，拔掉出气端 | 采集/存史/网格上报照常；`pressure2/temp2=-1000.00/-50.00`、`pressure2-status/temp2-status=*-err`；6.8/6.9 回"err+哨兵+反馈码"；不产生通道 2 报警/关阀 |
| 3 | 只插出气端，拔掉进气端 | 采集/存史/上报照常（修复当前停摆）；`pressure/temp=-1000.00/-50.00` + `pressure-status/temp-status=*-err`；6.6/6.7 回"err+哨兵+反馈码" |
| 4 | 两路都拔 | 不采集、不写历史、不上报；rtu/传感器状态反映离线；上电身份/汇总报文仍能发 |
| 5 | 通道掉线后再插回 | 第一拍**不得**报"压力突变"；恢复计数正常累积 |
| 6 | 单路在线时触发报警 | 报警批量中离线通道数值哨兵 + 状态 err；关阀只按在线通道策略判定（`ctx.online1/online2` 不变） |
| 7 | `APP_DEFAULT_SENSOR_COUNT=1` 编译 | 只评估通道 1；通道 2 恒无效；6.8/6.9 回 err+哨兵+反馈码 |
| 8 | 查询路径（6.6~6.9 连发） | 每条都先回自己的字段+反馈码，再追加安全检查；离线通道不参与重采/关阀；一轮轮询不会凑满恢复计数 |
| 9 | LCD 显示 | `lcd_ui_refresh`/翻页行为与改前一致（回归项） |

---

## 6. 构建

```bat
cd /d "F:\GD32_library\t-y-x\pressure_regulating_box_LBE - 800Z\Pressure_Regulating_Box\Projects\Wakeup_box_V0.0.1\MDK-ARM"
"D:\keil\core\UV4\UV4.exe" -r GD32L233R_EVAL.uvprojx -j0 -o build_sensor_offline.log
```

期望：`0 Error(s), 0 Warning(s)`。**必须查看日志内容**，不能只看退出码。

---

## 7. 交付

1. 修改后的源码；
2. 说明：哨兵值定义位置、离线通道"四不"语义、各场景行为、查询应答格式、单路机型的处理；
3. 明确列出未覆盖/已知限制：
   - 历史记录报文没有状态字段，平台需按 `-1000/-50`（或 `<0`）过滤；
   - 平台按数值判断的报警规则应对 `*-status=*-err` 的通道忽略数值。
